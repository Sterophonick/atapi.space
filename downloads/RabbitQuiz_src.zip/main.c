int question = 0;
#include <agb_lib.h>
#include "images.h"
#include "gates.h"
#include "ding.C"
#include "fail.C"
#include "gamebeat.C"
int start=0;
int wait = 0;
int secswait = 0;
int wrong=0;
int right=0;
int win=0;
int begin=0;
int loop;

void playSound(int s) {
 REG_SOUNDCNT1_H = 0x0B04;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 REG_SOUNDCNT1_X = 0x0080;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 REG_SD1SAD      = (unsigned long) sound[s].song;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 REG_SD1DAD      = 0x040000A0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 REG_SD1CNT_H    = 0xB640;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 REG_TM0SD       = 65536-(16777216/sound[s].frequency);                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 REG_TMSDCNT     = 0x00C0;  
}

int main()
{
	Initialize();
	question = 0;
	setbg2((void*)titleData, (void*)titlePalette);
	FadeIn(2);
	while(!(keyDown(KEY_START)))
	{
		wait = 0;
	}
	FadeOut(2);
	setbg2((void*)oneData, (void*)onePalette);
	FadeIn(2);
	question=1;
	while(1) {
		initsound8(1, 22050, 2800, (void*)ding);
		initsound8(2, 22050, 2800, (void*)fail);
		initsound8(3, 22050, 2800, (void*)gamebeat);
		// question 1
		if(question==1) 
		{
			setbg2((void*)oneData, (void*)onePalette);
			if(keyDown(KEY_A))
			{
				wrong = 1;
			}
			if(keyDown(KEY_B))
			{
				right = 1;
			}
		}	
		// question 2
		if(question==2) 
		{
			setbg2((void*)twoData, (void*)twoPalette);
			if(keyDown(KEY_A))
			{
				right = 1;
			}
			if(keyDown(KEY_B))
			{
				wrong = 1;
			}
		}
		//question 3
		if(question==3) 
		{
			setbg2((void*)threeData, (void*)threePalette);
			if(keyDown(KEY_A))
			{
				wrong = 1;
			}
			if(keyDown(KEY_B))
			{
				right = 1;
			}
		}
		//question 4
		if(question==4) 
		{
			setbg2((void*)fourData, (void*)fourPalette);
			if(keyDown(KEY_A))
			{
				right = 1;
			}
			if(keyDown(KEY_B))
			{
				wrong = 1;
			}
		}
		//question 5
		if(question==5) 
		{
			setbg2((void*)fiveData, (void*)fivePalette);
			if(keyDown(KEY_A))
			{
				wrong = 1;
			}
			if(keyDown(KEY_B))
			{
				win=1;
			}
		}
		if(right==1)
		{
			FadeOut(2);
			playSound(1);
			setbg2((void*)correctData, (void*)correctPalette);	
			FadeIn(2);
			REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  			REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   			REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  			REG_TM0CNT    = 0;   
			while(!(keyDown(KEY_START)))
			{
				wait = 0;	
			}
			FadeOut(2);
			if(question==1) 
			{
				setbg2((void*)twoData, (void*)twoPalette);
			}	
			// question 2
			if(question==2) 
			{
				setbg2((void*)threeData, (void*)threePalette);
			}
			//question 3
			if(question==3) 
			{
				setbg2((void*)fourData, (void*)fourPalette);
			}
			//question 4
			if(question==4) 
			{
				setbg2((void*)fiveData, (void*)fivePalette);
			}
			FadeIn(2);
			right=0;
			question++;
		}
		if(wrong==1)
		{
			FadeOut(2);
			setbg2((void*)wrongData, (void*)wrongPalette);
			playSound(2);
			FadeIn(2);
			Sleep(699);
			REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  			REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   			REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  			REG_TM0CNT    = 0;   
			while(!(keyDown(KEY_START))){
				wait = 0;
			}
			FadeOut(2);
			wrong = 0;
			question = 1;
			setbg2((void*)oneData, (void*)onePalette);
			FadeIn(1);
		}
		if(win==1)
		{
			FadeOut(2);
			playSound(3);
			setbg2((void*)winData, (void*)winPalette);
			FadeIn(2);
			Sleep(510);
			REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  			REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   			REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  			REG_TM0CNT    = 0;
			while(1);
		}
	}
	return 0;
}

