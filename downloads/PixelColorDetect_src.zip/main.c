#include <agb_lib.h>

int main()
{
	SetMode(MODE_3|BG2_ENABLE);
	PlotPixel(16, 16, 0x57C0);
	if(GetPixelm3(16, 16)==0x57C0)
	{
		PlotPixel(30, 30, 0xFFFF);
	}
	while(1);
	return 0;
}

