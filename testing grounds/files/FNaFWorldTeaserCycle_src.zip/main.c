#include <agb_lib.h>
#include "data.h"

void setbg2vb(u16* image, u16* pal)
{
	WaitForVblank();
	REG_DM3SAD = (unsigned long)image;
	REG_DM3DAD = (unsigned long)VideoBuffer;
	REG_DM3CNT = 0x80000000 | 120*160;
	SetPalette(pal);
}

int main()
{
	Initialize();
	SetMode(MODE_4|BG2_ENABLE);
	REG_BG2CNT |= BG_MOSAIC_ENABLE;
	setbg2vb((void*)fw1Bitmap, (void*)fw1Palette);
	FadeIn(2);
	Sleep(255);
	while(1)
	{
		setbg2vb((void*)fw1Bitmap, (void*)fw1Palette);
		Sleep(255);
		setbg2vb((void*)fw2Bitmap, (void*)fw2Palette);
		Sleep(255);
		setbg2vb((void*)fw3Bitmap, (void*)fw3Palette);
		Sleep(255);
		setbg2vb((void*)fw4Bitmap, (void*)fw4Palette);
		Sleep(255);
		setbg2vb((void*)fw5Bitmap, (void*)fw5Palette);
		Sleep(255);
		setbg2vb((void*)fw6Bitmap, (void*)fw6Palette);
		Sleep(255);
		setbg2vb((void*)fw7Bitmap, (void*)fw7Palette);
		Sleep(255);
		setbg2vb((void*)fw8Bitmap, (void*)fw8Palette);
		Sleep(255);
		setbg2vb((void*)fw9Bitmap, (void*)fw9Palette);
		Sleep(255);
		setbg2vb((void*)fw10Bitmap, (void*)fw10Palette);
		Sleep(255);
		setbg2vb((void*)fw11Bitmap, (void*)fw11Palette);
		Sleep(255);
		setbg2vb((void*)fw12Bitmap, (void*)fw12Palette);
		Sleep(255);
		setbg2vb((void*)fw13Bitmap, (void*)fw13Palette);
		Sleep(255);
		setbg2vb((void*)fw14Bitmap, (void*)fw14Palette);
		Sleep(255);
		setbg2vb((void*)fw15Bitmap, (void*)fw15Palette);
		Sleep(255);
		setbg2vb((void*)fw16Bitmap, (void*)fw16Palette);
		Sleep(255);
		setbg2vb((void*)fw18Bitmap, (void*)fw18Palette);
		Sleep(255);
		setbg2vb((void*)fw19Bitmap, (void*)fw19Palette);
		Sleep(255);
		setbg2vb((void*)fw20Bitmap, (void*)fw20Palette);
		Sleep(255);
		setbg2vb((void*)fw21Bitmap, (void*)fw21Palette);
		Sleep(255);
		setbg2vb((void*)fw22Bitmap, (void*)fw22Palette);
		Sleep(255);
		setbg2vb((void*)fw23Bitmap, (void*)fw23Palette);
		Sleep(255);
		setbg2vb((void*)fw24Bitmap, (void*)fw24Palette);
		Sleep(255);
		setbg2vb((void*)fw25Bitmap, (void*)fw25Palette);
		Sleep(255);
		setbg2vb((void*)fw26Bitmap, (void*)fw26Palette);
		Sleep(255);
		setbg2vb((void*)fw27Bitmap, (void*)fw27Palette);
		Sleep(255);
		setbg2vb((void*)fw28Bitmap, (void*)fw28Palette);
		Sleep(255);
		setbg2vb((void*)fw30Bitmap, (void*)fw30Palette);
		Sleep(255);
		setbg2vb((void*)fw31Bitmap, (void*)fw31Palette);
		Sleep(255);
		setbg2vb((void*)fw32Bitmap, (void*)fw32Palette);
		Sleep(255);
		setbg2vb((void*)fw33Bitmap, (void*)fw33Palette);
		Sleep(255);
	}
	return 0;
}