
//{{BLOCK(sprites_pal)

//======================================================================
//
//	sprites_pal, 32x48@8, 
//	+ palette 256 entries, not compressed
//	Total size: 512 = 512
//
//	Time-stamp: 2017-07-20, 14:13:05
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITES_PAL_H
#define GRIT_SPRITES_PAL_H

#define sprites_palPalLen 512
extern const unsigned short sprites_palPal[256];

#endif // GRIT_SPRITES_PAL_H

//}}BLOCK(sprites_pal)
