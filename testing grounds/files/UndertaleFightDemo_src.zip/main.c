#include <mygba.h>
#include "gfx/pap.map.c"
#include "gfx/pap.raw.c"
#include "gfx/master.pal.c"
#include "gfx/sprites.h"

u8 newframe=0;
u8 frames=0;
u16 my_x=76;
u16 my_y=16;
u8 soulx=0;
u8 souly=0;
u8 g_SprObj;
int i;
u16* OBJPaletteMem 	=(u16*)0x5000200;


int main(void)
{
   ham_Init();
   map_fragment_info_ptr papyrus;
   ham_LoadBGPal(&master_Palette,sizeof(master_Palette));
   	ham_bg[1].ti = ham_InitTileSet(&pap_Tiles,SIZEOF_16BIT(pap_Tiles),1,1);
	// init an empty map
	ham_bg[1].mi = ham_InitMapEmptySet(3,0);

	// make a reference to Map data in the ROM
	papyrus = ham_InitMapFragment(&pap_Map,30,20,0,0,64,64,0);

	// copy (in this case the whole) map to BG1 at x=0 y=0
	ham_InsertMapFragment(papyrus,1,0,0);
	// and get it on screen
	ham_InitBg(1,1,2,0);
   ham_InitText(0);
       ham_SetTextCol(0x01,    // Set texts front color to the BG palette index specified
                   0x00);   // Set texts back color to the BG palette index specified
                   ham_DrawText(1, 15, "*Papyrus blocks the way!");
                   	   g_SprObj = ham_CreateObj((void*)&sprites,  // A pointer to the tile data for this object
                             0,                       // obj_shape
                             0,                       // obj_size
                             OBJ_MODE_NORMAL,         // obj_mode
                             0,                       // col_mode
                             0,                       // pal_no
                             0,                       // mosaic
                             0,                       // hflip
                             0,                       // vflip
                             0,                       // dbl_size
                             0,                       // prio
                             0,                // x position of sprite on screen
                             0);               // y position of sprite on screen
   for(i=0;i>256;i++)
    {
        OBJPaletteMem[i] = (u16*)spritesPalette[i];
    }
                             	ham_CopyObjToOAM();
      	
   while(TRUE)
   {
       
   }

   return 0;
}


/* END OF FILE */
