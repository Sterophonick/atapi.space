
void levels(){
	if(level==1)
	{
		memcpy(VRAM, (void*)l1Bitmap, 76800);
	}
	if(level==2)
	{
		memcpy(VRAM, (void*)l2Bitmap, 76800);
	}
	if(level==3)
	{
		memcpy(VRAM, (void*)l3Bitmap, 76800);
	}
	if(level==4)
	{
		memcpy(VRAM, (void*)l4Bitmap, 76800);
	}
	if(level==5)
	{
		memcpy(VRAM, (void*)l5Bitmap, 76800);
	}
	if(level==6)
	{
		memcpy(VRAM, (void*)l6Bitmap, 76800);
	}
	if(level==7)
	{
		memcpy(VRAM, (void*)l7Bitmap, 76800);
	}
	if(level==8)
	{
		memcpy(VRAM, (void*)l8Bitmap, 76800);
	}
	if(level==9)
	{
		memcpy(VRAM, (void*)l9Bitmap, 76800);
	}
	if(level==10)
	{
		memcpy(VRAM, (void*)l10Bitmap, 76800);
	}
	if(level==11)
	{
		memcpy(VRAM, (void*)l11Bitmap, 76800);
	}
	if(level==12)
	{
		memcpy(VRAM, (void*)l12Bitmap, 76800);
	}
	if(level==13)
	{
		memcpy(VRAM, (void*)l13Bitmap, 76800);
	}
	if(level==14)
	{
		memcpy(VRAM, (void*)l14Bitmap, 76800);
	}
	if(level==15)
	{
		memcpy(VRAM, (void*)l15Bitmap, 76800);
	}
	if(level==16)
	{
		memcpy(VRAM, (void*)l16Bitmap, 76800);
	}
	if(level==17)
	{
		memcpy(VRAM, (void*)l17Bitmap, 76800);
	}
	if(level==18)
	{
		memcpy(VRAM, (void*)l18Bitmap, 76800);
	}
	if(level==19)
	{
		memcpy(VRAM, (void*)l19Bitmap, 76800);
	}
	if(level==20)
	{
		memcpy(VRAM, (void*)l20Bitmap, 76800);
	}
	if(level==21)
	{
		memcpy(VRAM, (void*)l21Bitmap, 76800);
	}
	if(level==22)
	{
		memcpy(VRAM, (void*)l22Bitmap, 76800);
	}
	if(level==23)
	{
		memcpy(VRAM, (void*)l23Bitmap, 76800);
	}
	if(level==24)
	{
		memcpy(VRAM, (void*)l24Bitmap, 76800);
	}
	if(level==25)
	{
		memcpy(VRAM, (void*)l25Bitmap, 76800);
	}
	if(level==26)
	{
		memcpy(VRAM, (void*)l26Bitmap, 76800);
	}
	if(level==27)
	{
		memcpy(VRAM, (void*)l27Bitmap, 76800);
	}
	if(level==28)
	{
		memcpy(VRAM, (void*)l28Bitmap, 76800);
	}
	if(level==29)
	{
		memcpy(VRAM, (void*)l29Bitmap, 76800);
	}
	if(level==30)
	{
		memcpy(VRAM, (void*)l30Bitmap, 76800);
	}
	if(level==31)
	{
		memcpy(VRAM, (void*)l31Bitmap, 76800);
	}
	if(level==32)
	{
		memcpy(VRAM, (void*)l32Bitmap, 76800);
	}
	if(level==33)
	{
		memcpy(VRAM, (void*)l33Bitmap, 76800);
	}
	if(level==34)
	{
		memcpy(VRAM, (void*)l34Bitmap, 76800);
	}
	if(level==35)
	{
		memcpy(VRAM, (void*)l35Bitmap, 76800);
	}
	if(level==36)
	{
		memcpy(VRAM, (void*)l36Bitmap, 76800);
	}
	if(level==37)
	{
		memcpy(VRAM, (void*)l37Bitmap, 76800);
	}
	if(level==38)
	{
		memcpy(VRAM, (void*)l38Bitmap, 76800);
	}
	if(level==39)
	{
		memcpy(VRAM, (void*)l39Bitmap, 76800);
	}
	if(level==40)
	{
		memcpy(VRAM, (void*)l40Bitmap, 76800);
	}
	if(level==41)
	{
		memcpy(VRAM, (void*)l41Bitmap, 76800);
	}
	if(level==42)
	{
		memcpy(VRAM, (void*)l42Bitmap, 76800);
	}
	if(level==43)
	{
		memcpy(VRAM, (void*)l43Bitmap, 76800);
	}
	if(level==44)
	{
		memcpy(VRAM, (void*)l44Bitmap, 76800);
	}
	if(level==45)
	{
		memcpy(VRAM, (void*)l45Bitmap, 76800);
	}
	if(level==46)
	{
		memcpy(VRAM, (void*)l46Bitmap, 76800);
	}
	if(level==47)
	{
		memcpy(VRAM, (void*)l47Bitmap, 76800);
	}
	if(level==48)
	{
		memcpy(VRAM, (void*)l48Bitmap, 76800);
	}
	if(level==49)
	{
		memcpy(VRAM, (void*)l49Bitmap, 76800);
	}
	if(level==50)
	{
		memcpy(VRAM, (void*)l50Bitmap, 76800);
	}
	if(level==51)
	{
		memcpy(VRAM, (void*)l51Bitmap, 76800);
	}
	if(level==52)
	{
		memcpy(VRAM, (void*)l52Bitmap, 76800);
	}
	if(level==53)
	{
		memcpy(VRAM, (void*)l53Bitmap, 76800);
	}
	if(level==54)
	{
		memcpy(VRAM, (void*)l54Bitmap, 76800);
	}
	if(level==55)
	{
		memcpy(VRAM, (void*)l55Bitmap, 76800);
	}
	if(level==56)
	{
		memcpy(VRAM, (void*)l56Bitmap, 76800);
	}
	if(level==57)
	{
		memcpy(VRAM, (void*)l57Bitmap, 76800);
	}
	if(level==58)
	{
		memcpy(VRAM, (void*)l58Bitmap, 76800);
	}
	if(level==59)
	{
		memcpy(VRAM, (void*)l59Bitmap, 76800);
	}
	if(level==60)
	{
		memcpy(VRAM, (void*)l60Bitmap, 76800);
	}
	if(level==61)
	{
		memcpy(VRAM, (void*)l61Bitmap, 76800);
	}
	if(level==62)
	{
		memcpy(VRAM, (void*)l62Bitmap, 76800);
	}
	if(level==63)
	{
		memcpy(VRAM, (void*)l63Bitmap, 76800);
	}
	if(level==64)
	{
		memcpy(VRAM, (void*)l64Bitmap, 76800);
	}
	if(level==65)
	{
		memcpy(VRAM, (void*)l65Bitmap, 76800);
	}
	if(level==66)
	{
		memcpy(VRAM, (void*)l66Bitmap, 76800);
	}
	if(level==67)
	{
		memcpy(VRAM, (void*)l67Bitmap, 76800);
	}
	if(level==68)
	{
		memcpy(VRAM, (void*)l68Bitmap, 76800);
	}
	if(level==69)
	{
		memcpy(VRAM, (void*)l69Bitmap, 76800);
	}
	if(level==70)
	{
		memcpy(VRAM, (void*)l70Bitmap, 76800);
	}
	if(level==71)
	{
		memcpy(VRAM, (void*)l71Bitmap, 76800);
	}
	if(level==72)
	{
		memcpy(VRAM, (void*)l72Bitmap, 76800);
	}
	if(level==73)
	{
		memcpy(VRAM, (void*)l73Bitmap, 76800);
	}
	if(level==74)
	{
		memcpy(VRAM, (void*)l74Bitmap, 76800);
	}
	if(level==75)
	{
		memcpy(VRAM, (void*)l75Bitmap, 76800);
	}
	if(level==76)
	{
		memcpy(VRAM, (void*)l76Bitmap, 76800);
	}
	if(level==77)
	{
		memcpy(VRAM, (void*)l77Bitmap, 76800);
	}
	if(level==78)
	{
		memcpy(VRAM, (void*)l78Bitmap, 76800);
	}
	if(level==79)
	{
		memcpy(VRAM, (void*)l79Bitmap, 76800);
	}
	if(level==80)
	{
		memcpy(VRAM, (void*)l80Bitmap, 76800);
	}
	if (level == 81)
	{
		memcpy(VRAM, (void*)l81Bitmap, 76800);
	}
	if (level == 82)
	{
		memcpy(VRAM, (void*)l82Bitmap, 76800);
	}
	if (level == 83)
	{
		memcpy(VRAM, (void*)l83Bitmap, 76800);
	}
	if (level == 84)
	{
		memcpy(VRAM, (void*)l84Bitmap, 76800);
	}
	if (level == 85)
	{
		memcpy(VRAM, (void*)l85Bitmap, 76800);
	}
	if (level == 86)
	{
		memcpy(VRAM, (void*)l86Bitmap, 76800);
	}
	if (level == 87)
	{
		memcpy(VRAM, (void*)l87Bitmap, 76800);
	}
	if (level == 88)
	{
		memcpy(VRAM, (void*)l88Bitmap, 76800);
	}
	if (level == 89)
	{
		memcpy(VRAM, (void*)l89Bitmap, 76800);
	}
	if (level == 90)
	{
		memcpy(VRAM, (void*)l90Bitmap, 76800);
	}
	if(level==91)
	{
		memcpy(VRAM, (void*)l91Bitmap, 76800);
	}
	if(level==92)
	{
		memcpy(VRAM, (void*)l92Bitmap, 76800);
	}
	if(level==93)
	{
		memcpy(VRAM, (void*)l93Bitmap, 76800);
	}
	if(level==94)
	{
		memcpy(VRAM, (void*)l94Bitmap, 76800);
	}
	if(level==95)
	{
		memcpy(VRAM, (void*)l95Bitmap, 76800);
	}
	if(level==96)
	{
		memcpy(VRAM, (void*)l96Bitmap, 76800);
	}
	if(level==97)
	{
		memcpy(VRAM, (void*)l97Bitmap, 76800);
	}
	if(level==98)
	{
		memcpy(VRAM, (void*)l98Bitmap, 76800);
	}
	if(level==99)
	{
		memcpy(VRAM, (void*)l99Bitmap, 76800);
	}
	if(level==100)
	{
		memcpy(VRAM, (void*)l100Bitmap, 76800);
	}
	if(level==101)
	{
		memcpy(VRAM, (void*)l101Bitmap, 76800);
	}
	if(level==102)
	{
		memcpy(VRAM, (void*)l102Bitmap, 76800);
	}
	if(level==103)
	{
		memcpy(VRAM, (void*)l103Bitmap, 76800);
	}
	if(level==104)
	{
		memcpy(VRAM, (void*)l104Bitmap, 76800);
	}
	if(level==105)
	{
		memcpy(VRAM, (void*)l105Bitmap, 76800);
	}
	if (level == 106)
	{
		memcpy(VRAM, (void*)l106Bitmap, 76800);
	}
	if (level == 107)
	{
		memcpy(VRAM, (void*)l107Bitmap, 76800);
	}
	if (level == 108)
	{
		memcpy(VRAM, (void*)l108Bitmap, 76800);
	}
	if (level == 109)
	{
		memcpy(VRAM, (void*)l109Bitmap, 76800);
	}
	if (level == 110)
	{
		memcpy(VRAM, (void*)l110Bitmap, 76800);
	}
	if (level == 111)
	{
		memcpy(VRAM, (void*)l111Bitmap, 76800);
	}
	if (level == 112)
	{
		memcpy(VRAM, (void*)l112Bitmap, 76800);
	}
	if (level == 113)
	{
		memcpy(VRAM, (void*)l113Bitmap, 76800);
	}
	if (level == 114)
	{
		memcpy(VRAM, (void*)l114Bitmap, 76800);
	}
	if (level == 115)
	{
		memcpy(VRAM, (void*)l115Bitmap, 76800);
	}
	if (level == 116)
	{
		memcpy(VRAM, (void*)l116Bitmap, 76800);
	}
	if (level == 117)
	{
		memcpy(VRAM, (void*)l117Bitmap, 76800);
	}
	if (level == 118)
	{
		memcpy(VRAM, (void*)l118Bitmap, 76800);
	}
	if (level == 119)
	{
		memcpy(VRAM, (void*)l119Bitmap, 76800);
	}
	if (level == 120)
	{
		memcpy(VRAM, (void*)l120Bitmap, 76800);
	}
	if (level == 121)
	{
		memcpy(VRAM, (void*)l121Bitmap, 76800);
	}
	if (level == 122)
	{
		memcpy(VRAM, (void*)l122Bitmap, 76800);
	}
	if (level == 123)
	{
		memcpy(VRAM, (void*)l123Bitmap, 76800);
	}
	if (level == 124)
	{
		memcpy(VRAM, (void*)l124Bitmap, 76800);
	}
	if (level ==levelmax)
	{
		memcpy(VRAM, (void*)endBitmap, 76800);
	}
}

	