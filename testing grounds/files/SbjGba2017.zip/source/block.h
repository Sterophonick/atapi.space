
void varreset()
{
	bx = 8;
	by = 108;
    x = 0;
    y = 0;
    deaths = 0;
    gravity = 0;
    restart = 0;
}

int BlockTouchingColor(u16* color)
{
	if ((GetPixel3(bx + 1, by + 24 + y) == color)OR(GetPixel3(bx + 1, by + 22 + y) == color)OR(GetPixel3(bx + 2, by + 24 + y) == color)OR(GetPixel3(bx + 2, by + 23 + y) == color)OR(GetPixel3(bx + 3, by + 24 + y) == color)OR(GetPixel3(bx + 3, by + 23 + y) == color)OR(GetPixel3(bx + 3, by + 22 + y) == color)OR(GetPixel3(bx + 4, by + 24 + y) == color)OR(GetPixel3(bx + 4, by + 23 + y) == color)OR(GetPixel3(bx + 4, by + 22 + y) == color)OR(GetPixel3(bx + 5, by + 24 + y) == color)OR(GetPixel3(bx + 5, by + 23 + y) == color)OR(GetPixel3(bx + 5, by + 22 + y) == color)OR(GetPixel3(bx + 6, by + 24 + y) == color)OR(GetPixel3(bx + 6, by + 23 + y) == color)OR(GetPixel3(bx + 6, by + 22 + y) == color)OR(GetPixel3(bx + 7, by + 24 + y) == color)OR(GetPixel3(bx + 7, by + 23 + y) == color)OR(GetPixel3(bx + 7, by + 22 + y) == color)OR(GetPixel3(bx + 8, by + 24 + y) == color)OR(GetPixel3(bx + 8, by + 23 + y) == color)OR(GetPixel3(bx + 8, by + 22 + y) == color)OR(GetPixel3(bx + 9, by + 24 + y) == color)OR(GetPixel3(bx + 9, by + 23 + y) == color)OR(GetPixel3(bx + 9, by + 22 + y) == color)OR(GetPixel3(bx + 10, by + 24 + y) == color)OR(GetPixel3(bx + 10, by + 23 + y) == color)OR(GetPixel3(bx + 10, by + 22 + y) == color)OR(GetPixel3(bx + 11, by + 24 + y) == color)OR(GetPixel3(bx + 12, by + 23 + y) == color)OR(GetPixel3(bx + 12, by + 22 + y) == color)OR(GetPixel3(bx + 13, by + 24 + y) == color)OR(GetPixel3(bx + 13, by + 23 + y) == color)OR(GetPixel3(bx + 13, by + 22 + y) == color)OR(GetPixel3(bx + 14, by + 24 + y) == color)OR(GetPixel3(bx + 14, by + 23 + y) == color)OR(GetPixel3(bx + 14, by + 22 + y) == color)OR(GetPixel3(bx + 15, by + 24 + y) == color)OR(GetPixel3(bx + 16, by + 23 + y) == color)OR(GetPixel3(bx + 17, by + 22 + y) == color)OR(GetPixel3(bx + 18, by + 24 + y) == color)OR(GetPixel3(bx + 19, by + 23 + y) == color)OR(GetPixel3(bx + 20, by + 22 + y) == color))
	{
		return 1;
	}
	else if ((GetPixel3(bx + 24 + x, by + 22) == color)OR(GetPixel3(bx + 24 + x, by + 21) == color)OR(GetPixel3(bx + 24 + x, by + 20) == color)OR(GetPixel3(bx + 24 + x, by + 19) == color)OR(GetPixel3(bx + 24 + x, by + 18) == color)OR(GetPixel3(bx + 24 + x, by + 17) == color)OR(GetPixel3(bx + 24 + x, by + 16) == color)OR(GetPixel3(bx + 24 + x, by + 15) == color)OR(GetPixel3(bx + 24 + x, by + 14) == color)OR(GetPixel3(bx + 24 + x, by + 13) == color)OR(GetPixel3(bx + 24 + x, by + 12) == color)OR(GetPixel3(bx + 24 + x, by + 11) == color)OR(GetPixel3(bx + 24 + x, by + 10) == color)OR(GetPixel3(bx + 24 + x, by + 9) == color)OR(GetPixel3(bx + 24 + x, by + 8) == color)OR(GetPixel3(bx + 24 + x, by + 7) == color)OR(GetPixel3(bx + 24 + x, by + 6) == color)OR(GetPixel3(bx + 24 + x, by + 5) == color)OR(GetPixel3(bx + 24 + x, by + 4) == color)OR(GetPixel3(bx + 24 + x, by + 3) == color)OR(GetPixel3(bx + 24 + x, by + 2) == color)OR(GetPixel3(bx + 24 + x, by + 1) == color)OR(GetPixel3(bx + 23 + x, by + 22) == color)OR(GetPixel3(bx + 23 + x, by + 21) == color)OR(GetPixel3(bx + 23 + x, by + 20) == color)OR(GetPixel3(bx + 23 + x, by + 19) == color)OR(GetPixel3(bx + 23 + x, by + 18) == color)OR(GetPixel3(bx + 23 + x, by + 17) == color)OR(GetPixel3(bx + 23 + x, by + 16) == color)OR(GetPixel3(bx + 23 + x, by + 15) == color)OR(GetPixel3(bx + 23 + x, by + 14) == color)OR(GetPixel3(bx + 23 + x, by + 13) == color)OR(GetPixel3(bx + 23 + x, by + 12) == color)OR(GetPixel3(bx + 23 + x, by + 11) == color)OR(GetPixel3(bx + 23 + x, by + 10) == color)OR(GetPixel3(bx + 23 + x, by + 9) == color)OR(GetPixel3(bx + 23 + x, by + 8) == color)OR(GetPixel3(bx + 23 + x, by + 7) == color)OR(GetPixel3(bx + 23 + x, by + 6) == color)OR(GetPixel3(bx + 23 + x, by + 5) == color)OR(GetPixel3(bx + 23 + x, by + 4) == color)OR(GetPixel3(bx + 23 + x, by + 3) == color)OR(GetPixel3(bx + 23 + x, by + 2) == color)OR(GetPixel3(bx + 23 + x, by + 1) == color))
	{
		return 1;
	}
	else if ((GetPixel3(bx + x, by + 22) == color)OR(GetPixel3(bx + x, by + 21) == color)OR(GetPixel3(bx + x, by + 20) == color)OR(GetPixel3(bx + x, by + 19) == color)OR(GetPixel3(bx + x, by + 18) == color)OR(GetPixel3(bx + x, by + 17) == color)OR(GetPixel3(bx + x, by + 16) == color)OR(GetPixel3(bx + x, by + 15) == color)OR(GetPixel3(bx + x, by + 14) == color)OR(GetPixel3(bx + x, by + 13) == color)OR(GetPixel3(bx + x, by + 12) == color)OR(GetPixel3(bx + x, by + 11) == color)OR(GetPixel3(bx + x, by + 10) == color)OR(GetPixel3(bx + x, by + 9) == color)OR(GetPixel3(bx + x, by + 8) == color)OR(GetPixel3(bx + x, by + 7) == color)OR(GetPixel3(bx + x, by + 6) == color)OR(GetPixel3(bx + x, by + 5) == color)OR(GetPixel3(bx + x, by + 4) == color)OR(GetPixel3(bx + x, by + 3) == color)OR(GetPixel3(bx + x, by + 2) == color)OR(GetPixel3(bx + x, by + 1) == color)OR(GetPixel3(bx + 1 + x, by + 22) == color)OR(GetPixel3(bx + 1 + x, by + 21) == color)OR(GetPixel3(bx + 1 + x, by + 20) == color)OR(GetPixel3(bx + 1 + x, by + 19) == color)OR(GetPixel3(bx + 1 + x, by + 18) == color)OR(GetPixel3(bx + 1 + x, by + 17) == color)OR(GetPixel3(bx + 1 + x, by + 16) == color)OR(GetPixel3(bx + 1 + x, by + 15) == color)OR(GetPixel3(bx + 1 + x, by + 14) == color)OR(GetPixel3(bx + 1 + x, by + 13) == color)OR(GetPixel3(bx + 1 + x, by + 12) == color)OR(GetPixel3(bx + 1 + x, by + 11) == color)OR(GetPixel3(bx + 1 + x, by + 10) == color)OR(GetPixel3(bx + 1 + x, by + 9) == color)OR(GetPixel3(bx + 1 + x, by + 8) == color)OR(GetPixel3(bx + 1 + x, by + 7) == color)OR(GetPixel3(bx + 1 + x, by + 6) == color)OR(GetPixel3(bx + 1 + x, by + 5) == color)OR(GetPixel3(bx + 1 + x, by + 4) == color)OR(GetPixel3(bx + 1 + x, by + 3) == color)OR(GetPixel3(bx + 1 + x, by + 2) == color)OR(GetPixel3(bx + 1 + x, by + 1) == color)OR(GetPixel3(bx + 2 + x, by + 22) == color)OR(GetPixel3(bx + 2 + x, by + 21) == color)OR(GetPixel3(bx + 2 + x, by + 20) == color)OR(GetPixel3(bx + 2 + x, by + 19) == color)OR(GetPixel3(bx + 2 + x, by + 18) == color)OR(GetPixel3(bx + 2 + x, by + 17) == color)OR(GetPixel3(bx + 2 + x, by + 16) == color)OR(GetPixel3(bx + 2 + x, by + 15) == color)OR(GetPixel3(bx + 2 + x, by + 14) == color)OR(GetPixel3(bx + 2 + x, by + 13) == color)OR(GetPixel3(bx + 2 + x, by + 12) == color)OR(GetPixel3(bx + 2 + x, by + 11) == color)OR(GetPixel3(bx + 2 + x, by + 10) == color)OR(GetPixel3(bx + 2 + x, by + 9) == color)OR(GetPixel3(bx + 2 + x, by + 8) == color)OR(GetPixel3(bx + 2 + x, by + 7) == color)OR(GetPixel3(bx + 2 + x, by + 6) == color)OR(GetPixel3(bx + 2 + x, by + 5) == color)OR(GetPixel3(bx + 2 + x, by + 4) == color)OR(GetPixel3(bx + 2 + x, by + 3) == color)OR(GetPixel3(bx + 2 + x, by + 2) == color)OR(GetPixel3(bx + 2 + x, by + 1) == color))
	{
		return 1;
	}
	else if ((GetPixel3(bx + 1, by) == color)OR(GetPixel3(bx + 2, by) == color)OR(GetPixel3(bx + 3, by) == color)OR(GetPixel3(bx + 4, by) == color)OR(GetPixel3(bx + 5, by) == color)OR(GetPixel3(bx + 6, by) == color)OR(GetPixel3(bx + 7, by) == color)OR(GetPixel3(bx + 8, by) == color)OR(GetPixel3(bx + 9, by) == color)OR(GetPixel3(bx + 10, by) == color)OR(GetPixel3(bx + 11, by) == color)OR(GetPixel3(bx + 12, by) == color)OR(GetPixel3(bx + 13, by) == color)OR(GetPixel3(bx + 14, by + 9) == color)OR(GetPixel3(bx + 15, by + 8) == color)OR(GetPixel3(bx + 16, by + 7) == color)OR(GetPixel3(bx + 17, by + 6) == color)OR(GetPixel3(bx + 18, by) == color)OR(GetPixel3(bx + 19, by) == color)OR(GetPixel3(bx + 20, by) == color)OR(GetPixel3(bx + 21, by) == color)OR(GetPixel3(bx + 22, by) == color)OR(GetPixel3(bx + 23, by) == color))
	{
		return 1;
	}
	else {
		return 0;
	}
}

void bottomcol()
{
	if ((GetPixel3(bx + 1, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 1, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 2, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 2, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 3, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 3, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 3, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 4, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 4, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 4, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 5, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 5, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 5, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 6, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 6, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 6, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 7, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 7, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 7, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 8, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 8, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 8, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 9, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 9, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 9, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 10, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 10, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 10, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 11, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 12, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 12, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 13, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 13, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 13, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 14, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 14, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 14, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 15, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 16, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 17, by + 22 + y) == 0x64c0)OR(GetPixel3(bx + 18, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 19, by + 23 + y) == 0x64c0)OR(GetPixel3(bx + 20, by + 22 + y) == 0x64c0)OR((GetPixel3(bx, by + 24) == 0x64c0))OR(GetPixel3(bx + 24, by + 24) == 0x64c0)OR(GetPixel3(bx + 22, by + 24 + y) == 0x64c0)OR(GetPixel3(bx + 21, by + 23 + y) == 0x64c0))
	{
			by -= 1;
		y = 0;
		if ((keyDown(KEY_A))AND(gravity==0))
		{
			y = -4.05;
		}
	}
}

void rightcol()
{
	if ((GetPixel3(bx + 24 + x, by + 22) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 21) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 20) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 19) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 18) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 17) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 16) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 15) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 14) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 13) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 12) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 11) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 10) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 9) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 8) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 7) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 6) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 5) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 4) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 3) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 2) == 0x64c0)OR(GetPixel3(bx + 24 + x, by + 1) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 22) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 21) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 20) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 19) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 18) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 17) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 16) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 15) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 14) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 13) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 12) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 11) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 10) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 9) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 8) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 7) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 6) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 5) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 4) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 3) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 2) == 0x64c0)OR(GetPixel3(bx + 23 + x, by + 1) == 0x64c0))
	{
		if (keyDown(KEY_A))
		{
			if (gravity == 0)
			{
				y = -4.05;
			}
			else {
				y = 4.05;
			}
			x = -5;
		}
		else
		{
			x = 0;
			bx -= 1;
		}
	}
}

void leftcol()
{
	if ((GetPixel3(bx + x, by + 22) == 0x64c0)OR(GetPixel3(bx + x, by + 21) == 0x64c0)OR(GetPixel3(bx + x, by + 20) == 0x64c0)OR(GetPixel3(bx + x, by + 19) == 0x64c0)OR(GetPixel3(bx + x, by + 18) == 0x64c0)OR(GetPixel3(bx + x, by + 17) == 0x64c0)OR(GetPixel3(bx + x, by + 16) == 0x64c0)OR(GetPixel3(bx + x, by + 15) == 0x64c0)OR(GetPixel3(bx + x, by + 14) == 0x64c0)OR(GetPixel3(bx + x, by + 13) == 0x64c0)OR(GetPixel3(bx + x, by + 12) == 0x64c0)OR(GetPixel3(bx + x, by + 11) == 0x64c0)OR(GetPixel3(bx + x, by + 10) == 0x64c0)OR(GetPixel3(bx + x, by + 9) == 0x64c0)OR(GetPixel3(bx + x, by + 8) == 0x64c0)OR(GetPixel3(bx + x, by + 7) == 0x64c0)OR(GetPixel3(bx + x, by + 6) == 0x64c0)OR(GetPixel3(bx + x, by + 5) == 0x64c0)OR(GetPixel3(bx + x, by + 4) == 0x64c0)OR(GetPixel3(bx + x, by + 3) == 0x64c0)OR(GetPixel3(bx + x, by + 2) == 0x64c0)OR(GetPixel3(bx + x, by + 1) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 22) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 21) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 20) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 19) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 18) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 17) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 16) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 15) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 14) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 13) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 12) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 11) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 10) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 9) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 8) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 7) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 6) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 5) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 4) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 3) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 2) == 0x64c0)OR(GetPixel3(bx + 1 + x, by + 1) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 22) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 21) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 20) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 19) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 18) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 17) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 16) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 15) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 14) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 13) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 12) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 11) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 10) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 9) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 8) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 7) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 6) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 5) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 4) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 3) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 2) == 0x64c0)OR(GetPixel3(bx + 2 + x, by + 1) == 0x64c0))
	{
		if (keyDown(KEY_A))
		{

			if (gravity == 0)
			{
				y = -4.05;
			}
			else {
				y = 4.05;
			}
			x = 5;
		}
		else
		{
			x = 0;
			bx += 1;
		}
	}
}

void topcol()
{
	if ((GetPixel3(bx + 1, by + y) == 0x64c0)OR(GetPixel3(bx + 2, by + y) == 0x64c0)OR(GetPixel3(bx + 3, by + y) == 0x64c0)OR(GetPixel3(bx + 4, by + y) == 0x64c0)OR(GetPixel3(bx + 5, by + y) == 0x64c0)OR(GetPixel3(bx + 6, by + y) == 0x64c0)OR(GetPixel3(bx + 7, by + y) == 0x64c0)OR(GetPixel3(bx + 8, by + y) == 0x64c0)OR(GetPixel3(bx + 9, by + y) == 0x64c0)OR(GetPixel3(bx + 10, by + y) == 0x64c0)OR(GetPixel3(bx + 11, by + y) == 0x64c0)OR(GetPixel3(bx + 12, by + y) == 0x64c0)OR(GetPixel3(bx + 13, by + y) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y) == 0x64c0)OR(GetPixel3(bx + 19, by + y) == 0x64c0)OR(GetPixel3(bx + 20, by + y) == 0x64c0)OR(GetPixel3(bx + 21, by + y) == 0x64c0)OR(GetPixel3(bx + 22, by + y) == 0x64c0)OR(GetPixel3(bx + 23, by + y) == 0x64c0))
	{
		if (gravity == 0)
		{
			by += 3;
			by -= y;
			y = 0;
			y += 0.24;
			MoveSprite(&sprites[1], bx, by);
		}
		else {
			y = 0;
			by += 1;
			if ((GetPixel3(bx + 1, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 1 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 1 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 1 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 1 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 1) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 1) == 0x64c0))
			{
				y = 0;
				by += 1;
				if ((GetPixel3(bx + 1, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 2 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 2 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 2 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 2 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 2) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 2) == 0x64c0))
				{
					y = 0;
					by += 1;
					if ((GetPixel3(bx + 1, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 3 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 3 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 3 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 3 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 3) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 3) == 0x64c0))
					{
						y = 0;
						by += 1;
						if ((GetPixel3(bx + 1, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 4 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 4 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 4 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 4 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 4) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 4) == 0x64c0))
						{
							y = 0;
							by += 1;
							if ((GetPixel3(bx + 1, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 2, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 3, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 4, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 5, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 6, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 7, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 8, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 9, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 10, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 11, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 12, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 13, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 14, by + (y * 2) + 5 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + (y * 2) + 5 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + (y * 2) + 5 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + (y * 2) + 5 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 19, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 20, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 21, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 22, by + (y * 2) + 5) == 0x64c0)OR(GetPixel3(bx + 23, by + (y * 2) + 5) == 0x64c0))
							{
								y = 0;
								by += 1;
								if ((GetPixel3(bx + 1, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 6 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 6 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 6 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 6 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 6) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 6) == 0x64c0)OR((GetPixel3(bx + 1, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 7 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 7 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 7 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 7 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 7) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 7) == 0x64c0)OR((GetPixel3(bx + 1, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 2, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 3, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 4, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 5, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 6, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 7, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 8, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 9, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 10, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 11, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 12, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 13, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 14, by + y + 10 + 9) == 0x64c0)OR(GetPixel3(bx + 15, by + y + 10 + 8) == 0x64c0)OR(GetPixel3(bx + 16, by + y + 10 + 7) == 0x64c0)OR(GetPixel3(bx + 17, by + y + 10 + 6) == 0x64c0)OR(GetPixel3(bx + 18, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 19, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 20, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 21, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 22, by + y + 10) == 0x64c0)OR(GetPixel3(bx + 23, by + y + 10) == 0x64c0))))
								{
									by -= 3;
									by -= y;
									y = 0;
									y -= 0.24;
								}
							}
						}
					}
				}
			}
			if (keyDown(KEY_A))
			{
				y = 4.05;
			}
		}
	}
}

void die()
{
	bx = 8;
	by = 108;
    x = 0;
    y = 0;
    restart = 0;
    gravity = 0;
}
void physics()
{
	if (gravity == 0)
	{
		y += 0.24;
	}
	else {
		y -= 0.24;
	}
	if (keyDown(KEY_LEFT))
	{
		x -= 0.5;
		dir = 1;
	}
	if (keyDown(KEY_RIGHT))
	{
		x += 0.5;
		dir = 0;
	}
	x *= 0.9;
	if ((dir == 1)AND(NOT(x>0))AND(NOT(keyDown(KEY_LEFT))))
	{
		x += 0.08;
		if (x>0)
		{
			x = 0;
		}
	}
	bx += x;
	by += y;
	bottomcol();
	leftcol();
	rightcol();
	topcol();
	if ((bx > 199)AND(by > 104))
	{
		level++;
		levels();
		varreset();
	}
}