/* Main source file for Super Block Jump Game Boy Advance Edition. Feel free to edit and recompile the source if you want. If you are to recompile the game, You will need DevKit Advance and place it in C:\devkitadv\*/


void vblfunc();

#include <agb_lib.h> //main function library (that I made)

#define startpressed keyDown(KEY_START)
#define selectpressed keyDown(KEY_SELECT)
/*
	GBA HARDWARE
	CPU: 32-bit arm7tdmi RISC 16.78MHz
	RAM: 32kb internal, 256kb external, 96kb VRAM
	DSP: TFT LCD, 15-bit 240x160
	ROM: 32MB
	SRAM/EEPROM: 32-64kb
	OAM: 128 Sprites
	BIOS: 16kb
*/
//The lowest amount of sprites that I want on screen is 6.
/*
SRAM Slots:
1. Crash Variable
2. File 1
3. File 2
4. File 3 
5.  RNG Seed (For random number generation)
*/

//variables
int px, py, psx, psy, pi,gci;
char* buf[255];
int fl,es,arpos,newframe,devmode;
int g2, gcd2, fl2, lv2,ea2;
int musici;
int deaths,time;
int musicsize;
int levelmax = 125;
int s1o, s2o, s3o, s4o, s5o, s6o,px,py,pdy,pdx;
int gemv;
int end;
int empty;
int empty2;
int arpos;
int why;
char *hello;
int jumpt, sndtmr, deatht, dir;
int boi;
int start = 0;
int g = 0;
int nostart = 1;
int level = 1;
int menu = 0;
int crash=0;
int wait;
int complete3;
int bx=17,by=128;
double x = 0;
double y = 0;
int gravity = 0;
int restart = 0;
int fx,fy,fb;
int pause,hit,charactercollision,ex,ea,ed,em,gm,tm,td,td2,ty,ty2,sm,sy,sd,fezaud,gcd,alock,block,sellock,saveone,savetwo,savethree,RNGSeed,realrng,RNGRSeed,h1,dum;
int trans;
int i, current;
#define BLOCK_OAM 0
#define GOAL_OAM 48
#define GEM_OAM 296
#define FIREBALL_OAM 32
#define VERSION_OAM 280
#define JUMPREFRESHER_OAM 56
#define PLAY_OAM 88
#define PONG_OAM 120
#define RESTART_OAM 152
#define SPIKE_OAM 184
#define TINFOIL_OAM 120
#define ENEMY_OAM 360

void playSound(int s) //Sound play Function
{
    REG_SOUNDCNT1_H = 0x0B04;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
    REG_SOUNDCNT1_X = 0x0080;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
    REG_SD1SAD = (unsigned long)sound[s].song;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
    REG_SD1DAD = 0x040000A0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
    REG_SD1CNT_H = 0xB640;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
    REG_TM0SD = 65536 - (16777216 / sound[s].frequency);                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
    REG_TMSDCNT = 0x00C0;
}

//includes
#include "backgrounds.h" //backgrounds
#include "allobjs.h" //Objects and palettes
#include "morebackgrounds.h" //backgrounds
#include "levels.h" //levels
#include "music.h" //music
#include "sounds.h" //sounds
#include "rotostuff.h" //rotostuff
#include "soundinit.h" //init sounds
#include "block.h" //the main controls for the block
#include "levelchange.h" //the DISPCNT for changing levels

int main() //Entry Point
{
    crash = LoadInt(0); //Crash
    saveone = LoadInt(16); //Save one
    savetwo = LoadInt(32); //Save two
    savethree = LoadInt(48); //Save Three
    RNGSeed = LoadInt(64); //RNG
    if (crash == 2) { //Crash 2
        SetMode(MODE_3 | BG2_ENABLE); //Mode 3, BG2 On
        memcpy(VRAM, 0x0000, 38400); //Glitchy Screen
        FadeIn(0); //Quick Fade
        Sleep(256); //Waits 1 Second
        SaveInt(0, 0); //Resets crash variable
        Print(8, 8, "HAHAHAHAHAHAHAHAHAHAH!", GREEN, BLACK); //Draws text
        while (!(KEY_ANY_PRESSED)); //Waits until any button is pressed
        vsync
        hardreset(); //Jumps Execution to Address 0x00000000, which cold resets the system.
    }
    if ((!((crash == 0)OR(crash == 1)))AND(!((saveone > 0)AND(saveone < levelmax)))AND(!((savetwo > 0)AND(savetwo < levelmax)))AND(!((savethree > 0)AND(savethree < levelmax)))) {
        Initialize(); //Start Fade
        setbg2((void*)sramcBitmap, (void*)sramcPalette); //SRAM Corruption screen
        memcpy(SRAM, 0x06000ED0, 65536); //Erases SRAM
        while (1); //Forever
    }
    if ((crash == 0)AND(saveone == 0)AND(savetwo == 0)AND(savethree == 0)AND(RNGSeed == 0)) {
        empty = 1;
    }
    if (empty == 1) { //SRAM Empty Screen
        Initialize();
        setbg2((void*)srameBitmap, (void*)sramePalette);
        FadeIn(2);
        while (!(KEY_ANY_PRESSED));
        empty2 = 1;
        FadeOut(2);
    }
    if ((keyDown(KEY_A))AND(keyDown(KEY_B))) { //SRAM Clear Function
        FadeOut(0);
        while (((keyDown(KEY_A))OR(keyDown(KEY_B))));
        SetMode(MODE_3 | BG2_ENABLE);
        Print(-1, 0, "ERASE SAVE DATA?", RED, BLACK);
        FadeIn(2);
        while (!(((keyDown(KEY_A))OR(keyDown(KEY_B)))));
        if (keyDown(KEY_A)) {
            fillscreen3(0x0000);
            Print(-1, 0, "ARE YOU SURE?", RED, BLACK);
            Print(-1, 9, "ALL DATA WILL BE ERASED.", RED, BLACK);
            while (((keyDown(KEY_A))OR(keyDown(KEY_B))));
            while (!(((keyDown(KEY_A))OR(keyDown(KEY_B)))));
            if (keyDown(KEY_A)) {
                while (((keyDown(KEY_A))OR(keyDown(KEY_B))));
                fillscreen3(0x0000);
                Print(-1, 0, "ERASING.....", RED, BLACK);
                memcpy(SRAM, 0x06000ED0, 65536);
                Sleep(1024);
                Print(-1, 0, "THE SYSTEM WILL NOW RESTART.", RED, BLACK);
                while (!(KEY_ANY_PRESSED));
                hardreset();
            }
            else {
                fillscreen3(0x0000);
                Print(-1, 0, "THE PROCESS WAS ABORTED.", RED, BLACK);
                Print(-1, 9, "THE SYSTEM WILL NOW RESTART.", RED, BLACK);
                while (!(KEY_ANY_PRESSED));
                hardreset();
            }
        }
        else {
            fillscreen3(0x0000);
            Print(-1, 0, "THE PROCESS WAS ABORTED.", RED, BLACK);
            Print(-1, 9, "THE SYSTEM WILL NOW RESTART.", RED, BLACK);
            while (!(KEY_ANY_PRESSED));
            hardreset();
        }
    }
    // RNGRSeed = (RNGSeed + REG_VCOUNT + x +y - bx + (by\3) + (level\3) + savetwo - saveone + (savethree\GetPixel(14, 4))) ;
    crash = LoadInt(0);
    saveone = LoadInt(16);
    savetwo = LoadInt(32);
    savethree = LoadInt(48);
    RNGSeed = LoadInt(64);
    hello = "//cart//data//allobjs.h: no newline at end of file       C:\\devkitadv\\bin\\objcopy -O binary main.elf main.gba       C:\\devkitadv\\bin\\gcc -marm -mthumb-interwork -o main.elf main.o      C:\\devkitadv\\bin\\gcc -c -O3 -mthumb-interwork main.c Hello. You have just found an eAsTeR eGg.";
    int s;
    initsound8(1, 22050, 2801, (void*)logotheme); //SOund
    initsound8(2, 22050, 2801, (void*)punch);
    initsound8(3, 22050, 2801, (void*)music);
    if (empty2 == 0) {
        WaitForVblank();
        fillscreen3(0xFFFF);
        SetMode(MODE_3 | BG2_ENABLE);
        scanlines3(0x0000, 0.5);
        fillscreen3(0x0000);
        FadeOut(0);
    }
    SetMode(MODE_4 | BG2_ENABLE); //Mode 4, BG2 On
    bgPic2Buffer((void*)discliamerBitmap); //disclaimer
    bgPal((void*)discliamerPalette);
    bgPic((void*)discliamerBitmap);
    FadeIn(2);
    time = 0;
    while (!(time == 255 | keyDown(KEY_A))) {
        time++;
        SetBGPalPoint(1, (void*)GetBGPalPoint(1) + 1); //Color Changing text
        SleepF(0.50);
        SetBGPalPoint(1, (void*)GetBGPalPoint(1) + 1);
        SleepF(0.50);
        SetBGPalPoint(1, (void*)GetBGPalPoint(1) + 1);
        SleepF(0.50);
    }
    FadeOut(2);
    bgPic2Buffer((void*)thxBitmap); //special thanks
    bgPal((void*)thxPalette);
    bgPic((void*)thxBitmap);
    FadeIn(2);
    time = 0;
    while (!(time == 255 | keyDown(KEY_A))) {
        time++;
        SleepF(1.50);
    }
    FadeOut(2);
    bgPic2Buffer((void*)scratchBitmap); //scratch
    bgPal((void*)scratchPalette);
    bgPic((void*)scratchBitmap);
    FadeIn(2);
    time = 0;
    while (!(time == 255 | keyDown(KEY_A))) {
        time++;
        SleepF(1.50);
    }
    FadeOut(2);
    bgPic2Buffer((void*)gbadevBitmap); //GBADEV logo
    bgPal((void*)gbadevPalette);
    bgPic((void*)gbadevBitmap);
    FadeIn(2);
    time = 0;
    while (!(time == 255 | keyDown(KEY_A))) {
        time++;
        SleepF(1.50);
    }
    FadeOut(2);
    bgPic2Buffer((void*)imadogBitmap); //meh
    bgPal((void*)imadogPalette);
    bgPic((void*)imadogBitmap);
    FadeIn(2);
    time = 0;
    while (!(time == 255 | keyDown(KEY_A))) {
        time++;
        SleepF(1.50);
    }
    FadeOut(2);
    bgPic2Buffer((void*)slyangelBitmap); //meh good brah
    bgPal((void*)slyangelPalette);
    bgPic((void*)slyangelBitmap);
    FadeIn(2);
    time = 0;
    while (!(time == 255 | keyDown(KEY_A))) {
        time++;
        SleepF(1.50);
    }
    FadeOut(2); //Quick Fade Out
    SetMode(MODE_4 | BG2_ENABLE); //Mode 4, BG2 On
    drawbitmap3((void*)titlescreenBitmap); //Titlescreen
    SetMode(MODE_3 | BG2_ENABLE); //Mode 3, BG2 On
    FadeIn(2);  //Quick Fade In
    while (!(keyDown(KEY_START))) {
        wait = 0;
    }
    if (crash == 1) { //Crash
        vsync
        SetMode(MODE_4 | BG2_ENABLE);
        for (i = 0; i<30; i++) {
            vsync
            setbg2(us stat1Bitmap, us stat1Palette);
            Sleep(10);
            vsync
            setbg2(us stat2Bitmap, us stat2Palette);
            Sleep(10);
        }
        setbg2(us bsodBitmap, us bsodPalette);
        SaveInt(0, 2);
        while (1);
    }
    vsync
    SetMode(MODE_4 | BG2_ENABLE);
    setbg2novb((void*)roto0Bitmap, (void*)roto0Palette); //logospin
    sound[1].tic = 1;
    s = 1;
    playSound(1); //play logotheme.wav
    setbg2((void*)roto0Bitmap, (void*)roto0Palette); //logospin
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(1);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(1);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(1);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(1);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(1);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(1);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(1);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(1);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(1);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(1);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(1);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(1);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(1);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(1);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(1);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(1);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(1);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(1);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(1);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(1);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(1);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(1);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(1);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(1);
    setbg2((void*)roto0Bitmap, (void*)roto0Palette);
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(1);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(1);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(1);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(1);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(1);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(1);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(1);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(1);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(1);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(1);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(1);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(1);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(1);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(1);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(1);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(1);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(1);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(1);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(1);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(1);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(1);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(1);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(1);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(1);
    setbg2((void*)roto0Bitmap, (void*)roto0Palette);
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(1);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(1);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(1);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(1);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(1);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(1);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(1);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(1);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(1);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(1);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(1);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(1);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(1);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(1);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(1);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(1);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(1);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(1);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(1);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(1);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(1);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(1);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(1);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(1);
    setbg2((void*)roto0Bitmap, (void*)roto0Palette);
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(1);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(1);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(1);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(1);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(1);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(1);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(1);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(1);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(1);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(1);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(1);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(1);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(1);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(1);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(1);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(1);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(1);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(1);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(1);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(1);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(1);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(1);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(1);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(1);
    setbg2((void*)roto0Bitmap, (void*)roto0Palette);
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(1);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(1);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(1);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(1);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(1);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(1);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(1);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(1);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(1);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(1);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(1);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(1);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(1);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(1);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(1);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(1);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(1);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(1);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(1);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(1);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(1);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(1);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(1);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(1);
    setbg2((void*)roto0Bitmap, (void*)roto0Palette);
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(1);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(1);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(1);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(1);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(1);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(1);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(1);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(1);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(1);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(1);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(1);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(1);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(1);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(1);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(1);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(1);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(1);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(1);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(1);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(1);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(1);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(1);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(1);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(1);
    setbg2((void*)roto0Bitmap, (void*)roto0Palette);
    Sleep(1);
    setbg2((void*)roto1Bitmap, (void*)roto1Palette);
    Sleep(1);
    setbg2((void*)roto2Bitmap, (void*)roto2Palette);
    Sleep(1);
    setbg2((void*)roto3Bitmap, (void*)roto3Palette);
    Sleep(1);
    setbg2((void*)roto4Bitmap, (void*)roto4Palette);
    Sleep(1);
    setbg2((void*)roto5Bitmap, (void*)roto5Palette);
    Sleep(1);
    setbg2((void*)roto6Bitmap, (void*)roto6Palette);
    Sleep(1);
    setbg2((void*)roto7Bitmap, (void*)roto7Palette);
    Sleep(1);
    setbg2((void*)roto8Bitmap, (void*)roto8Palette);
    Sleep(1);
    setbg2((void*)roto9Bitmap, (void*)roto9Palette);
    Sleep(1);
    setbg2((void*)roto10Bitmap, (void*)roto10Palette);
    Sleep(1);
    setbg2((void*)roto11Bitmap, (void*)roto11Palette);
    Sleep(1);
    setbg2((void*)roto12Bitmap, (void*)roto12Palette);
    Sleep(1);
    setbg2((void*)roto13Bitmap, (void*)roto13Palette);
    Sleep(1);
    setbg2((void*)roto14Bitmap, (void*)roto14Palette);
    Sleep(1);
    setbg2((void*)roto15Bitmap, (void*)roto15Palette);
    Sleep(1);
    setbg2((void*)roto16Bitmap, (void*)roto16Palette);
    Sleep(1);
    setbg2((void*)roto17Bitmap, (void*)roto17Palette);
    Sleep(1);
    setbg2((void*)roto18Bitmap, (void*)roto18Palette);
    Sleep(1);
    setbg2((void*)roto19Bitmap, (void*)roto19Palette);
    Sleep(1);
    setbg2((void*)roto20Bitmap, (void*)roto20Palette);
    Sleep(1);
    setbg2((void*)roto21Bitmap, (void*)roto21Palette);
    Sleep(1);
    setbg2((void*)roto22Bitmap, (void*)roto22Palette);
    Sleep(1);
    setbg2((void*)roto23Bitmap, (void*)roto23Palette);
    Sleep(1);
    setbg2((void*)roto24Bitmap, (void*)roto24Palette);
    Sleep(1);
    setbg2((void*)roto25Bitmap, (void*)roto25Palette);
    Sleep(1);
    setbg2((void*)roto26Bitmap, (void*)roto26Palette);
    Sleep(0.5);
    setbg2((void*)roto27Bitmap, (void*)roto27Palette);
    Sleep(0.5);
    setbg2((void*)roto28Bitmap, (void*)roto28Palette);
    Sleep(0.5);
    setbg2((void*)roto29Bitmap, (void*)roto29Palette);
    Sleep(0.5);
    setbg2((void*)roto30Bitmap, (void*)roto30Palette);
    Sleep(0.5);
    setbg2((void*)roto31Bitmap, (void*)roto31Palette);
    Sleep(0.5);
    setbg2((void*)roto32Bitmap, (void*)roto32Palette);
    Sleep(0.5);
    setbg2((void*)roto33Bitmap, (void*)roto33Palette);
    Sleep(0.5);
    setbg2((void*)roto34Bitmap, (void*)roto34Palette);
    Sleep(0.5);
    setbg2((void*)roto35Bitmap, (void*)roto35Palette);
    Sleep(0.5);
    setbg2((void*)roto36Bitmap, (void*)roto36Palette);
    Sleep(0.5);
    setbg2((void*)roto37Bitmap, (void*)roto37Palette);
    Sleep(0.5);
    setbg2((void*)roto38Bitmap, (void*)roto38Palette);
    Sleep(0.5);
    setbg2((void*)roto39Bitmap, (void*)roto39Palette);
    Sleep(0.5);
    setbg2((void*)roto40Bitmap, (void*)roto40Palette);
    Sleep(0.5);
    setbg2((void*)roto41Bitmap, (void*)roto41Palette);
    Sleep(0.5);
    setbg2((void*)roto42Bitmap, (void*)roto42Palette);
    Sleep(0.5);
    setbg2((void*)roto43Bitmap, (void*)roto43Palette);
    Sleep(0.5);
    setbg2((void*)roto44Bitmap, (void*)roto44Palette);
    Sleep(0.5);
    setbg2((void*)roto45Bitmap, (void*)roto45Palette);
    Sleep(0.5);
    setbg2((void*)roto46Bitmap, (void*)roto46Palette);
    Sleep(0.5);
    setbg2((void*)roto47Bitmap, (void*)roto47Palette);
    Sleep(0.5);
    setbg2((void*)roto48Bitmap, (void*)roto48Palette);
    Sleep(0.5);
    playSound(2);
    setbg2((void*)roto49Bitmap, (void*)roto49Palette);
    Sleep(0.5);
    vsync
    setbg2novb((void*)bgtwoBitmap, (void*)bgtwoPalette); //bgtwo
    Sleep(25);
    while (1) { //main loop for menu
        REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
        REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
        REG_DM1SAD = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
        REG_DM1DAD = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
        REG_DM1CNT_H = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
        REG_TM0D = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
        REG_TM0CNT = 0;
        if (keyDown(KEY_SELECT)) {
            FadeOut(2);
            setbg2((void*)controlspage1Bitmap, (void*)controlspage1Palette); //Controls Page 1
            FadeIn(2);
            while (!(keyDown(KEY_A))) {
                wait = 0;
            }
            while (keyDown(KEY_A)) {
                wait = 0;
            }
            FadeOut(2);
            setbg2((void*)controlspage2Bitmap, (void*)controlspage2Palette); //Controls Page 2
            FadeIn(2);
            while (!(keyDown(KEY_A))) {
                wait = 0;
            }
            while (keyDown(KEY_A)) {
                wait = 0;
            }
            FadeOut(2);
            drawbg2((void*)bgtwoBitmap, (void*)bgtwoPalette); //Bgtwo
            FadeIn(2);
        }
        if (keyDown(KEY_START)) {
            FadeOut(15);
			if (keyDown(KEY_R)) //Developer Mode
			{
				devmode = 1;
			}
            loadSpriteGraphics((void*)allobjs, 11904); //loads the bitmap data for all of the objects, so that I don't have to go throught the hassle of making a palette for each individual object.
            loadSpritePal((void*)allobjsPalette); //Copies the specified palette data into memory address 0x5000200, which is the location of the palette of the objects in OAM.

            SetMode(MODE_3 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
            drawbitmap3((void*)l1Bitmap);
            SetPalette((void*)blackPalette);
            initSprite(1, SIZE_32, 0); //Slot 1: Block (32x32)
            initSprite(2, SIZE_8, 48); //Slot 2: Goal (8x8)
            sprites[3].attribute0 = COLOR_256 | WIDE | 240; //Slot 3: Fireball (32x16)
            sprites[3].attribute1 = SIZE_32 | 160;
            sprites[3].attribute2 = 512 + 32;
            sprites[4].attribute0 = COLOR_256 | WIDE | 240; //Slot 4: Version Counter (64x32)
            sprites[4].attribute1 = SIZE_64 |160;
            sprites[4].attribute2 = 512 + 280;
            sprites[5].attribute0 = COLOR_256 | SQUARE | 160; //Slot 5: Level Object#1 (32 -- 64)
            sprites[5].attribute1 = SIZE_8 | 240;
            sprites[5].attribute2 = 512 + 56;
            sprites[6].attribute0 = COLOR_256 | SQUARE | 240; //Slot 6: Level Object#2 (32 -- 64)
            sprites[6].attribute1 = SIZE_8 | 160;
            sprites[6].attribute2 = 512 + 56;
            drawbitmap3((void*)l1Bitmap);
            FadeIn(15);
            varreset();
            level=1;
            musicsize = (sizeof(music) / sizeof(music[0]));
            MoveSprite(&sprites[4], 0, 152);
            MoveSprite(&sprites[2], 223, 128);
            playSound(3);
            while (1) {
                if(newframe==0) {
                    musici++;
                    physics();
                    if (BlockTouchingColor((void*)0x7ED3) == 1) {
                        if (gravity == 1) {
                            y = 6;
                        }
                        else {
                            y = -6;
                        }
                    }
                    if ((BlockTouchingColor(0x001F) == 1)OR(bx < 0)OR(bx > 216)OR(by < 0)OR(by > 136)) {
                        die();
                    }
                    if (level == 49) {
                        sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
                        sprites[5].attribute1 = SIZE_32 | 160;
                        sprites[5].attribute2 = 512 + 248; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
                        cloneSprite(5, 6);
                        sprites[6].attribute2 = 512 + 248; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

                        if (td == 1) {
                            MoveSprite(&sprites[5], 128, ty);
                            if (NOT(ty < 0)) {
                                ty -= 4;
                            }
                            else {
                                td = 0;
                            }
                        }
                        else {

                            MoveSprite(&sprites[5], 128, ty);
                            if (NOT(ty > 113)) {
                                ty += 4;
                            }
                            else {
                                td = 1;
                            }
                        }
                        if (td2 == 1) {
                            MoveSprite(&sprites[6], 64, ty2);
                            if (NOT(ty2 < 0)) {
                                ty2 -= 3;
                            }
                            else {
                                td2 = 0;
                            }
                        }
                        else {
                            MoveSprite(&sprites[6], 64, ty2);
                            if (NOT(ty2 > 113)) {
                                ty2 += 3;
                            }
                            else {
                                td2 = 1;
                            }
                        }
                        if (((bx > 104)AND(bx < 160)AND(by < ty + 32))OR((bx > 40)AND(bx < 96)AND(by < ty2 + 32))) {
                            bx = 8;
                            by = 108;
                            y = 0;
                            x = 0;
                        }
                    }
                    else if ((level == 50)OR(level == 51)) {
                        sprites[5].attribute0 = COLOR_256 | TALL | 240;
                        sprites[5].attribute1 = SIZE_64 | 160;
                        sprites[5].attribute2 = 512 + 184; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
                        MoveSprite(&sprites[6], 240, 160);
                        if (sd == 1) {
                            MoveSprite(&sprites[5], 128, sy);
                            if (NOT(sy < 0)) {
                                sy -= 4;
                            }
                            else {
                                sd = 0;
                            }
                        }
                        else {
                            MoveSprite(&sprites[5], 128, sy);
                            if (NOT(sy > 81)) {
                                sy += 4;
                            }
                            else {
                                sd = 1;
                            }
                        }
                        if ((bx > 104)AND(bx < 160)AND(by < sy + 64)) {
                            die();
                        }
                    }
                    else if (level == 52) {
                        sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
                        sprites[5].attribute1 = SIZE_8 | 160;

                        sprites[5].attribute2 = 512 + 56;
                    }
                    else if (level == 58) {
                        if (gemv == 0) {
                            sprites[5].attribute0 = COLOR_256 | WIDE | 240;
                            sprites[5].attribute1 = SIZE_64 | 160;
                            sprites[5].attribute2 = 512 + 296; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
                            MoveSprite(&sprites[5], 98, 66);
                            if (g == 1) {
                                sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
                                sprites[5].attribute1 = SIZE_8 | 160;
                                sprites[5].attribute2 = 512 + 56;
                                gemv = 1;
                            }
                        }
                        if ((bx > 74)AND(by < 94)AND(bx < 141)AND(by > 42)) {
                            sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
                            sprites[5].attribute1 = SIZE_8 | 160;

                            sprites[5].attribute2 = 512 + 56;
                            g = 1;
                            gemv = 1;
                        }
                    }
                    else if (level == 61) {
                        if ((es == 0)AND(!(ed==3))) {
                            sprites[5].attribute0 = COLOR_256 | SQUARE | 64;
                            sprites[5].attribute1 = SIZE_64 | 81;
                            sprites[5].attribute2 = 512 + 360; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
                            es = 1;
							ex = 64;
                            MoveSprite(&sprites[5], 64, 81);
                        }
                        if (ed == 1) {
                            sprites[5].attribute1 = SIZE_64 | 81;
                            MoveSprite(&sprites[5], ex, 81);
                            if (NOT(ex < 64)) {
                                ex -= 3;
                            }
                            else {
                                ed = 0;
                            }
                        }
                      if (ed == 0) {
                            sprites[5].attribute1 = SIZE_64 | HORIZONTAL_FLIP | ex;
                            MoveSprite(&sprites[5], ex, 81);
                            if (NOT(ex > 160)) {
                                ex += 3;
                            }
                            else {
                                ed = 1;
                            }
                        }
                        if ((bx > ex - 24)AND(!(ed==3))) {
							die();
                        }
                        if ((fx > ex - 32)AND(NOT(ea == 1))) {
                            fb = 0;
							ed = 3;
                            fx = 0;
                            MoveSprite(&sprites[3], 240, 160);
                            MoveSprite(&sprites[5], 240, 160);
                        }
                    }
                    else if (level == 62) {
                        sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
                        sprites[5].attribute1 = SIZE_8 | 160;

                        sprites[5].attribute2 = 512 + 56;
                    }
                    else if (((level >= 43)AND(level <= 47))OR(level == levelmax)) {
                        if ((keyDown(KEY_SELECT))AND(sellock == 0)) {
                            gravity++;
                            if (gravity == 2) {
                                gravity = 0;
                            }
                            sellock = 1;
                        }
                        if (NOT(keyDown(KEY_SELECT))) {
                            sellock = 0;
                        }
                    }
                    else if ((level == 55)OR(level == 56)) {
                        initSprite(5, SIZE_32, 56);
                        MoveSprite(&sprites[5], 104, 64);
                        if ((bx > 80)AND(by > 40)AND(bx < 136)AND(by < 96)) {
                            if (keyDown(KEY_A)) {
                                y = -4.05;
                            }
                        }
                    }
                    else if (level == 57) {
                        sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
                        sprites[5].attribute1 = SIZE_8 | 160;
                        sprites[5].attribute2 = 512 + 56;
                    }
                    else if (((level > 31)AND(level < 40))OR(level == 42)OR(level == 54)) {
                        if (BlockTouchingColor(0x7E8C) == 1) {
                            if (level == 32) {
                                bx = 159;
                                by = 3;
                            }
                            else if (level == 33) {
                                bx = 136;
                                by = 3;
                            }
                            else if (level == 34) {
                                bx = 195;
                                by = 4;
                            }
                            else if (level == 35) {
                                bx = 139;
                                by = 97;
                            }
                            else if (level == 36) {
                                bx = 6;
                                by = 31;
                            }
                            else if (level == 37) {
                                bx = 173;
                                by = 5;
                            }
                            else if (level == 38) {
                                bx = 16;
                                by = 3;
                            }
                            else if (level == 39) {
                                bx = 124;
                                by = 5;
                            }
                            else if (level == 42) {
                                bx = 196;
                                by = 101;
                            }
                            else if (level == 54) {
                                bx = 119;
                                by = 111;
                                y = -3.5;
                            }
                            else {
                                bx = 0;
                                by = 0;
                            }
                        }
                    }
                    else if (level == 85) {
						if ((bx > 90 - 24)AND(by > 81 - 24)AND(gcd==0))
						{
							die();
						}
						int gcbt,gcbx,gcby,gctx,gcty,gcttt;
						if (gci == 0)
						{
							initSprite(&sprites[5], SIZE_8, 74);
						}
                        if ((fx > 45)AND(NOT(gcd == 1))) {
                            sprites[3].attribute0 = COLOR_256 | WIDE  | 160;
                            sprites[3].attribute1 = SIZE_32 | 240;
                            sprites[3].attribute2 = 512 + 32; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

                            drawbitmap3((void*)l85bBitmap);
                            MoveSprite(&sprites[3], 240, 160);
                            fb = 0;
                            gcd = 1;
                        }
						if ((gcbt == 0)AND(gcd==0))
						{
							if (gcbx == 0)
							{
								MoveSprite(&sprites[5], 80, by);
								gcbx = 1;
								gctx = 80;
								gcby = by;
							}
							if (gcbx == 1)
							{
								MoveSprite(&sprites[5], gctx, gcby);
								if(gctx < 0)
								{
									gctx -= 4;
									if ((bx - 24 > gctx)AND(bx > gctx + 8)AND(by + 24 > gcby)AND(by < gcby + 8))
									{
										die();
										gcbx = 0;
										MoveSprite(&sprites[5], 240, 160);
									}

								}
								else {
									gctx = 0;
									MoveSprite(&sprites[5], 240,160);
								}
							}
						}
                    }
                    else if (level == 84) {
                        if (pi == 0) {
                            initSprite(5, SIZE_16, 120);
                            pi = 1;
                        }
                        px += psx;
                        py += psy;
                        if (py >= 128) {
                            psy = -4;
                        }
                        if (py <= 0) {
                            psy = 4;
                        }

                        if (px >= 224) {
                            psx = -4;
                        }
                        if (px <= 0) {
                            psx = 4;
                        }
                        MoveSprite(&sprites[5], px, py);
						if ((bx > px - 24)AND(bx < px + 16)AND(by > py - 24)AND(by < py + 16))
						{
							die();
						}
                    }
					else if (level == 85)
					{
						initSprite(5, SIZE_8, 0);
					}
                    else if ((level > 9)AND(level < 13)) {
                        if (BlockTouchingColor(0x6300) == 1) {
                            die();
                        }
                    }
                    if ((keyDown(KEY_B))AND(g == 1)) {
                        fb = 1;
                        fy = by + 4;
                        fx = bx;
                        block = 1;
                    }
                    if ((fb == 1)AND(NOT(fx > 240))) {
                        fx += 5;
                        MoveSprite(&sprites[3], fx, fy);
                    }
                    else {
                        fx = 0;
                        fb = 0;
                        MoveSprite(&sprites[3], 0, 160);
                    }
                    if (restart == 1) {
                        die();
                    }
                    MoveSprite(&sprites[1], bx, by);
                    if (level == 103) {
                        if (fl == 0) {
                            CopyOAM();
                            while (!(keyDown(KEY_UP)));
                            while ((keyDown(KEY_UP)));
                            while (!(keyDown(KEY_UP)));
                            while ((keyDown(KEY_UP)));
                            while (!(keyDown(KEY_DOWN)));
                            while ((keyDown(KEY_DOWN)));
                            while (!(keyDown(KEY_DOWN)));
                            while ((keyDown(KEY_DOWN)));
                            while (!(keyDown(KEY_LEFT)));
                            while ((keyDown(KEY_LEFT)));
                            while (!(keyDown(KEY_RIGHT)));
                            while ((keyDown(KEY_RIGHT)));
                            while (!(keyDown(KEY_LEFT)));
                            while ((keyDown(KEY_LEFT)));
                            while (!(keyDown(KEY_RIGHT)));
                            while ((keyDown(KEY_RIGHT)));
                            while (!(keyDown(KEY_B)));
                            while ((keyDown(KEY_B)));
                            while (!(keyDown(KEY_A)));
                            while ((keyDown(KEY_A)));
                            while (!(keyDown(KEY_START)));
                            while ((keyDown(KEY_START)));
                            drawbitmap3((void*)l103bBitmap);
                            fl = 1;
                        }
                    }
                    if (musici > 1320) {
                        REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
                        REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
                        REG_DM1SAD = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
                        REG_DM1DAD = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
                        REG_DM1CNT_H = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
                        REG_TM0D = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
                        REG_TM0CNT = 0;
                        playSound(3);
                        musici = 0;
                    }
                    if (level == 125) { //////////////////////////////////////////////////////////////////////////////////////////////////////////
                        if ((by < 45)AND(bx > 130)AND(bx < 149)) {
                            if (gravity == 1) {
                                REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
                                REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
                                REG_DM1SAD = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
                                REG_DM1DAD = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
                                REG_DM1CNT_H = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
                                REG_TM0D = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
                                REG_TM0CNT = 0;
                                vsync
                                EraseScreen();
                                SetMode(MODE_4 | BG2_ENABLE);
                                drawbg2((void*)killscreenBitmap, (void*)killscreenPalette);
                                Sleep(512);
                                setbg2((void*)whiteBitmap, (void*)blackPalette);
                                Sleep(256);
                                setbg2((void*)black_finalBitmap, (void*)black_finalPalette);
                                Sleep(256);
                                SaveInt(0, 1);
                                vsync
                                hardreset();
                            }
                            if (end == 0) {
                                drawbitmap3((void*)endeBitmap);
                                end = 1;
                            }
                        }
                    }
                    if (keyDown(KEY_START)) {
                        REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
                        REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
                        REG_DM1SAD = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
                        REG_DM1DAD = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
                        REG_DM1CNT_H = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
                        REG_TM0D = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
                        REG_TM0CNT = 0;
                        s1o = sprites[1].attribute2;
                        s2o = sprites[2].attribute2;
                        s3o = sprites[3].attribute2;
                        s4o = sprites[4].attribute2;
                        s5o = sprites[5].attribute2;
                        s6o = sprites[6].attribute2;
                        pause = 1;
                        while (pause == 1) {
							WaitForVblank();
                            SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
                            setbg2((void*)pauseBitmap, (void*)pausePalette);
                            MoveSprite(&sprites[1], 240, 160);
                            MoveSprite(&sprites[2], 240, 160);
                            MoveSprite(&sprites[3], 240, 160);
                            MoveSprite(&sprites[4], 240, 160);
                            initSprite(6, SIZE_32, RESTART_OAM);
                            initSprite(5, SIZE_32, PLAY_OAM);
                            MoveSprite(&sprites[5], 61, 66);
                            MoveSprite(&sprites[6], 121, 66);
                            CopyOAM();
                            while (!(keyDown(KEY_B))) {
                                if (keyDown(KEY_A)) {
                                    restart = 1;
                                }
                                if (keyDown(KEY_UP)) {
                                    SetMode(MODE_4 | BG2_ENABLE); //Mode 4, BG2 On
                                    FadeOut(15); //Fades Out
                                    vsync //WaitForVblank();
                                    vsync //WaitForVblank();
                                    vsync //WaitForVblank();
                                    REG_IE = 0; //Disables interrupts
                                    REG_INTERUPT = INT_KEYBOARD; //Disables all interrupts except Buttons
                                    REG_IE = 1; //Enables interrupts
                                    REG_DISPCNT = FORCE_BLANK; //Force White screen
                                    while (!((startpressed)AND(selectpressed))); //Waits until Sel+Start are pressed
                                    FadeIn(0); //Instant Fade In
									SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); //Mode 4, BG2 ON, Linear OBJ Tile mapping, OBJ On
                                    REG_IE = 0; //Disables Interrupts
                                    REG_INTERUPT = INT_ALL; // Enables all interrupts
                                    REG_IE = 1; //enables interrupts
                                }
                                if ((keyDown(KEY_L))OR(keyDown(KEY_R))) { //Save Management
                                    int arpos; //Arrow Position
                                    SetMode(MODE_4 | BG2_ENABLE); //Mode 4, BG2 On
                                    FadeOut(2); //Quick Fade Out
                                    setbg2((void*)srammBitmap, (void*)srammPalette); //SRAM Management screen
                                    FadeIn(2); //Quick Fade In
                                    initSprite(5, SIZE_8, 50); //Arrow Sprite
                                    MoveSprite(&sprites[5], 15, 112); //Move Arrow
                                    MoveSprite(&sprites[6], 240, 160); //Moves Sprite 6 offscreen
                                    CopyOAM(); //Copies Object Attributes
                                    SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); //Mode 4, BG2 on, Linear OBJ Tile mapping, OBJ On
                                    while (!(keyDown(KEY_B))) { // B pressed
                                        if (keyDown(KEY_LEFT)) { //Arrow Positions
                                            while (keyDown(KEY_LEFT));
                                            arpos--;
                                        }
                                        if (keyDown(KEY_RIGHT)) {
                                            while (keyDown(KEY_RIGHT));
                                            arpos++;
                                        }
                                        if (arpos < 0) {
                                            arpos = 0;
                                        }
                                        if (arpos > 2) {
                                            arpos = 2;
                                        }
                                        if (arpos == 0) {
                                            MoveSprite(&sprites[5], 15, 112);
                                            if (keyDown(KEY_A)) {
                                                arpos = 0;
                                                SetMode(MODE_4 | BG2_ENABLE); //Mode 4, BG2 ON
                                                FadeOut(2); //Quick Fade Out
                                                setbg2((void*)saveBitmap, (void*)savePalette); //Save Data Screen
                                                FadeIn(2); //Quick Fade In
                                                MoveSprite(&sprites[5], 25, 32); //Arrow
                                                CopyOAM(); //Copies OBJ Attrib
                                                SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); //Mode 4, BG2 on, Linear OBJ Tile mapping, OBJ On
                                                while (!(keyDown(KEY_B))) {
                                                    if (keyDown(KEY_UP)) {
                                                        while (keyDown(KEY_UP));
                                                        arpos--;
                                                    }
                                                    if (keyDown(KEY_DOWN)) {
                                                        while (keyDown(KEY_DOWN));
                                                        arpos++;
                                                    }
                                                    if (arpos < 0) {
                                                        arpos = 0;
                                                    }
                                                    if (arpos > 2) {
                                                        arpos = 2;
                                                    }
                                                    if (arpos == 0) {
                                                        MoveSprite(&sprites[5], 25, 32);
                                                        if (keyDown(KEY_A)) {
                                                            for (i = 0; i != 16; i++) {
                                                                memcpy(SRAM + 0x10 + i, 0xFF, 1);
                                                            }
                                                            SaveInt(0x10, level); //Saves
                                                            SaveInt(0x14, g);
                                                            SaveInt(0x16, gcd);
                                                            SaveInt(0x18, fl);
															SaveInt(0x1A, ed);
                                                        }
                                                    }
                                                    if (arpos == 1) {
                                                        MoveSprite(&sprites[5], 25, 45);
                                                        if (keyDown(KEY_A)) {
                                                            for (i = 0; i != 16; i++) { //saves
                                                                memcpy(SRAM + 0x20 + i, 0xFF, 1);
                                                            }
                                                            SaveInt(0x20, level);
                                                            SaveInt(0x24, g);
                                                            SaveInt(0x26, gcd);
                                                            SaveInt(0x28, fl);
															SaveInt(0x2A, ed);
                                                        }
                                                    }
                                                    if (arpos == 2) {
                                                        MoveSprite(&sprites[5], 25, 58); //Arrow Position
                                                        if (keyDown(KEY_A)) {
                                                            for (i = 0; i != 16; i++) {
                                                                memcpy(SRAM + 0x30 + i, 0xFF, 1); //Saves
                                                            }
                                                            SaveInt(0x30, level); //Saves
                                                            SaveInt(0x34, g);
                                                            SaveInt(0x36, gcd);
                                                            SaveInt(0x38, fl);
															SaveInt(0x3A, ed);
                                                        }
                                                    }
                                                    CopyOAM(); //COpies OBJ Attrib
                                                }
                                            }
                                        }
                                        if (arpos == 1) { //Load
                                            MoveSprite(&sprites[5], 94, 112);
                                            if (keyDown(KEY_A)) {
                                                arpos = 0;
                                                SetMode(MODE_4 | BG2_ENABLE);
                                                FadeOut(2);
                                                setbg2((void*)loadBitmap, (void*)loadPalette);
                                                FadeIn(2);
                                                MoveSprite(&sprites[5], 25, 32);
                                                CopyOAM();
                                                SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
                                                while (!(keyDown(KEY_B))) {
                                                    if (keyDown(KEY_UP)) {
                                                        while (keyDown(KEY_UP));
                                                        arpos--;
                                                    }
                                                    if (keyDown(KEY_DOWN)) {
                                                        while (keyDown(KEY_DOWN));
                                                        arpos++;
                                                    }
                                                    if (arpos < 0) {
                                                        arpos = 0;
                                                    }
                                                    if (arpos > 2) {
                                                        arpos = 2;
                                                    }
                                                    if (arpos == 0) {
                                                        MoveSprite(&sprites[5], 25, 32);
                                                        if (keyDown(KEY_A)) {
                                                            g2 = g;
                                                            gcd2 = gcd;
                                                            fl2 = fl;
                                                            lv2 = level;
															ea2 = ed;
                                                            level = LoadInt(0x10);
                                                            g = LoadInt(0x14);
                                                            gcd = LoadInt(0x16);
                                                            fl = LoadInt(0x18);
															ed = LoadInt(0x1A);
                                                            if (level == 0) {
                                                                level = lv2;
                                                                fl = fl2;
                                                                gcd = gcd2;
                                                                g = g2;
																ed = ea2;
                                                            }
                                                            varreset();
                                                        }
                                                    }
                                                    if (arpos == 1) {
                                                        MoveSprite(&sprites[5], 25, 45);
                                                        if (keyDown(KEY_A)) {
                                                            g2 = g;
                                                            gcd2 = gcd;
                                                            fl2 = fl;
                                                            lv2 = level;
															ea2 = ed;
                                                            level = LoadInt(0x20);
                                                            g = LoadInt(0x24);
                                                            gcd = LoadInt(0x26);
                                                            fl = LoadInt(0x28);
															ed = LoadInt(0x2A);
                                                            if (level == 0) {
																level = lv2;
																fl = fl2;
																gcd = gcd2;
																g = g2;
																ed = ea2;
                                                            }
                                                            varreset();
                                                        }
                                                    }
                                                    if (arpos == 2) {
                                                        MoveSprite(&sprites[5], 25, 58);
                                                        if (keyDown(KEY_A)) {
															g2 = g;
															gcd2 = gcd;
															fl2 = fl;
															lv2 = level;
															ea2 = ed;
															level = LoadInt(0x30);
															g = LoadInt(0x34);
															gcd = LoadInt(0x36);
															fl = LoadInt(0x38);
															ed = LoadInt(0x3A);
															if (level == 0) {
																level = lv2;
																fl = fl2;
																gcd = gcd2;
																g = g2;
																ed = ea2;
															}
                                                            varreset();
                                                        }
                                                    }
                                                    CopyOAM();
                                                }
                                            }
                                        }
                                        if (arpos == 2) { //Erase
                                            MoveSprite(&sprites[5], 173, 112);
                                            if (keyDown(KEY_A)) {
                                                arpos = 0;
                                                SetMode(MODE_4 | BG2_ENABLE);
                                                FadeOut(2);
                                                setbg2((void*)eraseBitmap, (void*)erasePalette);
                                                FadeIn(2);
                                                MoveSprite(&sprites[5], 25, 32);
                                                CopyOAM();
                                                SetMode(MODE_4 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D);
                                                while (!(keyDown(KEY_B))) {
                                                    if (keyDown(KEY_UP)) {
                                                        while (keyDown(KEY_UP));
                                                        arpos--;
                                                    }
                                                    if (keyDown(KEY_DOWN)) {
                                                        while (keyDown(KEY_DOWN));
                                                        arpos++;
                                                    }
                                                    if (arpos < 0) {
                                                        arpos = 0;
                                                    }
                                                    if (arpos > 2) {
                                                        arpos = 2;
                                                    }
                                                    if (arpos == 0) {
                                                        MoveSprite(&sprites[5], 25, 32);
                                                        if (keyDown(KEY_A)) {
                                                            for (i = 0; i != 16; i++) {
                                                                memcpy(SRAM + 0x10, 0x06000ED0, 16);
                                                            }
                                                        }
                                                    }
                                                    if (arpos == 1) {
                                                        MoveSprite(&sprites[5], 25, 45);
                                                        if (keyDown(KEY_A)) {
                                                            for (i = 0; i != 16; i++) {
                                                                memcpy(SRAM + 0x20, 0x06000ED0, 16);
                                                            }
                                                        }
                                                    }
                                                    if (arpos == 2) {
                                                        MoveSprite(&sprites[5], 25, 58);
                                                        if (keyDown(KEY_A)) {
                                                            memcpy(SRAM + 0x30, 0x06000ED0, 16);

                                                        }
                                                    }
                                                    CopyOAM(); //Copies OBJ Attrib
                                                }
                                            }
                                        }
                                        CopyOAM(); //Copies OBJ Attrib
                                    }
                                }
                            }
                            pause = 0; //Exits Pause
							SetMode(MODE_4 | BG2_ENABLE); //Mode 4, BG2 On
                            sprites[4].attribute0 = COLOR_256 | WIDE | 240; //Slot 4: Version Counter (64x32)
                            sprites[4].attribute1 = SIZE_64 | 160;
                            sprites[4].attribute2 = 512 + 280;
                            MoveSprite(&sprites[4], 0, 152); //Version pos
                            MoveSprite(&sprites[2], 223, 128); //Goal Pos
							MoveSprite(&sprites[5],240,160); //Spr5 Offscreen
							MoveSprite(&sprites[6], 240,160); //Spr6 Offscreen
                            updateSprite(1, 0, SIZE_32, 1); //Block
                            updateSprite(2, 48, SIZE_8, 1); //Goal
                            sprites[3].attribute0 = COLOR_256 | WIDE | 240; //Slot 3: Fireball (32x16)
                            sprites[3].attribute1 = SIZE_32 | 160;
                            sprites[3].attribute2 = 512 + 32;
                            sprites[4].attribute0 = COLOR_256 | WIDE | 240; //Slot 4: Version Counter (64x32)
                            sprites[4].attribute1 = SIZE_64 | 160;
                            sprites[4].attribute2 = 512 + 280;
                            updateSprite(5, s5o, SIZE_8, 1); //Spr5
                            updateSprite(6, s6o, SIZE_8, 1); //Spr6
                            MoveSprite(&sprites[4], 0, 152);
                            FadeOut(2); //Quick Fade In
                            levels(); //Level Draw
                            if (level == 103) {
                                if (fl == 1) {
                                    drawbitmap3((void*)l103bBitmap);
                                }
                            }
                            else if (level == 85) {
                                if (gcd == 1) {
                                    drawbitmap3((void*)l85bBitmap);
                                }
                            }
							CopyOAM();
							SetMode(MODE_3 | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_1D); //Mode 3, BG2 on, Linear OBJ Tile mapping, OBJ On
                            FadeIn(2);
                            musici = 0;
                            playSound(3);
                        }
                    }
					if (devmode == 1) //For Developers, Hold R to activate this as the game does the beginning slow fade.
					{
						sprintf(buf, "%d,%d ", bx, by);
						Print(-1, 0, buf, RED, BLACK);
						if (keyDown(KEY_L))
						{
							level--;
							levels();
							varreset();
						}
						if (keyDown(KEY_R))
						{
							level++;
							levels();
							varreset();
						}
					}
                    newframe = 1; //Better VSync
                }
                if (REG_VCOUNT>160) { //Better VSync
                    newframe = 0;
                    CopyOAM();
                }
            }
        }
    }
    return 0;
}

void vblfunc()
{
    CopyOAM(); //Copies OBJ Attrib
}