//C:\Users\nickm\Desktop\Code\Game Boy Advance\Super Block Jump Demake\files\data\allobjs\gocrew.bmp
//Converti avec GBA Graphics par Br�nni
//Map ("","C:\Users\nickm\Desktop\Code\Game Boy Advance\Super Block Jump Demake\files\data\allobjs\gocrew.til.c",0,ffffffff)
//Taille: 64*64 * 1*1
//M�moire: 2 octets

const unsigned short gocrew_map[1][1]=	{
	{0x0000}
};
