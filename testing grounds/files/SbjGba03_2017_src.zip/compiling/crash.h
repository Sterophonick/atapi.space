void trigger() {
	if (crash == 1) {
		playsound(1);
		Sleep(1000);
		playsound(1);
	}
}