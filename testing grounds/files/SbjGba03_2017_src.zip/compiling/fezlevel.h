#define waituntil(n) while(!(n))
void fezlevel(){
while (level == 103) {
	while(NOT(keyDown(KEY_UP)));
	while(keyDown(KEY_UP));
	while(NOT(keyDown(KEY_UP)));
	while(keyDown(KEY_UP));
	while(NOT(keyDown(KEY_DOWN)));
	while(keyDown(KEY_DOWN));
	while(NOT(keyDown(KEY_DOWN)));
	while(keyDown(KEY_DOWN));
	while(NOT(keyDown(KEY_LEFT)));
	while(keyDown(KEY_LEFT));
	while(NOT(keyDown(KEY_RIGHT)));
	while(keyDown(KEY_RIGHT));
	while(NOT(keyDown(KEY_LEFT)));
	while(keyDown(KEY_LEFT));
	while(NOT(keyDown(KEY_RIGHT)));
	while(keyDown(KEY_RIGHT));
	while(NOT(keyDown(KEY_B)));
	while(keyDown(KEY_B));
	while(NOT(keyDown(KEY_A)));
	while(keyDown(KEY_A));
	while(NOT(keyDown(KEY_START)));
	while(keyDown(KEY_START));
	drawbitmap3((void*)l103bBitmap);
      }
 playsound(1);
}
