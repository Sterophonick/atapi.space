void spike()
{
		if(sd==1)
		{			
			MoveSprite(&sprites[9], 128, sy);
			if(NOT(sy<0))
			{
				sy-=4;
			}else{
				sd=0;
			}
		}else{
			MoveSprite(&sprites[9], 128, sy);
			if(NOT(sy>81))
			{
				sy+=4;
			}else{
				sd=1;
			}
		}
		if((bx>104)AND(bx<160)AND(by<sy+64))
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
}