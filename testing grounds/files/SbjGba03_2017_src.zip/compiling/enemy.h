


void enemybehavior()
{
	if((ed==1)AND(ea==0))
	{
		sprites[5].attribute1 = SIZE_64 | 160;
		MoveSprite(&sprites[5], ex, 81);
		if(NOT(ex<64))
		{
			ex-=3;
		}else{
			ed=0;
		}
	}else if(ea==0){
		sprites[5].attribute1 = SIZE_64 | HORIZONTAL_FLIP | 160;
		MoveSprite(&sprites[5], ex, 81);
		if(NOT(ex>160))
		{
			ex+=3;
		}else{
			ed=1;
		}
	}
	if((fx>ex-32)AND(NOT(ea==1)))
	{
		fb=0;
		ea=1;
		MoveSprite(&sprites[3], 240, 160);
		MoveSprite(&sprites[5], 240, 160);
	}
}

