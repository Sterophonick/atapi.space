void gravidetect() {
	if ((level == 43)OR(level == 44)OR(level == 45)OR(level == 46)OR(level == 47)OR(level == 48))
	{
		if(keyDown(KEY_SELECT))
		{
			gravity = 1;
			while(!(keyDown(KEY_SELECT)));
		}
		if((keyDown(KEY_SELECT))AND(gravity==1))
		{
			gravity = 0;
			while(!(keyDown(KEY_SELECT)));
		}
	}
}