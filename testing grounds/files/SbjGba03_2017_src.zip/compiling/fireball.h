void fireballbehavior() {
	if((keyDown(KEY_B))AND(g==1))
	{
		fb=1;
		fy=by+4;
		fx=bx;
	}
	if((fb==1)AND(NOT(fx>240)))
	{
		fx+=5;
		MoveSprite(&sprites[3], fx, fy);
	}
}
