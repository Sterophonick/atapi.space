/* Main source file for Super Block Jump Game Boy Advance Edition */

//variables
int start = 0;
int g = 0;
int nostart = 1;
int level = 1;
int menu = 0;
int crash=0;
int wait;
int complete3;
int bx=17,by=128;
double x = 0;
double y = 0;
int deaths = 0;
int time = 0;
int gravity = 0;
int restart = 0;
int hazardcollision = 0;
int tramp = 0;
int pookacollision = 0;
int collision=0;
int fx,fy,fb;
int endcoll;
int pause,hit,charactercollision,ex,ea,ed,em,gm,tm,td,td2,ty,ty2,sm,sy,sd,fezaud,gcd,alock,block,sellock;
#define BLOCK_OAM 0
#define GOAL_OAM 48
#define GEM_OAM 296
#define FIREBALL_OAM 32
#define VERSION_OAM 280
#define JUMPREFRESHER_OAM 56
#define PLAY_OAM 88
#define PONG_OAM 120
#define RESTART_OAM 152
#define SPIKE_OAM 184
#define TINFOIL_OAM 120
#define ENEMY_OAM 360

//includes
#include <agb_lib.h> //main function library (that I made)
#include "backgrounds.h" //all the non-level backgrounds
#include "allobjs.h" //all the sprites and animations
#include "levels.h" //all the levels
#include "music.h" //the music data
#include "sounds.h" //all the sound data
#include "soundinit.h" //the initializing of all the sounds
#include "morebackgrounds.h" //more backgrounds
#include "rotostuff.h" //frames for spinning logo
#include "block.h" //the main controls for the block
#include "crash.h" //the main DISPCNT for the crash sequence
#include "enemy.h" //the control for the enemy
#include "epicgem.h" //the control for the gem
#include "fezlevel.h" //the FEZ Level DISPCNT
#include "fireball.h" //the fireball control
#include "go-crew.h" //the go-crew control
#include "levelchange.h" //the DISPCNT for changing levels
#include "theend.h" //end control
#include "tinfoil.h" //tinfoil control
#include "gravity.h" //gravity control
#include "spike.h" //spike control



int main() //agbmain
{
	SaveInt(0, 7.55);
	int s;
	initsound8(1, 22050, 2801, (void*)logotheme);
 	initsound8(2, 22050, 2801, (void*)punch);
	initsound8(3, 22050, 2801, (void*)music);
	Initialize(); //beginning fade
	bgPic2Buffer((void*)discliamerBitmap); //disclaimer
	bgPal((void*)discliamerPalette);
	bgPic((void*)discliamerBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		Sleep(1);
	}
	FadeOut(2);
	bgPic2Buffer((void*)thxBitmap); //special thanks
	bgPal((void*)thxPalette);
	bgPic((void*)thxBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		Sleep(1);
	}
	FadeOut(2);
	bgPic2Buffer((void*)scratchBitmap); //scratch
	bgPal((void*)scratchPalette);
	bgPic((void*)scratchBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		Sleep(1);
	}
	FadeOut(2);
	bgPic2Buffer((void*)gbadevBitmap); //GBADEV logo
	bgPal((void*)gbadevPalette);
	bgPic((void*)gbadevBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		Sleep(1);
	}
	FadeOut(2);
	bgPic2Buffer((void*)imadog54Bitmap); //meh
	bgPal((void*)imadog54Palette);
	bgPic((void*)imadog54Bitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		Sleep(1);
	}
	FadeOut(2);
	bgPic2Buffer((void*)slyangelBitmap); //meh good brah
	bgPal((void*)slyangelPalette);
	bgPic((void*)slyangelBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		Sleep(1);
	}
	FadeOut(2);
	setbg2((void*)titlescreenBitmap, (void*)titlescreenPalette);  //title
	FadeIn(2);
	while(!(keyDown(KEY_START)))
	{
		wait = 0;
	}
	sound[1].tic=1;
	s=1;
	playSound(1); //play logotheme.wav
		setbg2((void*)roto0Bitmap, (void*)roto0Palette); //logospin
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(0.5);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(0.5);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(0.5);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(0.5);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(0.5);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(0.5);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(0.5);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(0.5);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(0.5);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(0.5);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(0.5);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(0.5);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(0.5);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(0.5);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(0.5);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(0.5);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(0.5);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(0.5);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(0.5);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(0.5);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(0.5);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(0.5);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(0.5);
		playSound(2);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(0.5);
	SetPalette((void*)bgtwoPalette); //other thing
	REG_DM3SAD = (unsigned long)bgtwoBitmap;
	REG_DM3DAD = (unsigned long)VideoBuffer;
	REG_DM3CNT = 0x80000000 | 120*160;
	setbg2((void*)bgtwoBitmap, (void*)bgtwoPalette);
	Sleep(10);
	while(1) //main loop for menu
	{
		if(keyDown(KEY_SELECT))	
		{
			FadeOut(2);
			setbg2((void*)controlspage1Bitmap, (void*)controlspage1Palette);
			FadeIn(2);
			while(!(keyDown(KEY_A)))
			{
				wait = 0;
			}
			while(keyDown(KEY_A))
			{
				wait = 0;
			}
			FadeOut(2);
			setbg2((void*)controlspage2Bitmap, (void*)controlspage2Palette);
			FadeIn(2);
			while(!(keyDown(KEY_A)))
			{
				wait = 0;
			}
			while(keyDown(KEY_A))
			{
				wait = 0;
			}
			FadeOut(2);
			setbg2((void*)bgtwoBitmap, (void*)bgtwoPalette);
			FadeIn(2);
		}
		if(keyDown(KEY_START))
		{
			FadeOut(15);
			loadSpriteGraphics((void*)allobjsData, 11904);
			loadSpritePal((void*)allobjsPalette);
			initSprite(1, SIZE_32, 0); //block
			initSprite(2, SIZE_8, 48); //goal
			sprites[3].attribute0 = COLOR_256 | WIDE | 240;//fireball
			sprites[3].attribute1 = SIZE_32 | 160;
			sprites[3].attribute2 = 512 + 32; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd 
			sprites[4].attribute0 = COLOR_256 | WIDE | 240;
			sprites[4].attribute1 = SIZE_64 | 160;	
			sprites[4].attribute2 = 512 + 280; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
			initSprite(5, SIZE_64, 360);
			sprites[6].attribute0 = COLOR_256 | WIDE | 240;
			sprites[6].attribute1 = SIZE_64 | 160;
			sprites[6].attribute2 = 512 + 296; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
			initSprite(7, SIZE_32, 248);
			cloneSprite(7, 8);
			sprites[9].attribute0 = COLOR_256 | TALL | 240;
			sprites[9].attribute1 = SIZE_64 | 160;
			sprites[9].attribute2 = 512 + 184; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
			initSprite(10, SIZE_32, 56);
			initSprite(11, SIZE_32, PLAY_OAM); //playbutton
			initSprite(12, SIZE_32, RESTART_OAM); //restartbutton
			FadeIn(15);
			playSound(3);
			while(1)
			{
	while (NOT(crash==1)) {
		while(NOT(pause == 1)) {
			WaitForVblank();
     			playSound(17);
   			startblock();
     			levels();
     			init();
			if(level==61)
			{
				if(em==0)
				{
					MoveSprite(&sprites[5], 64, 81);
					em=1;
				}
				enemybehavior();
			}
			if(level==58)
			{
				if(gm==0)
				{
					MoveSprite(&sprites[6], 98, 66);
					gm=1;
				}
				gembehave();
			}
			MoveSprite(&sprites[2], 223, 128);
			if(level==49)
			{
				if(tm==0)
				{
					MoveSprite(&sprites[7], 64, 66);
					MoveSprite(&sprites[8], 98, 48);
					tm=1;
				}
				tinfoil();
			}else{
				MoveSprite(&sprites[7], 240, 160);
				MoveSprite(&sprites[8], 240, 160);
			}
			if(level==50)
			{
				if(sm==0)
				{
					MoveSprite(&sprites[9], 98, 66);
					sm=1;
				}
				spike();
			}else{
				MoveSprite(&sprites[9], 240, 160);
			}
			if((level==55)OR(level=56))
			{
				if((bx>80)AND(by>40)AND(bx<136)AND(by<96))
				{
					if(keyDown(KEY_A))
					{
						y=-3.85;
					}
				}
			}else{
				MoveSprite(&sprites[10], 240, 160);
			}
			if(keyDown(KEY_B))
			{
				fb=1;
				fy=by+4;
				fx=bx;
			}
			if((fb==1)AND(NOT(fx>240)))
			{
				fx+=5;
				MoveSprite(&sprites[3], fx, fy);
			}
			gocrew();
     		}
		}
    	}
			}
		}
		REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 		REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 		REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 		REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  		REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   		REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  		REG_TM0CNT    = 0;   
	}
	return 0;
}
                                                         
