void gembehave(){
	if((bx>74)AND(by<94)AND(bx<141)AND(by>42)AND(g=0))
	{
		MoveSprite(&sprites[6], 240, 160);
		g=1;
	}
}
