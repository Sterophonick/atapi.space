

void tinfoil()
{
		if(td==1)
		{			
			MoveSprite(&sprites[7], 128, ty);
			if(NOT(ty<0))
			{
				ty-=4;
			}else{
				td=0;
			}
		}else{

			MoveSprite(&sprites[7], 128, ty);
			if(NOT(ty>113))
			{
				ty+=4;
			}else{
				td=1;
			}
		}
		if(td2==1)
		{			
			MoveSprite(&sprites[8], 64, ty2);
			if(NOT(ty2<0))
			{
				ty2-=3;
			}else{
				td2=0;
			}
		}else{
			MoveSprite(&sprites[8], 64, ty2);
			if(NOT(ty2>113))
			{
				ty2+=3;
			}else{
				td2=1;
			}
		}
		if(((bx>104)AND(bx<160)AND(by<ty+32))OR((bx>40)AND(bx<96)AND(by<ty2+32)))
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
}