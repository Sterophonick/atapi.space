void end() {
     bx=0;
}
     
