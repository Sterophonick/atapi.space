
void gocrew()
{
	if(level==85)
	{
		if((fx>45)AND(NOT(gcd==1)))
		{
			sprites[3].attribute0 = COLOR_256 | SQUARE | 160;
			sprites[3].attribute1 = SIZE_8 | 240;
			sprites[3].attribute2 = 512 + 32; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

			drawbitmap3((void*)l85bBitmap);
			MoveSprite(&sprites[3], 240, 160);
			fb=0;
			gcd=1;
		}
		if((gcd==0)AND(bx>64))
		{
			bx=8;by=108;
		}
	}
}