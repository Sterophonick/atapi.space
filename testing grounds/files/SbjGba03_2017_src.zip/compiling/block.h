void varreset() {
bx=17,by=128;
x = 0;
y = 0;
deaths = 0;
time = 0;
gravity = 0;
restart = 0;
}

    void var_y(int16 number){
         if (gravity == 0){
                     y += number;
         } else {
                y -= number;
         }
		}
             void changey(int16 number){
         if (gravity == 0){
                     by += number;
         } else {
                by -= number;
         }
	}
                      void sety(int16 number){
         if (gravity == 0){
                     y = number;
         } else {
                y = (number * 2) - number;
         }
	}
         void die() {
              	int bx=17,by=128;
              	x = 0;
              	y = 0;
              	playSound(1);
              	restart = 0;
		gravity = 0;
        }
    void physics() {
    	CopyOAM();
	MoveSprite(&sprites[1], bx, by);
        y += -0.5;
	if (keyDown(KEY_RIGHT)) {
		x += 0.5;
        }
        if (keyDown(KEY_LEFT)) {
			x += -0.5;
        }
        x = (x * 0.9);
        bx += x;
        if (collision == 1) {
           changey(1);
           if (collision == 1) {
				changey(1);
				if (collision == 1) {
					changey(1);
					if (collision == 1) {
						changey(1);
						if (collision == 1) {
							changey(1);
							if (collision == 1) {
								changey(1);
								if (collision == 1) {
									changey(-6);
									bx += (x * -1);
									if (keyDown(KEY_A)) {
										if (x >= 0) {
											x = -10;
										}else {
											x = 10;
										}
										time = 2.9;
										while ((keyDown(KEY_A))OR(NOT(time <= 4.2))){
											time += .4;
											y = time;
											by += y;
											by -= 0.5;
											if (keyDown(KEY_RIGHT)) {
												x += 0.5;
											}
											if (keyDown(KEY_LEFT)) {
												x += -0.5;
											}
											x = (x * 0.9);
											bx += x;
											if (collision == 1) {
												bx += (x * -1);
											}
											if (collision == 1) {
												by += (y * -1); 
												y = 0;
											}else {
                                                x = 0;
											}	                                                  
												}
											}
										}
									}
								}
							}
						}           
						changey(y);
           			    if (collision == 1) {
							by += (y * -1); 
							y = 0;
						}
						by -= 0.5;
						if (keyDown(KEY_A)) {
							time = 2.9;
						while ((keyDown(KEY_A))OR(time <= 4.2)) {
							time += .4;
							y = time;
							by += y;
							by -= 0.5;
						if (keyDown(KEY_RIGHT)) {
							x += .48;
						}
						if (keyDown(KEY_LEFT)) {
							x += -.48;
						}
						x = x * 0.9;
						bx += x;
						if (collision == 1) {
                            bx += (x * -1);
                        }
                        if (collision == 1) {
                            by += (y * -1); 
                            y = 0;
                        }
                        }
			if (hazardcollision == 1) {
                            die();              
                        }
			if (pookacollision == 1) {
                           die();
                        }
                        if(bx>240-12){die();}                                    //deadly edge
                        if(by>160-12){die();}                                   //deadly edge
                        if(bx>0+12){die();}                                    //deadly edge
                        if(by>0+12){die();}                                   //deadly edge
                        if (restart == 1) {
                           die();
                        }
                        if (endcoll == 1) {
                           die();
                        }  	
		}	
	}	
}
					   
void startblock() {
	while(1){
		if (NOT(pause == 1)) {
			physics();
		}
	}
}
