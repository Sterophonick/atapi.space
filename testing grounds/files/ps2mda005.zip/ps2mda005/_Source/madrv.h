#ifndef madrv_h
#define madrv_h

#include "boolean.h"

#define madrv_ChannelCount 16

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram // ROM��Ŏ��s����Ƃ��͂�����

typedef struct {
  u8 myChNo;
  b8 myOPM;
  
  b8 Enabled; // False=End True=Playing
  u8 *Buffer;
  u32 MMLSize;
  u8 *Cmd;
  b8 Looped; // False=NotLoop True=Looped
  u32 NowPos;
  u8 NowVoice;
  u8 NowKeycode;
  u8 NowPanpot;
  u8 ExtPanpot;
  s32 NowPortament;
  u8 ADPCMMode;
  u32 LastPitch;

  u16 RestClock,StopClock;
  u8 LoopCount[256];
  u8 LoopMax;

  b8 Noteon;
  u8 Volume;
  b8 VolMode;
  u8 RealVolume;
  u16 Quartz;
  b8 QuartzMode; // False=Clk*n/8 True=Clk-n
  b8 KeyoffMode; // Next Keyon is False=Disabled True=Enabled
  s32 Detune,Portament;
  u8 KeyonDelay;
  
  u8 SLFODelay; // Delay
  u8 SLFONowDelay; // Start Delay Count

  b8 MPEnabled;
  u8 MPWaveType; // 0=���` 1=��`�g 2=�O�p�g
  u16 MPFreq;
  s32 MPDisplace;
  s32 MPNowDisplace;
  u16 MPNowFreq;
  s32 MPNowDetune;

  b8 MAEnabled;
  u8 MAWaveType; // 0=���` 1=��`�g 2=�O�p�g
  u16 MAFreq;
  s32 MADisplace;
  s32 MANowDisplace;
  u16 MANowFreq;
  s32 MANowDetune;

  b8 forVis_Noteon;
} Tmadrv_Channel;

typedef struct {
  u32 TotalClock;
  u8 Tempo;
  u32 Timer64Tempo;
  u8 LoopCount;
  b8 EndFlag;
  
  u16 NR10,NR11,NR12;
  u16 NR21,NR22;
  u16 NR42,NR43;
} Tmadrv_MDA;

extern attriwram void madrv_Handler(void);

extern void madrv_ClearData(void);
extern b8 madrv_LoadMDA2(u8 *buf);
extern u8* madrv_GetTitle(void);
extern u8* madrv_GetComment(void);
extern void madrv_MDARegisterInit(void);
extern void madrv_GBRegisterInit(void);
extern void madrv_AllNoteoff(void);

// --- debug

extern Tmadrv_MDA MDA;
extern Tmadrv_Channel MDAch[madrv_ChannelCount];
extern Tmadrv_Channel *pch; // �������`�����l��

#endif
