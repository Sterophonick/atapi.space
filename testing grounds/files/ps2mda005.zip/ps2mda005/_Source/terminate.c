
void terminate_dummy(void)
{
}
