
void wm_bootsplash_init(void);
void wm_bootsplash_MainLoop(void);
void wm_bootsplash_IRQ_VBlank(void);
void wm_bootsplash_IRQ_Timer3(void);

void wm_bootsplash_init(void)
{
  REG_DISPCNT=MODE_1;
  
  u32 x,y;
  x=(240-160)/2-8;
  y=160-32-8;
  
  ChangeSprite(0,0x00);
  SetSpriteSize(0,SP_SIZE_64,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(0,SP_MODE_TRANSPERANT);
  SetSpriteRotation(0,False);
  SetSpritePriority(0,0);
  MoveSprite(0,x+64*0,y);
  ChangeSprite(1,0x10);
  SetSpriteSize(1,SP_SIZE_64,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(1,SP_MODE_TRANSPERANT);
  SetSpriteRotation(1,False);
  SetSpritePriority(1,0);
  MoveSprite(1,x+64*1,y);
  ChangeSprite(2,0x80);
  SetSpriteSize(2,SP_SIZE_64,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(2,SP_MODE_TRANSPERANT);
  SetSpriteRotation(2,False);
  SetSpritePriority(2,0);
  MoveSprite(2,x+64*2,y);

  ChangeSprite(3,0x100);
  SetSpriteSize(3,SP_SIZE_32,SP_SQUARE,SP_COLOR_256);
  SetSpriteMode(3,SP_MODE_TRANSPERANT);
  SetSpriteRotation(3,False);
  SetSpritePriority(3,0);
  MoveSprite(3,240-32-8,y);
  
  REG_DISPCNT|=OBJ_ENABLE | OBJ_MAP_2D;
}

u32 IconIdx;

b8 inside(void)
{
  if(IconIdx==0){
    IconIdx=31;
    }else{
    IconIdx--;
  }
  ChangeSprite(3,0x100+((IconIdx/2%4)*8)+((IconIdx/2/4)*32*4));

  u16 loadkeys;
  loadkeys=(~*KEYS)&0x3ff;
  
  if(loadkeys==0){
    return(True);
  }
  
  return(False);
}

void wm_bootsplash_MainLoop(void)
{
  REG_BLDMOD = BLEND_TOP_OBJ | BLEND_MODE_DARK ;
  
  u32 BGFade,cnt;
  IconIdx=15;
  
  for(BGFade=16;BGFade!=0;BGFade--){
    REG_COLEY = BLEND_DEPTH(BGFade);
    WaitForVsync();
    if(inside()==True){
      wm_ChangeTo=wm_Player;
      wm_ChangeFlag=True;
      return;
    }
  }
  
  while(1){
    WaitForVsync();
    if(inside()==True) break;
  }
  
  for(BGFade=0;BGFade!=16;BGFade++){
    REG_COLEY = BLEND_DEPTH(BGFade);
    WaitForVsync();
  }

  wm_ChangeTo=wm_Player;
  wm_ChangeFlag=True;
}

void wm_bootsplash_IRQ_VBlank(void)
{
}

void wm_bootsplash_IRQ_Timer3(void)
{
  CPUFree=0;
}
