#include "header\GBA.h"
#include "header\BG.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\IRQ.h"
#include "header\sprite.h"
#include "header\blend.h"
#include "header\sound.h"

//#include "debug.c"

#include "pcmstream.h"
#include "madrv.h"
#include "boolean.h"
#include "sram_rw.h"

#include "BGChrImg\BGChrImg.h"

#include "pogoshell2_args.c"

#define wm_NULL 0
#define wm_BootSplash 1
#define wm_Player 2

b8 wm_ChangeFlag;
u8 wm_ChangeTo;
u8 wm_Current;

void (*wm_fp_MainLoop)(void);

u32 CPUFree;

#include "interrupt.c"
#include "GBATools.c"
#include "main_global.c"
#include "main_img.c"
#include "main_wm_bootsplash.c"
#include "main_wm_player.c"

void StartMADRV(void);
void StopMADRV(void);

int main(void)
{
  REG_DISPCNT=MODE_1;

  if(sram_isFirstBoot()==True){
    InitSRAM();
    SaveSRAM();
    }else{
    LoadSRAM();
  }
  
  InitializeSprites();
  SetOAMCHR(512,(u16*)OAM_data,(u16*)OAM_palette);
  
  sndbuf_Init();
  sndbuf_StartPCM();
  
  madrv_ClearData();
  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
  
  CPUFree=0;

  // �P�b�^�C�}�[16384clk
  REG_TM3CNT = 0;
  REG_TM3D=0x10000-16384;
  REG_TM3CNT = TM_FREQ_PER_1024 | TM_ENABLE | TM_USEIRQ;

  IRQTable[IRQIndex_DMA1]=(u32)sndbuf_DMA1_Handler;
  IRQTable[IRQIndex_VBlank]=(u32)IRQ_Dummy;
  IRQTable[IRQIndex_Timer2]=(u32)madrv_Handler;
  IRQTable[IRQIndex_Timer3]=(u32)IRQ_Dummy;
  IRQ_Setup(IRQ_BIT_TIMER2 | IRQ_BIT_TIMER3 | IRQ_BIT_DMA1 | IRQ_BIT_VBLANK, DSTAT_USE_VBLANK);

  wm_Current=wm_NULL;
  wm_ChangeTo=wm_BootSplash;
  wm_ChangeFlag=True;

  while(1){
    if(wm_ChangeFlag==True){
      wm_Current=wm_ChangeTo;
      wm_ChangeTo=wm_NULL;
      wm_ChangeFlag=False;
      switch(wm_Current){
        case wm_BootSplash:
          wm_bootsplash_init();
          wm_fp_MainLoop=wm_bootsplash_MainLoop;
          IRQTable[IRQIndex_VBlank]=(u32)wm_bootsplash_IRQ_VBlank;
          IRQTable[IRQIndex_Timer3]=(u32)wm_bootsplash_IRQ_Timer3;
          break;
        case wm_Player:
          StartMADRV();
          wm_player_init();
          wm_fp_MainLoop=wm_player_MainLoop;
          IRQTable[IRQIndex_VBlank]=(u32)wm_player_IRQ_VBlank;
          IRQTable[IRQIndex_Timer3]=(u32)wm_player_IRQ_Timer3;
          break;
      }
    }
    
    wm_fp_MainLoop();
    CPUFree++;
  }
}

extern u8 __iwram_overlay_lma;

void StartMADRV(void)
{
  REG_TM2CNT=TM_FREQ_PER_64 | TM_USEIRQ;
  REG_TM2D=0;
  
  madrv_ClearData();
  if(madrv_LoadMDA2(&__iwram_overlay_lma)==True){
    ps2ArgDataPtr=(u8*)&__iwram_overlay_lma;
    ps2ArgDataSize=0;
    }else{
    if(GetPogoShell2Args()==True){
      madrv_LoadMDA2(ps2ArgDataPtr);
      }else{
      return;
    }
  }

  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
}

void StopMADRV(void)
{
  REG_TM2CNT&=~TM_ENABLE;
  REG_TM2D=0;

  madrv_AllNoteoff();
  madrv_ClearData();
  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
}

