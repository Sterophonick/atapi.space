
#include "string.h"
#include "varargs.h"

typedef unsigned char du8;
typedef unsigned short du16;
typedef unsigned long du32;

typedef signed char ds8;
typedef signed short ds16;
typedef signed long ds32;
typedef signed long long int ds64;

extern du8 __iwram_overlay_start;

extern du8 resprintf[128];
//extern void uprintf(...);
extern void dprint(const char *sz);

extern void memchkinit(void);
extern du32 memchk(void);

