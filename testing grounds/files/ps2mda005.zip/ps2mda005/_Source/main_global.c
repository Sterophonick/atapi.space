
#define ADR_BGCHR0  0/16
#define ADR_BGMAP0  2/ 2
#define ADR_BGCHR1 16/16
#define ADR_BGMAP1  4/ 2
#define ADR_BGCHR2 32/16
#define ADR_BGMAP2 12/ 2
#define ADR_BGCHR3  0/16
#define ADR_BGMAP3  0/ 2

// BG�A�h���X
u16 *BGPAL = MEM_BG_PAL;
u16 *BGCHR0 = MEM_BG_CHAR(ADR_BGCHR0);
u16 *BGMAP0 = MEM_BG_MAP(ADR_BGMAP0);
u16 *BGCHR1 = MEM_BG_CHAR(ADR_BGCHR1);
u16 *BGMAP1 = MEM_BG_MAP(ADR_BGMAP1);
u16 *BGCHR2 = MEM_BG_CHAR(ADR_BGCHR2);
u16 *BGMAP2 = MEM_BG_MAP(ADR_BGMAP2);
u16 *BGCHR3 = MEM_BG_CHAR(ADR_BGCHR3);
u16 *BGMAP3 = MEM_BG_MAP(ADR_BGMAP3);

// BG0 16col 256x256 *2byte = 2kb
// BG1 16col 512x512 *2byte = 8kb
// BG2 256col 512x512 *1byte = 4kb
// BG0 BGSolid32.bmp 16col 16chr *32byte = 0.5kb
// BG1 BGSmall8Font.bmp 16col 400chr *32byte = 12.5kb
// BG2 BGParam.bmp 256col 256chr *64byte = 16kb

// OBJ OAM.bmp 256col 512chr *64byte = 32kb

// BG0 �őO�ʃe�L�X�g�E�B���h�E
// BG1 �w�i
// BG2 ���C��
// BG3 ���g�p

// Palette col   num
// BG0 128-191  8-11
// BG1 192-255 12-15
// BG2   0-127  0- 7
// BG3   0-  0  0- 0

s32 bgx,bgy;
u16 bg0off;
s32 zoom;

void InitSRAM(void)
{
  bgx=-104<<8;
  bgy=80<<8;
  bg0off=0;
  zoom=0x100;
}

void LoadSRAM(void)
{
  bgx=sram_read32(0);
  bgy=sram_read32(1);
  bg0off=sram_read16(2);
  zoom=sram_read32(3);
}

void SaveSRAM(void)
{
  sram_startwrite();
  sram_write32(0,bgx);
  sram_write32(1,bgy);
  sram_write16(2,bg0off);
  sram_write32(3,zoom);
  sram_endwrite();
}

