#include "header\GBA.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\sound.h"
#include "header\IRQ.h"

#include "boolean.h"
#include "pcmstream.h"
#include "madrv.h"

#include "interrupt.c"

void StartMADRV(void);
void StopMADRV(void);

int main(void)
{
  sndbuf_Init();
  sndbuf_StartPCM();
  StartMADRV();
  
  IRQTable[IRQIndex_DMA1]=(u32)sndbuf_DMA1_Handler;
  IRQTable[IRQIndex_Timer2]=(u32)madrv_Handler;
  IRQ_Setup(IRQ_BIT_TIMER2 | IRQ_BIT_DMA1, 0);
  
  while(1);
}

extern u8 ZanacTtl_MDA;

void StartMADRV(void)
{
  REG_TM2CNT=TM_FREQ_PER_64 | TM_USEIRQ;
  REG_TM2D=0;
  
  madrv_ClearData();
  madrv_LoadMDA2(&ZanacTtl_MDA);

  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
}

void StopMADRV(void)
{
  REG_TM2CNT&=~TM_ENABLE;
  REG_TM2D=0;

  madrv_AllNoteoff();
  madrv_ClearData();
  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
}

