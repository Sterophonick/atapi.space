

void ReturnPogoShell2(void)
{
  REG_BG2X=0;
  REG_BG2Y=0;
  REG_BG2PA=0x100;
  REG_BG2PD=0x100;
  
  pogoshell2_doReset();
  
  u32 fdat[7]; // uint32? int? u32? �ǂ�ł����ǂ͓��������ǁB
  static void (*fcall)(void); // FarCall(bx)�p
  
  // �A�Z���u����IWRAM��Ŏ��s���邽�߂ɒ������B�X�^�b�N��œ����܂��B
  fdat[0]=0xe3a00008; // mov r0, #0x8
  fdat[1]=0xef010000; // swi $010000
  fdat[2]=0xe3a00000; // mov r0, #0x0
  fdat[3]=0xe59f3004; // ldr r3, [pc,#4]
  fdat[4]=0xe1c300b0; // strh r0, [r3]
  fdat[5]=0xef000000; // swi $000000
  fdat[6]=0x096b592e; // .word 0x096B592E
  
  // �֐��|�C���^��o�^���Ď��s
  fcall=(void(*)(void))&fdat[0];
  fcall();
  
  while(1);
}

u8 *ps2ArgDataPtr;
u32 ps2ArgDataSize;
u8 ps2Arg0[128],ps2Arg1[128];

b8 GetPogoShell2Args(void)
{
  u8 *p = (u8 *)(0x02000000 + 255 * 1024 + 8);
  u32 *p2 = (u32 *)(0x02000000 + 255 * 1024);
  
  ps2ArgDataPtr=0;
  ps2ArgDataSize=0;
  ps2Arg0[0]=0;
  ps2Arg1[0]=0;
  
  b8 ps2ready=True;
  
  if(p2[0]!=0xFAB0BABE) ps2ready=False;
  if(p2[1]!=2) ps2ready=False;
  if(p2[-1]==0) ps2ready=False;
  if(p2[-2]==0) ps2ready=False;
  
  if(ps2ready==True){
    ps2ArgDataPtr=(u8*)p2[-1];
    ps2ArgDataSize=p2[-2];
    }else{
    return(False);
    static u8 *data="\0\0\0\0";
    ps2ArgDataPtr=data;
    ps2ArgDataSize=strlen(ps2ArgDataPtr);
    p="mda.bin\0dummy.txt\0";
  }
  
  u32 len;
  u32 cp;
  
  len=strlen(p)+1; // with Null
  for(cp=0;cp<len;cp++){
    ps2Arg0[cp]=*p;
    p++;
  }

  len=strlen(p)+1; // with Null
  for(cp=0;cp<len;cp++){
    ps2Arg1[cp]=*p;
    p++;
  }
  
  return(True);
}
