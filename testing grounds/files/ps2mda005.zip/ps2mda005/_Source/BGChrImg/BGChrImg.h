// bin2c converter ver0.1 by Moonlight.

#ifndef BGCHRIMG_h
#define BGCHRIMG_h

/*
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long int s64;
*/

#define BGSMALL8FONT_DATA_SIZE 6144
#define BGSMALL8FONT_PALETTE_SIZE 16
extern const u16 BGSmall8Font_palette[];
extern const u16 BGSmall8Font_data[];

#define BGSmall8Font_2byte8290 192
#define BGSmall8Font_2byte8340 304

#define BGSOLID32_DATA_SIZE 512
#define BGSOLID32_PALETTE_SIZE 16
extern const u16 BGSolid32_palette[];
extern const u16 BGSolid32_data[];

#define BGPARAM_DATA_SIZE 16384
#define BGPARAM_PALETTE_SIZE 256
extern const u16 BGParam_palette[];
extern const u16 BGParam_data[];

#define BGParam_Null (0x00)
#define BGParam_Fill (0x10)

#define BGParam_Flame (0x01)
#define BGParam_FlameDR   (BGParam_Flame+0)
#define BGParam_FlameDL   (BGParam_Flame+1)
#define BGParam_FlameUR   (BGParam_Flame+2)
#define BGParam_FlameUL   (BGParam_Flame+3)
#define BGParam_FlameD    (BGParam_Flame+4)
#define BGParam_FlameL    (BGParam_Flame+5)
#define BGParam_FlameU    (BGParam_Flame+6)
#define BGParam_FlameR    (BGParam_Flame+7)
#define BGParam_FlameDLDR (BGParam_Flame+8)
#define BGParam_FlameULDL (BGParam_Flame+9)
#define BGParam_FlameULUR (BGParam_Flame+10)
#define BGParam_FlameURDR (BGParam_Flame+11)
#define BGParam_FlameULURDLDR (BGParam_Flame+12)
#define BGParam_FlameLR   (BGParam_Flame+13)
#define BGParam_FlameUD   (BGParam_Flame+14)

#define BGParam_HexFont160 (0x20)
#define BGParam_HexFont161 (0x30)
#define BGParam_Font0x20 (0x40)

#define BGParam_VBarFull (0xa0)

#define BGParam_VBar7 (0xc0)
#define BGParam_VBar6 (0xc4)
#define BGParam_VBar5 (0xc8)
#define BGParam_VBar4 (0xcc)
#define BGParam_VBar3 (0xe0)
#define BGParam_VBar2 (0xe4)
#define BGParam_VBar1 (0xe8)
#define BGParam_VBar0 (0xec)

#define OAM_DATA_SIZE 65536
#define OAM_PALETTE_SIZE 512
extern const u16 OAM_palette[];
extern const u16 OAM_data[];

#endif
