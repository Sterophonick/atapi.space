
#define TitleX 0
#define TitleY 0
#define TitleWidth 28
#define TitleHeight 4

#define CommentX 0
#define CommentY 4
#define CommentWidth 28
#define CommentHeight 28

#define Ch_GlobalX 0
#define Ch_GlobalY 7
#define Ch_GlobalHeight 3

#define ChOff_WNameL 6
#define ChOff_WVBar 8
#define ChOff_WAddr 4
#define ChOff_WKey 3
#define ChOff_WTone 3
#define ChOff_WF 1
#define ChOff_WVol 3
#define ChOff_Wp 1
#define ChOff_WMPT 3
#define ChOff_WMPitch 5
#define ChOff_WMAT 3
#define ChOff_WMAMP 3
#define ChOff_WNameR 6

#define ChOff_PNameL 1
#define ChOff_PVBar (ChOff_PNameL+1+ChOff_WNameL)
#define ChOff_PAddr (ChOff_PVBar+1+ChOff_WVBar)
#define ChOff_PKey (ChOff_PAddr+1+ChOff_WAddr)
#define ChOff_PTone (ChOff_PKey+1+ChOff_WKey)
#define ChOff_PF (ChOff_PTone+1+ChOff_WTone)
#define ChOff_PVol (ChOff_PF+1+ChOff_WF)
#define ChOff_Pp (ChOff_PVol+1+ChOff_WVol)
#define ChOff_PMPT (ChOff_Pp+1+ChOff_Wp)
#define ChOff_PMPitch (ChOff_PMPT+1+ChOff_WMPT)
#define ChOff_PMAT (ChOff_PMPitch+1+ChOff_WMPitch)
#define ChOff_PMAMP (ChOff_PMAT+1+ChOff_WMAT)
#define ChOff_PNameR (ChOff_PMAMP+1+ChOff_WMAMP)

void wm_player_init(void);
void wm_player_MainLoop(void);
void wm_player_IRQ_VBlank(void);
void wm_player_IRQ_Timer3(void);

void initvis(void);
void calcvis(void);
void drawvis(u32 curch);
void DrawChFlame(u8 ch);
void DrawChStrName(u8 ch,u8 *str0,u8 *str1);
void DrawChTag(void);
void DrawChAll(void);
void StartDrawCh(u8 ch);
void DrawChVolume(u8 vol);
inline void DrawChParam1(u8 offset,u8 i);
inline void DrawChParam(u8 offset,s32 i,u32 len);
inline void DrawChParamHex(u8 offset,s32 i,u32 len);

b8 VsyncDrawed;
u32 curch;
b8 keysboot;
u8 DrawChY;

void wm_player_init(void)
{
  // ���[�h�ݒ�
  REG_DISPCNT=MODE_1;
  
  SetBGCHR(0,16,(u16*)BGSolid32_data,(u16*)BGSolid32_palette);
  SetBGCHR(1,400,(u16*)BGSmall8Font_data,(u16*)BGSmall8Font_palette);
  SetBG2CHR(256,(u16*)BGParam_data,(u16*)BGParam_palette);
  
  REG_BG0CNT = ( BG_SIZEA_256_256 | BG_COLOR_16 | BG_CHARBASE(ADR_BGCHR0) | BG_MAPBASE(ADR_BGMAP0) | 2); 
  REG_BG1CNT = ( BG_SIZEA_512_512 | BG_COLOR_16 | BG_CHARBASE(ADR_BGCHR1) | BG_MAPBASE(ADR_BGMAP1) | 0); 
  REG_BG2CNT = ( BG_SIZEB_512_512 | BG_COLOR_256 | BG_CHARBASE(ADR_BGCHR2) | BG_MAPBASE(ADR_BGMAP2) | 1); 
  REG_BG3CNT = 0;
  
  u32 x,y;
  
  for(y=0;y<32;y++){
    for(x=0;x<32;x++){
      SetBG0MAP(x,y,0,((y%4)*4)+(x%4));
    }
  }
  
  DrawChTag();
  DrawChAll();
  
  REG_BLDMOD = BLEND_TOP_OBJ | BLEND_LOW_BG0 | BLEND_MODE_ALPHA ;
  REG_COLEV = BLEND_BALANCE(8);
  
  ChangeSprite(0,0x00);
  SetSpriteSize(0,SP_SIZE_64,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(0,SP_MODE_TRANSPERANT);
  SetSpriteRotation(0,True);
  SetSpritePriority(0,1);
  ChangeSprite(1,0x10);
  SetSpriteSize(1,SP_SIZE_64,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(1,SP_MODE_TRANSPERANT);
  SetSpriteRotation(1,True);
  SetSpritePriority(1,1);
  ChangeSprite(2,0x80);
  SetSpriteSize(2,SP_SIZE_64,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(2,SP_MODE_TRANSPERANT);
  SetSpriteRotation(2,True);
  SetSpritePriority(2,1);
  
  ChangeSprite(3,0x90);
  SetSpriteSize(3,SP_SIZE_32,SP_WIDE,SP_COLOR_256);
  SetSpriteMode(3,SP_MODE_NORMAL);
  SetSpriteRotation(3,False);
  SetSpritePriority(3,2);
  
/*
  MoveSprite(0,64*0,0);
  MoveSprite(1,64*1,0);
  MoveSprite(2,64*2,0);
  MoveSprite(3,240-32,0);
*/

  DrawFlame(0,0,18,4);
  Mode1BG2_DrawStr(1,1,"CPULoadCnt=");
  Mode1BG2_DrawStr(1,2,"TotalClock=");
  DrawFlame(18,0,18,4);
  Mode1BG2_DrawStr(19,1,"Timer-BClk=");
  Mode1BG2_DrawStr(19,2,"Timer64Clk=");
  
  REG_DISPCNT|=BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | OBJ_ENABLE | OBJ_MAP_2D;
  
  Mode1BG1_DrawFlame(TitleX,TitleY,TitleWidth,TitleHeight,5);
  Mode1BG1_DrawStrMultiLine(TitleX+1,TitleY+1,TitleWidth-2,TitleHeight-2,madrv_GetTitle());

  Mode1BG1_DrawFlame(CommentX,CommentY,CommentWidth,CommentHeight,5);
  Mode1BG1_DrawStrMultiLine(CommentX+1,CommentY+1,CommentWidth-2,CommentHeight-2,madrv_GetComment());
  
  keysboot=True;
  curch=0;
  VsyncDrawed=False;
  initvis();
}

void wm_player_MainLoop(void)
{
  if(*(volatile u16*)0x4000006<160){
    if(VsyncDrawed==True){
      VsyncDrawed=False;
      calcvis();
    }
  }
  if(*(volatile u16*)0x4000006>=160){
    if(VsyncDrawed==False){
      VsyncDrawed=True;
      inttostr(MDA.TotalClock,5);
      Mode1BG2_DrawStr(12,2,res_inttostr);
    }
  }

  drawvis(curch);
  curch++;
  if(curch==12) curch=0;
}

void wm_player_IRQ_VBlank(void)
{
  u16 loadkeys;
  loadkeys=(~*KEYS)&0x3ff;

  if((keysboot!=False)||(loadkeys!=0)){
    keysboot=False;
    if(loadkeys & KEY_A){
      if(zoom>=0x0080) zoom-=4;
    }
    if(loadkeys & KEY_B){
      if(zoom<=0x0240) zoom+=4;
    }
    if(loadkeys & KEY_LEFT){
      if(bgx>(-240<<8)) bgx-=zoom*2;
    }
    if(loadkeys & KEY_RIGHT){
      bgx+=zoom*2;
    }
    if(loadkeys & KEY_UP){
      if(bgy>(40<<8)) bgy-=zoom*2;
    }
    if(loadkeys & KEY_DOWN){
      bgy+=zoom*2;
    }
    if(loadkeys & KEY_SELECT){
      InitSRAM();	
    }
    if((loadkeys&KEY_L)&&(loadkeys&KEY_R)){
      ReturnPogoShell2();
      while(1);
    }
  }
  
  void _MoveSprite(u32 no,s32 x,s32 y)
  {
    x=((x+32-(bgx>>8))*(0x10000/zoom))>>8;
    y=((y+16-(bgy>>8))*(0x10000/zoom))>>8;
    x=x+120;
    y=y+80;
    if((x>=-64)&&(y>=-32)){
      MoveSprite(no,x-64,y-32);
      }else{
      MoveSprite(no,-64-64,-32-32);
    }
  }
  
/*
  _MoveSprite(0,64*0,0);
  _MoveSprite(1,64*1,0);
  _MoveSprite(2,64*2,0);
*/
  
  *(u16*)0x07000006=zoom; // OBJPA0
  *(u16*)0x0700001e=zoom; // OBJPD0
  
  REG_BG2X=bgx-(zoom*120);
  REG_BG2Y=bgy-(zoom*80);
  REG_BG2PA=zoom;
  REG_BG2PD=zoom;

  REG_BG0HOFS=(bgx>>8>>1)+((bg0off)>>2);
  REG_BG0VOFS=(bgy>>8>>1)-((bg0off)>>2);
  bg0off++;
  if(bg0off==128) bg0off=0;
  
  s32 hofs;
  hofs=((bgx/(zoom))>>0)+(TitleWidth*8)-120;
  
  if(hofs>(TitleWidth*8)){
    REG_DISPCNT&=~BG1_ENABLE;
    }else{
    REG_DISPCNT|=BG1_ENABLE;
    REG_BG1HOFS=hofs;
    REG_BG1VOFS=((bgy/(zoom))>>0)-80;
  }
}

void wm_player_IRQ_Timer3(void)
{
  inttostr(CPUFree,5);
  CPUFree=0;
  Mode1BG2_DrawStr(12,1,res_inttostr);
  inttostr(MDA.Tempo,5);
  Mode1BG2_DrawStr(30,1,res_inttostr);
  inttostr(MDA.Timer64Tempo,5);
  Mode1BG2_DrawStr(30,2,res_inttostr);
  
  SaveSRAM();
}

typedef struct {
  b8 Enabled;
  u32 NowPos;
  u8 NowKeycode;
  u8 NowVoice;
  u8 ADPCMMode;
  u8 Volume;
  u8 NowPanpot;
  u8 MPWaveType;
  s32 MPNowDetune;
  u8 MAWaveType;
  s32 MANowDetune;
  
  u8 VisVolume;
  u8 LastVisVolume;
} Tmadrv_VisChannel;

Tmadrv_VisChannel MDAch_Vis[madrv_ChannelCount];

void initvis(void)
{
  Tmadrv_VisChannel *vch;
  u32 curch;

  for(curch=0;curch<12;curch++){
    if(curch<4){
      vch=&MDAch_Vis[curch];
      }else{
      vch=&MDAch_Vis[curch+4];
    }
    vch->Enabled=True;
    vch->NowPos=-1;
    vch->NowKeycode=-1;
    vch->NowVoice=-1;
    vch->ADPCMMode=-1;
    vch->Volume=-1;
    vch->NowPanpot=-1;
    vch->MPWaveType=-1;
    vch->MPNowDetune=-1;
    vch->MAWaveType=-1;
    vch->MANowDetune=-1;
    vch->VisVolume=0;
    vch->LastVisVolume=-1;
  }
}

void calcvis(void)
{
  Tmadrv_Channel *tch;
  Tmadrv_VisChannel *vch;
  
  u32 curch;
  for(curch=0;curch<12;curch++){
    if(curch<4){
      tch=&MDAch[curch];
      vch=&MDAch_Vis[curch];
      }else{
      tch=&MDAch[curch+4];
      vch=&MDAch_Vis[curch+4];
    }
    
    if(tch->forVis_Noteon==True){
      tch->forVis_Noteon=False;
      if(tch->VolMode==False){
        vch->VisVolume=tch->Volume*4;
        }else{
        vch->VisVolume=tch->Volume>>4*4;
      }
      }else{
      if(vch->VisVolume!=0) vch->VisVolume--;
    }
  }
}

void drawvis(u32 curch)
{
  Tmadrv_Channel *tch;
  Tmadrv_VisChannel *vch;
  
  if(curch<4){
    tch=&MDAch[curch];
    vch=&MDAch_Vis[curch];
    }else{
    tch=&MDAch[curch+4];
    vch=&MDAch_Vis[curch+4];
  }
  
  StartDrawCh(curch);
  
  if(vch->LastVisVolume!=vch->VisVolume){
    DrawChVolume(vch->VisVolume/2);
    vch->LastVisVolume=vch->VisVolume;
  }
  
  if(vch->Enabled==True){
    vch->Enabled=tch->Enabled;
    if(vch->NowPos!=tch->NowPos){
      vch->NowPos=tch->NowPos;
      DrawChParamHex(ChOff_PAddr,tch->NowPos,ChOff_WAddr);
    }
    if(vch->NowKeycode!=tch->NowKeycode){
      vch->NowKeycode=tch->NowKeycode;
      DrawChParam(ChOff_PKey,tch->NowKeycode,ChOff_WKey);
    }
    if(vch->NowVoice!=tch->NowVoice){
      vch->NowVoice=tch->NowVoice;
      DrawChParam(ChOff_PTone,tch->NowVoice,ChOff_WTone);
    }
    if(vch->ADPCMMode!=tch->ADPCMMode){
      vch->ADPCMMode=tch->ADPCMMode;
      DrawChParam1(ChOff_PF,tch->ADPCMMode);
    }
    if(vch->Volume!=tch->Volume){
      vch->Volume=tch->Volume;
      if(tch->VolMode==False){
        DrawChParam(ChOff_PVol,tch->Volume,ChOff_WVol);
        }else{
        DrawChParam(ChOff_PVol,tch->Volume>>4,ChOff_WVol);
      }
    }
    if(vch->NowPanpot!=tch->NowPanpot){
      vch->NowPanpot=tch->NowPanpot;
      DrawChParam1(ChOff_Pp,tch->NowPanpot);
    }
    if(vch->MPWaveType!=tch->MPWaveType){
      vch->MPWaveType=tch->MPWaveType;
      DrawChParam(ChOff_PMPT,tch->MPWaveType,ChOff_WMPT);
    }
    if(vch->MPNowDetune!=tch->MPNowDetune){
      vch->MPNowDetune=tch->MPNowDetune;
      DrawChParamHex(ChOff_PMPitch,tch->MPNowDetune,ChOff_WMPitch);
    }
    if(vch->MAWaveType!=tch->MAWaveType){
      vch->MAWaveType=tch->MAWaveType;
      DrawChParam(ChOff_PMAT,tch->MAWaveType,ChOff_WMAT);
    }
    if(vch->MANowDetune!=tch->MANowDetune){
      vch->MANowDetune=tch->MANowDetune;
      DrawChParamHex(ChOff_PMAMP,tch->MANowDetune>>8,ChOff_WMAMP);
    }
  }
}

void DrawChFlame(u8 ch)
{
  u8 x,y;
  b8 Tag;
  u8 FlameDR,FlameDLDR,FlameDL,FlameD;
  u8 FlameUR,FlameULUR,FlameUL,FlameU;
  u8 cnt;
  
  void DrawStart(void)
  {
    SetBG2MAP(x,y+0,FlameDR);
    SetBG2MAP(x,y+1,BGParam_FlameR);
    if(Tag==False){
      SetBG2MAP(x,y+2,BGParam_FlameR);
      SetBG2MAP(x,y+3,FlameUR);
      }else{
      SetBG2MAP(x,y+2,FlameUR);
    }
    x++;
  }
  
  void Draw(u8 w,b8 end)
  {
    for(cnt=0;cnt<w;cnt++){
      SetBG2MAP(x,y+0,FlameD);
      if(Tag==False){
        SetBG2MAP(x,y+3,FlameU);
        }else{
        SetBG2MAP(x,y+2,FlameU);
      }
      x++;
    }
    if(end==False){
      SetBG2MAP(x,y+0,FlameDLDR);
      SetBG2MAP(x,y+1,BGParam_FlameLR);
      if(Tag==False){
        SetBG2MAP(x,y+2,BGParam_FlameLR);
        SetBG2MAP(x,y+3,FlameULUR);
        }else{
        SetBG2MAP(x,y+2,FlameULUR);
      }
      }else{
      SetBG2MAP(x,y+0,FlameDL);
      SetBG2MAP(x,y+1,BGParam_FlameL);
      if(Tag==False){
        SetBG2MAP(x,y+2,BGParam_FlameL);
        SetBG2MAP(x,y+3,FlameUL);
        }else{
        SetBG2MAP(x,y+2,FlameUL);
      }
    }
    x++;
  }
  
  if(ch==0xff){
    Tag=True;
    }else{
    Tag=False;
  }
  
  if((Tag==True)||(ch==0)){ // not UpLink
    FlameDR=BGParam_FlameDR;
    FlameDLDR=BGParam_FlameDLDR;
    FlameDL=BGParam_FlameDL;
    FlameD=BGParam_FlameD;
    }else{
    FlameDR=BGParam_FlameURDR;
    FlameDLDR=BGParam_FlameULURDLDR;
    FlameDL=BGParam_FlameULDL;
    FlameD=BGParam_FlameUD;
  }
  
  if((Tag==True)||(ch==11)){ // not DownLink
    FlameUR=BGParam_FlameUR;
    FlameULUR=BGParam_FlameULUR;
    FlameUL=BGParam_FlameUL;
    FlameU=BGParam_FlameU;
    }else{
    FlameUR=BGParam_FlameURDR;
    FlameULUR=BGParam_FlameULURDLDR;
    FlameUL=BGParam_FlameULDL;
    FlameU=BGParam_FlameUD;
  }
  
  x=Ch_GlobalX;
  if(ch==0xff){
    y=Ch_GlobalY-Ch_GlobalHeight;
    }else{
    y=Ch_GlobalY+(ch*Ch_GlobalHeight);
  }
  
  if(ch==0xff){
    x++;
    x+=ChOff_WNameL+1;
    x+=ChOff_WVBar;
    DrawStart();
    }else{
    DrawStart();
    Draw(ChOff_WNameL,False);
    Draw(ChOff_WVBar,False);
  }

  Draw(ChOff_WAddr,False);
  Draw(ChOff_WKey,False);
  Draw(ChOff_WTone,False);
  Draw(ChOff_WF,False);
  Draw(ChOff_WVol,False);
  Draw(ChOff_Wp,False);
  Draw(ChOff_WMPT,False);
  Draw(ChOff_WMPitch,False);
  Draw(ChOff_WMAT,False);
  
  if(Tag==True){
    Draw(ChOff_WMAMP,True);
    }else{
    Draw(ChOff_WMAMP,False);
    Draw(ChOff_WNameR,True);
  }
}

void DrawChStrName(u8 ch,u8 *str0,u8 *str1)
{
  u8 x,y;

  x=Ch_GlobalX+ChOff_PNameL;
  y=Ch_GlobalY+(ch*Ch_GlobalHeight);
  Mode1BG2_DrawStr(x,y+1,str0);
  Mode1BG2_DrawStr(x,y+2,str1);

  x=Ch_GlobalX+ChOff_PNameR;
  y=Ch_GlobalY+(ch*Ch_GlobalHeight);
  Mode1BG2_DrawStr(x,y+1,str0);
  Mode1BG2_DrawStr(x,y+2,str1);
}

void DrawChTag(void)
{
  DrawChFlame(0xff);
  
  u8 x,y;
  
  x=Ch_GlobalX;
  y=Ch_GlobalY-Ch_GlobalHeight;
  
  Mode1BG2_DrawStr(x+ChOff_PAddr,y+1,"Addr");
  Mode1BG2_DrawStr(x+ChOff_PKey ,y+1,"Key");
  Mode1BG2_DrawStr(x+ChOff_PTone,y+1,"@  ");
  Mode1BG2_DrawStr(x+ChOff_PF   ,y+1,"F");
  Mode1BG2_DrawStr(x+ChOff_PVol ,y+1,"vol");
  Mode1BG2_DrawStr(x+ChOff_Pp   ,y+1,"p");
  Mode1BG2_DrawStr(x+ChOff_PMPT ,y+1,"MPT");
  Mode1BG2_DrawStr(x+ChOff_PMPitch,y+1,"Pitch");
  Mode1BG2_DrawStr(x+ChOff_PMAT ,y+1,"MAT");
  Mode1BG2_DrawStr(x+ChOff_PMAMP,y+1,"AMP");
}

void DrawChAll(void)
{
  u8 ch;
  for(ch=0;ch<12;ch++){
    DrawChFlame(ch);
    switch(ch){
      case  0: DrawChStrName(ch,"Ch 0/A","GBSnd1"); break;
      case  1: DrawChStrName(ch,"Ch 1/B","GBSnd2"); break;
      case  2: DrawChStrName(ch,"Ch 2/C","GBSnd3"); break;
      case  3: DrawChStrName(ch,"Ch 3/D","Noise0"); break;
      case  4: DrawChStrName(ch,"Ch 4/P","ADPCM1"); break;
      case  5: DrawChStrName(ch,"Ch 5/Q","ADPCM2"); break;
      case  6: DrawChStrName(ch,"Ch 6/R","ADPCM3"); break;
      case  7: DrawChStrName(ch,"Ch 7/S","ADPCM4"); break;
      case  8: DrawChStrName(ch,"Ch 8/T","ADPCM5"); break;
      case  9: DrawChStrName(ch,"Ch 9/U","ADPCM6"); break;
      case 10: DrawChStrName(ch,"Ch10/V","ADPCM7"); break;
      case 11: DrawChStrName(ch,"Ch11/W","ADPCM8"); break;
    }
  }
}

void StartDrawCh(u8 ch)
{
  DrawChY=Ch_GlobalY+(ch*Ch_GlobalHeight);
}

void DrawChVolume(u8 vol)
{
  u8 x,y;
  x=Ch_GlobalX+ChOff_PVBar;
  y=DrawChY;
  
  void Draw(u16 left,u16 chr,u16 right)
  {
    u32 cnt;
    u16 ptn;
    u16 *adr1,*adr2;
    
    adr1=(u16*)&BGMAP2[((y+1)*64+x)>>1];
    adr2=(u16*)&BGMAP2[((y+2)*64+x)>>1];
    
    ptn=((BGParam_VBarFull+0x01)<<8)+BGParam_VBarFull;
    for(cnt=0;cnt<(left/2);cnt++){
      *adr1=ptn+0x0000; *adr2=ptn+0x1010;
      adr1++; adr2++;
      ptn+=0x0202;
    }
    if((left&1)!=0){
      ptn=(chr<<8)+(BGParam_VBarFull+left-1);
      *adr1=ptn+0x0000; *adr2=ptn+0x1010;
      adr1++; adr2++;
      }else{
      ptn=(BGParam_Fill<<8)+chr;
      *adr1=ptn+0x00; *adr2=ptn+0x10;
      adr1++; adr2++;
    }
    
    ptn=(BGParam_Fill<<8)+BGParam_Fill;
    for(cnt=0;cnt<(right/2);cnt++){
      *adr1=ptn; *adr2=ptn;
      adr1++; adr2++;
    }
  }

  switch(vol){
    case 0x1f: case 0x1e: case 0x1d: case 0x1c:
      Draw(7,BGParam_VBar7+(0x1f-vol),0);
      break;
    case 0x1b: case 0x1a: case 0x19: case 0x18:
      Draw(6,BGParam_VBar6+(0x1b-vol),1);
      break;
    case 0x17: case 0x16: case 0x15: case 0x14:
      Draw(5,BGParam_VBar5+(0x17-vol),2);
      break;
    case 0x13: case 0x12: case 0x11: case 0x10:
      Draw(4,BGParam_VBar4+(0x13-vol),3);
      break;
    case 0x0f: case 0x0e: case 0x0d: case 0x0c:
      Draw(3,BGParam_VBar3+(0x0f-vol),4);
      break;
    case 0x0b: case 0x0a: case 0x09: case 0x08:
      Draw(2,BGParam_VBar2+(0x0b-vol),5);
      break;
    case 0x07: case 0x06: case 0x05: case 0x04:
      Draw(1,BGParam_VBar1+(0x07-vol),6);
      break;
    case 0x03: case 0x02: case 0x01: case 0x00:
      Draw(0,BGParam_VBar0+(0x03-vol),7);
      break;
  }
}

inline void DrawChParam1(u8 offset,u8 i)
{
  u8 x,y;
  x=Ch_GlobalX+offset;
  y=DrawChY;
  SetBG2MAP(x,y+1,BGParam_HexFont160+i);
  SetBG2MAP(x,y+2,BGParam_HexFont161+i);
}

inline void DrawChParam(u8 offset,s32 i,u32 len)
{
  u8 x,y;
  s8 cnt;
  x=Ch_GlobalX+offset;
  y=DrawChY;
  
  if(i<0){
    i=-i;
    SetBG2MAP(x,y+1,BGParam_HexFont160+0);
    SetBG2MAP(x,y+2,BGParam_HexFont161+0);
    x++;
    len--;
  }
  
  if(i==0){
    for(cnt=0;cnt<(len-1);cnt++){
      SetBG2MAP(x+cnt,y+1,BGParam_Fill);
      SetBG2MAP(x+cnt,y+2,BGParam_Fill);
    }
    SetBG2MAP(x+(len-1),y+1,BGParam_HexFont160+0);
    SetBG2MAP(x+(len-1),y+2,BGParam_HexFont161+0);
    }else{
    for(cnt=len-1;cnt>=0;cnt--){
      if(i==0){
        SetBG2MAP(x+cnt,y+1,BGParam_Fill);
        SetBG2MAP(x+cnt,y+2,BGParam_Fill);
        }else{
        SetBG2MAP(x+cnt,y+1,BGParam_HexFont160+(i%10));
        SetBG2MAP(x+cnt,y+2,BGParam_HexFont161+(i%10));
      }
      i/=10;
    }
  }
}

inline void DrawChParamHex(u8 offset,s32 i,u32 len)
{
  u8 x,y;
  s8 cnt;
  x=Ch_GlobalX+offset;
  y=DrawChY;
  
  if(i<0){
    i=-i;
    SetBG2MAP(x,y+1,BGParam_HexFont160+0);
    SetBG2MAP(x,y+2,BGParam_HexFont161+0);
    x++;
    len--;
  }
  
  if(i==0){
    for(cnt=0;cnt<(len-1);cnt++){
      SetBG2MAP(x+cnt,y+1,BGParam_Fill);
      SetBG2MAP(x+cnt,y+2,BGParam_Fill);
    }
    SetBG2MAP(x+(len-1),y+1,BGParam_HexFont160+0);
    SetBG2MAP(x+(len-1),y+2,BGParam_HexFont161+0);
    }else{
    for(cnt=len-1;cnt>=0;cnt--){
      if(i==0){
        SetBG2MAP(x+cnt,y+1,BGParam_Fill);
        SetBG2MAP(x+cnt,y+2,BGParam_Fill);
        }else{
        SetBG2MAP(x+cnt,y+1,BGParam_HexFont160+(i%16));
        SetBG2MAP(x+cnt,y+2,BGParam_HexFont161+(i%16));
      }
      i/=16;
    }
  }
}

