
// ���ׂẴX�v���C�g��\�������Ȃ�
void InitializeSprites(void)
{
  OAMEntry* sprites = (OAMEntry*)OAMmem; // OAM
  
  int loop;
  for(loop = 0; loop < 128; loop++)
  {
    sprites[loop].attribute0 = 160;  //y to > 159
    sprites[loop].attribute1 = 240;  //x to > 239
  }
}

// �X�v���C�g�̈ʒu��ύX
void MoveSprite(u8 no, int x, int y)
{
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM

  if(x<0) x=512+x;
  if(y<0) y=256+y;

  sp->attribute1 = sp->attribute1 & 0xFE00;
  sp->attribute1 = sp->attribute1 | x;
  
  sp->attribute0 = sp->attribute0 & 0xFF00;
  sp->attribute0 = sp->attribute0 | y;
}

/* -----------------------------------------  /
  SetSpriteSize
  �X�v���C�g�̌`���ݒ�
  sp�E�E�E�ύX����X�v���C�g���w��
  size�E�ESP_SIZE_8,SP_SIZE_16,SP_SIZE_32,SP_SIZE_64�̂����ꂩ
  form�E�ESP_SQUARE,SP_TALL,SP_WIDE
  color�E�ESP_COLOR_16,SP_COLOR_256
/ ------------------------------------------ */
void SetSpriteSize(u8 no,u16 size,u16 form,u16 color)
{  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM

  sp->attribute0 &= 0x1FFF;
  sp->attribute0 |= color | form | (160);
  
  sp->attribute1 &= 0x3FFF;
  sp->attribute1 |= size | (240);
}

void SetSpriteMode(u8 no,u16 mode)
{  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM

  // SP_MODE_NORMAL SP_MODE_TRANSPERANT SP_MODE_WINDOWED
  sp->attribute0 &= ~(BIT11|BIT10);
  sp->attribute0 |= mode;
}
void SetSpriteRotation(u8 no,b8 enable)
{  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute0 &= ~(BIT9|BIT8);
  if(enable==True) sp->attribute0 |= SP_SIZE_DOUBLE|SP_ROTATION_FLAG;
}

void ChangeSprite(u8 no, u16 ch)
{
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM

  sp->attribute2 = sp->attribute2 & 0xFC00;
  sp->attribute2 = sp->attribute2 | ch;
}

void SetSpritePriority(u8 no, u8 p)
{
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM

  sp->attribute2&=~(BIT11|BIT10);
  sp->attribute2|=p<<10;
}

void SetBGCHR(u8 BGNo,u16 chr,u16* img,u16* pal)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&pal[0];
  if(BGNo==0){
    REG_DM3DAD = (u32)&BGPAL[128];
    }else{
    REG_DM3DAD = (u32)&BGPAL[192];
  }
  REG_DM3CNT_L=64*2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);

  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&img[0];
  if(BGNo==0){
    REG_DM3DAD = (u32)BGCHR0;
    }else{
    REG_DM3DAD = (u32)BGCHR1;
  }
  REG_DM3CNT_L=chr*32/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
}

void SetBG2CHR(u16 chr,u16* img,u16* pal)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&pal[0];
  REG_DM3DAD = (u32)&BGPAL[0];
  REG_DM3CNT_L=128*2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);

  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&img[0];
  REG_DM3DAD = (u32)&BGCHR2[0];
  REG_DM3CNT_L=chr*64/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
}

void SetOAMCHR(u16 chr,u16* img,u16* pal)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&pal[0];
  REG_DM3DAD = (u32)OBJpal;
  REG_DM3CNT_L=128*2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
  
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&img[0];
  REG_DM3DAD = (u32)OAMdata;
  REG_DM3CNT_L=chr*64/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
}

inline void SetBG0MAP(u16 x,u16 y,u16 palno,u16 chr)
{
  BGMAP0[y*32+x]=((palno+(2*4))<<12)+chr;
}

inline void SetBG1MAP(u16 x,u16 y,u16 palno,u16 chr)
{
  BGMAP1[y*32+x]=((palno+(3*4))<<12)+chr;
}

inline void SetBG2MAP(u16 x,u16 y,u16 chr)
{
  u16 addr;
  addr=(y*64+x)>>1;
  if((x&1)==0){
    BGMAP2[addr]=(BGMAP2[addr]&0xff00)+chr;
    }else{
    BGMAP2[addr]=(BGMAP2[addr]&0x00ff)+(chr<<8);
  }
}

inline void SetBG2MAP16(u16 x,u16 y,u16 chr)
{
  // 16bit���E�A�h���X����Ȃ���C���B
  BGMAP2[(y*64+x)>>1]=chr;
}

void Mode1BG1_DrawFlame(u8 x,u8 y,u8 w,u8 h,u8 flameno)
{
  u8 dx,dy;
  u8 offset;
  
  offset=144+(flameno*8);
  
  dx=x;
  SetBG1MAP(dx,y+0,0,offset+0);
  for(dy=1;dy<(h-1);dy++){
    SetBG1MAP(dx,y+dy,0,offset+6);
  }
  SetBG1MAP(dx,y+(h-1),0,offset+2);
  for(dx=(x+1);dx<(x+w-1);dx++){
    SetBG1MAP(dx,y+0,0,offset+4);
    for(dy=1;dy<(h-1);dy++){
      SetBG1MAP(dx,y+dy,0,1);
    }
    SetBG1MAP(dx,y+(h-1),0,offset+5);
  }
  dx=x+w-1;
  SetBG1MAP(dx,y+0,0,offset+1);
  for(dy=1;dy<(h-1);dy++){
    SetBG1MAP(dx,y+dy,0,offset+7);
  }
  SetBG1MAP(dx,y+(h-1),0,offset+3);
}

void Mode1BG1_DrawStr(u8 x,u8 y,u8* str)
{
  int i=0;
  while(str[i]!=0x00){
    SetBG1MAP(x,y,0,str[i]);
    x++;
    i++;
  }
}

void Mode1BG1_DrawStrLimit(u8 x,u8 y,u8* str,u8 start,u8 len)
{
  int i=0;
  while(str[i]!=0x00){
    if(start!=0){
      start--;
      }else{
      if(len==0) return;
      len--;
      SetBG1MAP(x,y,0,str[i]);
      x++;
    }
    i++;
  }
}

void Mode1BG1_DrawStrMultiLine(u8 x,u8 y,u8 w,u8 h,u8* str)
{
  int dx,dy;
  int i;
  u16 c;
  
  dx=0;
  dy=0;
  i=0;
  while(str[i]!=0x00){
    if(str[i]<=0x7f){ // 1bytechar
      if(str[i]==0x0a){
        dx=0;
        dy++;
        if(dy==h) return;
      }
      if(0x20<=str[i]){
        SetBG1MAP(x+dx,y+dy,0,str[i]);
        dx++;
      }
      i++;
      }else{ // 2bytechar
      c=((u16)str[i+0])<<8;
      c+=(u16)str[i+1];
      if(str[i]==0x82){
        c=c-0x8290+BGSmall8Font_2byte8290;
        SetBG1MAP(x+dx,y+dy,0,c);
        dx++;
      }
      if(str[i]==0x83){
        c=c-0x8340+BGSmall8Font_2byte8340;
        SetBG1MAP(x+dx,y+dy,0,c);
        dx++;
      }
      i+=2;
    }
    
    if(dx==w){
      dx=0;
      dy++;
    }
    if(dy==h) return;
  }
}

void Mode1BG2_DrawStr(u8 x,u8 y,u8* str)
{
  int i=0;
  while(str[i]!=0x00){
    SetBG2MAP(x,y,(str[i]+(BGParam_Font0x20-0x20)));
    x++;
    i++;
  }
}

void DrawFlame(u8 x,u8 y,u8 w,u8 h)
{
  u8 dx,dy;
  
  dx=x;
  SetBG2MAP(dx,y,BGParam_FlameDR);
  for(dy=1;dy<(h-1);dy++){
    SetBG2MAP(dx,y+dy,BGParam_FlameR);
  }
  SetBG2MAP(dx,y+(h-1),BGParam_FlameUR);
  dx++;
  
  for(dx=x+1;dx<x+(w-1);dx++){
    SetBG2MAP(dx,y,BGParam_FlameD);
    for(dy=1;dy<(h-1);dy++){
      SetBG2MAP(dx,y+dy,BGParam_Fill);
    }
    SetBG2MAP(dx,y+(h-1),BGParam_FlameU);
  }
  
  dx=x+(w-1);
  SetBG2MAP(dx,y,BGParam_FlameDL);
  for(dy=1;dy<(h-1);dy++){
    SetBG2MAP(dx,y+dy,BGParam_FlameL);
  }
  SetBG2MAP(dx,y+(h-1),BGParam_FlameUL);
  dx++;
}

