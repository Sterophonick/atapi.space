#include "header\GBA.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\sound.h"
#include "header\IRQ.h"
#include "boolean.h"
#include "pcmstream.h"

#define farcall(p) static void(*p)(void)

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram // ROM��Ŏ��s����Ƃ��͂�����

#define sndbuf_REG_DM1CNT_H (DMA_SIZE_32 | DMA_TIMING_FIFO | DMA_REPEAT_ON | \
                             DMA_SAD_INC | DMA_DAD_FIX | DMA_INTR_ON)

#define sndbuf_size (16<<4)
#define sndbuf_DMA1Timeout (sndbuf_size>>4)
#define sndbuf_REG_TM1D_11025 (u16)(-1522);
#define sndbuf_REG_TM1D_15625 (u16)(-1067);

#define VarVolume_Equal 16

#define sndbuf_ChannelCount 8 // MultiChannels
Tsndbuf_Channel sndbuf_ch[sndbuf_ChannelCount];

u32 sndbuf_playpos;

s8 sndbuf0[sndbuf_size+256];
s8 sndbuf1[sndbuf_size+256];
u8 writebufno;
s8 *writebuf;
attriwram void (*CMixProc[sndbuf_ChannelCount])(u32 ch);
u8 CMixShift[sndbuf_ChannelCount];

void sndbuf_Init(void);
attriwram void sndbuf_RecalcMixProc(u32 ch);
void (*farcall_sndbuf_RecalcMixProc)(u32 ch)=sndbuf_RecalcMixProc;
void sndbuf_SetPCM(u8 chno,s8* Data,u32 Size);
void sndbuf_SetLoopFlag(u8 chno,b8 LoopFlag);
void sndbuf_SetVolume(u8 chno,u8 v);
void sndbuf_SetSrcPos(u8 chno,u32 SrcPos);
void sndbuf_SetKeyon(u8 chno,b8 Keyon);
void sndbuf_SetVarSrcPos(u8 chno,u32 SrcPos);
void sndbuf_SetVarKeyon(u8 chno,b8 Keyon);
void sndbuf_SetVarPCMFreq(u8 chno,u32 PCMFreq);
attriwram void sndbuf_DMA1_Handler(void);
attriwram void sndbuf_Handler(void);

attriwram void CMixProc_Null(u32 ch);
attriwram void CMixProc_Equal(u32 ch);
attriwram void CMixProc_Up(u32 ch);
attriwram void CMixProc_Down(u32 ch);
attriwram void CMixProc_Var(u32 ch);

void sndbuf_Init(void)
{
  u32 ch;
  Tsndbuf_Channel *tch;

  for(ch=0;ch<sndbuf_ChannelCount;ch++){
    tch=&sndbuf_ch[ch];
    tch->Data=0;
    tch->Size=0;
    tch->Keyon=False;
    tch->SrcPos=0;
    tch->LoopFlag=False;
    tch->Volume=8;
    tch->VarSrcPos=0;
    tch->VarKeyon=False;
    tch->VarPCMFreq=0;
    tch->VarVolume=VarVolume_Equal;
  }
  
  for(ch=0;ch<sndbuf_ChannelCount;ch++){
    CMixProc[ch]=CMixProc_Null;
    CMixShift[ch]=0;
  }
}

attriwram void sndbuf_RecalcMixProc(u32 ch)
{
  Tsndbuf_Channel *tch=&sndbuf_ch[ch];

  if(tch->Keyon==False){
    if(tch->VarKeyon==False){
      CMixProc[ch]=CMixProc_Null;
      CMixShift[ch]=0;
      }else{
      CMixProc[ch]=CMixProc_Var;
      CMixShift[ch]=0;
    }
    }else{
    switch(tch->Volume){
      case 8:
        CMixProc[ch]=CMixProc_Equal;
        CMixShift[ch]=0;
        break;
      case 9: case 10: case 11: case 12: case 13: case 14: case 15:
        CMixProc[ch]=CMixProc_Up;
        CMixShift[ch]=tch->Volume-8;
        break;
      case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
        CMixProc[ch]=CMixProc_Down;
        CMixShift[ch]=8-tch->Volume;
        break;
    }
  }
}

void sndbuf_SetPCM(u8 chno,s8* Data,u32 Size)
{
  sndbuf_ch[chno].Data=Data;
  sndbuf_ch[chno].Size=Size;
}

void sndbuf_SetLoopFlag(u8 chno,b8 LoopFlag)
{
  sndbuf_ch[chno].LoopFlag=LoopFlag;
}

void sndbuf_SetVolume(u8 chno,u8 v)
{
  Tsndbuf_Channel *tch;
  
  tch=&sndbuf_ch[chno];
  tch->Volume=v;
  tch->VarVolume=VarVolume_Equal;
  farcall_sndbuf_RecalcMixProc(chno);
}

void sndbuf_SetSrcPos(u8 chno,u32 SrcPos)
{
  sndbuf_ch[chno].SrcPos=SrcPos;
}

void sndbuf_SetKeyon(u8 chno,b8 Keyon)
{
  sndbuf_ch[chno].Keyon=Keyon;
  sndbuf_ch[chno].VarKeyon=False;
  farcall_sndbuf_RecalcMixProc(chno);
}

void sndbuf_SetVarSrcPos(u8 chno,u32 SrcPos)
{
  sndbuf_ch[chno].VarSrcPos=SrcPos;
}

void sndbuf_SetVarKeyon(u8 chno,b8 Keyon)
{
  sndbuf_ch[chno].VarKeyon=Keyon;
  sndbuf_ch[chno].Keyon=False;
  farcall_sndbuf_RecalcMixProc(chno);
}

void sndbuf_SetVarPCMFreq(u8 chno,u32 PCMFreq)
{
  sndbuf_ch[chno].VarPCMFreq=PCMFreq;
}

void sndbuf_SetVarVolume(u8 chno,u8 v)
{
  Tsndbuf_Channel *tch;

  tch=&sndbuf_ch[chno];
  tch->Volume=8;
  tch->VarVolume=VarVolume_Equal+(8-v);
//  const u8 ppVolumeTable[16]={2,3,4,5,6,8,10,12,16,20,24,32,40,48,64,80};
//  tch->VarVolume=ppVolumeTable[v];
  farcall_sndbuf_RecalcMixProc(chno);
}

void sndbuf_StartPCM(void)
{
  REG_DM1CNT_H&= ~DMA_TRANSFER_ON;

  REG_SGCNT1  = ENABLE_SOUND_MASTER;
  REG_SGCNT0_L=0x0000;
  REG_SGCNT0_H|=(DSOUND_A_TIMER1 | ENABLE_DSOUND_A_RIGHT | ENABLE_DSOUND_A_LEFT | DSOUND_A_FULL_OUTPUT);
  REG_SGCNT0_H|=(RESET_DSOUND_A);
  
  REG_DM1CNT_H= 0;
  REG_DM1SAD   = (u32)(sndbuf1);
  REG_DM1DAD   = (u32)SGFIF0A;
  REG_DM1CNT_H= sndbuf_REG_DM1CNT_H;

  REG_TM1D = sndbuf_REG_TM1D_15625;
  REG_TM1CNT = TM_ENABLE | TM_FREQ_PER_1;

  writebuf=sndbuf1;
  writebufno=0;
  sndbuf_playpos=sndbuf_DMA1Timeout-1;
  
  s8 *twb;
  u32 cnt;
  twb=sndbuf0;
  for(cnt=0;cnt<(sndbuf_size+256);cnt++) twb[cnt]=0;
  twb=sndbuf1;
  for(cnt=0;cnt<(sndbuf_size+256);cnt++) twb[cnt]=0;

  REG_DM1CNT_H|= DMA_TRANSFER_ON;
}

b8 processing=False;

attriwram void sndbuf_DMA1_Handler(void)
{
  if(sndbuf_playpos!=0){
    sndbuf_playpos--;
    }else{
    if (processing==False){
      processing=True;
      sndbuf_playpos=sndbuf_DMA1Timeout-1;
      REG_DM1CNT_H= (sndbuf_REG_DM1CNT_H |DMA_TRANSFER_OFF);
      REG_DM1SAD   = (u32)(writebuf);
      REG_DM1CNT_H= (sndbuf_REG_DM1CNT_H |DMA_TRANSFER_ON);
      if(writebufno==0){
        writebuf=sndbuf0;
        writebufno=1;
        }else{
        writebuf=sndbuf1;
        writebufno=0;
      }
      farcall(fp)=sndbuf_Handler;
      fp();
      processing=False;
    }
  }
}

attriwram void sndbuf_Handler(void)
{
  s8 *twb=writebuf;
  u32 cnt;
  for(cnt=0;cnt<sndbuf_size;cnt++) twb[cnt]=0;
  
  u32 ch;
  Tsndbuf_Channel *tch;
  
  for(ch=0;ch<sndbuf_ChannelCount;ch++){
    CMixProc[ch](ch);
  }
  
  for(ch=0;ch<sndbuf_ChannelCount;ch++){
    tch=&sndbuf_ch[ch];
    
    if(tch->Keyon==True){
      tch->SrcPos+=sndbuf_size;
      if (tch->SrcPos>=tch->Size){
        if (tch->LoopFlag==True){
          tch->SrcPos=0;
          }else{
          tch->SrcPos=0;
          tch->Keyon=False;
          farcall_sndbuf_RecalcMixProc(ch);
        }
      }
    }
    
    if(tch->VarKeyon==True){
      if ((tch->VarSrcPos>>16)>=tch->Size){
        if (tch->LoopFlag==True){
          tch->VarSrcPos=0;
          }else{
          tch->VarSrcPos=0;
          tch->VarKeyon=False;
          farcall_sndbuf_RecalcMixProc(ch);
        }
      }
    }
  }
}

attriwram void CMixProc_Null(u32 ch)
{
}

attriwram void CMixProc_Equal(u32 ch)
{
  s8 *twb=writebuf;
  s8 *dch=(s8*)&sndbuf_ch[ch].Data[sndbuf_ch[ch].SrcPos];
  
  u32 cnt;
  for(cnt=0;cnt<sndbuf_size;cnt++) twb[cnt]+=dch[cnt];
}

attriwram void CMixProc_Up(u32 ch)
{
  s8 *twb=writebuf;
  s8 *dch=(s8*)&sndbuf_ch[ch].Data[sndbuf_ch[ch].SrcPos];
  u8 vch=CMixShift[ch];
  
  u32 cnt;
  for(cnt=0;cnt<sndbuf_size;cnt++) twb[cnt]+=dch[cnt]<<vch;
}

attriwram void CMixProc_Down(u32 ch)
{
  s8 *twb=writebuf;
  s8 *dch=(s8*)&sndbuf_ch[ch].Data[sndbuf_ch[ch].SrcPos];
  u8 vch=CMixShift[ch];
  
  u32 cnt;
  for(cnt=0;cnt<sndbuf_size;cnt++) twb[cnt]+=dch[cnt]>>vch;
}

attriwram void CMixProc_Var(u32 ch)
{
  u32 cnt;

  Tsndbuf_Channel *tch=&sndbuf_ch[ch];
  s8 *twb=writebuf;

  u32 SrcPos=tch->VarSrcPos;
  u32 PCMFreq=tch->VarPCMFreq;
  s8 *data=&tch->Data[0];
  u8 VarVolume=tch->VarVolume;
  
  u32 datapos;
  u32 vol;

  if(VarVolume==VarVolume_Equal){
    for(cnt=0;cnt<sndbuf_size;cnt++){
      vol=SrcPos&0xffff;
      datapos=SrcPos>>16;
      twb[cnt]+=((data[datapos+0]*(0xffff-vol))+(data[datapos+1]*vol))>>16;
      SrcPos+=PCMFreq;
    }
    }else{
    for(cnt=0;cnt<sndbuf_size;cnt++){
      vol=SrcPos&0xffff;
      datapos=SrcPos>>16;
      twb[cnt]+=((data[datapos+0]*(0xffff-vol))+(data[datapos+1]*vol))>>VarVolume;
      SrcPos+=PCMFreq;
    }
  }
  tch->VarSrcPos=SrcPos;
}

