// bin2c converter ver0.1 by Moonlight.

#ifndef OPM2GBATable_h
#define OPM2GBATable_h

/*
typedef unsigned short u16;
*/

// 96note + 64detune

#define OPM2GBATable_Count 6144
extern const u16 OPM2GBATable[6144];

#endif
