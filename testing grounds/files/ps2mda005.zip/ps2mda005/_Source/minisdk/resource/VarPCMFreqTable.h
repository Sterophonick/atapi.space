// bin2c converter ver0.1 by Moonlight.

#ifndef VarPCMFreqTable_h
#define VarPCMFreqTable_h

/*
typedef unsigned long u32;
*/

// 96note + 64detune

#define VarPCMFreqTable_Count 6144
extern const u32 VarPCMFreqTable[6144];

#endif
