#ifndef pcmstream_h
#define pcmstream_h

#include "boolean.h"

typedef struct {
  s8 *Data;
  u32 Size;
  b8 Keyon;
  u32 SrcPos;
  b8 LoopFlag;
  u8 Volume;
  u32 VarSrcPos;
  b8 VarKeyon;
  u32 VarPCMFreq;
  u8 VarVolume;
} Tsndbuf_Channel;

extern void sndbuf_SetPCM(u8 chno,s8* Data,u32 Size);
extern void sndbuf_SetLoopFlag(u8 chno,b8 LoopFlag);
extern void sndbuf_SetVolume(u8 chno,u8 v);
extern void sndbuf_SetSrcPos(u8 chno,u32 SrcPos);
extern void sndbuf_SetKeyon(u8 chno,b8 Keyon);

extern void sndbuf_SetVarSrcPos(u8 chno,u32 SrcPos); // 16.16bit
extern void sndbuf_SetVarKeyon(u8 chno,b8 Keyon);
extern void sndbuf_SetVarPCMFreq(u8 chno,u32 PCMFreq); // 16.16bit
extern void sndbuf_SetVarVolume(u8 chno,u8 v);

extern void sndbuf_Init(void);
extern void sndbuf_StartPCM(void);
extern void sndbuf_DMA1_Handler(void);

#endif
