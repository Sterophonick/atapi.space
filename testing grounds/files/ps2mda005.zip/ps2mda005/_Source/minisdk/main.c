#include "header\GBA.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\sound.h"
#include "header\IRQ.h"

#include "debug.h"

#include "boolean.h"
#include "pcmstream.h"
#include "madrv.h"

#include "interrupt.c"
#include "GBATools.c"

void StartMADRV(void);
void StopMADRV(void);

void IRQHandler_Timer3(void)
{
  dprint("MDA.TotalClock=");
  inttostr(MDA.TotalClock,5);
  dprint(res_inttostr);
  dprint("\n");
}

int main(void)
{
  sndbuf_Init();
  sndbuf_StartPCM();
  StartMADRV();
  
  // �P�b�^�C�}�[16384clk
  REG_TM3CNT = 0;
  REG_TM3D=0x10000-16384;
  REG_TM3CNT = TM_FREQ_PER_1024 | TM_ENABLE | TM_USEIRQ;

  IRQTable[IRQIndex_DMA1]=(u32)sndbuf_DMA1_Handler;
  IRQTable[IRQIndex_Timer2]=(u32)madrv_Handler;
  IRQTable[IRQIndex_Timer3]=(u32)IRQHandler_Timer3;
  IRQ_Setup(IRQ_BIT_TIMER2 | IRQ_BIT_TIMER3 | IRQ_BIT_DMA1, 0);
  
  while(1){
    WaitForVsync();
  }
}

extern u8 __iwram_overlay_lma;

void StartMADRV(void)
{
  REG_TM2CNT=TM_FREQ_PER_64 | TM_USEIRQ;
  REG_TM2D=0;
  
  madrv_ClearData();
  if(madrv_LoadMDA2(&__iwram_overlay_lma)==False){
    dprint("MDA�f�[�^��ROM�����Ɍ�����܂���ł����BHALT���܂��B");
    REG_DM1CNT_H=0;
    REG_IME=0;
    while(1);
  }

  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
}

void StopMADRV(void)
{
  REG_TM2CNT&=~TM_ENABLE;
  REG_TM2D=0;

  madrv_AllNoteoff();
  madrv_ClearData();
  madrv_MDARegisterInit();
  madrv_GBRegisterInit();
}

