#include "header\GBA.h"
#include "header\sound.h"
#include "header\IRQ.h"
#include "header\Timer.h"
#include "boolean.h"
#include "madrv.h"
#include "pcmstream.h"
#include "resource\OPM2GBATable.h"
#include "resource\VarPCMFreqTable.h"

//#include "debug.h"

#define farcall(p) static void(*p)(void)
#define farcallu32(p) static void(*p)(u32)
#define farcallb8(p) static void(*p)(b8)

#define NULL (void *)0

#define code_EnableOPMMP True
#define code_EnableOPMMA True
#define code_EnableExtendPanpot False
#define code_EnablePCM8 True
#define code_EnableVarPCM8 True

const u8 MDA_ChannelMap[madrv_ChannelCount]={0,1,2,3,4,5,6,7,
                                             8,9,10,11,12,13,14,15};

#define ATI_MDA_ttl 0
#define ATI_MDA_ofs 1
#define ATI_MDA_siz 2
#define ATI_MDA_mml 3
#define ATI_MDA_voi 4
#define ATI_PDA_pcm 8
#define ATI_PDA_ofs 9
#define ATI_PDA_siz 10
#define ATI_CMT 11
#define ATI_GB3P 12
#define ATICount 32

typedef struct {
  u32 offset;
  u32 size;
} Toffset;

u8 *MDA_ttl;
u16 *MDA_ofs;
u16 *MDA_siz;
u8 *MDA_mml;
u8 *MDA_voi;
s8 *PDA_pcm;
u32 *PDA_ofs;
u32 *PDA_siz;
u16 *GB3P;
u8 *CMT;

Tmadrv_MDA MDA;
Tmadrv_Channel MDAch[madrv_ChannelCount];
Tmadrv_Channel *pch; // �������`�����l��

attriwram void madrv_Handler(void);

void SetOPMVoice(void);
void SetOPMMode(void);
attriwram void SetOPMNoteNumber(b8 ResetKey);
void (*farcall_SetOPMNoteNumber)(b8)=SetOPMNoteNumber;
attriwram void SetOPMVolume(void);
void (*farcall_SetOPMVolume)(void)=SetOPMVolume;
void SetOPMNoteon(void);
void SetOPMNoteoff(void);
void SetOPMMPInit(void);
void SetOPMMAInit(void);
void SetOPMReg(u8 addr,u8 val);
void SetADPCMMode(b8 EnabledNoteon);
void SetADPCMNoteoff(void);
void SetVarADPCMMode(b8 EnabledNoteon);
void SetVarADPCMNoteoff(void);
void MMLAnalize(void);

attriwram void ProcessOPMMP(void);
attriwram void ProcessOPMMA(void);

void madrv_ClearData(void)
{
  MDA_ttl=NULL;
  MDA_ofs=NULL;
  MDA_siz=NULL;
  MDA_mml=NULL;
  MDA_voi=NULL;
  PDA_pcm=NULL;
  PDA_ofs=NULL;
  PDA_siz=NULL;
  CMT=NULL;
  GB3P=NULL;
}

b8 madrv_LoadMDA2(u8 *buf)
{
  u32 baseadr;
  Toffset *AT;
  
  baseadr=(u32)buf;
  if(*(u32*)baseadr!=0x3241444d) return(False); // ignore not "MDA2"
  baseadr+=4;
  AT=(Toffset*)baseadr;
  
  if(AT[ATI_MDA_ttl].offset!=0) MDA_ttl=(u8*)(baseadr+AT[ATI_MDA_ttl].offset);
  if(AT[ATI_MDA_ofs].offset!=0) MDA_ofs=(u16*)(baseadr+AT[ATI_MDA_ofs].offset);
  if(AT[ATI_MDA_siz].offset!=0) MDA_siz=(u16*)(baseadr+AT[ATI_MDA_siz].offset);
  if(AT[ATI_MDA_mml].offset!=0) MDA_mml=(u8*)(baseadr+AT[ATI_MDA_mml].offset);
  if(AT[ATI_MDA_voi].offset!=0) MDA_voi=(u8*)(baseadr+AT[ATI_MDA_voi].offset);
  if(AT[ATI_PDA_pcm].offset!=0) PDA_pcm=(u8*)(baseadr+AT[ATI_PDA_pcm].offset);
  if(AT[ATI_PDA_ofs].offset!=0) PDA_ofs=(u32*)(baseadr+AT[ATI_PDA_ofs].offset);
  if(AT[ATI_PDA_siz].offset!=0) PDA_siz=(u32*)(baseadr+AT[ATI_PDA_siz].offset);
  if(AT[ATI_CMT].offset!=0)     CMT=(u8*)(baseadr+AT[ATI_CMT].offset);
  if(AT[ATI_GB3P].offset!=0)    GB3P=(u16*)(baseadr+AT[ATI_GB3P].offset);
  
  return(True);
}

u8* madrv_GetTitle(void)
{
  if(MDA_ttl==NULL){
    return("can't load MusicData");
    }else{
    return(MDA_ttl);
  }
}

u8* madrv_GetComment(void)
{
  if(CMT==NULL){
    return("can't load CommentData");
    }else{
    return(CMT);
  }
}

void madrv_MDARegisterInit(void)
{
  // MML Struct Init.
  MDA.TotalClock=0;
  MDA.Tempo=200;
  MDA.Timer64Tempo=0x40000/(3840/(0x100-(u32)MDA.Tempo));
  MDA.LoopCount=0;
  MDA.EndFlag=False;
  MDA.NR10=0;
  MDA.NR11=2<<6;
  MDA.NR12=0;
  MDA.NR21=2<<6;
  MDA.NR22=0;
  MDA.NR42=0;
  MDA.NR43=0;
  
  REG_TM2CNT&=~TM_ENABLE;
  REG_TM2D=0x10000-MDA.Timer64Tempo;
  REG_TM2CNT|=TM_ENABLE;
  
  // MML Channel Parametor Init.
  Tmadrv_Channel *tch;
  u32 ChCnt;
  
  for(ChCnt=0;ChCnt<madrv_ChannelCount;ChCnt++){
    tch=&MDAch[ChCnt];
    tch->myChNo=ChCnt;
    if(ChCnt<=7){
      tch->myOPM=True;
      }else{
      tch->myOPM=False;
    }
  }
  
  for(ChCnt=0;ChCnt<madrv_ChannelCount;ChCnt++){
    tch=&MDAch[ChCnt];
    
    if(MDA_mml==NULL){
      tch->Enabled=False;
      tch->Buffer=NULL;
      }else{
      tch->Enabled=True;
      if(MDA_ChannelMap[ChCnt]!=0xff){
        tch->Buffer=&MDA_mml[MDA_ofs[MDA_ChannelMap[ChCnt]]];
        }else{
        tch->Buffer=NULL;
      }
    }
    
    tch->MMLSize=0;
    tch->Cmd=NULL;
    tch->Looped=False;
    tch->NowPos=0;
    tch->NowVoice=0;
    tch->NowKeycode=1;
    tch->NowPanpot=3;
    tch->ExtPanpot=0;
    tch->NowPortament=0;
    if(tch->myOPM==True){
      tch->ADPCMMode=2;
      }else{
      tch->ADPCMMode=4;
    }
    tch->LastPitch=0;
    
    if(tch->myOPM==True){
      tch->RestClock=2; // PCMBuffer�x���␳
      }else{
      tch->RestClock=1;
    }
    tch->StopClock=1;
    tch->LoopCount[0]=0;
    tch->LoopMax=0;
    
    tch->Noteon=False;
    tch->Volume=8;
    tch->VolMode=False;
    tch->Quartz=0;
    tch->QuartzMode=True;
    tch->KeyoffMode=True;
    tch->Detune=0;
    tch->Portament=0;
    tch->KeyonDelay=0;

    tch->SLFODelay=0;
    tch->SLFONowDelay=0;
    
    tch->MPEnabled=False;
    tch->MPWaveType=0; // 0=���` 1=��`�g 2=�O�p�g
    tch->MPFreq=0;
    tch->MPDisplace=0;
    tch->MPNowDisplace=0;
    tch->MPNowFreq=0;
    tch->MPNowDetune=0;

    tch->MAEnabled=False;
    tch->MAWaveType=0; // 0=���` 1=��`�g 2=�O�p�g
    tch->MAFreq=0;
    tch->MADisplace=0;
    tch->MANowDisplace=0;
    tch->MANowFreq=0;
    tch->MANowDetune=0;

    tch->forVis_Noteon=False;
  }
}

void madrv_GBRegisterInit(void)
{
  REG_SGCNT0_L=(BIT6|BIT5|BIT4) | (BIT2|BIT1|BIT0);
  REG_SGCNT1=ENABLE_SOUND_MASTER |
             ENABLE_SOUND4 | ENABLE_SOUND3 | ENABLE_SOUND2 | ENABLE_SOUND1;
  REG_SG10_L=0;
  REG_SG10_H=0;
  REG_SG11=0;
  REG_SG20=0;
  REG_SG21=0;
  REG_SG30_L=BIT7|BIT5;
  REG_SG30_H=0;
  REG_SG31=0;
  REG_SG40=0;
  REG_SG41=0;

  // �O�p�g
  REG_SG30_L&=~(BIT6);
  REG_SGWR0_L=0x2301;
  REG_SGWR0_H=0x6745;
  REG_SGWR1_L=0xab89;
  REG_SGWR1_H=0xefcd;
  REG_SGWR2_L=0xdcfe;
  REG_SGWR2_H=0x98ba;
  REG_SGWR3_L=0x5476;
  REG_SGWR3_H=0x1032;

  REG_SG30_L|=BIT6;
  REG_SGWR0_L=0x2301;
  REG_SGWR0_H=0x6745;
  REG_SGWR1_L=0xab89;
  REG_SGWR1_H=0xefcd;
  REG_SGWR2_L=0xdcfe;
  REG_SGWR2_H=0x98ba;
  REG_SGWR3_L=0x5476;
  REG_SGWR3_H=0x1032;

  REG_SG30_L&=~(BIT6);
}

void madrv_AllNoteoff(void)
{
  u32 ChCnt;
  for(ChCnt=0;ChCnt<4;ChCnt++){
    pch=&MDAch[ChCnt];
    SetOPMNoteoff();
  }
#if code_EnablePCM8==True
  for(ChCnt=8;ChCnt<madrv_ChannelCount;ChCnt++){
    pch=&MDAch[ChCnt];
    SetADPCMNoteoff();
  }
#endif
}

attriwram void madrv_Handler(void)
{
  MDA.TotalClock++;
  
  Tmadrv_Channel *tch;
  
  inline void MMLCompile(void)
  {
    if(tch->NowKeycode!=0){
      if(tch->Portament!=0){
        tch->NowPortament+=tch->Portament;
        farcallb8(fp)=SetOPMNoteNumber;
        fp(False);
      }
      if(tch->SLFONowDelay!=0){
        tch->SLFONowDelay--;
        }else{
  #if code_EnableOPMMP==True
        if(tch->MPEnabled==True){
          ProcessOPMMP();
          if(tch->myOPM==True){
            SetOPMNoteNumber(False);
            }else{
            farcallb8(fp)=SetADPCMMode;
            fp(False);
          }
        }
  #endif
  #if code_EnableOPMMA==True
        if(tch->MAEnabled==True){
          ProcessOPMMA();
          if(tch->myOPM==True){
            SetOPMVolume();
            }else{
            farcallb8(fp)=SetADPCMMode;
            fp(False);
          }
        }
  #endif
      }
      
      if(tch->KeyoffMode==True){
        if(tch->StopClock!=0){
          tch->StopClock--;
          if(tch->StopClock==0){
            tch->Portament=0;
            tch->NowPortament=0;
            tch->NowKeycode=0;
            if(tch->myOPM==True){
              farcall(fp1)=SetOPMNoteoff;
              fp1();
              }else{
              farcall(fp2)=SetADPCMNoteoff;
              fp2();
            }
          }
        }
      }
    }
    if(tch->RestClock!=0){
      tch->RestClock--;
      if(tch->RestClock==0){
        farcall(fp)=MMLAnalize;
        fp();
      }
    }
  }

  u32 ChCnt;
  for(ChCnt=0;ChCnt<4;ChCnt++){
    pch=&MDAch[ChCnt];
    tch=pch;
    if((tch->Buffer!=NULL)&&(tch->Enabled==True)) MMLCompile();
  }
#if code_EnablePCM8==True
  for(ChCnt=8;ChCnt<madrv_ChannelCount;ChCnt++){
    pch=&MDAch[ChCnt];
    tch=pch;
    if((tch->Buffer!=NULL)&&(tch->Enabled==True)) MMLCompile();
  }
#endif
}

void SetOPMVoice(void)
{
  u16 *pcm;
  
  switch(pch->myChNo){
    case 0: // sound1
      MDA.NR12=pch->NowVoice&(BIT0|BIT1|BIT2|BIT3);
      break;
    case 1: // sound2
      MDA.NR22=pch->NowVoice&(BIT0|BIT1|BIT2|BIT3);
      break;
    case 2: // gb3pcm
      pcm=GB3P;
      pcm+=(pch->NowVoice*16); // 4bit64step(32byte)
    
      REG_SG30_L&=~(BIT6);
      REG_SGWR0_L=pcm[0];
      REG_SGWR0_H=pcm[1];
      REG_SGWR1_L=pcm[2];
      REG_SGWR1_H=pcm[3];
      REG_SGWR2_L=pcm[4];
      REG_SGWR2_H=pcm[5];
      REG_SGWR3_L=pcm[6];
      REG_SGWR3_H=pcm[7];
    
      REG_SG30_L|=BIT6;
      REG_SGWR0_L=pcm[8];
      REG_SGWR0_H=pcm[9];
      REG_SGWR1_L=pcm[10];
      REG_SGWR1_H=pcm[11];
      REG_SGWR2_L=pcm[12];
      REG_SGWR2_H=pcm[13];
      REG_SGWR3_L=pcm[14];
      REG_SGWR3_H=pcm[15];

      REG_SG30_L&=~(BIT6);
      break;
    case 3: // sound4
      MDA.NR42=pch->NowVoice&(BIT0|BIT1|BIT2|BIT3);
      break;
  }
    
}

void SetOPMMode(void)
{
  switch(pch->myChNo){
    case 0: // sound1
      MDA.NR11=(pch->ADPCMMode%4)<<6;
      break;
    case 1: // sound2
      MDA.NR21=(pch->ADPCMMode%4)<<6;
      break;
    case 2: // gb3pcm
      break;
    case 3: // sound4
      break;
  }
    
}

attriwram void SetOPMNoteNumber(b8 ResetKey)
{
  Tmadrv_Channel *tch=pch;

  s32 Freq;
  Freq=tch->Detune+(tch->MPNowDetune>>8)+(tch->NowPortament>>8); // 1note / 64pitch
  tch->LastPitch=((tch->NowKeycode+1)*64)+Freq;
  
  u16 GBPitch;
  GBPitch=OPM2GBATable[tch->LastPitch];
  switch(tch->myChNo){
    case 0:
      if(ResetKey==True){
        REG_SG11=GBPitch|BIT15;
        }else{
        REG_SG11=GBPitch;
      }
      break;
    case 1:
      if(ResetKey==True){
        REG_SG21=GBPitch|BIT15;
        }else{
        REG_SG21=GBPitch;
      }
      break;
    case 2:
      if(ResetKey==True){
        REG_SG31=GBPitch|BIT15;
        }else{
        REG_SG31=GBPitch;
      }
      break;
    case 3:
      if(ResetKey==True){
        REG_SG41=MDA.NR43|BIT15;
        }else{
        REG_SG41=MDA.NR43;
      }
      break;
  }
}

const u16 gb3voltbl[16]={0,3,3,3,2,2,2,2,4,4,4,4,1,1,1,1};

attriwram void SetOPMVolume(void)
{
  // gb3pcm VolumeTable 0=0% 3=25% 2=50% 4=75% 1=100%
  //  0= 0%  1= 6%  2=13%  3=20%  4=26%  5=33%  6=40%  7=%46
  //  8=53%  9=60% 10=66% 11=73% 12=80% 13=86% 14=93% 15=100%

  s16 vol;
  
#if code_EnableOPMMA==True
  if(pch->VolMode==True){
    vol=pch->Volume;
    }else{
    vol=pch->Volume<<3;
  }
  
  vol+=pch->MANowDetune>>8;
  if(vol<0) vol=0;
  if(127<vol) vol=127;
  vol=vol>>3;
#else
  if(pch->VolMode==True){
    vol=pch->Volume>>3;
    }else{
    vol=pch->Volume;
  }
#endif

  if(pch->RealVolume!=vol){
    pch->RealVolume=vol;
    switch(pch->myChNo){
      case 0:
        REG_SG10_H=(vol<<12)+(MDA.NR12<<8)+MDA.NR11;
        break;
      case 1:
        REG_SG20=(vol<<12)+(MDA.NR22<<8)+MDA.NR21;
        break;
      case 2:
        REG_SG30_H=gb3voltbl[vol]<<13;
        break;
      case 3:
        REG_SG40=(vol<<12)+(MDA.NR42<<8);
        break;
      default:
        break;
    }
    SetOPMNoteNumber(True);
  }
}

void SetOPMPanpot(void)
{
  u8 panpot;
  
  panpot=pch->NowPanpot;
  
#if code_EnableExtendPanpot==True
  const u8 extpantbl_rnd[8]={2,1,3,1,2,2,3,1};
  const u8 extpantbl_l2r[3]={1,3,2};
  const u8 extpantbl_r2l[3]={2,3,1};
  const u8 extpantbl_rot[4]={1,3,2,3};

  if(panpot>=4){
    switch(panpot){
      case 4: // random
        panpot=extpantbl_rnd[pch->ExtPanpot];
        pch->ExtPanpot++;
        if(pch->ExtPanpot==7) pch->ExtPanpot=0;
        break;
      case 5: // left to right
        panpot=extpantbl_l2r[pch->ExtPanpot];
        pch->ExtPanpot++;
        if(pch->ExtPanpot==2) pch->ExtPanpot=0;
        break;
      case 6: // right to left
        panpot=extpantbl_r2l[pch->ExtPanpot];
        pch->ExtPanpot++;
        if(pch->ExtPanpot==2) pch->ExtPanpot=0;
        break;
      case 7: // rotate
        panpot=extpantbl_rot[pch->ExtPanpot];
        pch->ExtPanpot++;
        if(pch->ExtPanpot==3) pch->ExtPanpot=0;
        break;
    }
  }
#endif
  
  u16 LeftEnable,RightEnable;

  if((pch->NowPanpot&0x01)==0x00){
    LeftEnable=0x0000;
    }else{
    LeftEnable=0xffff;
  }
  if((pch->NowPanpot&0x02)==0x00){
    RightEnable=0x0000;
    }else{
    RightEnable=0xffff;
  }

  u16 mask;
  
  switch(pch->myChNo){
    case 0:
      mask=(ENABLE_SOUND1_LEFT&LeftEnable) | (ENABLE_SOUND1_RIGHT&RightEnable);
      break;
    case 1:
      mask=(ENABLE_SOUND2_LEFT&LeftEnable) | (ENABLE_SOUND2_RIGHT&RightEnable);
      break;
    case 2:
      mask=(ENABLE_SOUND3_LEFT&LeftEnable) | (ENABLE_SOUND3_RIGHT&RightEnable);
      break;
    case 3:
      mask=(ENABLE_SOUND4_LEFT&LeftEnable) | (ENABLE_SOUND4_RIGHT&RightEnable);
      break;
    default:
      mask=0;
      break;
  }
  
  REG_SGCNT0_L|=mask;
}

void SetOPMNoteon(void)
{
  SetOPMNoteoff();
#if code_EnableOPMMP==True
  SetOPMMPInit();
#endif
#if code_EnableOPMMA==True
  SetOPMMAInit();
#endif
  farcall_SetOPMVolume();
  SetOPMPanpot();
  farcall_SetOPMNoteNumber(True);
}

void SetOPMNoteoff(void)
{
  u16 mask;
  
  switch(pch->myChNo){
    case 0:
      mask=ENABLE_SOUND1_LEFT | ENABLE_SOUND1_RIGHT;
      break;
    case 1:
      mask=ENABLE_SOUND2_LEFT | ENABLE_SOUND2_RIGHT;
      break;
    case 2:
      mask=ENABLE_SOUND3_LEFT | ENABLE_SOUND3_RIGHT;
      break;
    case 3:
      mask=ENABLE_SOUND4_LEFT | ENABLE_SOUND4_RIGHT;
      break;
    default:
      mask=0;
      break;
  }
  
  REG_SGCNT0_L&=~mask;
}

void SetOPMMPInit(void)
{
  Tmadrv_Channel *tch=pch;
  
  if(tch->MPEnabled==False){
    tch->MPNowFreq=0;
    tch->MPNowDetune=0;
    tch->MPNowDisplace=tch->MPDisplace;
    return;
  }
  
  if(tch->MPWaveType!=1){
    tch->MPNowFreq=tch->MPFreq/2;
    }else{
    tch->MPNowFreq=0;
  }
  
  tch->MPNowDetune=0;
  tch->MPNowDisplace=tch->MPDisplace;
  
  if(tch->MPWaveType==4){
    tch->MPNowDetune=tch->MPDisplace*(tch->MPFreq/2);
  }
}

attriwram void ProcessOPMMP(void)
{
  Tmadrv_Channel *tch=pch;
  
  switch(tch->MPWaveType){
    case 0: // ���`
      if(tch->MPNowFreq!=0){
        tch->MPNowFreq--;
        }else{
        tch->MPNowFreq=tch->MPFreq;
        tch->MPNowDetune=-tch->MPNowDetune;
      }
      tch->MPNowDetune+=tch->MPNowDisplace;
      break;
    case 1: // ��`�g
      if(tch->MPNowFreq!=0){
        tch->MPNowFreq--;
        }else{
        tch->MPNowFreq=tch->MPFreq;
        tch->MPNowDisplace=-tch->MPNowDisplace;
      }
      tch->MPNowDetune=tch->MPNowDisplace;
      break;
    case 2: // �O�p�g
      if(tch->MPNowFreq!=0){
        tch->MPNowFreq--;
        }else{
        tch->MPNowFreq=tch->MPFreq;
        tch->MPNowDisplace=-tch->MPNowDisplace;
      }
      tch->MPNowDetune+=tch->MPNowDisplace;
      break;
    case 3: // �����_���g
      tch->MPNowDetune=0;
      break;
    case 4: // ���`
      if(tch->MPNowFreq!=0){
        tch->MPNowFreq--;
        tch->MPNowDetune-=tch->MPNowDisplace;
      }
      break;
  }
}

void SetOPMMAInit(void)
{
  Tmadrv_Channel *tch=pch;

  if(tch->MAEnabled==False){
    tch->MANowFreq=0;
    tch->MANowDetune=0;
    tch->MANowDisplace=tch->MADisplace;
    return;
  }
  
  if(tch->MAWaveType!=1){
    tch->MANowFreq=tch->MAFreq;
    }else{
    tch->MANowFreq=0;
  }

  tch->MANowDetune=0;
  tch->MANowDisplace=tch->MADisplace;

  if(tch->MAWaveType==4){
    tch->MANowDetune=(tch->MADisplace/4)*tch->MAFreq;
  }
}

attriwram void ProcessOPMMA(void)
{
  Tmadrv_Channel *tch=pch;
  
  switch(tch->MAWaveType){
    case 0: // ���`
      if(tch->MANowFreq!=0){
        tch->MANowFreq--;
        }else{
        tch->MANowFreq=tch->MAFreq;
        tch->MANowDetune=0;
      }
      tch->MANowDetune+=tch->MANowDisplace;
      break;
    case 1: // ��`�g
      if(tch->MANowFreq!=0){
        tch->MANowFreq--;
        }else{
        tch->MANowFreq=tch->MAFreq;
        if(tch->MANowDisplace==0){
          tch->MANowDisplace=tch->MADisplace;
          }else{
          tch->MANowDisplace=0;
        }
      }
      tch->MANowDetune=tch->MANowDisplace;
      break;
    case 2: // �O�p�g
      if(tch->MANowFreq!=0){
        tch->MANowFreq--;
        }else{
        tch->MANowFreq=tch->MAFreq;
        tch->MANowDisplace=-tch->MANowDisplace;
      }
      tch->MANowDetune+=tch->MANowDisplace;
      break;
    case 3: // �����_���g
      tch->MANowDetune=0;
      break;
    case 4: // ���`
      if(tch->MANowFreq!=0){
        tch->MANowFreq--;
        tch->MANowDetune-=(tch->MANowDisplace/4);
      }
      break;
  }
}

void SetOPMReg(u8 addr,u8 val)
{
  switch(addr){
    case 10:
      MDA.NR10=val;
    case 43:
      MDA.NR43=val;
  }
}

void SetADPCMMode(b8 EnabledNoteon)
{
#if code_EnablePCM8==False
  return;
#endif
  
  Tmadrv_Channel *tch=pch;
  
  if((tch->ADPCMMode==2)||(tch->ADPCMMode==3)){
    SetVarADPCMMode(EnabledNoteon);
    return;
  }

  tch->LastPitch=0;
  if(tch->Noteon==False) return;
  if(tch->NowKeycode==0) return;
  
  tch->LastPitch=(tch->NowKeycode-1)*64;
  
  if(EnabledNoteon==True){
    u16 ADPCMNo;
    ADPCMNo=tch->NowVoice*0x60+(tch->NowKeycode-1);
    
    sndbuf_SetKeyon(tch->myChNo-8,False);
    sndbuf_SetSrcPos(tch->myChNo-8,0);
    if(PDA_siz[ADPCMNo]!=0){
      sndbuf_SetPCM(tch->myChNo-8,&PDA_pcm[PDA_ofs[ADPCMNo]],PDA_siz[ADPCMNo]);
      sndbuf_SetKeyon(tch->myChNo-8,True);
    }
  }
  sndbuf_SetLoopFlag(tch->myChNo-8,False);
  if(tch->VolMode==False){
    sndbuf_SetVolume(tch->myChNo-8,tch->Volume);
    }else{
    sndbuf_SetVolume(tch->myChNo-8,(tch->Volume>>4));
  }
}

void SetADPCMNoteoff(void)
{
  pch->LastPitch=0;
  sndbuf_SetKeyon(pch->myChNo-8,False);
}

void SetVarADPCMMode(b8 EnabledNoteon)
{
#if code_EnableVarPCM8==False
  return;
#endif

  Tmadrv_Channel *tch=pch;
  
  tch->LastPitch=0;
  if(tch->Noteon==False) return;
  if(tch->NowKeycode==0) return;
  
  s32 Freq;
  Freq=tch->Detune+(tch->MPNowDetune>>8)+(tch->NowPortament>>8); // 1note / 64pitch
  tch->LastPitch=(tch->NowKeycode-1)*64+Freq; // key54(o4a)=0x0036*64
  u32 VarPCMFreq; // 16.16bit
  VarPCMFreq=VarPCMFreqTable[tch->LastPitch];
  
  if(EnabledNoteon==True){
    u16 ADPCMNo;
    ADPCMNo=tch->NowVoice*0x60;
    
    sndbuf_SetVarKeyon(tch->myChNo-8,False);
    sndbuf_SetVarSrcPos(tch->myChNo-8,0);
    if(PDA_siz[ADPCMNo]!=0){
      sndbuf_SetPCM(tch->myChNo-8,&PDA_pcm[PDA_ofs[ADPCMNo]],PDA_siz[ADPCMNo]);
      sndbuf_SetVarKeyon(tch->myChNo-8,True);
    }
  }
  sndbuf_SetLoopFlag(tch->myChNo-8,False);
  sndbuf_SetVarPCMFreq(tch->myChNo-8,VarPCMFreq);
  if(tch->VolMode==False){
    sndbuf_SetVarVolume(tch->myChNo-8,tch->Volume);
    }else{
    sndbuf_SetVarVolume(tch->myChNo-8,(tch->Volume>>4));
  }
}

void SetVarADPCMNoteoff(void)
{
  pch->LastPitch=0;
  sndbuf_SetVarKeyon(pch->myChNo-8,False);
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

void MMLAnalize(void)
{
  b8 SetKeyoffMode;
  s32 SetPortament;
  Tmadrv_Channel *tch=pch;
  u8 tcmd0;

  SetKeyoffMode=True;
  SetPortament=0;
  
  while(tch->RestClock==0){
    tch->Cmd=&tch->Buffer[tch->NowPos];
    tcmd0=tch->Cmd[0];
    tch->NowPos++;
    
    if(tcmd0<=0x7f){ // Rest offing
      tch->RestClock=(u16)tcmd0+1;
      tch->Portament=0;
      tch->NowPortament=0;
      tch->StopClock=0;
      tch->Noteon=False;
      if(tch->KeyoffMode==True){
        if(tch->myOPM==True){
          SetOPMNoteoff();
          }else{
          SetADPCMNoteoff();
        }
        tch->NowKeycode=0;
      }
      SetKeyoffMode=True;
    }
    
    if((0x80<=tcmd0)&&(tcmd0<=0xdf)){ // Set Noteon
      tch->Noteon=True;
      tch->Portament=0;
      tch->NowPortament=0;
      tch->NowKeycode=tcmd0-0x80+1;
      if(tch->QuartzMode==True){
        if((u16)tch->Cmd[1]<=tch->Quartz){
          tch->StopClock=1;
          }else{
          tch->StopClock=((u16)tch->Cmd[1]-tch->Quartz)+1;
        }
        }else{
        tch->StopClock=((u16)tch->Cmd[1]*tch->Quartz/8)+1;
      }
      
      if(tch->KeyoffMode==False){
        if(tch->myOPM==True){
          SetOPMVoice();
          farcall_SetOPMNoteNumber(False);
          }else{
          SetADPCMMode(False);
        }
        }else{
        tch->forVis_Noteon=True;
        tch->SLFONowDelay=tch->SLFODelay;
        if(tch->myOPM==True){
          SetOPMNoteoff();
          SetOPMVoice();
          SetOPMNoteon();
          }else{
          SetADPCMMode(True);
        }
      }
      tch->RestClock=(u16)tch->Cmd[1]+1;
      tch->NowPos++;
    }
    
    if(0xe0<=tcmd0){
      switch(tcmd0){
        case 0xff: // Set Tempo
          MDA.Tempo=tch->Cmd[1];
          MDA.Timer64Tempo=0x40000/(3840/(0x100-(u32)MDA.Tempo));
          REG_TM2CNT&=~TM_ENABLE;
          REG_TM2D=0x10000-MDA.Timer64Tempo;
          REG_TM2CNT|=TM_ENABLE;
          tch->NowPos++;
          break;
        case 0xfe: // Set OPM Register
          SetOPMReg(tch->Cmd[1],tch->Cmd[2]);
          tch->NowPos+=2;
          break;
        case 0xfd: // Set VoiceNo.
          tch->NowVoice=tch->Cmd[1];
          if(tch->myOPM==False){
            if(tch->NowVoice>=0x80) tch->NowVoice=0;
          }
          tch->NowPos++;
          SetOPMVoice();
          break;
        case 0xfc: // Set Panpot
          tch->NowPanpot=tch->Cmd[1];
          tch->ExtPanpot=0;
          tch->NowPos++;
          if(tch->myOPM){
            SetOPMPanpot();
            }else{
            SetADPCMMode(False);
          }
          break;
        case 0xfb: // Set Volume
          if(tch->Cmd[1]<=0x7f){
            tch->Volume=tch->Cmd[1];
            if(tch->Volume>=0x10) tch->Volume=0x0f;
            tch->VolMode=False;
            }else{
            tch->Volume=0x7f-(tch->Cmd[1]-0x80);
            tch->VolMode=True;
          }
          tch->NowPos++;
          if(tch->myOPM){
            farcall_SetOPMVolume();
            }else{
            SetADPCMMode(False);
          }
          break;
        case 0xfa: // Downto Volume
          if(tch->Volume>=1) tch->Volume--;
          if(tch->myOPM){
            farcall_SetOPMVolume();
            }else{
            SetADPCMMode(False);
          }
          break;
        case 0xf9: // Downto Volume
          if(tch->myOPM){
            if(tch->Volume<=14) tch->Volume++;
            farcall_SetOPMVolume();
            }else{
            if(tch->Volume<=126) tch->Volume++;
            SetADPCMMode(False);
          }
          break;
        case 0xf8: // Set Pronounce Percent
          if(tch->Cmd[1]<=8){
            tch->Quartz=tch->Cmd[1];
            tch->QuartzMode=False;
            }else{
            tch->Quartz=0x80-((u16)tch->Cmd[1]-0x80)+1;
            tch->QuartzMode=True;
          }
          tch->NowPos++;
          break;
        case 0xf7: // Disable Keyoff
          SetKeyoffMode=False;
          break;
        case 0xf6: // Start Repert
          tch->LoopMax++;
          if(tch->Cmd[1]==0){
            tch->LoopCount[tch->LoopMax]=0xff;
            }else{
            tch->LoopCount[tch->LoopMax]=tch->Cmd[1]-1;
          }
          tch->NowPos+=2;
          break;
        case 0xf5: // End Repert
          if(tch->LoopCount[tch->LoopMax]==0){
            if(tch->LoopMax!=0) tch->LoopMax--;
            tch->NowPos+=2;
            }else{
            tch->LoopCount[tch->LoopMax]--;
            tch->NowPos-=((u16)0xffff)-((u16)tch->Cmd[1]*0x100+(u16)tch->Cmd[2])-1;
          }
          break;
        case 0xf4: // Exit Repert
          if(tch->LoopCount[tch->LoopMax]==0){
            if(tch->LoopMax!=0){
              tch->LoopMax--;
              tch->NowPos+=((u16)tch->Cmd[1]*0x100+(u16)tch->Cmd[2])+4;
            }
            }else{
            tch->NowPos+=2;
          }
          break;
        case 0xf3: // Set Detune
          tch->Detune=(s16)((u16)tch->Cmd[1]*0x100+(u16)tch->Cmd[2]);
          if(tch->myOPM==True) farcall_SetOPMNoteNumber(False);
          tch->NowPos+=2;
          break;
        case 0xf2: // Set Portament
          tch->NowPortament=0;
          SetPortament=(s16)((u16)tch->Cmd[1]*0x100+(u16)tch->Cmd[2]);
          tch->NowPos+=2;
          break;
        case 0xf1: // End of data
          if(tch->Cmd[1]==0x00){
            if(tch->myOPM==True){
              SetOPMNoteoff();
              }else{
              SetADPCMNoteoff();
            }
            tch->Enabled=False;
            }else{
            tch->NowPos-=((u16)0xffff)-((u16)tch->Cmd[1]*0x100+(u16)tch->Cmd[2])-1;
          }
          break;
        case 0xf0: // Set Keyon Delay
          tch->RestClock-=tch->KeyonDelay;
          tch->KeyonDelay=tch->Cmd[1];
          tch->RestClock+=tch->KeyonDelay;
          tch->NowPos++;
          break;
        case 0xef: // Send Adjust Signal
          break;
        case 0xee: // Waiting Adjust Signal
          break;
        case 0xed: // Set Noize Frequency // Supported Ch.H only (MDA SetADPCMMode)
          if(tch->myOPM==True){
            tch->ADPCMMode=tch->Cmd[1];
            SetOPMMode();
            }else{
            tch->ADPCMMode=tch->Cmd[1];
            SetADPCMMode(False);
          }
          tch->NowPos++;
          break;
        case 0xec: // Set Tone LFO
          if(tch->Cmd[1]==0x80){
            tch->MPEnabled=False;
            tch->NowPos++;
            }else{
            if(tch->Cmd[1]==0x81){
              if(tch->MPDisplace!=0) tch->MPEnabled=True;
              tch->NowPos++;
              }else{
              tch->MPEnabled=True;
              tch->MPWaveType=tch->Cmd[1];
              tch->MPFreq=((u16)tch->Cmd[2]<<8)+(u16)tch->Cmd[3]+2;
              tch->MPDisplace=(s16)(((u16)tch->Cmd[4]<<8)+(u16)tch->Cmd[5]);
              tch->NowPos+=5;
              if(tch->MPDisplace==0) tch->MPEnabled=False;
            }
          }
          SetOPMMPInit();
          break;
        case 0xeb: // Set Volume LFO
          if(tch->Cmd[1]==0x80){
            tch->MAEnabled=False;
            tch->NowPos++;
            }else{
            if(tch->Cmd[1]==0x81){
              if(tch->MADisplace!=0) tch->MAEnabled=True;
              tch->NowPos++;
              }else{
              tch->MAEnabled=True;
              tch->MAWaveType=tch->Cmd[1];
              tch->MAFreq=((u16)tch->Cmd[2]<<8)+(u16)tch->Cmd[3]+2;
              tch->MADisplace=(s16)(((u16)tch->Cmd[4]<<8)+(u16)tch->Cmd[5]);
              tch->NowPos+=5;
              if(tch->MADisplace==0) tch->MAEnabled=False;
            }
          }
          SetOPMMAInit();
          break;
        case 0xea: // Set OPM LFO
          if(tch->Cmd[1]==0x80){
            tch->NowPos++;
            }else{
            if(tch->Cmd[1]==0x81){
              tch->NowPos++;
              }else{
              tch->NowPos+=5;
            }
          }
          break;
        case 0xe9: // Set LFO Delay
          tch->SLFODelay=tch->Cmd[1];
          tch->NowPos++;
          break;
        case 0xe8: // Set Expanded PCM8 Mode
          break;
        case 0xe7: // Start Fadeout
          if(tch->Cmd[1]==0x01){
            // MDX.FadeoutFlag:=True;
            // Cmd[2] of FadeoutSpeed not use.
            tch->NowPos+=2;
          }
          break;
        case 0xe6: // Extend Command mxdrv16x system
          tch->Enabled=False;
          break;
        default:
          tch->Enabled=False;
          break;
      }
    }
    
  }
  
  tch->KeyoffMode=SetKeyoffMode;
  tch->Portament=SetPortament;
  if(tch->Portament==0) tch->NowPortament=0;
}
