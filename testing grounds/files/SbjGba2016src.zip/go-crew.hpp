void crew() {      
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+12,by+12, gocrewData);
  }
 }                                                             //draw the block
}

void unloadcrew() {      
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+12,by+12, unload_sprite);
  }
 }                                                             //draw the block
}

if (level == 85) {
          gocrew();
          }
if Not(level == 85) {
             unloadgocrew();
             }
