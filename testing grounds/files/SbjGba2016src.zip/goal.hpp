int gy;
void goalbobble() {
    goal();
    int gty;
    for(gty=0;gty<4;gty++) {
		gy++;
        delay(5);
        }
        for(gty=0;gty<4;gty++) {
            gy--;
            delay(5);
            }
}
void goal()                                                                     //draw the ball
{int dotx,doty;
 for(doty=0;doty<10;doty++)
 { 
  for(dotx=0;dotx<10;dotx++)                                                             //2 pixels are drawn at once
  { 
  goal = PlotPixel(bx+5,by+5, goalData);
  }
 }
 gx = 223;
 gy = 128;
 goalbobble();
}





