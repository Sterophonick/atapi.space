void theend() {
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+12,by+12, theendData);
  }
 }        
}
void unloadtheend() {
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+12,by+12, unload_sprite);
  }
 }        
}


void end() {
     theend();
}
     
