void logo1(){
     logotex = PlotPixel(bx+,by+12, logo1Data);
     };
void logo2(){
     logotex = PlotPixel(bx+,by+12, logo2Data);
     };
void spin() {
     logotex.r += 0x5;
     };

