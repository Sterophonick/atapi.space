/* Main source file for sbjgba */
//includes
#include <agb_lib.h>
#include "backgrounds.hpp"
#include "objects.hpp"
#include "levels.hpp"
#include "music.hpp"
#include "sounds.hpp"
#include "soundinit.hpp"
#include "unused.hpp"
#include "block.hpp"
#include "crash.hpp"
#include "enemy.hpp"
#include "epicgem.hpp"
#include "fezlevel.hpp"
#include "fireball.hpp"
#include "gates.hpp"
#include "go-crew.hpp"
#include "levelchange.hpp"
#include "menu.hpp"
#include "otherfunctions.hpp"
#include "pause.hpp"
#include "theend.hpp"
#include "tinfoil.hpp"
#include "version.hpp"
#include "gravity.hpp"
int start = 0;
int g = 0;
int x = 0;
int y = 0;
int nostart = 1;
int level = 1;
int menu = 0;
int crash=0;
int wait;

void begin() {
	while (Not(crash == 1)) {
		while(Not(pause == 1)) {
     			playsound(17);
   			startblock();
     			goal();
     			levels();
     			init();
     			gem();
     			versionst();
     		}
    	}
}

int main(){
	Initialize();
	bgPic2Buffer((void*)discliamerBitmap);
	bgPal((void*)discliamerPalette);
	bgPic((void*)discliamerBitmap);
	FadeIn(2);
	Sleep(255);
	FadeOut(2);
	bgPic2Buffer((void*)thxBitmap);
	bgPal((void*)thxPalette);
	bgPic((void*)thxBitmap);
	FadeIn(2);
	Sleep(255);
	FadeOut(2);
	bgPic2Buffer((void*)scratchBitmap);
	bgPal((void*)scratchPalette);
	bgPic((void*)scratchBitmap);
	FadeIn(2);
	Sleep(255);
	FadeOut(2);
	bgPic2Buffer((void*)gbadevBitmap);
	bgPal((void*)gbadevPalette);
	bgPic((void*)gbadevBitmap);
	FadeIn(2);
	Sleep(255);
	FadeOut(2);
	bgPic2Buffer((void*)imadog54Bitmap);
	bgPal((void*)imadog54Palette);
	bgPic((void*)imadog54Bitmap);
	FadeIn(2);
	Sleep(255);
	FadeOut(2);
	bgPic2Buffer((void*)slyangelBitmap);
	bgPal((void*)slyangelPalette);
	bgPic((void*)slyangelBitmap);
	FadeIn(2);
	Sleep(255);
	FadeOut(2);
	setbg2((void*)titlescreenBitmap, (void*)titlescreenPalette);
	FadeIn(2);
	while(!(keyDown(KEY_START)))
	{
		wait = 0;
	}
	setbg2((void*)bgBitmap, (void*)bgPalette);
	Sleep(255);
	SetPalette((void*)bgtwoPalette);
	REG_DM3SAD = (unsigned long)bgtwoBitmap;
	REG_DM3DAD = (unsigned long)VideoBuffer;
	REG_DM3CNT = 0x80000000 | 120*160;
	setbg2((void*)bgtwoBitmap, (void*)bgtwoPalette);
	while(1)
	{
		if(keyDown(KEY_SELECT))	
		{
			FadeOut(2);
			setbg2((void*)controlspage1Bitmap, (void*)controlspage1Palette);
			FadeIn(2);
			while(!(keyDown(KEY_A)))
			{
				wait = 0;
			}
			while(keyDown(KEY_A))
			{
				wait = 0;
			}
			FadeOut(2);
			setbg2((void*)controlspage2Bitmap, (void*)controlspage2Palette);
			FadeIn(2);
			while(!(keyDown(KEY_A)))
			{
				wait = 0;
			}
			while(keyDown(KEY_A))
			{
				wait = 0;
			}
			FadeOut(2);
			setbg2((void*)bgtwoBitmap, (void*)bgtwoPalette);
			FadeIn(2);
		}
		if(keyDown(KEY_START))
		{
			FadeOut(15);
			setbg2((void*)l1Bitmap, (void*)l1Palette);
			FadeIn(15);
		}
	}
	return 0;
}
                                                         
