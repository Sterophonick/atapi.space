void screen()                                                                     //draw the block
{int dotx,doty;
 for(doty=0;doty<160;doty++)
 { 
  for(dotx=0;dotx<240;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+10,by+10, blockData);
  }
 }
}

void unloadscreen()                                                                     //unload the block
{int dotx,doty;
 for(doty=0;doty<160;doty++)
 { 
  for(dotx=0;dotx<240;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+10,by+10, unload_sprite);
  }
 }
}

void trigger() {
	if (crash == 1) {
		screen();
		playsound(buzz);
		unloadscreen();
		switchbackdrop(blackData);
		delay(1000);
		playsound(discrestart);
		switchbackdrop(black_finalData);
		delay