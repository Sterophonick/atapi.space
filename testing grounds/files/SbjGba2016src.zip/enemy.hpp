void detectcolor() {
     // -- Don't do this inside the loop, but somewhere else 
// and keep a pointer to the pixels array
// read the entire image into a buffer
CroppedBitmap cb = new CroppedBitmap(source, new Int32Rect(0, 0, 1018, 731));
int px = 240 * 160 * (source.Format.BitsPerPixel / 8);
byte[] pixels = new byte[px];
cb.CopyPixels(pixels, px, 0);

// -- do this inside your loop
// calculate the offset into the array
int offset = (by * 1018 + bx) * 4;
Color c = Color.FromArgb(
    pixels[offset + 3], pixels[offset + 2], pixels[offset + 1], pixels[offset]);

if (c.R == 100 && c.G == 19 && c.B == 0) {
   pixels = null;
   fireballcoll = 1;
}

void enemy()                                                                     //draw the block
{int cx,cy;
 for(doty=0;cy<18;doty++)
 { 
  for(dotx=0;cx<31;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(cx+31,cy+18, eneliveData);
      cx = bx;
  }
 }
}

void unloadenemy()                                                                     //draw the block
{int cx,cy;
 for(cy=0;cy<18;cy++)
 { 
  for(cx=0;cx<31;cx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(cx+31,cy+18, unload_sprite);
  }
 }
}

void enemyDEAD()                                                                     //draw the block
{int cx,cy;
 for(doty=0;cy<18;doty++)
 { 
  for(dotx=0;cx<31;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(cx+31,cy+18, enedeadData);
  }
 }
}

void unloadenemydead()                                                                     //unload a sprite
{int cx,cy;
 for(cy=0;cy<18;cy++)
 { 
  for(cx=0;cx<31;cx++)                                                             //2 pixels are unloaded at once
  { 
      PlotPixel(cx+31,cy+18, unload_sprite);
  }
 }
}

void enemybehavior()
{
enemy();
cx = 120;
cy = 113;
while Not(fireballcoll == 1) {
	cx = 120;
}
unloadenemy();
enemyDEAD();
for(cy=113;cy<131;cy++)
{
cy+=3;
}
for(cy=131;cy<128;cy++)
{
cy-=3;
}
unloadenemydead();
}

