void buttons()                                                                     //draw the ball
{int rx,ry;
 for(ry=0;ry<34;ry++)
 { 
  for(rx=0;rx<32;rx++)                                                             //2 pixels are drawn at once
  { 
     PlotPixel(px+12,py+12, play_data);
     PlotPixel(rx+12,ry+12, restart_data);
  }
 }
}
void unloadbuttons()                                                                     //draw the ball
{int rx,ry;
 for(ry=0;ry<34;ry++)
 { 
  for(rx=0;rx<32;rx++)                                                             //2 pixels are drawn at once
  { 
     PlotPixel(px+12,py+12, unload_sprite);
     PlotPixel(rx+12,ry+12, unload_sprite);
  }
 }
}

void unloadplay()                                                                     //draw the ball
{int px,py;
 for(py=0;py<34;y++)
 { 
  for(px=0;px<32;px++)                                                             //2 pixels are drawn at once
  { 
     PlotPixel(px+12,py+12, unload_sprite);
  }
 }
}

void unloadrestart()                                                                     //draw the ball
{int rx,ry;
 for(ry=0;ry<34;y++)
 { 
  for(rx=0;rx<32;rx++)                                                             //2 pixels are drawn at once
  { 
     PlotPixel(rx+12,ry+12, unload_sprite);
  }
 }
}


int pause = 0;
while (start == 1) {
      if keyDown(KEY_START) {
                                pause = 1;
								rx=60,ry=80;
								px=120,py=80;
								buttons();
                                }
								delay(1000);
      while (pause == 1) {
            if Or(keyDown(KEY_START), keyDown(KEY_A)) {
                                      pause = 0;
                                      }
            if Or(keyDown(KEY_SELECT), keyDown(KEY_B)) {
                                       restart = 1;
                                       }
                                       }
								}
