void gravidetect() {
	if (Or(level == 43), Or(level == 44), Or(level == 45), Or(level == 46), Or(level == 47), (level == 48))
	{
		waituntil(keyDown(KEY_SELECT));
		waituntil(Not(keyDown(KEY_SELECT)));
		gravity = 1;
		waituntil(keyDown(KEY_SELECT));
		waituntil(Not(keyDown(KEY_SELECT)));
		gravity = 0;
	}
}