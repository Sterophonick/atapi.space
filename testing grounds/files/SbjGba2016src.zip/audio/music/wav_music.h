#ifndef _WAV_MUSIC_H_
#define _WAV_MUSIC_H_

#include <gba.h>

extern "C" const u32 g_wav_music[ 741648 + 1 ];

#endif
