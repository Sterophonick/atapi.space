#include "objects.hpp"

int tx=0,ty=0;
void tinfoil()                                                                     //draw the block
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(tx+12,ty+12, tinfoilData);
  }
 }
}

void unloadtinfoil()                                                                     //unload the block
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(tx+12,ty+12, unload_sprite);
  }
 }
}