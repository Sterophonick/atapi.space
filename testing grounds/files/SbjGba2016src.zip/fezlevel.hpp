void fezlevel(){
while (level == 103) {
      waituntil(keyDown(KEY_UP));
      waituntil(keyDown(KEY_UP));
      waituntil(keyDown(KEY_DOWN));
      waituntil(keyDown(KEY_DOWN));
      waituntil(keyDown(KEY_LEFT));
      waituntil(keyDown(KEY_RIGHT));
      waituntil(keyDown(KEY_LEFT));
      waituntil(keyDown(KEY_RIGHT));
      waituntil(keyDown(KEY_B));
      waituntil(keyDown(KEY_A));
      waituntil(keyDown(KEY_START));
      }
 REG_DM3SAD = (unsigned long)l103 (2)Data;
 REG_DM3DAD = (unsigned long)VideoBuffer;
 REG_DM3CNT = 0x80000000 | 120*160;
 playsound(secretsolved);
}
