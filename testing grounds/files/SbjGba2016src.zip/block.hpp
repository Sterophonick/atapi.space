int bx=17,by=128;
int x = 0;
int y = 0;
int deaths = 0;
int time = 0;
int gravity = 0;
int restart = 0;
int collision = GetPixel(x+12,y+12);
int hazardcollision = 0;
int tramp = 0;
int pookacollision = 0;

void block()                                                                     //draw the block
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+12,by+12, blockData);
  }
 }
}

void unloadblock()                                                                     //unload the block
{int dotx,doty;
 for(doty=0;doty<24;doty++)
 { 
  for(dotx=0;dotx<24;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(bx+12,by+12, unload_sprite);
  }
 }
}

void detectcolor() {
// -- Don't do this inside the loop, but somewhere else 
// and keep a pointer to the pixels array
// read the entire image into a buffer
CroppedBitmap cb = new CroppedBitmap(source, new Int32Rect(0, 0, 1018, 731));
int px = 240 * 160 * (source.Format.BitsPerPixel / 8);
byte[] pixels = new byte[px];
cb.CopyPixels(pixels, px, 0);

// -- do this inside your loop
// calculate the offset into the array
int offset = (by * 1018 + bx) * 4;
Color c = Color.FromArgb(
    pixels[offset + 3], pixels[offset + 2], pixels[offset + 1], pixels[offset]);

if (c.R == 0 && c.G == 2.9 && c.B == 61.2) {
   pixels = null;
   collision = 1;
   return true;
}
   if (c.R == 100 && c.G == 0 && c.B == 0) {
   pixels = null;
   hazardcollision = 1;
   return true;
}
   if (c.R == 94.9 && c.G == 0 && c.B == 0) {
   pixels = null;
   pookacollision == 1;
   return true;
}
   if (c.R == 32.5 && c.G == 45.3 && c.B == 100) {
   pixels = null;
   trampoline = 1;
   return true;
}
   if (c.R == 12.8 && c.G == 34.9 && c.B == 100) {
   pixels = null;
		if (level == 32) {
			bx=174,by=15;
		}
		if (level == 33) {
			bx=148,by=15;
		}
		if (level == 34) {
			bx=206,by=18;
		}
		if (level == 35) {
			bx=151,by=115;
		}
		if (level == 36) {
			bx=17,by=50;
		}
		if (level == 37) {
			bx=186,by=17;
		}
		if (level == 38) {
			bx=27,by=14;
		}
   return true;
}
}

void varreset() {
bx=17,by=128;
x = 0;
y = 0;
deaths = 0;
time = 0;
gravity = 0;
restart = 0;
}

    void var_y(int number){
         detectcolor();
         if (gravity == 0){
                     y += number;
         } else {
                y -= number;
         }
		}
             void changey(int number){
         if (gravity == 0){
                     by += number;
         } else {
                by -= number;
         }
	}
                      void sety(int number){
         if (gravity == 0){
                     y = number;
         } else {
                y = (number * 2) - number;
         }
	}
         void die() {
              int bx=17,by=128;
              x = 0;
              y = 0;
              playsound(death);
              restart = 0;
		gravity = 0;
        }
    void physics() {
        block();
        y += -0.5;
		if (keyDown(KEY_RIGHT)) {
			x += 0.5;
        }
        if (keyDown(KEY_LEFT)) {
			x += -0.5;
        }
        x = (x * 0.9);
        bx += x;
        if (collision == 1) {
           changey(1);
           if (collision == 1) {
				changey(1);
				if (collision == 1) {
					changey(1);
					if (collision == 1) {
						changey(1);
						if (collision == 1) {
							changey(1);
							if (collision == 1) {
								changey(1);
								if (collision == 1) {
									changey(-6);
									bx += (x * -1)
									if (keyDown(KEY_A)) {
										if x >= 0 {
											x = -10;
										}else {
											x = 10;
										}
										time = 2.9;
										while Or(keyDown(KEY_A), Not(time <= 4.2)){
											time += .4;
											y = time;
											by += y;
											by -= 0.5;
											if (keyDown(KEY_RIGHT)) {
												x += 0.5;
											}
											if (keyDown(KEY_LEFT)) {
												x += -0.5;
											}
											x = (x * 0.9);
											bx += x;
											if (collision == 1) {
												bx += (x * -1);
											}
											if (collision == 1) {
												by += (y * -1); 
												y = 0;
										    }
											}else {
                                                x = 0;
											}	                                                  
												}
											}
										}
									}
								}
							}
						}           
						changey(y);
           			    if (collision == 1) {
							by += (y * -1); 
							y = 0;
						}
						by -= 0.5
						if (keyDown(KEY_A)) {
							time = 2.9;
						while Or(keyDown(KEY_A), (time <= 4.2)) {
							time += .4;
							y = time;
							by += y;
							by -= 0.5;
						if (keyDown(KEY_RIGHT)) {
							x += .48;
						}
						if (keyDown(KEY_LEFT)) {
							x += -.48;
						}
						x = (x * 0.9);
						bx += x;
						if (collision == 1) {
                            bx += (x * -1);
                        }
                        if (collision == 1) {
                            by += (y * -1); 
                            y = 0;
                        }
                        }
						if (hazardcollision == 1) {
                            die();              
                        }
						if (pookacollision == 1) {
                           diepooka();
                        }
                        if(bx>240-12){die();}                                    //deadly edge
                        if(by>160-12){die();}                                   //deadly edge
                        if(bx>0+12){die();}                                    //deadly edge
                        if(by>0+12){die();}                                   //deadly edge
					    if (trampoline == 1) {
						   sety(4.8);
                        }
                        if (restart == 1) {
                           die();
                        }
                        if (endcoll == 1) {
                           ender();
                        }  			
}
					   
void startblock() {
	while(True){
		if Not(pause == 1) {
		physics();
		}
	}
}