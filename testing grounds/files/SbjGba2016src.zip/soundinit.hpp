typedef struct                                                                  //sound variables
{
 const unsigned char* music;                                                     //pointer to sound's data array	
 int frequency;                                                                 //sound frequency
 int tic;                                                                       //increase up to sounds end
 int end;                                                                       //end of sound
}sounds; sounds sound[17];                                                       //array of sounds structs

void init() {
sound[1].song=complete; sound[1].frequency=22050; sound[1].end=1020; sound[1].tic=0; //init complete
sound[2].song=complete2; sound[2].frequency=22050; sound[2].end=560; sound[2].tic=0; //init complete2
sound[3].song=death; sound[3].frequency=22050; sound[3].end=322; sound[3].tic=0; //init death
sound[4].song=enedeath; sound[4].frequency=22050; sound[4].end=024; sound[4].tic=0; //init enedeath
sound[5].song=gamebeat; sound[5].frequency=22050; sound[5].end=3520; sound[5].tic=0; //init gamebeat
sound[6].song=jump; sound[6].frequency=22050; sound[6].end=600; sound[6].tic=0; //init jump
sound[7].song=laugh; sound[7].frequency=22050; sound[7].end=93; sound[7].tic=0; //init laugh
sound[8].song=logotheme; sound[8].frequency=22050; sound[8].end=5805; sound[8].tic=0; //init logotheme
sound[9].song=pong; sound[9].frequency=22050; sound[9].end=139; sound[9].tic=0; //init pong
sound[10].song=pooka; sound[10].frequency=22050; sound[10].end=683; sound[10].tic=0; //init pooka
sound[11].song=portal; sound[11].frequency=22050; sound[11].end=470; sound[11].tic=0; //init portal
sound[12].song=punch; sound[12].frequency=22050; sound[12].end=420; sound[12].tic=0; //init punch
sound[13].song=rebootdisc; sound[13].frequency=22050; sound[13].end=4200; sound[13].tic=0; //init rebootdisc
sound[14].song=secretsolved; sound[14].frequency=22050; sound[14].end=3660; sound[14].tic=0; //init secretsolved
sound[15].song=staticend; sound[15].frequency=22050; sound[15].end=4874; sound[15].tic=0; //init staticend
sound[16].song=trampoline; sound[16].frequency=22050; sound[16].end=670; sound[16].tic=0; //init trampoline
sound[17].song=music; sound[17].frequency=22050; sound[17].end=134539; sound[17].tic=0; //init song
}