int vx=0,vy=0;

void version()
{int dotx,doty;
 for(dotx=0;dotx<31;dotx++)
 {
  for(doty=0;doty<4;doty++)
  {
   PlotPixel(vx+1,vy+2, versiondata);
  }
 }
}

void versionst()
{
	version();
	vx=240,vy=160;
}