void fireball()                                                                     //draw the block
{int fx,fy;
 for(doty=0;fy<18;doty++)
 { 
  for(dotx=0;fx<31;dotx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(fx+31,fy+18, fireballData);
      fx = bx;
  }
 }
}

void unloadfireball()                                                                     //draw the block
{int fx,fy;
 for(fy=0;fy<18;fy++)
 { 
  for(fx=0;fx<31;fx++)                                                             //2 pixels are drawn at once
  { 
      PlotPixel(fx+31,fy+18, unload_sprite);
  }
 }
}

void fireballbehavior() {
	if (keyDown(KEY_B)) {
		fireball();
		for(fx=0;fx<209;fx++)
		{
                             fx+=5;
							 if (hit == 1) {
							 unloadfireball();
							 }
        }
	}
}
