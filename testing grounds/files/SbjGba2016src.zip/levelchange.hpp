int swag = "l";
int swag2 = "Data";
int level2 = (swag, level, swag2);

void levels(){
	switchbackdrop(level2);
	waittuntil(complete == 1);
	complete = 0;
}

	