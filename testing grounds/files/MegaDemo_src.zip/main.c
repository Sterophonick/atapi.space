#include <agb_lib.h>
#include <stdlib.h>
#include "block.h"
#include "title.h"
#include "goal.h"
#include "boi.h"
#include "gocrew.h"
#include "jumprefresher.h"
#include "such.h"
#include "fnaf.h"
#include "rainh.h"
int bx,rot,by;
int boix, boiy;
double x,y;
int x1,y1;

s16 BallX = 120;	//ball position x
s16 BallY = 80;	//and y

s8  BallSX = 2;	//variable containing value '2'
s8  BallSY = 2;	//variable containing value '2'

void demo()
{
	   	SetMode(MODE_3 | BG2_ENABLE);
	SetPalette((void*)blackPalette);
	FadeIn(0);
	Sleep(255);
	for(y1=0;y1<160;y1++)
	{
		for(x1=0;x1<240;x1++)
		{
			DrawPixel3(x1, y1, rand() % 65536);
			Sleep(0.0005);
		}
	}
	Sleep(510);
	for(y1=0;y1<160;y1++)
	{
		for(x1=0;x1<240;x1++)
		{
			DrawPixel3(x1, y1, 0x0000);
			Sleep(0.0005);
		}
	}
	Sleep(128);
	SetMode(MODE_4|BG2_ENABLE);
	setbg2((void*)titleBitmap, (void*)titlePalette);
	Sleep(255);
	InitializeSprites();
	loadSpritePal((void*)blockPalette);
	loadSpriteGraphics((void*)blockData, 576);
	initSprite(1, SIZE_32, 0);
	SetMode(MODE_4|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	for(bx=-24;bx<266;bx+=5)
	{
		vsync
		CopyOAM();
		MoveSprite(&sprites[1], bx, 68);
	}
	Sleep(255);
	InitializeSprites();
	loadSpritePal((void*)goalPalette);
	loadSpriteGraphics((void*)goalData, 512);
	initSprite(1, SIZE_8, 0);
	SetPalette((void*)blackPalette);
	for(rot=0; rot<999; rot++)
	{
		vsync
		MoveSprite(&sprites[1], BallX, BallY);
		CopyOAM();
		BallX+= BallSX;
	 	BallY+= BallSY;

	 	if( BallY >= 152 ) BallSY = -2;
	 	if( BallY <= 0 )   BallSY = 2;

		if( BallX >= 232 ) BallSX = -2;
	 	if( BallX <= 0 )   BallSX = 2;	
		Sleep(2);
	}
	FadeOut(2);
	
	InitializeSprites();
	loadSpriteGraphics((void*)gocrewData, 2048);
	loadSpritePal((void*)gocrewPalette);
	initSprite(1, SIZE_64, 0);
	setbg2((void*)boiData, (void*)boiPalette);
	FadeIn(2);
	Sleep(255);
	int i;
	MoveSprite(&sprites[1], 0, 0);
	for(i=0;i<999;i++)
	{
		vsync
		MoveSprite(&sprites[1], BallX, BallY);
		CopyOAM();
		CycleBGPalette();
		Sleep(1);
		BallX+= BallSX;
	 	BallY+= BallSY;

	 	if( BallY >= 92 ) BallSY = -2;
	 	if( BallY <= 0 )   BallSY = 2;

		if( BallX >= 176 ) BallSX = -2;
	 	if( BallX <= 0 )   BallSX = 2;	
	}
	InitializeSprites();
	FadeOut(2);
	SetMode(MODE_3|BG2_ENABLE);
	EraseScreen();
	FadeIn(0);
	Sleep(255);
	Print(0,0,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,8,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,16,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,24,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,32,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,40,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,48,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,8,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,16,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,24,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,32,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,40,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,48,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,56,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,64,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,72,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,80,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,88,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,96,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,104,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,112,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,120,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,128,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,136,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,140,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,148,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,156,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	Print(0,164,"101001010010001100110010110010", GREEN, BLACK);
	Sleep(18);
	SetMode(MODE_3|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	InitializeSprites();
	loadSpritePal((void*)jumprefresherPalette);
	loadSpriteGraphics((void*)jumprefresherData, 512);
	initSprite(1, SIZE_32, 0);
	MoveSprite(&sprites[1], 0, 0);
	bx=0;
		for(boiy = 0; boiy < 160; boiy++)
		{
			for(boix = 0; boix < 240; boix++)
			{
				DrawPixel3(boix,boiy,suchBitmap[boiy*240+boix]);
			}
		}
	for(i=0;i<595;i++)
	{
		vsync
		MoveSprite(&sprites[1], BallX, BallY);
		CopyOAM();
		Sleep(1);
		BallX+= BallSX;
	 	BallY+= BallSY;

	 	if( BallY >= 92 ) BallSY = -2;
	 	if( BallY <= 0 )   BallSY = 2;

		if( BallX >= 176 ) BallSX = -2;
	 	if( BallX <= 0 )   BallSX = 2;	
	}
	FadeOut(2);
	SetMode(MODE_4|BG2_ENABLE);
	vsync
	setbg2((void*)titleBitmap, (void*)titlePalette);
	FadeIn(2);
	Sleep(255);
	InitializeSprites();
	loadSpritePal((void*)blockPalette);
	loadSpriteGraphics((void*)blockData, 576);
	initSprite(1, SIZE_32, 0);
	SetMode(MODE_4|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	for(bx=-24;bx<266;bx+=5)
	{
		vsync
		CopyOAM();
		MoveSprite(&sprites[1], bx, 68);
	}
	Sleep(255);
	setbg2((void*)rainhData, (void*)rainhPalette);
	for(i=0;i<512;i++)
	{
		vsync
		CycleBGPalette();
	}
	Sleep(2);
	SetMode(MODE_3|BG2_ENABLE);
	for(y1=0;y1<160;y1++)
	{
		for(x1=0;x1<240;x1++)
		{
			DrawPixel3(x1, y1, 0xFFFF);
		}
	}
	InitializeSprites();
	loadSpritePal((void*)blockPalette);
	loadSpriteGraphics((void*)blockData, 576);
	initSprite(1, SIZE_32, 0);
	SetMode(MODE_3|BG2_ENABLE|OBJ_ENABLE|OBJ_MAP_1D);
	MoveSprite(&sprites[1], 108, 68);
	Sleep(255);
	for(x=0;x<200;x+=0.25)
	{
		CopyOAM();
		vsync
		bx+=x;
		MoveSprite(&sprites[1], bx, 68);
	}
	Sleep(255);
	InitializeSprites();
	loadSpritePal((void*)blockPalette);
	loadSpriteGraphics((void*)blockData, 576);
	initSprite(1, SIZE_32, 0);
	SetMode(MODE_3|BG2_ENABLE|OBJ_ENABLE|OBJ_MAP_1D);
	MoveSprite(&sprites[1], 108, 68);
	Sleep(255);
	for(y=0;y<200;y+=0.25)
	{
		CopyOAM();
		vsync
		by+=y;
		MoveSprite(&sprites[1], 108, by);
	}
	Sleep(255);
	SetMode(MODE_3|BG2_ENABLE);
	fillscreen3(0x0000);
	fillpal(fBG, 0x0000);
	fillpal(fOBJ, 0x0000);
	for(y=0;y<255;y++)	
	{
		vsync
		DrawLine3(120,80,60,y,0x001F);
	}
	Sleep(128);
	fillscreen3(0x0000);
	Sleep(128);
	fillscreen3(0x64C0);
	Sleep(128);
	fillscreen3(WHITE);
	Sleep(128);
	fillscreen3(RED);
	Sleep(128);
	fillscreen3(BLUE);
	Sleep(128);
	fillscreen3(CYAN);
	Sleep(128);
	fillscreen3(GREEN);
	Sleep(128);
	fillscreen3(MAGENTA);
	Sleep(128);
	fillscreen3(BROWN);
	Sleep(128);
	fillscreen3(BRICK);
	Sleep(128);
	fillscreen3(PINK);
	Sleep(128);
	fillscreen3(ORANGE);
	Sleep(128);
	fillscreen3(YELLOW);
	Sleep(128);
	fillscreen3(GREY);
	Sleep(128);
	SetMode(MODE_4|BG2_ENABLE);
	setbg2((void*)titleBitmap, (void*)titlePalette);
	MosaicIn(4);
	MosaicOut(4);
	MosaicIn(4);
	MosaicOut(4);
	MosaicIn(4);
	MosaicOut(4);
	MosaicIn(4);
	MosaicOut(4);
	MosaicIn(4);
	MosaicOut(4);
	MosaicIn(4);
	FadeOut(4);
	FadeIn(4);
	FadeOut(4);
	FadeIn(4);
	FadeOut(4);
	FadeIn(4);
	FadeOut(4);
	FadeIn(4);
	FadeOut(4);
	FadeIn(4);
	InitializeSprites();
	loadSpritePal((void*)blockPalette);
	loadSpriteGraphics((void*)blockData, 576);
	initSprite(1, SIZE_32, 0);
	SetMode(MODE_4|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	for(bx=-24;bx<266;bx+=5)
	{
		vsync
		CopyOAM();
		MoveSprite(&sprites[1], bx, 68);
	}
	SetMode(MODE_3|BG2_ENABLE);
	fillpal(fBG, 0x0000);
	fillpal(fOBJ, 0x0000);
	fillscreen3(WHITE);
	rightwipe3(0x0000, 0.05);
	fillscreen3(RED);
	leftwipe3(0x0000, 0.05);
	fillscreen3(BLUE);
	scanlines3(0x0000, 0.05);
	fillscreen3(CYAN);
	topwipe3(0x0000, 0.05);
	fillscreen3(GREEN);
	bottomwipe3(0x0000, 0.05);
	fillscreen3(MAGENTA);
	circlewipe3(0x0000, 0.05);
	fillscreen3(BROWN);
	Sleep(128);
	fillscreen3(BLACK);
	for(i=0;i<111111;i++)
	{
		static3();
	}
	fillscreen3(0x0000);
	for(i=0;i<111111;i++)
	{
		DrawPixel3(rand() % 240, rand() % 160, rand() % 32768);
	}
	FadeOut(15);
	fillscreen3(0x0000);
	fillpal(fBG, 0x0000);
	fillpal(fOBJ, 0x0000);
	Sleep(512);
	fillscreen3(WHITE);
	FadeIn(2);
	Sleep(128);
	vsync
}

int main()
{
	int x1,y1,n;
	Initialize();
		demo();
	hardreset();
	return 0;
}
		
