#ifndef __AAS_DATA__
#define __AAS_DATA__

#include "AAS.h"

#if AAS_VERSION != 0x109
#error AAS version does not match Conv2AAS version
#endif

AAS_BEGIN_DECLS

extern const AAS_s8* const AAS_DATA_SFX_START_logotheme;

extern const AAS_s8* const AAS_DATA_SFX_END_logotheme;

extern const AAS_s8* const AAS_DATA_SFX_START_punch;

extern const AAS_s8* const AAS_DATA_SFX_END_punch;

AAS_END_DECLS

#endif
