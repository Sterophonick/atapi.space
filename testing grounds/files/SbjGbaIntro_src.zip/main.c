#include <agb_lib.h>
#include "backgrounds.h"
#include "l1.c"
#include "music.h"
#include "rotostuff.h"
#include "logotheme.C"
#include "punch.C"

int wait;
int i;
int j;
int time;
int hdrth=0,Lhdrth=0;
int w;
int bx, by;
u8 block;
int xvel=0; 
int yvel=0;

void drawbg2vb(u16* image, u16* pal)
{
	WaitForVblank();
	bgPic2Buffer(image);
	bgPal(pal);
	bgPic(image);
	SetPalette(pal);
}

void playSound(int s) {
 REG_SOUNDCNT1_H = 0x0B04;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 REG_SOUNDCNT1_X = 0x0080;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 REG_SD1SAD      = (unsigned long) sound[s].song;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 REG_SD1DAD      = 0x040000A0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 REG_SD1CNT_H    = 0xB640;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 REG_TM0SD       = 65536-(16777216/sound[s].frequency);                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 REG_TMSDCNT     = 0x00C0;  
}

int main() //agbmain
{
	SaveInt(0, 7.55);
	int s;
	initsound8(1, 22050, 2801, (void*)logotheme);
 	initsound8(2, 22050, 2801, (void*)punch);
	initsound8(3, 22050, 2801, (void*)music);
	Initialize(); //beginning fade
	bgPic2Buffer((void*)discliamerBitmap); //disclaimer
	bgPal((void*)discliamerPalette);
	bgPic((void*)discliamerBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SetBGPalPoint(1, (void*)GetBGPalPoint(1)+1);
		SleepF(0.50);
		SetBGPalPoint(1, (void*)GetBGPalPoint(1)+1);
		SleepF(0.50);
		SetBGPalPoint(1, (void*)GetBGPalPoint(1)+1);
		SleepF(0.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)thxBitmap); //special thanks
	bgPal((void*)thxPalette);
	bgPic((void*)thxBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)scratchBitmap); //scratch
	bgPal((void*)scratchPalette);
	bgPic((void*)scratchBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)gbadevBitmap); //GBADEV logo
	bgPal((void*)gbadevPalette);
	bgPic((void*)gbadevBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)imadogBitmap); //meh
	bgPal((void*)imadogPalette);
	bgPic((void*)imadogBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)slyangelBitmap); //meh good brah
	bgPal((void*)slyangelPalette);
	bgPic((void*)slyangelBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	setbg2m3(us titlescreenBitmap);
	SetMode(MODE_3|BG2_ENABLE);
	FadeIn(2);
	while(!(keyDown(KEY_START)))
	{
		wait = 0;
	}
	vsync
	SetMode(MODE_4|BG2_ENABLE);
	setbg2novb((void*)roto0Bitmap, (void*)roto0Palette); //logospin
	sound[1].tic=1;
	s=1;
	playSound(1); //play logotheme.wav
		setbg2((void*)roto0Bitmap, (void*)roto0Palette); //logospin
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(1);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(1);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(1);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(1);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(1);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(1);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(1);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(1);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(1);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(1);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(1);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(1);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(1);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(1);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(1);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(1);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(1);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(1);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(1);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(1);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(1);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(1);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(1);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(1);
		setbg2((void*)roto0Bitmap, (void*)roto0Palette);
		Sleep(1);
		setbg2((void*)roto1Bitmap, (void*)roto1Palette);
		Sleep(1);
		setbg2((void*)roto2Bitmap, (void*)roto2Palette);
		Sleep(1);
		setbg2((void*)roto3Bitmap, (void*)roto3Palette);
		Sleep(1);
		setbg2((void*)roto4Bitmap, (void*)roto4Palette);
		Sleep(1);
		setbg2((void*)roto5Bitmap, (void*)roto5Palette);
		Sleep(1);
		setbg2((void*)roto6Bitmap, (void*)roto6Palette);
		Sleep(1);
		setbg2((void*)roto7Bitmap, (void*)roto7Palette);
		Sleep(1);
		setbg2((void*)roto8Bitmap, (void*)roto8Palette);
		Sleep(1);
		setbg2((void*)roto9Bitmap, (void*)roto9Palette);
		Sleep(1);
		setbg2((void*)roto10Bitmap, (void*)roto10Palette);
		Sleep(1);
		setbg2((void*)roto11Bitmap, (void*)roto11Palette);
		Sleep(1);
		setbg2((void*)roto12Bitmap, (void*)roto12Palette);
		Sleep(1);
		setbg2((void*)roto13Bitmap, (void*)roto13Palette);
		Sleep(1);
		setbg2((void*)roto14Bitmap, (void*)roto14Palette);
		Sleep(1);
		setbg2((void*)roto15Bitmap, (void*)roto15Palette);
		Sleep(1);
		setbg2((void*)roto16Bitmap, (void*)roto16Palette);
		Sleep(1);
		setbg2((void*)roto17Bitmap, (void*)roto17Palette);
		Sleep(1);
		setbg2((void*)roto18Bitmap, (void*)roto18Palette);
		Sleep(1);
		setbg2((void*)roto19Bitmap, (void*)roto19Palette);
		Sleep(1);
		setbg2((void*)roto20Bitmap, (void*)roto20Palette);
		Sleep(1);
		setbg2((void*)roto21Bitmap, (void*)roto21Palette);
		Sleep(1);
		setbg2((void*)roto22Bitmap, (void*)roto22Palette);
		Sleep(1);
		setbg2((void*)roto23Bitmap, (void*)roto23Palette);
		Sleep(1);
		setbg2((void*)roto24Bitmap, (void*)roto24Palette);
		Sleep(1);
		setbg2((void*)roto25Bitmap, (void*)roto25Palette);
		Sleep(1);
		setbg2((void*)roto26Bitmap, (void*)roto26Palette);
		Sleep(0.5);
		setbg2((void*)roto27Bitmap, (void*)roto27Palette);
		Sleep(0.5);
		setbg2((void*)roto28Bitmap, (void*)roto28Palette);
		Sleep(0.5);
		setbg2((void*)roto29Bitmap, (void*)roto29Palette);
		Sleep(0.5);
		setbg2((void*)roto30Bitmap, (void*)roto30Palette);
		Sleep(0.5);
		setbg2((void*)roto31Bitmap, (void*)roto31Palette);
		Sleep(0.5);
		setbg2((void*)roto32Bitmap, (void*)roto32Palette);
		Sleep(0.5);
		setbg2((void*)roto33Bitmap, (void*)roto33Palette);
		Sleep(0.5);
		setbg2((void*)roto34Bitmap, (void*)roto34Palette);
		Sleep(0.5);
		setbg2((void*)roto35Bitmap, (void*)roto35Palette);
		Sleep(0.5);
		setbg2((void*)roto36Bitmap, (void*)roto36Palette);
		Sleep(0.5);
		setbg2((void*)roto37Bitmap, (void*)roto37Palette);
		Sleep(0.5);
		setbg2((void*)roto38Bitmap, (void*)roto38Palette);
		Sleep(0.5);
		setbg2((void*)roto39Bitmap, (void*)roto39Palette);
		Sleep(0.5);
		setbg2((void*)roto40Bitmap, (void*)roto40Palette);
		Sleep(0.5);
		setbg2((void*)roto41Bitmap, (void*)roto41Palette);
		Sleep(0.5);
		setbg2((void*)roto42Bitmap, (void*)roto42Palette);
		Sleep(0.5);
		setbg2((void*)roto43Bitmap, (void*)roto43Palette);
		Sleep(0.5);
		setbg2((void*)roto44Bitmap, (void*)roto44Palette);
		Sleep(0.5);
		setbg2((void*)roto45Bitmap, (void*)roto45Palette);
		Sleep(0.5);
		setbg2((void*)roto46Bitmap, (void*)roto46Palette);
		Sleep(0.5);
		setbg2((void*)roto47Bitmap, (void*)roto47Palette);
		Sleep(0.5);
		setbg2((void*)roto48Bitmap, (void*)roto48Palette);
		Sleep(0.5);
		playSound(2);
		setbg2((void*)roto49Bitmap, (void*)roto49Palette);
		Sleep(0.5);
	vsync
	setbg2novb((void*)bgtwoBitmap, (void*)bgtwoPalette);
	Sleep(10);
	while(1) //main loop for menu
	{
		if(keyDown(KEY_SELECT))	
		{
			FadeOut(2);
			setbg2((void*)controlspage1Bitmap, (void*)controlspage1Palette);
			FadeIn(2);
			while(!(keyDown(KEY_A)))
			{
				wait = 0;
			}
			while(keyDown(KEY_A))
			{
				wait = 0;
			}
			FadeOut(2);
			setbg2((void*)controlspage2Bitmap, (void*)controlspage2Palette);
			FadeIn(2);
			while(!(keyDown(KEY_A)))
			{
				wait = 0;
			}
			while(keyDown(KEY_A))
			{
				wait = 0;
			}
			FadeOut(2);
			drawbg2vb((void*)bgtwoBitmap, (void*)bgtwoPalette);
			FadeIn(2);
		}
		if(keyDown(KEY_START))
		{
			FadeOut(15);
			setbg2((void*)l1Data, (void*)l1Palette);
			FadeIn(15);
			playSound(3);
			while(1)
			{
				if(keyDown(KEY_A))
				{
					hardreset();
				}
			}
		}
		REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 		REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 		REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 		REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  		REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   		REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  		REG_TM0CNT    = 0;   
	}
	return 0;
}

