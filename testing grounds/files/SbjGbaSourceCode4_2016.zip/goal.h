int gx=222,gy=127;


