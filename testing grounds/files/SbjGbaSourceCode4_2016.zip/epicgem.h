#include "levels.h"
#include "otherfunctions.h"
#include "gates.h"
#include "block.h"
int charactercollision = 0;
void detectcolor() {
     // -- Don't do this inside the loop, but somewhere else 
// and keep a pointer to the pixels array
// read the entire image into a buffer
CroppedBitmap cb = new CroppedBitmap(source, new Int32Rect(0, 0, 1018, 731));
int px = 240 * 160 * (source.Format.BitsPerPixel / 8);
byte[] pixels = new byte[px];
cb.CopyPixels(pixels, px, 0);

// -- do this inside your loop
// calculate the offset into the array
int offset = (y * 1018 + x) * 4;
Color c = Color.FromArgb(
    pixels[offset + 3], pixels[offset + 2], pixels[offset + 1], pixels[offset]);

if (c.R == 0 && c.G == 2.9 && c.B == 61.2) {
   pixels = null;
   charactercollision = 1;
   return true;
}
while (start == 1) {
if (level == 58) {
          show();
          if(charactercollision == 10) {
                            g = 1;    
          }
if Not(level == 58) {
             hide();
             }
}
detectcolor();
}
