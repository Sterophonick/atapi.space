#include "gba_keys.h"
#include "gba_video.h"
#include "otherfunctions.h"

FILE *input;
char get_char;
input = fopen("block.bmp");

fclose(input);

int collision = 0;
int hazardcollision = 0;

void detectcolor() {
     // -- Don't do this inside the loop, but somewhere else 
// and keep a pointer to the pixels array
// read the entire image into a buffer
CroppedBitmap cb = new CroppedBitmap(source, new Int32Rect(0, 0, 1018, 731));
int px = 240 * 160 * (source.Format.BitsPerPixel / 8);
byte[] pixels = new byte[px];
cb.CopyPixels(pixels, px, 0);

// -- do this inside your loop
// calculate the offset into the array
int offset = (y * 1018 + x) * 4;
Color c = Color.FromArgb(
    pixels[offset + 3], pixels[offset + 2], pixels[offset + 1], pixels[offset]);

if (c.R == 0 && c.G == 2.9 && c.B == 61.2) {
   pixels = null;
   collision == 1;
   return true;
}
   if (c.R == 100 && c.G == 0 && c.B == 0) {
   pixels = null;
   hazardcollision == 1;
   return true;
}
   if (c.R == 94.9 && c.G == 0 && c.B == 0) {
   pixels = null;
   pookacollision == 1;
   return true;
}
}


int bx=17,by=128;
int x = 0;
int y = 0;
int deaths = 0;
int time = 0;
int main() {
    void var_y(int number){
         detectcolor();
         if (gravity == 0){
                     y += number;
         } else {
                y -= number;
         }
             void changey(int number){
         if (gravity == 0){
                     by += number;
         } else {
                by -= number;
         }
                      void sety(int number){
         if (gravity == 0){
                     y = number;
         } else {
                y = (number * 2) - number;
         }
         void die() {
              int bx=17,by=128;
              x = 0;
              y = 0;
              playsound(death);
              }
    void physics(void) {
         y += -0.5;
    if ((keyDown(KEY_RIGHT))) {
                      x += 1;
                      }
        if ((keyDown(KEY_LEFT))) {
                      x += -1;
                      }
        x = (x * 0.9);
        bx += x;
        if (collision == 1) {
           changey(number);
           if (collision == 1) {
           changey(number);
           if (collision == 1) {
           changey(number);
           if (collision == 1) {
           changey(number);
           if (collision == 1) {
           vchangey(number);
           if (collision == 1) {
           changey(number);
           if (collision == 1) {
           changey(-6);
           bx += (x * -1)
           if ((keyDown(KEY_A))) {
              
              if x >= 0 {
                   x = -10;
                   }else {
                         x = 10;
                         }
              time = 5.8;
              while ((keyDown(KEY_A)) or (time <= 8.8){
                    time += 1;
                    y = time;
                    by += y;
                    by -= 0.5;
                      if ((keyDown(KEY_RIGHT))) {
                      x += 1;
                      }
        if ((keyDown(KEY_LEFT))) {
                      x += -1;
                      }
        x = (x * 0.9);
        bx += x;
        if (collision == 1) {
                      bx += (x * -1);
                      }
                              if (collision == 1) {
                                           by += (y * -1); 
                                           y = 0;
                                           }
                                           if (hazardcollision == 1) {
                                                    die();           
                                           }
                                           else {
                                                x = 0;
                                                }                                                  
           }
           }
           }
           }
           }
           }
           }           
           changey(y);
           if (collision == 1) {
           by += (y * -1); 
           y = 0;
           }
           by -= 0.5
                      if ((keyDown(KEY_A))) {
              time = 5.8;
              while ((keyDown(KEY_A)) or (time <= 8.8){
                    time += 1;
                    y = time;
                    by += y;
                    by -= 0.5;
                      if ((keyDown(KEY_RIGHT))) {
                      x += 1;
                      }
        if ((keyDown(KEY_LEFT))) {
                      x += -1;
                      }
        x = (x * 0.9);
        bx += x;
        if (collision == 1) {
                      bx += (x * -1);
                      }
                              if (collision == 1) {
                                           by += (y * -1); 
                                           y = 0;
                                           }
                                           if (hazardcollision == 1) {
                                              die();                 
                                           }
        if (hazardcollision == 1) {
                            die();              
                                           }
        if (pookacollision == 1) {
                           diepooka();
                           }
                            if(bx>240-12){die();}                                    //deadly edge
                             if(by>160-12){die();}                                   //deadly edge
