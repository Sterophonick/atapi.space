#include "levels.h"
#include "otherfunctions.h"
#include "gates.h"
if (level == 85) {
          show();
          }
if Not(level == 85) {
             hide();
             }
