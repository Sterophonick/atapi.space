#include "mygba.h"


#include "gfx/isle.pal.c"
#include "gfx/isle.raw.c"
#include "gfx/isle.map.c"
#include "gfx/player.h"

/*
----------------------------------
 Program entry point
----------------------------------
*/

u8 newframe=0;
u8 frames=0;
u16 my_x=76;
u16 my_y=16;
u8 g_SprObj;
u8 spr_key;
u8 spr_saw;
double x;
double y;
u16 ipx,ipy;
int px,py,level,py1,px1,pw,ph,stx=0,sty=129;

typedef struct {
    int ox;
    int oy;
    u16 iox;
    u16 ioy;
    int haz;
} levelobj;

void hblFunc()
{
	//signify new frame
	newframe=1;
	frames++;
}

int main(void)
{
    pw=16;
    ph=16;
    my_y=76;
    my_x=16;
	map_fragment_info_ptr mymap;

    // initialize HAMlib
    ham_Init();
    // set the new BGMode
    ham_SetBgMode(0);
    // init the Text display system on bg of choice
    ham_InitText(0);
	// init the Palettes for Sprite and BG Text
	ham_LoadBGPal(&isle_Palette,sizeof(isle_Palette));
	ham_LoadObjPal((void *)&playerPalette,        // a pointer to the palette data that is to be loaded
                   SIZEOF_16BIT(playerPalette)); // the number of the 16 color OBJ (sprite) palette you
                                                  // want to load with the 16 color values at address src.

	   g_SprObj = ham_CreateObj((void*)&player,  // A pointer to the tile data for this object
                             0,                       // obj_shape
                             1,                       // obj_size
                             OBJ_MODE_NORMAL,         // obj_mode
                             1,                       // col_mode
                             0,                       // pal_no
                             0,                       // mosaic
                             0,                       // hflip
                             0,                       // vflip
                             0,                       // dbl_size
                             0,                       // prio
                             stx,                // x position of sprite on screen
                             sty);               // y position of sprite on screen

	// set the Text Color
	ham_SetTextCol(0x5,0x4);
	ham_CopyObjToOAM();
	M_BG1SCRLY_SET(my_y)
	M_BG1SCRLX_SET(my_x)

	// load the tileset
	ham_bg[1].ti = ham_InitTileSet(&isle_Tiles,SIZEOF_16BIT(isle_Tiles),1,1);
	// init an empty map
	ham_bg[1].mi = ham_InitMapEmptySet(3,0);

	// make a reference to Map data in the ROM
	mymap = ham_InitMapFragment(&isle_Map,64,64,0,0,64,64,0);

	// copy (in this case the whole) map to BG1 at x=0 y=0
	ham_InsertMapFragment(mymap,1,0,0);
	
	// and get it on screen
	ham_InitBg(1,1,2,0);

    // start hblFunc every frame
    ham_StartIntHandler(INT_TYPE_VBL,&hblFunc);
    while(1)
    {
		if(newframe)
		{

			// and make people move the map around
			if(F_CTRLINPUT_DOWN_PRESSED)
			{
				if(my_y<(176+100))
					M_BG1SCRLY_SET(my_y++)
			}
			if(F_CTRLINPUT_UP_PRESSED)
			{
				if(my_y>76)
				M_BG1SCRLY_SET(my_y--)
			}
			if(F_CTRLINPUT_LEFT_PRESSED)
			{
				if(my_x>16)
				    
                    M_BG1SCRLX_SET(my_x--)
   	                x--;
			}
			if(F_CTRLINPUT_RIGHT_PRESSED)
			{
				if(my_x<(256))
				M_BG1SCRLX_SET(my_x++)
				x++;
			}
			x*=0.9;
			newframe=0;
		}

    }    
}


