
#define	lrint(dbl)		((long) (dbl))
#define	lrintf(flt)		((long) (flt))

#define		WAV_W64_GSM610_BLOCKSIZE	65
#define		WAV_W64_GSM610_SAMPLES		320

#define	SF_BUFFER_LEN			(128*2)
#define	SF_FILENAME_LEN			(512)
#define	SF_HEADER_LEN			(4096)
#define	SF_TEXT_LEN				(1024)
#define SF_SYSERR_LEN			(256)
#define SF_MAX_STRINGS			(16)

enum
{	/* True and false */
	SF_FALSE	= 0,
	SF_TRUE		= 1,
} ;

typedef int	sf_count_t ;

#define SF_COUNT_MAX		0x7FFFFFFFFFFFFFFFLL

struct SF_INFO
{	sf_count_t	frames ;		/* Used to be called samples.  Changed to avoid confusion. */
//	int			samplerate ;
//	int			channels ;
//	int			format ;
//	int			sections ;
//	int			seekable ;
} ;

typedef	struct SF_INFO SF_INFO ;

typedef struct sf_private_tag
{	/* Force the compiler to double align the start of buffer. */
	union
	{
		short			sbuf	[SF_BUFFER_LEN / sizeof (short)] ;
	} u ;


	/* logbuffer and logindex should only be changed within the logging functions
	** of common.c
	*/

	/* Storage and housekeeping data for adding/reading strings from
	** sound files.
	*/

	/* Guard value. If this changes the buffers above have overflowed. */

	/* Index variables for maintaining logbuffer and header above. */

	/* File descriptors for the file and (possibly) the resource fork. */
	int				error ;

	/*
	** Maximum float value for calculating the multiplier for
	** float/double to short/int conversions.
	*/

	/* Vairables for handling pipes. */

	/* True if clipping must be performed on float->int conversions. */
	SF_INFO			sf ;

	/* Loop Info */
	sf_count_t		filelength ;	/* Overall length of (embedded) file. */
	sf_count_t		fileoffset ;	/* Offset in number of bytes from beginning of file. */

	sf_count_t		dataoffset ;	/* Offset in number of bytes from beginning of file. */
	sf_count_t		datalength ;	/* Length in bytes of the audio data. */
	
	
	void			*fdata ;		/*	This is a pointer to dynamically allocated file format
									**	specific data.
									*/


	/* A set of file specific function pointers */

} SF_PRIVATE ;

enum
{	SF_ERR_NO_ERROR				= 0,
	SF_ERR_UNRECOGNISED_FORMAT	= 1,
	SF_ERR_SYSTEM				= 2
} ;

enum
{	SFE_NO_ERROR		= SF_ERR_NO_ERROR,
	SFE_BAD_OPEN_FORMAT	= SF_ERR_UNRECOGNISED_FORMAT,
	SFE_SYSTEM			= SF_ERR_SYSTEM,

	SFE_BAD_FILE,
	SFE_BAD_FILE_READ,
	SFE_OPEN_FAILED,
	SFE_BAD_SNDFILE_PTR,
	SFE_BAD_SF_INFO_PTR,
	SFE_BAD_SF_INCOMPLETE,
	SFE_BAD_FILE_PTR,
	SFE_BAD_INT_PTR,
	SFE_BAD_STAT_SIZE,
	SFE_MALLOC_FAILED,
	SFE_UNIMPLEMENTED,
	SFE_BAD_READ_ALIGN,
	SFE_BAD_WRITE_ALIGN,
	SFE_UNKNOWN_FORMAT,
	SFE_NOT_READMODE,
	SFE_NOT_WRITEMODE,
	SFE_BAD_MODE_RW,
	SFE_BAD_SF_INFO,
	SFE_BAD_OFFSET,
	SFE_NO_EMBED_SUPPORT,
	SFE_NO_EMBEDDED_RDWR,
	SFE_NO_PIPE_WRITE,

	SFE_INTERNAL,
	SFE_LOG_OVERRUN,
	SFE_BAD_CONTROL_CMD,
	SFE_BAD_ENDIAN,
	SFE_CHANNEL_COUNT,
	SFE_BAD_RDWR_FORMAT,

	SFE_INTERLEAVE_MODE,
	SFE_INTERLEAVE_SEEK,
	SFE_INTERLEAVE_READ,

	SFE_BAD_SEEK,
	SFE_NOT_SEEKABLE,
	SFE_AMBIGUOUS_SEEK,
	SFE_WRONG_SEEK,
	SFE_SEEK_FAILED,


	SFE_MAX_ERROR			/* This must be last in list. */
} ;

enum
{	/* Major formats. */
	SF_FORMAT_WAV			= 0x010000,		/* Microsoft WAV format (little endian). */

	/* Subtypes from here on. */

	/* Endian-ness options. */

	SF_ENDIAN_FILE			= 0x00000000,	/* Default file endian-ness. */
	SF_ENDIAN_LITTLE		= 0x10000000,	/* Force little endian-ness. */
	SF_ENDIAN_BIG			= 0x20000000,	/* Force big endian-ness. */
	SF_ENDIAN_CPU			= 0x30000000,	/* Force CPU endian-ness. */

	SF_FORMAT_SUBMASK		= 0x0000FFFF,
	SF_FORMAT_TYPEMASK		= 0x0FFF0000,
	SF_FORMAT_ENDMASK		= 0x30000000
} ;

#define	ARRAY_LEN(x)		((int) (sizeof (x)) / (sizeof ((x) [0])))

attrinline sf_count_t psf_get_filelen (SF_PRIVATE *psf) ;
attrinline sf_count_t psf_fread (void *ptr, sf_count_t bytes, sf_count_t count, SF_PRIVATE *psf) ;

u8 *fio_data;
u8 *fio_top;
u32 fio_size;

sf_count_t
psf_get_filelen (SF_PRIVATE *psf)
{
	return(fio_size);
} /* psf_get_filelen */

sf_count_t
psf_fread (void *ptr, sf_count_t bytes, sf_count_t items, SF_PRIVATE *psf)
{
  memcpy((char*)ptr, fio_data, 65);
  fio_data+=65;
  return(65);
  
  u32 count=items*bytes;
  
  /* Do this check after the multiplication above. */
  if (count <= 0) return(0);
  
  memcpy((char*)ptr, fio_data, count);
  fio_data+=count;
  
  return(items);
} /* psf_fread */

