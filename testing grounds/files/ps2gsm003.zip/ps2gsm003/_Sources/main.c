
#define attriwram __attribute__ ((section (".data.iwram")))
#define attrinline __attribute__ ((always_inline, const)) static inline 

#include "header\GBA.h"
#include "header\BG.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\IRQ.h"
#include "header\sprite.h"
#include "header\blend.h"
#include "header\sound.h"

#include "boolean.h"
#include "GBATools.c"

#include "string.h"
#include "varargs.h"
#include "debug.c"
#include "interrupt.c"

#include "BGChrImg\BGChrImg.h"
#include "main_img.c"
#include "pogoshell2_args.c"
#include "pogoshell2_reset.c"

#include "gsm610.c"

#define sndbuf_REG_DMCNT_H (DMA_SIZE_32 | DMA_TIMING_FIFO | DMA_REPEAT_ON | DMA_SAD_INC | DMA_DAD_FIX)

SF_PRIVATE _psf;
SF_PRIVATE *psf=&_psf;

typedef struct {
  u16 wFormatTag;
  u16 nChannels;
  u32 nSamplesPerSec;
  u32 nAvgBytesPerSec;
  u16 nBlockAlign;
  u16 wBitsPerSample;
  u16 cbSize;
} WAVEFORMATEX;

volatile u32 Timer2OverflowCount;

// �K��340*2�̐����{�ŁB�I�[�o�[�T���v�����O����̂Ńu���b�N�T�C�Y�̂Q�{�K�v�B
#define sndbufsize (320*2*8)
#define sndbuf_DMATimeout (sndbufsize/16)

u8 sndbuf0[sndbufsize],sndbuf1[sndbufsize];
u8 *writebuf;
u32 writebufno;
u32 sndbuf_playpos;
u32 sndbuf_LostFlame;
b8 sndbuf_Processing;
s16 OverSamplingLast=0;

u32 SamplePos;
u32 SampleSize;
u32 SampleFreq;

b8 RequestReturnPogoShell=False;
u32 RequestRefreshCPULoadCount=0;

static void sndbuf_SetStereo(b8 e);
static void sndbuf_ResetFreqRate(u32 freq);
static void sndbuf_StartPCM(u32 freq);
attriwram static void sndbuf_DMA1_Handler(void);
static b8 gsm610_Open(u8 *ptr,u32 size);
attriwram static b8 gsm610_GetData(u8 *buf8,u32 bufsize);
attriwram static void IRQ_Timer2(void);
attriwram static void IRQ_Timer3(void);
static b8 WaveFile_CheckRIFF(void);
static void WaveFile_ReadWaveChunk(void);
static void WaveFile_SeekDataChunk(void);

void sndbuf_SetStereo(b8 e)
{
  REG_SGCNT0_H&=~(ENABLE_DSOUND_A_LEFT | ENABLE_DSOUND_A_RIGHT | ENABLE_DSOUND_B_LEFT | ENABLE_DSOUND_B_RIGHT);
  if(e==False){
    REG_SGCNT0_H|=(ENABLE_DSOUND_A_LEFT | ENABLE_DSOUND_A_RIGHT);
    }else{
    REG_SGCNT0_H|=(ENABLE_DSOUND_A_LEFT | ENABLE_DSOUND_B_RIGHT);
  }
}

void sndbuf_ResetFreqRate(u32 freq)
{
  REG_TM1D = -(16670000/freq);
}

void sndbuf_StartPCM(u32 freq)
{
  REG_TM1CNT = 0;
  
  REG_DM1CNT_H=0;
  REG_DM2CNT_H=0;

  REG_SGCNT1  = ENABLE_SOUND_MASTER;
  REG_SGCNT0_L=0x0000;
  REG_SGCNT0_H&=~(BIT11 | BIT10 | BIT9 | BIT8 | BIT2); // DirectSoundA�֘A���N���A
  REG_SGCNT0_H&=~(BIT15 | BIT14 | BIT13 | BIT12 | BIT3); // DirectSoundB�֘A���N���A
  REG_SGCNT0_H|=(DSOUND_A_TIMER1 | DSOUND_A_FULL_OUTPUT | RESET_DSOUND_A);
  REG_SGCNT0_H|=(DSOUND_B_TIMER1 | DSOUND_B_FULL_OUTPUT | RESET_DSOUND_B);
  
  sndbuf_SetStereo(False);
  
  REG_DM1CNT_H= 0;
  REG_DM1SAD   = (u32)(sndbuf1);
  REG_DM1DAD   = (u32)SGFIFOA;
  REG_DM1CNT_H= sndbuf_REG_DMCNT_H | DMA_TRANSFER_ON | DMA_INTR_ON;
  
/*
  REG_DM2CNT_H= 0;
  REG_DM2SAD   = (u32)(sndbuf1R);
  REG_DM2DAD   = (u32)SGFIFOB;
  REG_DM2CNT_H= sndbuf_REG_DMCNT_H | DMA_TRANSFER_ON;
*/
  
  writebuf=sndbuf1;
  writebufno=0;
  sndbuf_playpos=sndbuf_DMATimeout-1;
  sndbuf_LostFlame=0;
  
  sndbuf_ResetFreqRate(freq*2);
  REG_TM1CNT = TM_ENABLE | TM_FREQ_PER_1;
  
  sndbuf_Processing=False;
}

void sndbuf_DMA1_Handler(void)
{
  if(sndbuf_playpos!=0){
    sndbuf_playpos--;
    }else{
    if (sndbuf_Processing==False){
      if(SamplePos>SampleSize){
        RequestReturnPogoShell=True;
        REG_DM1CNT_H= 0;
        return;
      }
      
      sndbuf_Processing=True;
      REG_TM2CNT = TM_FREQ_PER_64 | TM_ENABLE | TM_USEIRQ;
      
      sndbuf_playpos=sndbuf_DMATimeout-1;
      REG_DM1CNT_H= 0;
      REG_DM1SAD   = (u32)(writebuf);
      REG_DM1CNT_H= sndbuf_REG_DMCNT_H | DMA_TRANSFER_ON | DMA_INTR_ON;
      if(writebufno==0){
        writebuf=sndbuf0;
        writebufno=1;
        }else{
        writebuf=sndbuf1;
        writebufno=0;
      }
      
      gsm610_GetData(&writebuf[0],sndbufsize);
      
      REG_TM2CNT = 0;
      Timer2OverflowCount+=REG_TM2D;
      sndbuf_Processing=False;
      }else{
      sndbuf_LostFlame++;
//      REG_TM1CNT = 0; // ���������������~
    }
  }
}

b8 gsm610_Open(u8 *ptr,u32 size)
{
  u32 res;
  
  memset(psf,0,sizeof(SF_PRIVATE));
  
  fio_top=ptr;
  fio_data=fio_top;
  fio_size=size;
  
  psf->datalength=fio_size;
  
  res=gsm610_init(psf);
  if(res!=0){
    uprintf("gsm610_init() error:%d\n",res);
    Mode1BG1_DrawStrMultiChar(1,2,resprintf);
    return(False);
  }
  
  SamplePos=0;
  SampleSize=psf->sf.frames;
  
  return(True);
}

b8 gsm610_GetData(u8 *buf8,u32 bufsize)
{
  GSM610_PRIVATE 	*pgsm610=(GSM610_PRIVATE*) psf->fdata ;
  
  u32 pos;
  u32 blocksize=pgsm610->samplesperblock;
  s16 *samples=&pgsm610->samples[0];
  
  pos=0;
  
  s16 last=OverSamplingLast;
  
  while(pos<bufsize){
    pgsm610->decode_block (psf,pgsm610) ;
    
    u32 bufcnt;
    s16 cur;
    
    for(bufcnt=0;bufcnt<blocksize;bufcnt++){
      cur=samples[bufcnt];
      buf8[bufcnt*2+0]=(last+cur)/0x200;
      buf8[bufcnt*2+1]=cur/0x100;
      last=cur;
    }
    
    pos+=blocksize*2;
    buf8+=blocksize*2;
    SamplePos+=blocksize;
  }
  
  OverSamplingLast=last;
  
  return(True);
}

void IRQ_Timer2(void)
{
  Timer2OverflowCount+=0x10000;
}

void IRQ_Timer3(void)
{
  RequestRefreshCPULoadCount=Timer2OverflowCount;
  Timer2OverflowCount=0;
}

b8 WaveFile_CheckRIFF(void)
{
  if((ps2ArgDataPtr[0]!='R')||(ps2ArgDataPtr[1]!='I')||(ps2ArgDataPtr[2]!='F')||(ps2ArgDataPtr[3]!='F')){
    return(False);
    }else{
    return(True);
  }
}

void WaveFile_ReadWaveChunk(void)
{
  WAVEFORMATEX *wfex=(void*)&ps2ArgDataPtr[0x14];
  
  if(wfex->wFormatTag!=0x31){
    Mode1BG1_DrawStrMultiChar(1,10,"Illigal CompressFormat Error.");
    while(1);
  }
  
  uprintf("fmt:0x31(GSM06.10) chns:%d\n",wfex->wFormatTag,wfex->nChannels);
  Mode1BG1_DrawStrMultiChar(1,10,resprintf);
  uprintf("Smpls/Sec:%d AvgBPS:%d\n",wfex->nSamplesPerSec,wfex->nAvgBytesPerSec);
  Mode1BG1_DrawStrMultiChar(1,11,resprintf);
  uprintf("BlockAlign:%d Bits/Smpl:%d\n",wfex->nBlockAlign,wfex->wBitsPerSample);
  Mode1BG1_DrawStrMultiChar(1,12,resprintf);
  
  SampleFreq=wfex->nSamplesPerSec;
}

void WaveFile_SeekDataChunk(void)
{
  b8 findflag;
  
  findflag=False;
  while(findflag==False){
    if((ps2ArgDataPtr[0]!='d')||(ps2ArgDataPtr[1]!='a')||(ps2ArgDataPtr[2]!='t')||(ps2ArgDataPtr[3]!='a')){
      ps2ArgDataPtr++;
      }else{
      findflag=True;
    }
  }
  
  ps2ArgDataPtr+=4;
  ps2ArgDataSize=ps2ArgDataPtr[0]+(ps2ArgDataPtr[1]<<8)+(ps2ArgDataPtr[2]<<16)+(ps2ArgDataPtr[3]<<24);
  ps2ArgDataPtr+=4;
  
  uprintf("GSMDataStartAddr:0x%x\n",(u32)ps2ArgDataPtr);
  Mode1BG1_DrawStrMultiChar(1,14,resprintf);
}

int main(void)
{
  // ���[�h�ݒ�
  REG_DISPCNT=MODE_1;
  
  SetBGCHR(1,131,(u16*)BGSmall8Font_data,(u16*)BGSmall8Font_palette);
  
  REG_BG0CNT = 0;
  REG_BG1CNT = ( BG_SIZEA_512_512 | BG_COLOR_16 | BG_CHARBASE(ADR_BGCHR1) | BG_MAPBASE(ADR_BGMAP1) | 0); 
  REG_BG2CNT = 0;
  REG_BG3CNT = 0;
  
  u32 x,y;
  
  for(y=0;y<64;y++){
    for(x=0;x<64;x++){
      SetBG1MAP(x,y,0,0x20);
    }
  }
  
  REG_DISPCNT|=BG1_ENABLE;
  
  Mode1BG1_DrawStrMultiChar(1,17,"ps2gsm ver 0.02 2005/01/14");
  Mode1BG1_DrawStrMultiChar(1,18,"http://home.att.ne.jp/blue");
  Mode1BG1_DrawStrMultiChar(1,19,"/moonlight/index.html");
  
  IRQTable[IRQIndex_DMA1]=(u32)sndbuf_DMA1_Handler;
  IRQTable[IRQIndex_Timer2]=(u32)IRQ_Timer2;
  IRQTable[IRQIndex_Timer3]=(u32)IRQ_Timer3;
  IRQ_Setup(IRQ_BIT_DMA1 | IRQ_BIT_TIMER2 | IRQ_BIT_TIMER3,0);
  
  GetPogoShell2Args();
  
  uprintf("data:%d at 0x%x\n",ps2ArgDataSize,(u32)ps2ArgDataPtr);
  Mode1BG1_DrawStrMultiChar(1,5,resprintf);
  uprintf("arg0:%s\n",ps2Arg0);
  Mode1BG1_DrawStrMultiChar(1,6,resprintf);
  uprintf("arg1:%s\n",ps2Arg1);
  Mode1BG1_DrawStrMultiChar(1,7,resprintf);
  
  if(WaveFile_CheckRIFF()==False){
    Mode1BG1_DrawStrMultiChar(1,9,"error.not RIFFWAVEFILE");
    while(1);
    }else{
    Mode1BG1_DrawStrMultiChar(1,9,"detect RIFFWAVEFORMAT");
  }
  
  WaveFile_ReadWaveChunk();
  
  WaveFile_SeekDataChunk();
  
  if(gsm610_Open(ps2ArgDataPtr,ps2ArgDataSize)==False){
    while(1);
  }
  
  uprintf("SampleSize:%d\n",SampleSize);
  Mode1BG1_DrawStrMultiChar(1,2,resprintf);
  
  REG_TM2CNT = 0;
  REG_TM2D=0;
  
  REG_TM3CNT=0;
  REG_TM3D=-(16670000/256/4);
  REG_TM3CNT = TM_FREQ_PER_256 | TM_ENABLE | TM_USEIRQ;
  
  sndbuf_StartPCM(SampleFreq);
  
  while(RequestReturnPogoShell==False){
    WaitForVsync();
    
    uprintf("SamplePos:%d\n",SamplePos);
    Mode1BG1_DrawStrMultiChar(1,3,resprintf);
    
    u16 loadkeys;
    loadkeys=(~*KEYS)&0x3ff;
    
    if(loadkeys!=0){
      if((loadkeys&KEY_L)&&(loadkeys&KEY_R)){
        RequestReturnPogoShell=True;
      }
    }
    
    if(RequestRefreshCPULoadCount!=0){
      uprintf("LoadCPU.%dms %d% Lost.%d\n",RequestRefreshCPULoadCount*(1000*4/4)/0x10000,RequestRefreshCPULoadCount*(100*4/4)/0x10000,sndbuf_LostFlame);
      RequestRefreshCPULoadCount=0;
      Mode1BG1_DrawStrMultiChar(1,0,resprintf);
      dprint(resprintf);
    }
  }
  
  gsm610_close(psf);
  ReturnPogoShell2();
  
  while(1);
  
}
