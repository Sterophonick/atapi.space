
u8 *ps2ArgDataPtr;
u32 ps2ArgDataSize;
u8 ps2Arg0[128],ps2Arg1[128];

#define __iwram_overlay_lma __appended_start
extern u8 __iwram_overlay_lma;

b8 GetPogoShell2Args(void)
{
  u8 *p = (u8 *)(0x02000000 + 255 * 1024 + 8);
  u32 *p2 = (u32 *)(0x02000000 + 255 * 1024);
  
  ps2ArgDataPtr=0;
  ps2ArgDataSize=0;
  ps2Arg0[0]=0;
  ps2Arg1[0]=0;
  
  b8 ps2ready=True;
  
  if(p2[0]!=0xFAB0BABE) ps2ready=False;
  if(p2[1]!=2) ps2ready=False;
  if(p2[-1]==0) ps2ready=False;
  if(p2[-2]==0) ps2ready=False;
  
  if(ps2ready==True){
    ps2ArgDataPtr=(u8*)p2[-1];
    ps2ArgDataSize=p2[-2];
    }else{
    ps2ArgDataPtr=(u8*)&__iwram_overlay_lma;
    ps2ArgDataSize=-1;
    p="singleboot.bin\0ROMMAP ExtendData\0";
  }
  
  u32 len;
  u32 cp;
  
  len=strlen(p)+1; // with Null
  for(cp=0;cp<len;cp++){
    ps2Arg0[cp]=*p;
    p++;
  }

  len=strlen(p)+1; // with Null
  for(cp=0;cp<len;cp++){
    ps2Arg1[cp]=*p;
    p++;
  }
  
  return(True);
}
