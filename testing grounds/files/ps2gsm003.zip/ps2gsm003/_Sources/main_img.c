
#define ADR_BGCHR0  0/16
#define ADR_BGMAP0  2/ 2
#define ADR_BGCHR1 16/16
#define ADR_BGMAP1  4/ 2
#define ADR_BGCHR2 32/16
#define ADR_BGMAP2 12/ 2
#define ADR_BGCHR3  0/16
#define ADR_BGMAP3  0/ 2

// BG�A�h���X
u16 *BGPAL = MEM_BG_PAL;
u16 *BGCHR0 = MEM_BG_CHAR(ADR_BGCHR0);
u16 *BGMAP0 = MEM_BG_MAP(ADR_BGMAP0);
u16 *BGCHR1 = MEM_BG_CHAR(ADR_BGCHR1);
u16 *BGMAP1 = MEM_BG_MAP(ADR_BGMAP1);
u16 *BGCHR2 = MEM_BG_CHAR(ADR_BGCHR2);
u16 *BGMAP2 = MEM_BG_MAP(ADR_BGMAP2);
u16 *BGCHR3 = MEM_BG_CHAR(ADR_BGCHR3);
u16 *BGMAP3 = MEM_BG_MAP(ADR_BGMAP3);

// BG0 16col 256x256 *2byte = 2kb
// BG1 16col 512x512 *2byte = 8kb
// BG2 256col 512x512 *1byte = 4kb
// BG0 BGSolid32.bmp 16col 16chr *32byte = 0.5kb
// BG1 BGSmall8Font.bmp 16col 400chr *32byte = 12.5kb
// BG2 BGParam.bmp 256col 256chr *64byte = 16kb

// OBJ OAM.bmp 256col 512chr *64byte = 32kb

// BG0 �őO�ʃe�L�X�g�E�B���h�E
// BG1 �w�i
// BG2 ���C��
// BG3 ���g�p

// Palette col   num
// BG0 128-191  8-11
// BG1 192-255 12-15
// BG2   0-127  0- 7
// BG3   0-  0  0- 0

static void SetBGCHR(u8 BGNo,u16 chr,u16* img,u16* pal);
static inline void SetBG0MAP(u16 x,u16 y,u16 palno,u16 chr);
static inline void SetBG1MAP(u16 x,u16 y,u16 palno,u16 chr);
static inline void SetBG2MAP(u16 x,u16 y,u16 chr);
static inline void SetBG2MAP16(u16 x,u16 y,u16 chr);
attriwram static void fp_Mode1BG1_DrawStrMultiChar(u8 x,u8 y,u8* str);
static void (*Mode1BG1_DrawStrMultiChar)(u8 x,u8 y,u8* str)=&fp_Mode1BG1_DrawStrMultiChar;

void SetBGCHR(u8 BGNo,u16 chr,u16* img,u16* pal)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&pal[0];
  if(BGNo==0){
    REG_DM3DAD = (u32)&BGPAL[128];
    }else{
    REG_DM3DAD = (u32)&BGPAL[192];
  }
  REG_DM3CNT_L=64*2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);

  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  REG_DM3SAD = (u32)&img[0];
  if(BGNo==0){
    REG_DM3DAD = (u32)BGCHR0;
    }else{
    REG_DM3DAD = (u32)BGCHR1;
  }
  REG_DM3CNT_L=chr*32/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
}

void SetBG0MAP(u16 x,u16 y,u16 palno,u16 chr)
{
  BGMAP0[y*32+x]=((palno+(2*4))<<12)+chr;
}

void SetBG1MAP(u16 x,u16 y,u16 palno,u16 chr)
{
  BGMAP1[y*32+x]=((palno+(3*4))<<12)+chr;
}

void SetBG2MAP(u16 x,u16 y,u16 chr)
{
  u16 addr;
  addr=(y*64+x)>>1;
  if((x&1)==0){
    BGMAP2[addr]=(BGMAP2[addr]&0xff00)+chr;
    }else{
    BGMAP2[addr]=(BGMAP2[addr]&0x00ff)+(chr<<8);
  }
}

void SetBG2MAP16(u16 x,u16 y,u16 chr)
{
  // 16bit���E�A�h���X����Ȃ���C���B
  BGMAP2[(y*64+x)>>1]=chr;
}

void fp_Mode1BG1_DrawStrMultiChar(u8 x,u8 y,u8* str)
{
  int dx;
  int i;
  u16 c;
  
  dx=0;
  i=0;
  while(str[i]!=0x00){
    if(str[i]<=0x7f){ // 1bytechar
      if(str[i]==0x0a){
        return;
      }
      if(0x20<=str[i]){
        SetBG1MAP(x+dx,y,0,str[i]);
        dx++;
      }
      i++;
      }else{ // 2bytechar
      c=((u16)str[i+0])<<8;
      c+=(u16)str[i+1];
      if(str[i]==0x82){
        c=c-0x8290+BGSmall8Font_2byte8290;
        SetBG1MAP(x+dx,y,0,c);
        dx++;
      }
      if(str[i]==0x83){
        c=c-0x8340+BGSmall8Font_2byte8340;
        SetBG1MAP(x+dx,y,0,c);
        dx++;
      }
      i+=2;
    }
  }
}

