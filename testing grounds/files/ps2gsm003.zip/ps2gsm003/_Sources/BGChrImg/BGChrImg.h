// bin2c converter ver0.1 by Moonlight.

#ifndef BGCHRIMG_h
#define BGCHRIMG_h

/*
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long int s64;
*/

#define BGSMALL8FONT_DATA_SIZE 6144
#define BGSMALL8FONT_PALETTE_SIZE 16
extern const u16 BGSmall8Font_palette[];
extern const u16 BGSmall8Font_data[];

#define BGSmall8Font_2byte8290 192
#define BGSmall8Font_2byte8340 304

#endif
