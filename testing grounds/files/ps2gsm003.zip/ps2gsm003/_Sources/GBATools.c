#ifndef	GBATools_H
#define	GBATools_H

#include "header\GBA.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\IRQ.h"

u8 irqres_inttostr[32];
u8 res_inttostr[32];

static void WaitForVsync(void)
{
  while (*(volatile u16*)0x4000006 >= 160) {};
  while (*(volatile u16*)0x4000006 < 160) {};
}

static void Mode3PutPixel(u8 x,u8 y,u16 color)
{
  u16* ScreenBuffer = (u16*)0x6000000;
  
  ScreenBuffer[y*240+x] = color;
}

static void Mode3DrawBox(u8 x1,u8 y1,u8 x2,u8 y2,u16 color)
{
  u16* ScreenBuffer;
  u16* Draw;
  
  u32 x,y;
  
  ScreenBuffer=(u16*)0x6000000;
  ScreenBuffer+=(y1*240)+x1;
  
  for(y=y1;y<y2;y++)
  {
    Draw=ScreenBuffer;
    for(x=x1;x<x2;x++)
    {
      *Draw = color;
      Draw++;
    }
    ScreenBuffer+=240;
  }
  
}

static void Mode3DrawBoxDMA3(u8 x1,u8 y1,u8 x2,u8 y2,u16 color)
{
  // 16bitDMA = 1pixel(16bitColor)
  
  u16* ScreenBuffer;
  u16* dst;
  u32 y;

  ScreenBuffer=(u16*)0x6000000;
  
  dst=ScreenBuffer;
  dst+=(y1*240)+x1;
  
  REG_DM3SAD = (u32)&color;
  REG_DM3CNT_L=x2-x1;
  REG_DM3CNT_H = (DMA_TRANSFER_OFF);
  
  for(y=y1;y<y2;y++)
  {
    REG_DM3DAD = (u32)dst;
    REG_DM3CNT_H=(DMA_SIZE_16 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                  DMA_REPEAT_OFF | DMA_SAD_FIX | DMA_DAD_INC | DMA_INTR_OFF);
    while((REG_DM3CNT_H&BIT15)==1);
    REG_DM3CNT_H = (DMA_TRANSFER_OFF);
    dst+=240;
  }

}

static void inttostr(int cnt,u8 len)
{
  if (cnt<0){
    res_inttostr[0]='-';
    res_inttostr[1]='?';
    res_inttostr[2]=0;
    return;
  }
  
  int i;

  for(i=len-1;i>=0;i--){
    if(cnt==0)
    {
      res_inttostr[i]=' ';
      }else{
      res_inttostr[i]=(cnt%10)+'0';
    }
    cnt/=10;
  }

  if(res_inttostr[len-1]==' ')
  {
    res_inttostr[len-1]='0';
  }

  res_inttostr[len]=0;
}

static void inttostrZeroPadding(int cnt,u8 len)
{
  int i;
  
  for(i=len-1;i>=0;i--){
    res_inttostr[i]=(cnt%10)+'0';
    cnt/=10;
  }

  res_inttostr[len]=0;
}

static void u32tostr(u32 cnt,u8 len)
{
  int i;
  
  for(i=len-1;i>=0;i--){
    if(cnt==0)
    {
      res_inttostr[i]=' ';
      }else{
      res_inttostr[i]=(cnt%10)+'0';
    }
    cnt/=10;
  }

  if(res_inttostr[len-1]==' ')
  {
    res_inttostr[len-1]='0';
  }

  res_inttostr[len]=0;
}

static void irqinttostr(int cnt,u8 len)
{
  if (cnt<0){
    irqres_inttostr[0]='-';
    irqres_inttostr[1]='?';
    irqres_inttostr[2]=0;
    return;
  }
  
  int i;

  for(i=len-1;i>=0;i--){
    if(cnt==0)
    {
      irqres_inttostr[i]=' ';
      }else{
      irqres_inttostr[i]=(cnt%10)+'0';
    }
    cnt/=10;
  }

  if(irqres_inttostr[len-1]==' ')
  {
    irqres_inttostr[len-1]='0';
  }

  irqres_inttostr[len]=0;
}

#endif
