// gba.h by eloist

// volatile�ǉ� by Moonlight. 2004/06/29
// SGFIF0A,SGFIF0B�ǉ� by Moonlight. 2004/06/29

// SGFIFO���[���ɂȂ��Ă����̂��I�[�ɏC�� by Moonlight. 2004/10/29


#ifndef GBA_HEADER
#define GBA_HEADER

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long int s64;

typedef unsigned char byte;
typedef unsigned short hword;
typedef unsigned long word;

typedef volatile unsigned char _u8;
typedef volatile unsigned short _u16;
typedef volatile unsigned long _u32;

typedef volatile signed char _s8;
typedef volatile signed short _s16;
typedef volatile signed long _s32;
typedef volatile signed long long int _s64;

typedef volatile unsigned char _byte;
typedef volatile unsigned short _hword;
typedef volatile unsigned long _word;

#define  OAMmem		(u32*)0x7000000
#define  VideoBuffer	(u16*)0x6000000

#define  OAMdata	(u16*)0x6010000
//#define  OAMdata	(u16*)0x6014000 // �r�b�g�}�b�v���[�h��
#define  BGpal		(u16*)0x5000000

#define  OBJpal		(u16*)0x5000200

#define SGFIFOA    (u32*)0x40000A0
#define SGFIFOB    (u32*)0x40000A4

#define REG_INTERUPT   *(volatile u32*)0x3007FFC
#define REG_DISPCNT    *(volatile u32*)0x4000000
#define REG_DISPCNT_L  *(volatile u16*)0x4000000
#define REG_DISPCNT_H  *(volatile u16*)0x4000002
#define REG_DISPSTAT   *(volatile u16*)0x4000004
#define REG_VCOUNT     *(volatile u16*)0x4000006
#define REG_BG0CNT     *(volatile u16*)0x4000008
#define REG_BG1CNT     *(volatile u16*)0x400000A
#define REG_BG2CNT     *(volatile u16*)0x400000C
#define REG_BG3CNT     *(volatile u16*)0x400000E
#define REG_BG0HOFS    *(volatile u16*)0x4000010
#define REG_BG0VOFS    *(volatile u16*)0x4000012
#define REG_BG1HOFS    *(volatile u16*)0x4000014
#define REG_BG1VOFS    *(volatile u16*)0x4000016
#define REG_BG2HOFS    *(volatile u16*)0x4000018
#define REG_BG2VOFS    *(volatile u16*)0x400001A
#define REG_BG3HOFS    *(volatile u16*)0x400001C
#define REG_BG3VOFS    *(volatile u16*)0x400001E
#define REG_BG2PA      *(volatile u16*)0x4000020
#define REG_BG2PB      *(volatile u16*)0x4000022
#define REG_BG2PC      *(volatile u16*)0x4000024
#define REG_BG2PD      *(volatile u16*)0x4000026
#define REG_BG2X       *(volatile u32*)0x4000028
#define REG_BG2X_L     *(volatile u16*)0x4000028
#define REG_BG2X_H     *(volatile u16*)0x400002A
#define REG_BG2Y       *(volatile u32*)0x400002C
#define REG_BG2Y_L     *(volatile u16*)0x400002C
#define REG_BG2Y_H     *(volatile u16*)0x400002E
#define REG_BG3PA      *(volatile u16*)0x4000030
#define REG_BG3PB      *(volatile u16*)0x4000032
#define REG_BG3PC      *(volatile u16*)0x4000034
#define REG_BG3PD      *(volatile u16*)0x4000036
#define REG_BG3X       *(volatile u32*)0x4000038
#define REG_BG3X_L     *(volatile u16*)0x4000038
#define REG_BG3X_H     *(volatile u16*)0x400003A
#define REG_BG3Y       *(volatile u32*)0x400003C
#define REG_BG3Y_L     *(volatile u16*)0x400003C
#define REG_BG3Y_H     *(volatile u16*)0x400003E
#define REG_WIN0H      *(volatile u16*)0x4000040
#define REG_WIN1H      *(volatile u16*)0x4000042
#define REG_WIN0V      *(volatile u16*)0x4000044
#define REG_WIN1V      *(volatile u16*)0x4000046
#define REG_WININ      *(volatile u16*)0x4000048
#define REG_WINOUT     *(volatile u16*)0x400004A
#define REG_MOSAIC     *(volatile u32*)0x400004C
#define REG_MOSAIC_L   *(volatile u32*)0x400004C
#define REG_MOSAIC_H   *(volatile u32*)0x400004E
#define REG_BLDMOD     *(volatile u16*)0x4000050
#define REG_COLEV      *(volatile u16*)0x4000052
#define REG_COLEY      *(volatile u16*)0x4000054
#define REG_SG10_L     *(volatile u16*)0x4000060
#define REG_SG10_H     *(volatile u16*)0x4000062
#define REG_SG11       *(volatile u16*)0x4000064
#define REG_SG20       *(volatile u16*)0x4000068
#define REG_SG21       *(volatile u16*)0x400006C
#define REG_SG30_L     *(volatile u16*)0x4000070
#define REG_SG30_H     *(volatile u16*)0x4000072
#define REG_SG31       *(volatile u16*)0x4000074
#define REG_SG40       *(volatile u16*)0x4000078
#define REG_SG41       *(volatile u16*)0x400007C
#define REG_SGCNT0_L   *(volatile u16*)0x4000080
#define REG_SGCNT0_H   *(volatile u16*)0x4000082
#define REG_SGCNT1     *(volatile u16*)0x4000084
#define REG_SGBIAS     *(volatile u16*)0x4000088
#define REG_SGWR0      *(volatile u32*)0x4000090
#define REG_SGWR0_L    *(volatile u16*)0x4000090
#define REG_SGWR0_H    *(volatile u16*)0x4000092
#define REG_SGWR1      *(volatile u32*)0x4000094
#define REG_SGWR1_L    *(volatile u16*)0x4000094
#define REG_SGWR1_H    *(volatile u16*)0x4000096
#define REG_SGWR2      *(volatile u32*)0x4000098
#define REG_SGWR2_L    *(volatile u16*)0x4000098
#define REG_SGWR2_H    *(volatile u16*)0x400009A
#define REG_SGWR3      *(volatile u32*)0x400009C
#define REG_SGWR3_L    *(volatile u16*)0x400009C
#define REG_SGWR3_H    *(volatile u16*)0x400009E
#define REG_SGFIFOA    *(volatile u32*)0x40000A0
#define REG_SGFIFOA_L  *(volatile u16*)0x40000A0
#define REG_SGFIFOA_H  *(volatile u16*)0x40000A2
#define REG_SGFIFOB    *(volatile u32*)0x40000A4
#define REG_SGFIFOB_L  *(volatile u16*)0x40000A4
#define REG_SGFIFOB_H  *(volatile u16*)0x40000A6
#define REG_DM0SAD     *(volatile u32*)0x40000B0
#define REG_DM0SAD_L   *(volatile u16*)0x40000B0
#define REG_DM0SAD_H   *(volatile u16*)0x40000B2
#define REG_DM0DAD     *(volatile u32*)0x40000B4
#define REG_DM0DAD_L   *(volatile u16*)0x40000B4
#define REG_DM0DAD_H   *(volatile u16*)0x40000B6
#define REG_DM0CNT     *(volatile u32*)0x40000B8
#define REG_DM0CNT_L   *(volatile u16*)0x40000B8
#define REG_DM0CNT_H   *(volatile u16*)0x40000BA
#define REG_DM1SAD     *(volatile u32*)0x40000BC
#define REG_DM1SAD_L   *(volatile u16*)0x40000BC
#define REG_DM1SAD_H   *(volatile u16*)0x40000BE
#define REG_DM1DAD     *(volatile u32*)0x40000C0
#define REG_DM1DAD_L   *(volatile u16*)0x40000C0
#define REG_DM1DAD_H   *(volatile u16*)0x40000C2
#define REG_DM1CNT     *(volatile u32*)0x40000C4
#define REG_DM1CNT_L   *(volatile u16*)0x40000C4
#define REG_DM1CNT_H   *(volatile u16*)0x40000C6
#define REG_DM2SAD     *(volatile u32*)0x40000C8
#define REG_DM2SAD_L   *(volatile u16*)0x40000C8
#define REG_DM2SAD_H   *(volatile u16*)0x40000CA
#define REG_DM2DAD     *(volatile u32*)0x40000CC
#define REG_DM2DAD_L   *(volatile u16*)0x40000CC
#define REG_DM2DAD_H   *(volatile u16*)0x40000CE
#define REG_DM2CNT     *(volatile u32*)0x40000D0
#define REG_DM2CNT_L   *(volatile u16*)0x40000D0
#define REG_DM2CNT_H   *(volatile u16*)0x40000D2
#define REG_DM3SAD     *(volatile u32*)0x40000D4
#define REG_DM3SAD_L   *(volatile u16*)0x40000D4
#define REG_DM3SAD_H   *(volatile u16*)0x40000D6
#define REG_DM3DAD     *(volatile u32*)0x40000D8
#define REG_DM3DAD_L   *(volatile u16*)0x40000D8
#define REG_DM3DAD_H   *(volatile u16*)0x40000DA
#define REG_DM3CNT     *(volatile u32*)0x40000DC
#define REG_DM3CNT_L   *(volatile u16*)0x40000DC
#define REG_DM3CNT_H   *(volatile u16*)0x40000DE
#define REG_TM0D       *(volatile u16*)0x4000100
#define REG_TM0CNT     *(volatile u16*)0x4000102
#define REG_TM1D       *(volatile u16*)0x4000104
#define REG_TM1CNT     *(volatile u16*)0x4000106
#define REG_TM2D       *(volatile u16*)0x4000108
#define REG_TM2CNT     *(volatile u16*)0x400010A
#define REG_TM3D       *(volatile u16*)0x400010C
#define REG_TM3CNT     *(volatile u16*)0x400010E
#define REG_SCD0       *(volatile u16*)0x4000120
#define REG_SCD1       *(volatile u16*)0x4000122
#define REG_SCD2       *(volatile u16*)0x4000124
#define REG_SCD3       *(volatile u16*)0x4000126
#define REG_SCCNT      *(volatile u32*)0x4000128
#define REG_SCCNT_L    *(volatile u16*)0x4000128
#define REG_SCCNT_H    *(volatile u16*)0x400012A
#define REG_P1         *(volatile u16*)0x4000130
#define REG_P1CNT      *(volatile u16*)0x4000132
#define REG_R          *(volatile u16*)0x4000134
#define REG_HS_CTRL    *(volatile u16*)0x4000140
#define REG_JOYRE      *(volatile u32*)0x4000150
#define REG_JOYRE_L    *(volatile u16*)0x4000150
#define REG_JOYRE_H    *(volatile u16*)0x4000152
#define REG_JOYTR      *(volatile u32*)0x4000154
#define REG_JOYTR_L    *(volatile u16*)0x4000154
#define REG_JOYTR_H    *(volatile u16*)0x4000156
#define REG_JSTAT      *(volatile u32*)0x4000158
#define REG_JSTAT_L    *(volatile u16*)0x4000158
#define REG_JSTAT_H    *(volatile u16*)0x400015A
#define REG_IE         *(volatile u16*)0x4000200
#define REG_IF         *(volatile u16*)0x4000202
#define REG_WSCNT      *(volatile u16*)0x4000204
#define REG_IME        *(volatile u16*)0x4000208
#define REG_PAUSE      *(volatile u16*)0x4000300

#define NVREG_INTERUPT   *(u32*)0x3007FFC
#define NVREG_DISPCNT    *(u32*)0x4000000
#define NVREG_DISPCNT_L  *(u16*)0x4000000
#define NVREG_DISPCNT_H  *(u16*)0x4000002
#define NVREG_DISPSTAT   *(u16*)0x4000004
#define NVREG_VCOUNT     *(u16*)0x4000006
#define NVREG_BG0CNT     *(u16*)0x4000008
#define NVREG_BG1CNT     *(u16*)0x400000A
#define NVREG_BG2CNT     *(u16*)0x400000C
#define NVREG_BG3CNT     *(u16*)0x400000E
#define NVREG_BG0HOFS    *(u16*)0x4000010
#define NVREG_BG0VOFS    *(u16*)0x4000012
#define NVREG_BG1HOFS    *(u16*)0x4000014
#define NVREG_BG1VOFS    *(u16*)0x4000016
#define NVREG_BG2HOFS    *(u16*)0x4000018
#define NVREG_BG2VOFS    *(u16*)0x400001A
#define NVREG_BG3HOFS    *(u16*)0x400001C
#define NVREG_BG3VOFS    *(u16*)0x400001E
#define NVREG_BG2PA      *(u16*)0x4000020
#define NVREG_BG2PB      *(u16*)0x4000022
#define NVREG_BG2PC      *(u16*)0x4000024
#define NVREG_BG2PD      *(u16*)0x4000026
#define NVREG_BG2X       *(u32*)0x4000028
#define NVREG_BG2X_L     *(u16*)0x4000028
#define NVREG_BG2X_H     *(u16*)0x400002A
#define NVREG_BG2Y       *(u32*)0x400002C
#define NVREG_BG2Y_L     *(u16*)0x400002C
#define NVREG_BG2Y_H     *(u16*)0x400002E
#define NVREG_BG3PA      *(u16*)0x4000030
#define NVREG_BG3PB      *(u16*)0x4000032
#define NVREG_BG3PC      *(u16*)0x4000034
#define NVREG_BG3PD      *(u16*)0x4000036
#define NVREG_BG3X       *(u32*)0x4000038
#define NVREG_BG3X_L     *(u16*)0x4000038
#define NVREG_BG3X_H     *(u16*)0x400003A
#define NVREG_BG3Y       *(u32*)0x400003C
#define NVREG_BG3Y_L     *(u16*)0x400003C
#define NVREG_BG3Y_H     *(u16*)0x400003E
#define NVREG_WIN0H      *(u16*)0x4000040
#define NVREG_WIN1H      *(u16*)0x4000042
#define NVREG_WIN0V      *(u16*)0x4000044
#define NVREG_WIN1V      *(u16*)0x4000046
#define NVREG_WININ      *(u16*)0x4000048
#define NVREG_WINOUT     *(u16*)0x400004A
#define NVREG_MOSAIC     *(u32*)0x400004C
#define NVREG_MOSAIC_L   *(u32*)0x400004C
#define NVREG_MOSAIC_H   *(u32*)0x400004E
#define NVREG_BLDMOD     *(u16*)0x4000050
#define NVREG_COLEV      *(u16*)0x4000052
#define NVREG_COLEY      *(u16*)0x4000054
#define NVREG_SG10       *(u32*)0x4000060
#define NVREG_SG10_L     *(u16*)0x4000060
#define NVREG_SG10_H     *(u16*)0x4000062
#define NVREG_SG11       *(u16*)0x4000064
#define NVREG_SG20       *(u16*)0x4000068
#define NVREG_SG21       *(u16*)0x400006C
#define NVREG_SG30       *(u32*)0x4000070
#define NVREG_SG30_L     *(u16*)0x4000070
#define NVREG_SG30_H     *(u16*)0x4000072
#define NVREG_SG31       *(u16*)0x4000074
#define NVREG_SG40       *(u16*)0x4000078
#define NVREG_SG41       *(u16*)0x400007C
#define NVREG_SGCNT0     *(u32*)0x4000080
#define NVREG_SGCNT0_L   *(u16*)0x4000080
#define NVREG_SGCNT0_H   *(u16*)0x4000082
#define NVREG_SGCNT1     *(u16*)0x4000084
#define NVREG_SGBIAS     *(u16*)0x4000088
#define NVREG_SGWR0      *(u32*)0x4000090
#define NVREG_SGWR0_L    *(u16*)0x4000090
#define NVREG_SGWR0_H    *(u16*)0x4000092
#define NVREG_SGWR1      *(u32*)0x4000094
#define NVREG_SGWR1_L    *(u16*)0x4000094
#define NVREG_SGWR1_H    *(u16*)0x4000096
#define NVREG_SGWR2      *(u32*)0x4000098
#define NVREG_SGWR2_L    *(u16*)0x4000098
#define NVREG_SGWR2_H    *(u16*)0x400009A
#define NVREG_SGWR3      *(u32*)0x400009C
#define NVREG_SGWR3_L    *(u16*)0x400009C
#define NVREG_SGWR3_H    *(u16*)0x400009E
#define NVREG_SGFIFOA    *(u32*)0x40000A0
#define NVREG_SGFIFOA_L  *(u16*)0x40000A0
#define NVREG_SGFIFOA_H  *(u16*)0x40000A2
#define NVREG_SGFIFOB    *(u32*)0x40000A4
#define NVREG_SGFIFOB_L  *(u16*)0x40000A4
#define NVREG_SGFIFOB_H  *(u16*)0x40000A6
#define NVREG_DM0SAD     *(u32*)0x40000B0
#define NVREG_DM0SAD_L   *(u16*)0x40000B0
#define NVREG_DM0SAD_H   *(u16*)0x40000B2
#define NVREG_DM0DAD     *(u32*)0x40000B4
#define NVREG_DM0DAD_L   *(u16*)0x40000B4
#define NVREG_DM0DAD_H   *(u16*)0x40000B6
#define NVREG_DM0CNT     *(u32*)0x40000B8
#define NVREG_DM0CNT_L   *(u16*)0x40000B8
#define NVREG_DM0CNT_H   *(u16*)0x40000BA
#define NVREG_DM1SAD     *(u32*)0x40000BC
#define NVREG_DM1SAD_L   *(u16*)0x40000BC
#define NVREG_DM1SAD_H   *(u16*)0x40000BE
#define NVREG_DM1DAD     *(u32*)0x40000C0
#define NVREG_DM1DAD_L   *(u16*)0x40000C0
#define NVREG_DM1DAD_H   *(u16*)0x40000C2
#define NVREG_DM1CNT     *(u32*)0x40000C4
#define NVREG_DM1CNT_L   *(u16*)0x40000C4
#define NVREG_DM1CNT_H   *(u16*)0x40000C6
#define NVREG_DM2SAD     *(u32*)0x40000C8
#define NVREG_DM2SAD_L   *(u16*)0x40000C8
#define NVREG_DM2SAD_H   *(u16*)0x40000CA
#define NVREG_DM2DAD     *(u32*)0x40000CC
#define NVREG_DM2DAD_L   *(u16*)0x40000CC
#define NVREG_DM2DAD_H   *(u16*)0x40000CE
#define NVREG_DM2CNT     *(u32*)0x40000D0
#define NVREG_DM2CNT_L   *(u16*)0x40000D0
#define NVREG_DM2CNT_H   *(u16*)0x40000D2
#define NVREG_DM3SAD     *(u32*)0x40000D4
#define NVREG_DM3SAD_L   *(u16*)0x40000D4
#define NVREG_DM3SAD_H   *(u16*)0x40000D6
#define NVREG_DM3DAD     *(u32*)0x40000D8
#define NVREG_DM3DAD_L   *(u16*)0x40000D8
#define NVREG_DM3DAD_H   *(u16*)0x40000DA
#define NVREG_DM3CNT     *(u32*)0x40000DC
#define NVREG_DM3CNT_L   *(u16*)0x40000DC
#define NVREG_DM3CNT_H   *(u16*)0x40000DE
#define NVREG_TM0D       *(u16*)0x4000100
#define NVREG_TM0CNT     *(u16*)0x4000102
#define NVREG_TM1D       *(u16*)0x4000104
#define NVREG_TM1CNT     *(u16*)0x4000106
#define NVREG_TM2D       *(u16*)0x4000108
#define NVREG_TM2CNT     *(u16*)0x400010A
#define NVREG_TM3D       *(u16*)0x400010C
#define NVREG_TM3CNT     *(u16*)0x400010E
#define NVREG_SCD0       *(u16*)0x4000120
#define NVREG_SCD1       *(u16*)0x4000122
#define NVREG_SCD2       *(u16*)0x4000124
#define NVREG_SCD3       *(u16*)0x4000126
#define NVREG_SCCNT      *(u32*)0x4000128
#define NVREG_SCCNT_L    *(u16*)0x4000128
#define NVREG_SCCNT_H    *(u16*)0x400012A
#define NVREG_P1         *(u16*)0x4000130
#define NVREG_P1CNT      *(u16*)0x4000132
#define NVREG_R          *(u16*)0x4000134
#define NVREG_HS_CTRL    *(u16*)0x4000140
#define NVREG_JOYRE      *(u32*)0x4000150
#define NVREG_JOYRE_L    *(u16*)0x4000150
#define NVREG_JOYRE_H    *(u16*)0x4000152
#define NVREG_JOYTR      *(u32*)0x4000154
#define NVREG_JOYTR_L    *(u16*)0x4000154
#define NVREG_JOYTR_H    *(u16*)0x4000156
#define NVREG_JSTAT      *(u32*)0x4000158
#define NVREG_JSTAT_L    *(u16*)0x4000158
#define NVREG_JSTAT_H    *(u16*)0x400015A
#define NVREG_IE         *(u16*)0x4000200
#define NVREG_IF         *(u16*)0x4000202
#define NVREG_WSCNT      *(u16*)0x4000204
#define NVREG_IME        *(u16*)0x4000208
#define NVREG_PAUSE      *(u16*)0x4000300




///// REG_DISPCNT defines

#define MODE_0 0x0
#define MODE_1 0x1
#define MODE_2 0x2
#define MODE_3 0x3
#define MODE_4 0x4
#define MODE_5 0x5

#define BACKBUFFER 0x10
#define H_BLANK_OAM 0x20 

#define OBJ_MAP_2D 0x0
#define OBJ_MAP_1D 0x40

#define FORCE_BLANK 0x80

#define BG0_ENABLE 0x100
#define BG1_ENABLE 0x200 
#define BG2_ENABLE 0x400
#define BG3_ENABLE 0x800
#define OBJ_ENABLE 0x1000 

#define WIN1_ENABLE 0x2000 
#define WIN2_ENABLE 0x4000
#define WINOBJ_ENABLE 0x8000


///////SetMode Macro
#define SetMode(mode) REG_DISPCNT = (mode) 




#define KEY_A 		1
#define KEY_B 		2
#define KEY_SELECT	4
#define KEY_START 	8
#define KEY_RIGHT 	16
#define KEY_LEFT 	32
#define KEY_UP 		64
#define KEY_DOWN 	128
#define KEY_R		256
#define KEY_L 		512

// �L�[���͗p
#define KEYS (volatile u32*)0x04000130



#define BIT0	1
#define BIT1	2
#define BIT2	4
#define BIT3	8
#define BIT4	16
#define BIT5	32
#define BIT6	64
#define BIT7	128
#define BIT8	256
#define BIT9	512
#define BIT10	1024
#define BIT11	2048
#define BIT12	4096
#define BIT13	8192
#define BIT14	16384
#define BIT15	32768



// 15bit�̐F��\������}�N��
#define RGB(r,g,b)	(((b)<<10)+((g)<<5)+(r))




#endif



