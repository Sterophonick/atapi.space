#include <agb_lib.h>
#include "data.h"
#include "cameradata.h"
#include "bonniboi.h"
#include "chicaboi.h"
#include "foxyboi.h"
#include "fredboi1.h"
#include "fredboi2.h"
#include "morestuff.h"
#include "gf.h"
#include "hals.h"
int left=0;
int right=0;
int ldoor=0;
int llight=0;
int rdoor=0;
int rlight=0;
int bonniel=0;
int chicar=0;
int boncnt=0;
int chicnt=0;
int bonniecount=0;
int chicacount=0;
int arrowx=0;
int arrowy=0;
int no;
int office=0;
int night=0;
int offset=0;
int cam=1;
int dieloop,alock,block,dlock,llock,rlock;

#define not  !
#define and  &&
#define nor  !|
#define or   |
#define nand !&
#define xor  ^
#define xnor !^

#define us   (void*)
#define vsync WaitForVblank();


void setbg2vb(u16* image, u16* pal)
{
	WaitForVblank();
	REG_DM3SAD = (unsigned long)image;
	REG_DM3DAD = (unsigned long)VideoBuffer;
	REG_DM3CNT = 0x80000000 | 120*160;
	SetPalette(pal);
}
void drawbg2vb(u16* image, u16* pal)
{
	WaitForVblank();
	bgPic2Buffer(image);
	bgPal(pal);
	bgPic(image);
	SetPalette(pal);
}

void testkill()
{
	if(keyDown(KEY_A))	
	{
	for(dieloop=0; dieloop<3; dieloop++) //bonnie
	{	
		vsync
		setbg2(us bon0Bitmap, us bon0Palette);
		Sleep(5);	
		vsync
		setbg2(us bon1Bitmap, us bon1Palette);
		Sleep(5);
		vsync
		setbg2(us bon2Bitmap, us bon2Palette);
		Sleep(5);
		vsync
		setbg2(us bon3Bitmap, us bon3Palette);
		Sleep(5);
		vsync
		setbg2(us bon4Bitmap, us bon4Palette);
		Sleep(5);
		vsync
		setbg2(us bon5Bitmap, us bon5Palette);
		Sleep(5);
		vsync
		setbg2(us bon6Bitmap, us bon6Palette);
		Sleep(5);
		vsync
		setbg2(us bon7Bitmap, us bon7Palette);
		Sleep(5);
		vsync
		setbg2(us bon8Bitmap, us bon8Palette);
		Sleep(5);
		vsync
		setbg2(us bon9Bitmap, us bon9Palette);
		Sleep(5);
	}
	}
	if(keyDown(KEY_B)) //chica
	{
	for(dieloop=0; dieloop<3; dieloop++)
	{	
		vsync
		setbg2(us boi0Bitmap, us boi0Palette);
		Sleep(5);	
		vsync
		setbg2(us boi1Bitmap, us boi1Palette);
		Sleep(5);
		vsync
		setbg2(us boi2Bitmap, us boi2Palette);
		Sleep(5);
		vsync
		setbg2(us boi3Bitmap, us boi3Palette);
		Sleep(5);
		vsync
		setbg2(us boi4Bitmap, us boi4Palette);
		Sleep(5);
		vsync
		setbg2(us boi5Bitmap, us boi5Palette);
		Sleep(5);
		vsync
		setbg2(us boi6Bitmap, us boi6Palette);
		Sleep(5);
		vsync
		setbg2(us boi7Bitmap, us boi7Palette);
		Sleep(5);
		vsync
		setbg2(us boi8Bitmap, us boi8Palette);
		Sleep(5);
		vsync
		setbg2(us boi9Bitmap, us boi9Palette);
		Sleep(5);
	}
	}
	if(keyDown(KEY_L)) //foxy
	{
	for(dieloop=0; dieloop<1; dieloop++)
	{	
		vsync
		setbg2(us o0Bitmap, us o0Palette);
		Sleep(5);	
		vsync
		setbg2(us o1Bitmap, us o1Palette);
		Sleep(5);
		vsync
		setbg2(us o2Bitmap, us o2Palette);
		Sleep(5);
		vsync
		setbg2(us o3Bitmap, us o3Palette);
		Sleep(5);
		vsync
		setbg2(us o4Bitmap, us o4Palette);
		Sleep(5);
		vsync
		setbg2(us o5Bitmap, us o5Palette);
		Sleep(5);
		vsync
		setbg2(us o6Bitmap, us o6Palette);
		Sleep(5);
		vsync
		setbg2(us o7Bitmap, us o7Palette);
		Sleep(5);
		vsync
		setbg2(us o8Bitmap, us o8Palette);
		Sleep(5);
		vsync
		setbg2(us o9Bitmap, us o9Palette);
		Sleep(5);
	}
	}
	if(keyDown(KEY_R)) //freddy office
	{
	for(dieloop=0; dieloop<1; dieloop++)
	{	
		vsync
		setbg2(us fredo0Bitmap, us fredo0Palette);
		Sleep(5);	
		vsync
		setbg2(us fredo1Bitmap, us fredo1Palette);
		Sleep(5);
		vsync
		setbg2(us fredo2Bitmap, us fredo2Palette);
		Sleep(5);
		vsync
		setbg2(us fredo3Bitmap, us fredo3Palette);
		Sleep(5);
		vsync
		setbg2(us fredo4Bitmap, us fredo4Palette);
		Sleep(5);
		vsync
		setbg2(us fredo5Bitmap, us fredo5Palette);
		Sleep(5);
		vsync
		setbg2(us fredo6Bitmap, us fredo6Palette);
		Sleep(5);
		vsync
		setbg2(us fredo7Bitmap, us fredo7Palette);
		Sleep(5);
		vsync
		setbg2(us fredo8Bitmap, us fredo8Palette);
		Sleep(5);
		vsync
		setbg2(us fredo9Bitmap, us fredo9Palette);
		Sleep(5);
		vsync
		setbg2(us fredo10Bitmap, us fredo10Palette);
		Sleep(5);
		vsync
		setbg2(us fredo11Bitmap, us fredo11Palette);
		Sleep(5);
		vsync
		setbg2(us fredo12Bitmap, us fredo12Palette);
		Sleep(5);
		vsync
		setbg2(us fredo13Bitmap, us fredo13Palette);
		Sleep(5);
	}
	}
	if(keyDown(KEY_UP)) //freddy power
	{
	for(dieloop=0; dieloop<1; dieloop++)
	{	
		vsync
		setbg2(us waddup0Bitmap, us waddup0Palette);
		Sleep(5);	
		vsync
		setbg2(us waddup1Bitmap, us waddup1Palette);
		Sleep(5);
		vsync
		setbg2(us waddup2Bitmap, us waddup2Palette);
		Sleep(5);
		vsync
		setbg2(us waddup3Bitmap, us waddup3Palette);
		Sleep(5);
		vsync
		setbg2(us waddup4Bitmap, us waddup4Palette);
		Sleep(5);
		vsync
		setbg2(us waddup5Bitmap, us waddup5Palette);
		Sleep(5);
		vsync
		setbg2(us waddup6Bitmap, us waddup6Palette);
		Sleep(5);
		vsync
		setbg2(us waddup7Bitmap, us waddup7Palette);
		Sleep(5);
		vsync
		setbg2(us waddup8Bitmap, us waddup8Palette);
		Sleep(5);
		vsync
		setbg2(us waddup9Bitmap, us waddup9Palette);
		Sleep(5);
	}
	}
	for(dieloop=0;dieloop<70;dieloop++) //static
	{
		vsync
		setbg2(us stat1Bitmap, us stat1Palette);
		Sleep(2);
		vsync
		setbg2(us stat2Bitmap, us stat2Palette);
		Sleep(2);
	}
	Sleep(88);
	setbg2(us gameoverBitmap, us gameoverPalette); //game over
	while(not(keyDown(KEY_A))) //waits until A is pressed
	{
		no=0;
	}
}

void gfkill()
{
	vsync
	setbg2(us gfBitmap, us gfPalette); //golden freddy
	Sleep(255);
	jmp((void*)0x57C0FFA0); //jumps to address 57C0FFA0, which doesn't exist, and crashes the game
}

int main()
{
	night = LoadInt(offset); //loads night the player is on
	if(night==0) //checks if SRAM is empty
	{
		SaveInt(offset,1); //saves night
		night=1; //sets night
	}
	office=1; //defaults office state
	Initialize(); //fade from BIOS
	SetPalette((void*)blackPalette); //black screen
	FadeIn(2);
	Sleep(127.5);
	FadeIn(2);
	setbg2((void*)WRNINGBitmap, (void*)WRNINGPalette); //warning
	Sleep(510); //waits 2 seconds
	FadeOut(15);
	setbg2vb(us MenuBitmap, us MenuPalette); //menu
	FadeIn(2);
	while(not(keyDown(KEY_START)))
	{
		if(keyDown(KEY_UP)) //night + 1
		{
			night++;
			Sleep(25);
		}
		if(keyDown(KEY_DOWN)) //night - 1
		{
			night--;
			Sleep(25);
		}
		if(night=0) //checks if night is below minimum
		{
			night=1;
			SaveInt(offset,1);
		}
		if(night=8) //checks if night is above maximum
		{
			night=7;
			SaveInt(offset,7);
		}
	}
	FadeOut(2);
	setbg2(us newsBitmap, us newsPalette); //news
	FadeIn(2);
	Sleep(255);
	FadeOut(15);
	if(night==1) //night screens
	{
		drawbg2vb(us n1Bitmap, us n1Palette);
		SaveInt(offset,night);
	}
	if(night==2)
	{
		drawbg2vb(us n2Bitmap, us n2Palette);
		SaveInt(offset,night);
	}
	if(night==3)
	{
		drawbg2vb(us n3Bitmap, us n3Palette);
		SaveInt(offset,night);
	}
	if(night==4)
	{
		drawbg2vb(us n4Bitmap, us n4Palette);
		SaveInt(offset,night);
	}
	if(night==5)
	{
		drawbg2vb(us n5Bitmap, us n5Palette);
		SaveInt(offset,night);
	}
	if(night==6)
	{
		drawbg2vb(us n6Bitmap, us n6Palette);
		SaveInt(offset,night);
	}
	if(night==7)
	{
		drawbg2vb(us n7Bitmap, us n7Palette);
		SaveInt(offset,night);
	}
	FadeIn(0);
	Sleep(510);
	FadeOut(3);
	Sleep(765);
	setbg2vb(us l00Bitmap, us l00Palette); //office
	FadeIn(2);
	left = 1;
	boncnt=1;
	chicnt=1;
	seedMT(1);
	while(1) //forever
	{
		if(boncnt==2)
		{
			bonniel=1;
			bonniecount++;
			if(bonniecount<10)
			{
				bonniel=0;
				boncnt=0;
				boncnt = Random(5);
				bonniecount=0;
			}
		}else{
			boncnt = Random(5);
			bonniel=0;
		}
		if(chicnt==2)
		{
			chicar=1;
			chicacount++;
			if(chicacount<12)
			{
				chicar=0;
				chicnt = Random(6);
				chicacount=0;
			}
		}else{
			chicnt = Random(6);
			chicar=0;
		}
			if(left==1)
			{
				if(keyDown(KEY_B)and(office==1))
				{
					llight=1;
				}
				if(keyDown(KEY_A)and(office==1))
				{
					ldoor=1;
				}
				if((llight==0)and(ldoor==0)and(office==1))
				{
					WaitForVblank();
					setbg2(us l00Bitmap, us l00Palette);
					right=0;
				}else{	
					if((llight==1)and(ldoor==0)and(office==1))
					{
						if(bonniel==1)
						{
							WaitForVblank();
							setbg2((void*)l10bonBitmap, (void*)l10bonPalette);
							Sleep(20);
							if(keyDown(KEY_B))
							{
								WaitForVblank();
								setbg2((void*)l00Bitmap, (void*)l00Palette);
								Sleep(20);
								llight = 0;
							}
						}else{
							WaitForVblank();
							setbg2((void*)l10Bitmap, (void*)l10Palette);
							llight=1;
							rlight=0;
							Sleep(20);
							if(keyDown(KEY_B))
							{
								WaitForVblank();
								setbg2((void*)l00Bitmap, (void*)l00Palette);
								Sleep(20);
								llight = 0;
							}
						}
					}
					if((ldoor==1)and(llight==0)and(office==1))
					{
						WaitForVblank();
						setbg2((void*)l01Bitmap, (void*)l01Palette);
						ldoor=1;
						Sleep(20);
						if(keyDown(KEY_A))
						{
							WaitForVblank();
							setbg2((void*)l00Bitmap, (void*)l00Palette);
							Sleep(20);
							ldoor = 0;
						}
					}
					if((ldoor==1)and(llight==1)and(not(bonniel==1))and(office==1))
					{
						rlight=0;
						WaitForVblank();
						setbg2((void*)l11Bitmap, (void*)l11Palette);
						Sleep(25);
						if(keyDown(KEY_B))
						{
							llight=0;
							WaitForVblank();
							setbg2((void*)l01Bitmap, (void*)l01Palette);
							Sleep(25);
						}
						if(keyDown(KEY_A))
						{
							ldoor=0;
							WaitForVblank();
							setbg2((void*)l10Bitmap, (void*)l10Palette);
							Sleep(25);
						}
					}
					if((ldoor==1)and(llight==1)and(bonniel==1)and(office==1))
					{
						rlight=0;
						WaitForVblank();
						setbg2((void*)l11bonBitmap, (void*)l11bonPalette);
						Sleep(25);
						if(keyDown(KEY_B))
						{
							llight=0;
							WaitForVblank();
							setbg2((void*)l01Bitmap, (void*)l01Palette);
							Sleep(25);
						}
						if(keyDown(KEY_A))
						{
							ldoor=0;
							WaitForVblank();
							setbg2((void*)l10bonBitmap, (void*)l10bonPalette);
							Sleep(25);
						}
					}	
				}
			}
			if((right==1)and(office==1))
			{
				if(keyDown(KEY_B))
				{
					rlight=1;
				}
				if(keyDown(KEY_A))
				{
					rdoor=1;
			}
			if((rlight==0)and(rdoor==0)and(office==1))
			{
				WaitForVblank();
				setbg2((void*)r00Bitmap, (void*)r00Palette);
				left=0;
			}else{	
				if((rlight==1)and(rdoor==0)and(office==1))
				{
					if(chicar==1)
					{
						WaitForVblank();
						setbg2((void*)r01chicaBitmap, (void*)r01chicaPalette);
						Sleep(20);
						if(keyDown(KEY_B))
						{
							WaitForVblank();
							setbg2((void*)r00Bitmap, (void*)r00Palette);
							Sleep(20);
							rlight = 0;
						}
					}else{
						WaitForVblank();
						setbg2((void*)r01Bitmap, (void*)r01Palette);
						rlight=1;
						llight=0;
						Sleep(20);
						if(keyDown(KEY_B))
						{
							WaitForVblank();
							setbg2((void*)r00Bitmap, (void*)r00Palette);
							Sleep(20);
							rlight = 0;
						}
					}
				}
				if((rdoor==1)and(rlight==0)and(office==1))
				{
					WaitForVblank();
					setbg2((void*)r10Bitmap, (void*)r10Palette);
					rdoor=1;
					Sleep(20);
					if(keyDown(KEY_A))
					{
						WaitForVblank();
						setbg2((void*)r00Bitmap, (void*)r00Palette);
						Sleep(20);
						rdoor = 0;
					}
				}
				if((rdoor==1)and(rlight==1)and(not(chicar==1))and(office==1))
				{
					llight=0;
					WaitForVblank();
					setbg2((void*)r11Bitmap, (void*)r11Palette);
					Sleep(25);
					if(keyDown(KEY_B))
					{
						rlight=0;
						WaitForVblank();
						setbg2((void*)r10Bitmap, (void*)r10Palette);
						Sleep(25);
					}
					if(keyDown(KEY_A))
					{
						rdoor=0;
						WaitForVblank();
						setbg2((void*)r01Bitmap, (void*)r01Palette);
						Sleep(25);
					}
				}
				if((rdoor==1)and(rlight==1)and(chicar==1)and(office==1))
				{
					llight=0;
					WaitForVblank();
					setbg2((void*)r11chicaBitmap, (void*)r11chicaPalette);
					Sleep(25);
					if(keyDown(KEY_B))
					{
						rlight=0;
						setbg2((void*)r10Bitmap, (void*)r10Palette);
						Sleep(25);
						rlight=0;
					}
					if(keyDown(KEY_A))
					{
						rdoor=0;
						WaitForVblank();
						setbg2((void*)r01chicaBitmap, (void*)r01chicaPalette);
						Sleep(25);
					}
				}				
			}
		}
		if((keyDown(KEY_LEFT))and(office==1))
		{
			left=1;
			right=0;
		}
		if((keyDown(KEY_RIGHT))and(office==1))
		{
			left=0;
			right=1;
		}
		if(keyDown(KEY_DOWN))
		{
			while(keyDown(KEY_DOWN))
			{
				no=0;
			}
			office==0;

			while(not(keyDown(KEY_DOWN)))
			{			
				if(keyDown(KEY_SELECT))
				{
					testkill();
					return 0;
				}
				if((keyDown(KEY_L))AND(llock==0))
				{
					llock==1;
					cam--;
					if(cam<0)
					{
						cam=11;
					}
				}
				if((keyDown(KEY_R))AND(rlock==0))
				{
					cam++;
					if(cam>11)
					{
						cam=1;
					}
					rlock==1;
				}
				if(keyDown(KEY_L))
				{
					llock==1;
				}
				if(keyDown(KEY_R))
				{
					rlock==1;
				}
				if(cam==1)
				{
					WaitForVblank();
					setbg2((void*)Stage000Bitmap, (void*)Stage000Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==2)
				{
					WaitForVblank();
					setbg2((void*)NoneBitmap, (void*)NonePalette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==3)
				{
					WaitForVblank();
					setbg2((void*)f0Bitmap, (void*)f0Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==4)
				{
					WaitForVblank();
					setbg2((void*)h2aBitmap, (void*)h2aPalette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==5)
				{
					WaitForVblank();
					setbg2((void*)abnoneBitmap, (void*)abnonePalette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==6)
				{
					WaitForVblank();
					setbg2((void*)b0Bitmap, (void*)b0Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==7)
				{
					WaitForVblank();
					setbg2((void*)a40Bitmap, (void*)a40Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==8)
				{
					WaitForVblank();
					setbg2((void*)noneb4Bitmap, (void*)noneb4Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==9)
				{
					WaitForVblank();
					setbg2((void*)blah0Bitmap, (void*)blah0Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==10)
				{
					WaitForVblank();
					setbg2((void*)kitchenBitmap, (void*)kitchenPalette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
				if(cam==11)
				{
					WaitForVblank();
					setbg2((void*)None2Bitmap, (void*)None2Palette);
				if(NOT(keyDown(KEY_L)))
				{
					llock=0;
				}
				if(NOT(keyDown(KEY_R)))
				{
					rlock=0;
				}
				}
			}
			while(keyDown(KEY_DOWN))
			{
				no=0;
			}
		}
		if(keyDown(KEY_SELECT))
		{
			testkill();
			return 0; //resets the game
		}
		if(keyDown(KEY_START))
		{
			gfkill();
			return 0;
		}
	}
	return 0;
}