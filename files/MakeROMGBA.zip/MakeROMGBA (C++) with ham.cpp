#include <iostream>
#include <windows.h>
#include <cstdio>
#include <fstream>
#include <string>
using namespace std;


//initiations
void setcolor(unsigned short color)
{
	HANDLE hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hcon,color);                                    
}

void codeerrorcheck()
{
ifstream fin;
fin.open("main.cpp");
setcolor(11);
if(!fin)
{
	setcolor(11);
	std::cout << "The main.cpp file doesn't exist. Compilation failed." << std::endl;
} else {
    std::cout << "Errors were found. The list is above." << std::endl;
    }
setcolor(13);
system("pause");
system("exit");
}

void elferrorcheck()
{
ifstream fin;
fin.open("main.o");
setcolor(11);
if(!fin)
{
	setcolor(11);
	std::cout << "The main.o file doesn't exist. Failed to make the main.elf file." << std::endl;
} else {
    std::cout << "There are problems with main.o. Please fix your source code." << std::endl;
    }
setcolor(13);
system("pause");
system("exit");
}

void gbaerrorcheck()
{
ifstream fin;
fin.open("main.elf");
setcolor(11);
if(!fin)
{
	setcolor(11);
	std::cout << "The main.elf file doesn't exist. Failed to make the main.elf file." << std::endl;
} else {
    std::cout << "There are problems with main.elf. Please fix your source code." << std::endl;
    }
setcolor(13);
system("pause");
system("exit");
}

int main() 
{
	system("del *.gba>nul");
	system("del *.o>nul");
   	system("del *.elf>nul");
   	system("del *.sav>nul");
	SetConsoleTitle("MakeROMGBA v1.9c");
	system("CLS");
	setcolor(110);
	std::cout << "MakeROM GBA tool created by imadog54. Scratch account is called imadog54." << std::endl;
	std::cout << "For this tool to work properly, your GBA Projects must all be organized in folders." << std::endl;
	std::cout << "The source file MUST be named 'main.cpp.'" << std::endl;
	std::cout << "\n";
	std::cout << "\n";
	std::cout << "\n";
	std::cout << "\n";
	setcolor(9);
	std::cout << "The ROM source code is being checked. Please wait a moment..." << std::endl;
	setcolor(12);
	Sleep(3000);
	int ret;
	if( !(ret = system("C:\\devkitadv\\bin\\gcc -c -O3 -mthumb-interwork main.cpp")) ) {
		setcolor(10);
 		std::cout << "No errors were found. In the process, an .O file was created." << std::endl;
		std::cout << "\n";
	} else {
    	codeerrorcheck();
    	system("exit");
	}
	setcolor(9);
	std::cout << "Making an .elf file from the .o file..." << std::endl;
	setcolor(12);
	Sleep(3000);
	int ret2;
	if( !(ret2 = system("C:\\devkitadv\\bin\\gcc -marm -mthumb-interwork -o main.elf main.o C:\\devkitadv\\lib\\gcc-lib\\arm-agb-elf\\3.2.2\\include\\libham.a")) ) {
		setcolor(10);
 		std::cout << "ELF Built! " << std::endl;
 		std::cout << "\n";
	} else {
    	elferrorcheck();
    	system("exit");
	}
	setcolor(9);
	std::cout << "Making GBA ROM file from the .elf file..." << std::endl;
	setcolor(12);
	Sleep(3000);
	int ret3;
	if( !(ret3 = system("C:\\devkitadv\\bin\\objcopy -O binary main.elf main.gba")) ) {
		setcolor(10);
 		std::cout << "ROM Built! " << std::endl;
 		std::cout << "\n";
	} else {
    	gbaerrorcheck();
    	system("exit");
	}
	system("C:\\devkitadv\\tools\\gbafix main.gba");
	setcolor(93);
	system("PAUSE");;
   	system("cls");
	return 0;
}
