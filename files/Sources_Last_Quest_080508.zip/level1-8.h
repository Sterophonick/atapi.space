#include "gfx/maps/lq/map_8.til.c"
#include "gfx/maps/lq/map_8.map.c"
#include "gfx/maps/lq/map_8.pal.c"
#include "gfx/maps/lq/map_8bg.map.c"
