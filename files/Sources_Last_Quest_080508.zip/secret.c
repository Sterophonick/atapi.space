#include <mygba.h>
#include "header.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void EnterSecretZone()
{
   while ( collisions_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 9) >> 3)] == t_secret) mario.pos_x--; //je centre mario sur le tuyau
   while ( collisions_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 24) >> 3)] == t_secret) mario.pos_x++;
   AnimEnterSecretZone();
}

void ExitSecretZone()
{
   AnimExitSecretZone();
}

u8 SecretZonePresent() // return 1 si mario a le pied sur ou est devant un tuyau secret
{
   return ( collisions_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 16) >> 3)] == t_secret)
   || ( collisions_map[((Pty + mario.pos_y + mario.dec_dg_y2) >> 3)][((Ptx + mario.pos_x + mario.dec_droite_x) >> 3)] == t_secret)
   || ( collisions_map[((Pty + mario.pos_y + mario.dec_dg_y2) >> 3)][((Ptx + mario.pos_x + mario.dec_gauche_x) >> 3)] == t_secret);
}

u8 TuyauFin() // return 1 si mario a le pied sur ou est devant un tuyau de fin
{
   return ( carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 16) >> 3)] == 87)
   || ( carte_map[((Pty + mario.pos_y + mario.dec_dg_y2) >> 3)][((Ptx + mario.pos_x + mario.dec_droite_x) >> 3)] == 87)
   || ( carte_map[((Pty + mario.pos_y + mario.dec_dg_y2) >> 3)][((Ptx + mario.pos_x + mario.dec_gauche_x) >> 3)] == 87)
   || ( carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 16) >> 3)] == 94)
   || ( carte_map[((Pty + mario.pos_y + mario.dec_dg_y2) >> 3)][((Ptx + mario.pos_x + mario.dec_droite_x) >> 3)] == 94)
   || ( carte_map[((Pty + mario.pos_y + mario.dec_dg_y2) >> 3)][((Ptx + mario.pos_x + mario.dec_gauche_x) >> 3)] == 94);
}
