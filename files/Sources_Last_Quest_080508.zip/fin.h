#include "gfx/maps/lq/end_01.til.c"
#include "gfx/maps/lq/end_01.pal.c"
#include "gfx/maps/lq/end_01.map.c"
#include "gfx/maps/lq/end_02.map.c"
#include "gfx/maps/lq/end_03.map.c"
#include "gfx/maps/lq/end_04.map.c"
#include "gfx/maps/lq/end_05.map.c"
#include "gfx/maps/lq/end_06.map.c"
#include "gfx/maps/lq/end_07.map.c"
#include "gfx/maps/lq/end_08.map.c"
#include "gfx/maps/lq/end_09.map.c"
#include "gfx/maps/lq/end_10.map.c"
#include "gfx/maps/lq/end_11.map.c"
#include "gfx/maps/lq/end_12.map.c"






