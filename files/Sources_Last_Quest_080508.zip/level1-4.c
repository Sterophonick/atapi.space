#include <mygba.h>
#include "header.h"
#include "level1-4.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void AfficheNiveau14()
{
	for (taby = 0; taby < 40; taby++)
	{
		for (tabx = 0; tabx < 1024; tabx++)
		{
			carte_map[taby][tabx] = map_4_map[taby][tabx];
		}
	}

   	collisions_map = map_4_col_map;

	hel_PalBgLoad256((void*)map_4_palette); //chargement de la palette des bg

	InitTexte(4);

	ham_bg[3].ti = ham_InitTileSet((void*)&map_4_tiles,SIZEOF_16BIT(map_4_tiles),1,1);
	ham_bg[2].ti = ham_bg[3].ti;	
	
	hel_MapCreate(2, 1024, 40, (void*)carte_map, sizeof(u16), (MAP_FLAGS_DEFAULT & ~MAP_FLAGS_TRANSMITIMMEDIATELY));	
	hel_MapSetPosition(2,FIXED_FROMINT(0),FIXED_FROMINT(160));	
	
	hel_MapCreate(3, 512, 40, (void*)map_4bg_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	hel_MapSetPosition(3,0,FIXED_FROMINT(160));
	
	ham_InitBg(2, TRUE, 2, FALSE);
	ham_InitBg(3, TRUE, 3, FALSE);

	hel_BgSetMosaic(0,TRUE); //activation du mode mosaique pour les BG
	hel_BgSetMosaic(2,TRUE);
	hel_BgSetMosaic(3,TRUE);
	hel_BgSetMosaicSize(15,15);

	if ((quete%100000 - quete%10000)/10000 == 2) bonus_tuyau = 1;
	else bonus_tuyau = 0;
	face_coin = pacoin_tile;
	num_niveau = 4;
	checkpoint = 0;

	//1er checkpoint
	retry[0][0] = 1022; //Ptx
	retry[0][1] = 36; //Pty
	retry[0][2] = 60; //mario_y
	
	//2�me checkpoint
	retry[1][0] = 2038; //Ptx
	retry[1][1] = 160; //Pty
	retry[1][2] = 64; //mario_y
	
	//3�me checkpoint
	retry[4][0] = 3400; //Ptx
	retry[4][1] = 148; //Pty
	retry[4][2] = 60; //mario_y
	
	//4�me checkpoint
	retry[5][0] = 4800; //Ptx
	retry[5][1] = 160; //Pty
	retry[5][2] = 64; //mario_y

	retry[2][1] = 7630; //fin niveau
	retry[2][2] = 64; //mario_y d�but niveau
	
	//sortie de la salle bonus
	retry[3][0] = 5878; //Ptx 
	retry[3][1] = 148; //Pty
	retry[3][2] = 90; //mario_x
	retry[3][3] = 92; //mario_y

	mario.pos_x = 49;
    temps = 400;

	PreNiveau();

	play_music = 1; // on balance la musique du niveau

	ScanEcran();
	
	hel_BgTextPrintF(0,20,0,0,"�"); //affichage du 4
	
}

void ReAfficheNiveau14()
{
    for (taby = 0; taby < 40; taby++)
    {
       for (tabx = 0; tabx < 1024; tabx++)
       {
          carte_map[taby][tabx] = map_4_map[taby][tabx];
       }
    }
    
	
	ScanEcran();

	if (checkpoint == 1) 
	{
		hel_MapSetPosition(2,FIXED_FROMINT(retry[0][0]),FIXED_FROMINT(retry[0][1])); 
		hel_MapSetPosition(3,0,FIXED_FROMINT(retry[0][1]));
		mario.pos_y = retry[0][2];
	}
	else if (checkpoint == 2) 
	{
		hel_MapSetPosition(2,FIXED_FROMINT(retry[1][0]),FIXED_FROMINT(retry[1][1])); 
		hel_MapSetPosition(3,0,FIXED_FROMINT(retry[1][1]));
		mario.pos_y = retry[1][2];
	}
	else if (checkpoint == 3) 
	{
		hel_MapSetPosition(2,FIXED_FROMINT(retry[4][0]),FIXED_FROMINT(retry[4][1])); 
		hel_MapSetPosition(3,0,FIXED_FROMINT(retry[4][1]));
		mario.pos_y = retry[4][2];
	}
	else if (checkpoint == 4) 
	{
		hel_MapSetPosition(2,FIXED_FROMINT(retry[5][0]),FIXED_FROMINT(retry[5][1])); 
		hel_MapSetPosition(3,0,FIXED_FROMINT(retry[5][1]));
		mario.pos_y = retry[5][2];
	}
	else 
	{
		hel_MapSetPosition(2,FIXED_FROMINT(retry[2][0]),FIXED_FROMINT(retry[2][1])); 
		hel_MapSetPosition(3,0,FIXED_FROMINT(retry[2][1]));
		mario.pos_y = retry[2][2];
	}
	
	hel_MapGetPosition(2, &Ptx, &Pty);
	{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
    {Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

	play_music = 1; // on balance la musique du niveau
}
