#include "gfx/maps/lq/map_2.map.c"
#include "gfx/maps/lq/map_2.til.c"
#include "gfx/maps/lq/map_2.pal.c"
#include "gfx/maps/lq/map_2bg.map.c"
//#include "gfx/maps/maps/map_2bg.til.c"

/*#include "gfx/maps/lv1-2/desert12.map.c"
#include "gfx/maps/lv1-2/blanc12.map.c"
#include "gfx/maps/lv1-2/desert12.til.c"*/



