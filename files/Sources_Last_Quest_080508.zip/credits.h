#include "gfx/maps/maps/credit.til.c"
#include "gfx/maps/maps/credit.pal.c"
#include "gfx/maps/maps/credit.map.c"
