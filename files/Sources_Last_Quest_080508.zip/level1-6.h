#include "gfx/maps/lq/map_6.til.c"
#include "gfx/maps/lq/map_6.map.c"
#include "gfx/maps/lq/map_6.pal.c"
#include "gfx/maps/lq/map_6bg.map.c"
