#include <mygba.h>
#include "header.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void DecaleEcranHaut() //4 fonctions pour que les sprites soient bien plac�s m�me quand l'�cran bouge
{
   DE_Blocs_Haut();
   DE_Plateformes_Haut();
   for (b = goombad; b <= goombaf; b++) DE_Haut(b);
   for (b = points1n; b <= points3n; b++) DE_Haut(b);
   DE_Haut(ballen);
   DE_Haut(flyn);
   DE_Haut(koopan);
   DE_Haut(bonusn);
   DE_Haut(cachen);
   DE_Haut(unevien);
   DE_Haut(boumn);   

}

void DecaleEcranBas()
{
   DE_Blocs_Bas();
   DE_Plateformes_Bas();
   for (b = goombad; b <= goombaf; b++) DE_Bas(b);
   for (b = points1n; b <= points3n; b++) DE_Bas(b);
   DE_Bas(ballen);
   DE_Bas(flyn);
   DE_Bas(koopan);
   DE_Bas(bonusn);
   DE_Bas(cachen);
   DE_Bas(unevien);
   DE_Bas(boumn);   

}

void DecaleEcranGauche()
{
   DE_Blocs_Gauche();
   DE_Plateformes_Gauche();
   for (b = goombad; b <= goombaf; b++) DE_Gauche(b);
   for (b = points1n; b <= points3n; b++) DE_Gauche(b);
   DE_Gauche(ballen);
   DE_Gauche(flyn);
   DE_Gauche(koopan);
   DE_Gauche(bonusn);
   DE_Gauche(cachen);
   DE_Gauche(unevien);
   DE_Gauche(boumn);

}

void DecaleEcranDroite()
{
   DE_Blocs_Droite();
   DE_Plateformes_Droite();
   for (b = goombad; b <= goombaf; b++) DE_Droite(b);
   for (b = points1n; b <= points3n; b++) DE_Droite(b);
   DE_Droite(ballen);
   DE_Droite(flyn);
   DE_Droite(koopan);
   DE_Droite(bonusn);
   DE_Droite(cachen);
   DE_Droite(unevien);
   DE_Droite(boumn);

}


//fonctions g�n�ralistes

void DE_Haut(u8 f)
{
   if (sprite[f].ecran_delta_y > 0)
   {
      sprite[f].pos_y--;
      sprite[f].ecran_delta_y--;
      hel_ObjSetY(sprite[f].sprite,sprite[f].pos_y);
      if (sprite[f].pos_y > 160) hel_ObjSetY(sprite[f].sprite, 160); //correction de bug
      //hel_ObjUpdateInOAM(sprite[f].sprite);
   }
}

void DE_Bas(u8 f)
{
   //if (!BlocPresentBas(sprite[f]))
   {
      sprite[f].pos_y++;
      sprite[f].ecran_delta_y++;
      hel_ObjSetY(sprite[f].sprite,sprite[f].pos_y);
      if (sprite[f].pos_y > 160) hel_ObjSetY(sprite[f].sprite, 160); //correction de bug
      //hel_ObjUpdateInOAM(sprite[f].sprite);
   }
}

void DE_Gauche(u8 f)
{
   if (sprite[f].etat != sprite_inactif)
   {
      sprite[f].pos_x--;
      hel_ObjSetX(sprite[f].sprite,sprite[f].pos_x);
      if (sprite[f].pos_x > 240) hel_ObjSetX(sprite[f].sprite, 240);
      //hel_ObjUpdateInOAM(sprite[f].sprite);
   }
}

void DE_Droite(u8 f)
{
   if (Ptx != 0 && sprite[f].etat != sprite_inactif)
   {
      sprite[f].pos_x++;
      hel_ObjSetX(sprite[f].sprite,sprite[f].pos_x);
      if (sprite[f].pos_x > 240) hel_ObjSetX(sprite[f].sprite, 240);
      //hel_ObjUpdateInOAM(sprite[f].sprite);
   }
}


//j'effectue le d�calage des blocs et des plateformes mobiles � part des autres (pas de fonctions DE_ simples pour eux)

void DE_Blocs_Haut()
{
   for (b = 0; b < 7; b++)
   {
      if (bloc_piece[b].ecran_delta_y > 0)
      {
         bloc_piece[b].ecran_delta_y--;
         bloc_piece[b].pos_y--;
         hel_ObjSetY(bloc_piece[b].sprite,bloc_piece[b].pos_y);
         //hel_ObjUpdateInOAM(bloc_piece[b].sprite);
      }
   }
   if (bloc_piece_plus[0].ecran_delta_y > 0)
   {
      bloc_piece_plus[0].ecran_delta_y--;
      bloc_piece_plus[0].pos_y--;
      hel_ObjSetY(bloc_piece_plus[0].sprite,bloc_piece_plus[0].pos_y);
      //hel_ObjUpdateInOAM(bloc_piece_plus[0].sprite);
   }
   if (b_bloc[0].ecran_delta_y > 0)
   {
      b_bloc[0].ecran_delta_y--;
      b_bloc[0].pos_y--;
      hel_ObjSetY(b_bloc[0].sprite,b_bloc[0].pos_y);
      //hel_ObjUpdateInOAM(b_bloc[0].sprite);
   }
   for (b = 0; b < 4; b++)
   {
      if (bloc_std[b].ecran_delta_y > 0)
      {
         bloc_std[b].ecran_delta_y--;
         bloc_std[b].pos_y--;
         hel_ObjSetY(bloc_std[b].sprite,bloc_std[b].pos_y);
         //hel_ObjUpdateInOAM(bloc_std[b].sprite);
      }
   }
   for (b = 0; b < 5; b++)
   {
      if (bloc_morceaux[b].morceau1_ecran_delta_y > 0)
      {
         bloc_morceaux[b].morceau1_ecran_delta_y--;
         bloc_morceaux[b].morceau1_pos_y--;
         hel_ObjSetY(bloc_morceaux[b].morceau1_sprite,bloc_morceaux[b].morceau1_pos_y);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau1_sprite);
      }
      if (bloc_morceaux[b].morceau2_ecran_delta_y > 0)
      {
         bloc_morceaux[b].morceau2_ecran_delta_y--;
         bloc_morceaux[b].morceau2_pos_y--;
         hel_ObjSetY(bloc_morceaux[b].morceau2_sprite,bloc_morceaux[b].morceau2_pos_y);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau2_sprite);
      }
      if (bloc_morceaux[b].morceau3_ecran_delta_y > 0)
      {
         bloc_morceaux[b].morceau3_ecran_delta_y--;
         bloc_morceaux[b].morceau3_pos_y--;
         hel_ObjSetY(bloc_morceaux[b].morceau3_sprite,bloc_morceaux[b].morceau3_pos_y);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau3_sprite);
      }
      if (bloc_morceaux[b].morceau4_ecran_delta_y > 0)
      {
         bloc_morceaux[b].morceau4_ecran_delta_y--;
         bloc_morceaux[b].morceau4_pos_y--;
         hel_ObjSetY(bloc_morceaux[b].morceau4_sprite,bloc_morceaux[b].morceau4_pos_y);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau4_sprite);
      }
   }
}

void DE_Blocs_Bas()
{
   for (b = 0; b < 7; b++)
   {
      bloc_piece[b].pos_y++;
      bloc_piece[b].ecran_delta_y++;
      hel_ObjSetY(bloc_piece[b].sprite,bloc_piece[b].pos_y);
      //hel_ObjUpdateInOAM(bloc_piece[b].sprite);
   }
   bloc_piece_plus[0].pos_y++;
   bloc_piece_plus[0].ecran_delta_y++;
   hel_ObjSetY(bloc_piece_plus[0].sprite,bloc_piece_plus[0].pos_y);
   //hel_ObjUpdateInOAM(bloc_piece_plus[0].sprite);

   b_bloc[0].pos_y++;
   b_bloc[0].ecran_delta_y++;
   hel_ObjSetY(b_bloc[0].sprite,b_bloc[0].pos_y);
   //hel_ObjUpdateInOAM(b_bloc[0].sprite);

   for (b = 0; b < 4; b++)
   {
      bloc_std[b].pos_y++;
      bloc_std[b].ecran_delta_y++;
      hel_ObjSetY(bloc_std[b].sprite,bloc_std[b].pos_y);
      //hel_ObjUpdateInOAM(bloc_std[b].sprite);
   }
   
   for (b = 0; b < 5; b++)
   {
      bloc_morceaux[b].morceau1_pos_y++;
      bloc_morceaux[b].morceau1_ecran_delta_y++;
      bloc_morceaux[b].morceau2_pos_y++;
      bloc_morceaux[b].morceau2_ecran_delta_y++;
      bloc_morceaux[b].morceau3_pos_y++;
      bloc_morceaux[b].morceau3_ecran_delta_y++;
      bloc_morceaux[b].morceau4_pos_y++;
      bloc_morceaux[b].morceau4_ecran_delta_y++;
      hel_ObjSetY(bloc_morceaux[b].morceau1_sprite,bloc_morceaux[b].morceau1_pos_y);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau1_sprite);
      hel_ObjSetY(bloc_morceaux[b].morceau2_sprite,bloc_morceaux[b].morceau2_pos_y);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau2_sprite);
      hel_ObjSetY(bloc_morceaux[b].morceau3_sprite,bloc_morceaux[b].morceau3_pos_y);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau3_sprite);
      hel_ObjSetY(bloc_morceaux[b].morceau4_sprite,bloc_morceaux[b].morceau4_pos_y);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau4_sprite);
   }
}

void DE_Blocs_Gauche()
{
   for (b = 0; b < 7; b++)
   {
      bloc_piece[b].pos_x--;
      hel_ObjSetX(bloc_piece[b].sprite,bloc_piece[b].pos_x);
      //hel_ObjUpdateInOAM(bloc_piece[b].sprite);
   }
   bloc_piece_plus[0].pos_x--;
   hel_ObjSetX(bloc_piece_plus[0].sprite,bloc_piece_plus[0].pos_x);
   //hel_ObjUpdateInOAM(bloc_piece_plus[0].sprite);

   b_bloc[0].pos_x--;
   hel_ObjSetX(b_bloc[0].sprite,b_bloc[0].pos_x);
   //hel_ObjUpdateInOAM(b_bloc[0].sprite);

   for (b = 0; b < 4; b++)
   {
      bloc_std[b].pos_x--;
      hel_ObjSetX(bloc_std[b].sprite,bloc_std[b].pos_x);
      //hel_ObjUpdateInOAM(bloc_std[b].sprite);
   }
   
   for (b = 0; b < 5; b++)
   {
      bloc_morceaux[b].morceau1_pos_x--;
      bloc_morceaux[b].morceau2_pos_x--;
      bloc_morceaux[b].morceau3_pos_x--;
      bloc_morceaux[b].morceau4_pos_x--;
      hel_ObjSetX(bloc_morceaux[b].morceau1_sprite,bloc_morceaux[b].morceau1_pos_x);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau1_sprite);
      hel_ObjSetX(bloc_morceaux[b].morceau2_sprite,bloc_morceaux[b].morceau2_pos_x);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau2_sprite);
      hel_ObjSetX(bloc_morceaux[b].morceau3_sprite,bloc_morceaux[b].morceau3_pos_x);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau3_sprite);
      hel_ObjSetX(bloc_morceaux[b].morceau4_sprite,bloc_morceaux[b].morceau4_pos_x);
      //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau4_sprite);
   }
}

void DE_Blocs_Droite()
{
   for (b = 0; b < 7; b++)
   {
      bloc_piece[b].pos_x++;
      hel_ObjSetX(bloc_piece[b].sprite,bloc_piece[b].pos_x);
      //hel_ObjUpdateInOAM(bloc_piece[b].sprite);
   }
   if (Ptx != 0)
   {
      bloc_piece_plus[0].pos_x++;
      hel_ObjSetX(bloc_piece_plus[0].sprite,bloc_piece_plus[0].pos_x);
      //hel_ObjUpdateInOAM(bloc_piece_plus[0].sprite);

      b_bloc[0].pos_x++;
      hel_ObjSetX(b_bloc[0].sprite,b_bloc[0].pos_x);
      //hel_ObjUpdateInOAM(b_bloc[0].sprite);

      for (b = 0; b < 4; b++)
      {
         bloc_std[b].pos_x++;
         hel_ObjSetX(bloc_std[b].sprite,bloc_std[b].pos_x);
         //hel_ObjUpdateInOAM(bloc_std[b].sprite);
      }
      
      for (b = 0; b < 5; b++)
      {
         bloc_morceaux[b].morceau1_pos_x++;
         bloc_morceaux[b].morceau2_pos_x++;
         bloc_morceaux[b].morceau3_pos_x++;
         bloc_morceaux[b].morceau4_pos_x++;
         hel_ObjSetX(bloc_morceaux[b].morceau1_sprite,bloc_morceaux[b].morceau1_pos_x);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau1_sprite);
         hel_ObjSetX(bloc_morceaux[b].morceau2_sprite,bloc_morceaux[b].morceau2_pos_x);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau2_sprite);
         hel_ObjSetX(bloc_morceaux[b].morceau3_sprite,bloc_morceaux[b].morceau3_pos_x);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau3_sprite);
         hel_ObjSetX(bloc_morceaux[b].morceau4_sprite,bloc_morceaux[b].morceau4_pos_x);
         //hel_ObjUpdateInOAM(bloc_morceaux[b].morceau4_sprite);
      }
   }
}


void DE_Plateformes_Haut()
{
   for (b = plateforme1n; b <= plateforme3n; b++)
   {
      if (sprite[b].etat != sprite_inactif && (!CollisionMarioPlateforme(sprite[p]) || mario.saut > 0))
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         //else if (sprite[b].ecran_delta_y > -2) sprite[b].ecran_delta_y--;
		 else if (sprite[b].ecran_delta_y > 0)
	     {
			sprite[b].pos_y--;
			sprite[b].ecran_delta_y--;
			hel_ObjSetY(sprite[b].sprite,sprite[b].pos_y);
			if (sprite[b].pos_y > 160) hel_ObjSetY(sprite[b].sprite, 160); //correction de bug
			//hel_ObjUpdateInOAM(sprite[b].sprite);
	     }
      }
   }
   
   for (b = tombanted; b <= tombantef; b++)
   {
      if (sprite[b].etat != sprite_inactif && (!CollisionMarioPlateforme(sprite[b]) || mario.saut > 0))
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         else DE_Haut(b);
      }
   }

   if (ascenseur.etat != sprite_inactif)
   {
       if (CollisionMarioPlateforme(ascenseur) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
       else DE_Haut(ascenseurn);
   }
}

void DE_Plateformes_Bas()
{
   for (b = plateforme1n; b <= plateforme3n; b++)
   {
      if (sprite[b].etat != sprite_inactif && (!CollisionMarioPlateforme(sprite[p]) || mario.saut > 0))
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         //else  if (sprite[b].ecran_delta_y < 2) sprite[b].ecran_delta_y++;
		 else 
		 {
			  sprite[b].pos_y++;
			  sprite[b].ecran_delta_y++;
			  hel_ObjSetY(sprite[b].sprite,sprite[b].pos_y);
			  if (sprite[b].pos_y > 160) hel_ObjSetY(sprite[b].sprite, 160); //correction de bug
			  //hel_ObjUpdateInOAM(sprite[b].sprite);
		 }
      }
   }
   
   for (b = tombanted; b <= tombantef; b++)
   {
      if (sprite[b].etat != sprite_inactif && (!CollisionMarioPlateforme(sprite[b]) || mario.saut > 0))
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         else
		 {
			  sprite[b].pos_y++;
			  sprite[b].ecran_delta_y++;
			  hel_ObjSetY(sprite[b].sprite,sprite[b].pos_y);
			  if (sprite[b].pos_y > 160) hel_ObjSetY(sprite[b].sprite, 160); //correction de bug
			  //hel_ObjUpdateInOAM(sprite[b].sprite);
		 }
      }
   }

   if (ascenseur.etat != sprite_inactif)
   {
      if (CollisionMarioPlateforme(ascenseur) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
      else DE_Bas(ascenseurn);
   }
}

void DE_Plateformes_Gauche()
{
   for (b = plateforme1n; b <= plateforme3n; b++)
   {
      if (sprite[b].etat != sprite_inactif)
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         else sprite[b].pos_x--;
      }
   }

   for (b = tombanted; b <= tombantef; b++)
   {
      if (sprite[b].etat != sprite_inactif)
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         else DE_Gauche(b);
      }
   }

   if (ascenseur.etat != sprite_inactif)
   {
      if (CollisionMarioPlateforme(ascenseur) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
      else DE_Gauche(ascenseurn);
   }
}

void DE_Plateformes_Droite()
{
   for (b = plateforme1n; b <= plateforme3n; b++)
   {
      if (sprite[b].etat != sprite_inactif)
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         else sprite[b].pos_x++;
      }
   }

   for (b = tombanted; b <= tombantef; b++)
   {
      if (sprite[b].etat != sprite_inactif)
      {
         if (CollisionMarioPlateforme(sprite[b]) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
         else DE_Droite(b);
      }
   }

   if (ascenseur.etat != sprite_inactif)
   {
      if (CollisionMarioPlateforme(ascenseur) && !mario.saut && mario.etat == mario_stop) {} //si mario est sur la plateforme on fait rien
      else DE_Droite(ascenseurn);
   }
}
