/*#include "gfx/maps/lv1-1/carte11.map.c"
#include "gfx/maps/lv1-1/tileset11.til.c"
#include "gfx/maps/lv1-1/palette11.pal.c"*/

#include "gfx/maps/lq/map_1.map.c"
#include "gfx/maps/lq/map_1.til.c"
#include "gfx/maps/lq/map_1.pal.c"
#include "gfx/maps/lq/map_1bg.map.c"
//#include "gfx/maps/lq/map_1bg.til.c"

/*#include "gfx/maps/lv1-1/desert.map.c"
#include "gfx/maps/lv1-1/blanc.map.c"
#include "gfx/maps/lv1-1/desert.til.c"*/







