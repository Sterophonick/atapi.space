#include "gfx/maps/lq/map_4.til.c"
#include "gfx/maps/lq/map_4.map.c"
#include "gfx/maps/lq/map_4.pal.c"
#include "gfx/maps/lq/map_4bg.map.c"
//#include "gfx/maps/maps/map_4bg.til.c"

/*#include "gfx/maps/lv1-1/desert.map.c"
#include "gfx/maps/lv1-1/blanc.map.c"
#include "gfx/maps/lv1-1/desert.til.c"*/







