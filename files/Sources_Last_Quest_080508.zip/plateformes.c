#include <mygba.h>
#include "header.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


/*void EN_IWRAM AffichePlateformes(int tabrx, int tabry)
{
   hel_MapGetPosition(2, &Ptx, &Pty);
   {Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
   {Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

   for (tabpy = Pt.Y - 2; tabpy < (Pt.Y + 22); tabpy++) //tout les tiles (+4) en hauteur
   {
      if (tabrx >= Pt.X + 15)
      {
         for (tabpx = Pt.X + 28; tabpx < (Pt.X + 70); tabpx++) //et en largeur je couvre large pour n'oublier aucune plateforme. Je fait ca pour que chaque groupe de plateforme d�marre en m�me temps sans conditionner le depart de chacune au bon vouloir de l'avanc� du joueur, ce qui casse la syncro et peut rendre injouable le tout. (il est long ce commmentaire, hein ?)
         {
            if (carte_map[tabpy][tabpx] == plateforme_tile) AffichePlateforme(tabpx,tabpy); //si c'est une plateforme mobile
         }
      }
      else if (tabrx < Pt.X + 15)
      {
         for (tabpx = Pt.X - 50; tabpx < (Pt.X + 2); tabpx++) //et en largeur je couvre large pour n'oublier aucune plateforme. Je fait ca pour que chaque groupe de plateforme d�marre en m�me temps sans conditionner le depart de chacune au bon vouloir de l'avanc� du joueur, ce qui casse la syncro et peut rendre injouable le tout. (il est long ce commmentaire, hein ?)
         {
            if (carte_map[tabpy][tabpx] == plateforme_tile) AffichePlateforme(tabpx,tabpy); //si c'est une plateforme mobile
         }
      }
   }
}*/

void AffichePlateforme(u32 tabrx, u32 tabry)
{
	for (b = 0; b < nbr_plateforme; b++)
	{
		if (ns_plateformes[b].pos_x == tabrx<<3 && !ns_plateformes[b].sprite)
		{
			for (p = 0; p < 3; p++)
			{
				if (sprite[plateforme1n+p].etat == sprite_inactif) // je n'utilise qu'un sprite non utilis�
				{
					sprite[plateforme1n+p].ecran_delta_y = 0;
					sprite[plateforme1n+p].ecran_delta_x = 0;
					sprite[plateforme1n+p].dep_y = 0;
					sprite[plateforme1n+p].dep_x = 0;
					sprite[plateforme1n+p].pos_x = ns_plateformes[b].pos_x;
					sprite[plateforme1n+p].pos_y = ns_plateformes[b].pos_y;
					hel_ObjSetXY(sprite[plateforme1n+p].sprite,(ns_plateformes[b].pos_x-Ptx),(ns_plateformes[b].pos_y-Pty));
					if ((ns_plateformes[b].pos_x-Ptx) < -54 || (ns_plateformes[b].pos_x-Ptx) > 240 || (ns_plateformes[b].pos_y-Pty) < -54 || (ns_plateformes[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[plateforme1n+p].sprite,240,160);

					hel_ObjSetVisible(sprite[plateforme1n+p].sprite,1);

					if (ns_plateformes[b].type == petite_plateforme)
					{					
						if (num_niveau == 6 || num_niveau == 8)
						{
							hel_ObjSetPalette(sprite[plateforme1n+p].sprite,15);
							hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_rouge_Bitmap[1024]);
						}
						else if (num_niveau == 5)
						{
							hel_ObjSetPalette(sprite[plateforme1n+p].sprite,15);
							hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_nuage_Bitmap[1024]);
						}
						else
						{
							hel_ObjSetPalette(sprite[plateforme1n+p].sprite,9);
							hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_Bitmap[1024]);
						}
						sprite[plateforme1n+p].dec_hb_x3 = 31;
						sprite[plateforme1n+p].dec_hb_x4 = 24;
						sprite[plateforme1n+p].dec_droite_x = 32;
					}
					else
					{				
						hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_Bitmap[0]);
						sprite[plateforme1n+p].dec_hb_x3 = 32;
						sprite[plateforme1n+p].dec_hb_x4 = 40;
						sprite[plateforme1n+p].dec_droite_x = 48;
					}

					sprite[plateforme1n+p].etat = sprite_vivant;	
					ns_plateformes[b].sprite = p+1;

					p = 3;
					b = nbr_plateforme+1;
				}
			}
		}

		else if (ns_plateformes[b].pos_y == tabry<<3 && !ns_plateformes[b].sprite)
		{
			for (p = 0; p < 3; p++)
			{
				if (sprite[plateforme1n+p].etat == sprite_inactif) // je n'utilise qu'un sprite non utilis�
				{
					sprite[plateforme1n+p].ecran_delta_y = 0;
					sprite[plateforme1n+p].ecran_delta_x = 0;
					sprite[plateforme1n+p].dep_y = 0;
					sprite[plateforme1n+p].dep_x = 0;
					sprite[plateforme1n+p].pos_x = ns_plateformes[b].pos_x;
					sprite[plateforme1n+p].pos_y = ns_plateformes[b].pos_y;
					hel_ObjSetXY(sprite[plateforme1n+p].sprite,(ns_plateformes[b].pos_x-Ptx),(ns_plateformes[b].pos_y-Pty));
					if ((ns_plateformes[b].pos_x-Ptx) < -54 || (ns_plateformes[b].pos_x-Ptx) > 240 || (ns_plateformes[b].pos_y-Pty) < -54 || (ns_plateformes[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[plateforme1n+p].sprite,240,160);

					hel_ObjSetVisible(sprite[plateforme1n+p].sprite,1);

					if (ns_plateformes[b].type == petite_plateforme)
					{					
						if (num_niveau == 6 || num_niveau == 8)
						{
							hel_ObjSetPalette(sprite[plateforme1n+p].sprite,15);
							hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_rouge_Bitmap[1024]);
						}
						else if (num_niveau == 5)
						{
							hel_ObjSetPalette(sprite[plateforme1n+p].sprite,15);
							hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_nuage_Bitmap[1024]);
						}
						else
						{
							hel_ObjSetPalette(sprite[plateforme1n+p].sprite,9);
							hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_Bitmap[1024]);
						}
						sprite[plateforme1n+p].dec_hb_x3 = 31;
						sprite[plateforme1n+p].dec_hb_x4 = 24;
						sprite[plateforme1n+p].dec_droite_x = 32;
					}
					else
					{				
						hel_ObjUpdateGfx(sprite[plateforme1n+p].sprite,(void*)&plateforme_Bitmap[0]);
						sprite[plateforme1n+p].dec_hb_x3 = 32;
						sprite[plateforme1n+p].dec_hb_x4 = 40;
						sprite[plateforme1n+p].dec_droite_x = 48;
					}

					sprite[plateforme1n+p].etat = sprite_vivant;	
					ns_plateformes[b].sprite = p+1;

					p = 3;
					b = nbr_plateforme+1;
				}
			}
		}
	}	
}

void GestionPlateformes()
{
	hel_MapGetPosition(2, &Ptx, &Pty);
    {Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
    {Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

	//plateformes mouvantes
	for (p = 0; p < nbr_plateforme; p++)
	{
		if (ns_plateformes[p].sprite > 0) 
		{
			if (!sprite[plateforme1n+ns_plateformes[p].sprite-1].pos_y) test = 1; //debug ???
			ns_plateformes[p].temp++;

		if (ns_plateformes[p].temp >= 2 && mario.etat != mario_gagne && mario.etat != mario_mort && mario.etat != mario_pg && mario.etat != mario_fleur)
		{
			ns_plateformes[p].temp = 0;					

			if (CollisionMarioPlateforme(sprite[plateforme1n+ns_plateformes[p].sprite-1]) && !BlocPresentDroite(mario) && !BlocPresentGauche(mario)) //si mario est sur la plateforme
			{
				if (ns_plateformes[p].dep_x == -1) //la plateforme va � gauche
				{
					if (mario.pos_x <= limite_x) // on defile la map vers la droite si mario atteind une certaine distance (environ le milieu de l'�cran : mario ne bouge plus mais tout le niveau � sa place : la th�orie de la relativit� restreinte d'Einstein appliqu�e au jeux vid�os ^^)
					{
						hel_MapScroll(2,FIXED_FROMINT(-1),0);
						hel_MapGetPosition(2, &Ptx, &Pty);
						{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
						{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

						scroll--;
						 if (scroll == -3)
						 {
							 scroll = 0;
							 hel_MapScroll(3,FIXED_FROMINT(-1),0);
						 }

						sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x++;
					}
					else if (mario.pos_x > limite_x)  // sinon on ne change que l'abscisse de mario
					{
						mario.pos_x--;
						ns_plateformes[p].pos_x--;
					}

					if (Ptx == 0)  // gestion de la gauche du niveau
					{
						mario.pos_x--;
						ns_plateformes[p].pos_x--;
					}
				}
				else if (ns_plateformes[p].dep_x == 1) //la plateforme va � droite
				{
					if (mario.pos_x >= limite_x) // on defile la map vers la gauche si mario atteind une certaine distance (environ le milieu de l'�cran : mario ne bouge plus mais tout le niveau � sa place : la th�orie de la relativit� restreinte d'Einstein appliqu�e au jeux vid�os ^^)
					{
						hel_MapScroll(2,FIXED_FROMINT(1),0);
						hel_MapGetPosition(2, &Ptx, &Pty);
						{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
						{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

						scroll++;
						 if (scroll == 3)
						 {
							 scroll = 0;
							 hel_MapScroll(3,FIXED_FROMINT(1),0);
						 }

						sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x--;
					}
					else if (mario.pos_x < limite_x) // sinon on ne change que l'abscisse de mario
					{
						mario.pos_x++;
						ns_plateformes[p].pos_x++;
					}
				}

				if (ns_plateformes[p].dep_y == -1) //la plateforme monte
				{
					if (mario.pos_y <= 50) // on defile la map vers le bas si mario a atteind une certaine hauteur pour ne pas qu'il disparaisse de l'�cran
					{
						hel_MapScroll(2,0,FIXED_FROMINT(-1));
						hel_MapGetPosition(2, &Ptx, &Pty);
						{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
						{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
												
						sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y++;
					}
					else if (mario.pos_y > 50)
					{
						mario.pos_y--; // sinon on ne change que son ordonn�e
						ns_plateformes[p].pos_y--;
					}
					if (Pt.Y == 0) 
					{
						mario.pos_y--; // gestion du bas du niveau
						ns_plateformes[p].pos_y--;
					}
				}
				else if (ns_plateformes[p].dep_y == 1) //la plateforme descend
				{
					if (mario.pos_y >= limite_y) // on defile la map vers le haut si mario a atteind une certaine hauteur
					{
						if (mario.pos_y >= 60) 
						{
							hel_MapScroll(2,0,FIXED_FROMINT(1));
							hel_MapGetPosition(2, &Ptx, &Pty);
							{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
							{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
							if (sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y > 0) sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y--;
						}
						else {mario.pos_y++; ns_plateformes[p].pos_y++;}
						
						//if (sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y > 0) sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y--;
					}
					else if (mario.pos_y < limite_y)
					{
						if (!VraiBlocPresentBas(mario)) mario.pos_y++; // sinon on ne change que son ordonn�e
						ns_plateformes[p].pos_y++;
					}
					
					if (Pt.Y == 20) 
					{
						if (!VraiBlocPresentBas(mario)) mario.pos_y++; // gestion du bas du niveau
						ns_plateformes[p].pos_y++;
					}

				}

				hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
			}

			//c'est ici qu'on bouge la plateforme dans le cas ou mario n'est pas dessus ou est bloqu� par un bloc
			//if ((mario.etat == mario_marche) || !CollisionMarioPlateforme(sprite[p]) || (CollisionMarioPlateforme(sprite[p]) && (BlocPresentGauche(mario) || BlocPresentDroite(mario)))) sprite[p].pos_x += sprite[p].dep_x; 
			//if (!CollisionMarioPlateforme(sprite[p]) || mario.pos_y < limite_y) sprite[p].pos_y += sprite[p].dep_y;			 
         
			else if (!CollisionMarioPlateforme(sprite[plateforme1n+ns_plateformes[p].sprite-1]) || (CollisionMarioPlateforme(sprite[plateforme1n+ns_plateformes[p].sprite-1]) && (BlocPresentDroite(mario) || BlocPresentGauche(mario))))
			{
				ns_plateformes[p].pos_x += ns_plateformes[p].dep_x;
				ns_plateformes[p].pos_y += ns_plateformes[p].dep_y;
			}
			
			sprite[plateforme1n+ns_plateformes[p].sprite-1].pos_x = ns_plateformes[p].pos_x;
			sprite[plateforme1n+ns_plateformes[p].sprite-1].pos_y = ns_plateformes[p].pos_y;
			sprite[plateforme1n+ns_plateformes[p].sprite-1].dep_x = ns_plateformes[p].dep_x;
			sprite[plateforme1n+ns_plateformes[p].sprite-1].dep_y = ns_plateformes[p].dep_y;

			RebondPlateforme(); //c'est ici que la plateforme change de sens

			
			if (Pt.X != 0 && (((ns_plateformes[p].pos_x-Ptx-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x) <= (mario.pos_x - 300)) || ((ns_plateformes[p].pos_x-Ptx-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x) >= (mario.pos_x + 400))))  //�loignement
			{
				FixePlateforme(plateforme1n+ns_plateformes[p].sprite-1);
			}
			
		}
		
		//if (hel_ObjExists(sprite[plateforme1n+p].sprite))
		{
			
			hel_ObjSetXY(sprite[plateforme1n+ns_plateformes[p].sprite-1].sprite,(ns_plateformes[p].pos_x-Ptx-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x),(ns_plateformes[p].pos_y-Pty-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y));
			if ((ns_plateformes[p].pos_x-Ptx-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x) < -54 || (ns_plateformes[p].pos_x-Ptx-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x) > 240 || (ns_plateformes[p].pos_y-Pty-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) < -54 || (ns_plateformes[p].pos_y-Pty-sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) > 160) hel_ObjSetXY(sprite[plateforme1n+ns_plateformes[p].sprite-1].sprite,240,160);		
		}}
	}	

	//ascenseur
	if (ascenseur.etat == sprite_vivant)
	{
		if (CollisionMarioPlateforme(ascenseur) && !mario.saut)
		{
			ascenseur.dep_y = -1;

			if (mario.pos_y <= limite_y) // on defile la map vers le bas si mario a atteind une certaine hauteur pour ne pas qu'il disparaisse de l'�cran
			{
				hel_MapScroll(2,0,FIXED_FROMINT(-1));

				hel_MapGetPosition(2, &Ptx, &Pty);
				{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
				{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
			}
			else if (mario.pos_y > limite_y) 
			{
				mario.pos_y += ascenseur.dep_y; // sinon on ne change que son ordonn�e
				ascenseur.pos_y += ascenseur.dep_y;
			}
			if (Pt.Y == 0)
			{
				mario.pos_y += ascenseur.dep_y; // gestion du bas du niveau
				ascenseur.pos_y += ascenseur.dep_y;
			}

			hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
		}
        else ascenseur.pos_y += ascenseur.dep_y;

		if (mario.etat == mario_marche || !CollisionMarioPlateforme(ascenseur) || (CollisionMarioPlateforme(ascenseur) && (BlocPresentGauche(mario) || BlocPresentDroite(mario)))) //dans le cas ou mario n'est pas sur la plateforme ou est bloqu� par un bloc
        {
            ascenseur.pos_y += ascenseur.dep_y;
        }		

		//if (hel_ObjExists(ascenseur.sprite))
		{
			hel_ObjSetXY(ascenseur.sprite,ascenseur.pos_x-Ptx,ascenseur.pos_y-Pty);
			if ((ascenseur.pos_x-Ptx) < -54 || (ascenseur.pos_x-Ptx) > 240 || (ascenseur.pos_y-Pty) < -54 || (ascenseur.pos_y-Pty) > 160) hel_ObjSetXY(ascenseur.sprite,240,160);
		}

		if (ascenseur.pos_y - Pty < -10) //si la plateforme disparait en haut de l'�cran
        {
            //if (hel_ObjExists(ascenseur.sprite)) hel_ObjDelete(ascenseur.sprite);
			hel_ObjSetVisible(ascenseur.sprite,0);
			ascenseur.pos_x = 240;
			ascenseur.pos_y = 160;
			ascenseur.etat = sprite_inactif; //on veut plus te voir
        }
				
	}
   
	//plateformes tombantes
	for (p = tombanted; p <= tombantef; p++)
	{
		if (sprite[p].etat == sprite_vivant)
		{
			if (sprite[p].temp_course > 0 && sprite[p].temp_course < 13) sprite[p].temp_course++;
			if (sprite[p].temp_course > 12)
			{
				carte_map[sprite[p].tile_origine_y][sprite[p].tile_origine_x] = 0; //on "efface" la plateforme de la map (en fait on remplace par une tile transparente)
				carte_map[sprite[p].tile_origine_y][sprite[p].tile_origine_x+1] = 0;
				carte_map[sprite[p].tile_origine_y+1][sprite[p].tile_origine_x] = 0;
				carte_map[sprite[p].tile_origine_y+1][sprite[p].tile_origine_x+1] = 0;
				
				sprite[p].dep_y = 1; //la plateforme ne doit descendre que si mario y pose le pied au moins une fois et apr�s une chtite tempo
			}
         
			if (CollisionMarioPlateforme(sprite[p]))
			{
				if (!sprite[p].temp_course) sprite[p].temp_course++;               
				
				if (mario.pos_y >= limite_y) // on defile la map vers le haut si mario a atteind une certaine hauteur
				{
					if (mario.pos_y >= 60) hel_MapScroll(2,0,FIXED_FROMINT(1));
					else {mario.pos_y += sprite[p].dep_y; sprite[p].pos_y += sprite[p].dep_y;}
				}
				else if (mario.pos_y < limite_y)
				{
					if (!VraiBlocPresentBas(mario)) mario.pos_y += sprite[p].dep_y; // sinon on ne change que son ordonn�e
					sprite[p].pos_y += sprite[p].dep_y;
				}		
				if (Pt.Y == 20)
				{
					if (!VraiBlocPresentBas(mario)) mario.pos_y += sprite[p].dep_y; // gestion du bas du niveau
					sprite[p].pos_y += sprite[p].dep_y;
				}
				
				hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
			}
			else sprite[p].pos_y += sprite[p].dep_y;
            
			if ((sprite[p].pos_y-Pty) > 180) //si la plateforme disparait au bas de l'�cran
			{
				sprite[p].ecran_delta_y = 0;
				sprite[p].pos_x = 240;
				sprite[p].pos_y = 160;
				sprite[p].etat = sprite_inactif; //on veut plus te voir
				//if (hel_ObjExists(sprite[p].sprite)) hel_ObjDelete(sprite[p].sprite);
				hel_ObjSetVisible(sprite[p].sprite,0);
			}

			//if (hel_ObjExists(sprite[p].sprite))
			{
				hel_ObjSetXY(sprite[p].sprite,(sprite[p].pos_x-Ptx),(sprite[p].pos_y-Pty));
				if ((sprite[p].pos_x-Ptx) < -54 || (sprite[p].pos_x-Ptx) > 240 || (sprite[p].pos_y-Pty) < -54 || (sprite[p].pos_y-Pty) > 160) hel_ObjSetXY(sprite[p].sprite,240,160);		
			}
		}
	}
}

void FixePlateforme(u8 f)
{
	ns_plateformes[p].sprite = 0;
	sprite[f].etat = sprite_inactif; //je cache le sprite
	sprite[f].ecran_delta_x = 0;
	sprite[f].ecran_delta_y = 0;
	sprite[f].pos_x = 240;
	sprite[f].pos_y = 160;
	hel_ObjSetVisible(sprite[f].sprite,0);
}

void RebondPlateforme() //EN_IWRAM
{
	if (collisions_map[(ns_plateformes[p].pos_y - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) >> 3][ns_plateformes[p].pos_x >> 3] == p_haut) {ns_plateformes[p].dep_y = -1; ns_plateformes[p].dep_x = 0;}
	else if (collisions_map[(ns_plateformes[p].pos_y + 7 - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) >> 3][ns_plateformes[p].pos_x >> 3] == p_bas) {ns_plateformes[p].dep_y = 1; ns_plateformes[p].dep_x = 0;}
	else if (collisions_map[ns_plateformes[p].pos_y >> 3][(ns_plateformes[p].pos_x + 7 - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x) >> 3] == p_droite) {ns_plateformes[p].dep_x = 1; ns_plateformes[p].dep_y = 0;}
	else if (collisions_map[ns_plateformes[p].pos_y >> 3][(ns_plateformes[p].pos_x + ns_plateformes[p].type - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_x) >> 3] == p_gauche) {ns_plateformes[p].dep_x = -1; ns_plateformes[p].dep_y = 0;}			
	
	if (!sprite[plateforme1n+ns_plateformes[p].sprite-1].dep_x && sprite[plateforme1n+ns_plateformes[p].sprite-1].dep_y != 0)
	while ((collisions_map[(ns_plateformes[p].pos_y - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) >> 3][ns_plateformes[p].pos_x >> 3] != 32)
		&& (collisions_map[(ns_plateformes[p].pos_y - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) >> 3][ns_plateformes[p].pos_x >> 3] != p_haut)
		&& (collisions_map[(ns_plateformes[p].pos_y - sprite[plateforme1n+ns_plateformes[p].sprite-1].ecran_delta_y) >> 3][ns_plateformes[p].pos_x >> 3] != p_bas)) ns_plateformes[p].pos_y++;

	/*else if (collisions_map[ns_plateformes[p].pos_y >> 3][(ns_plateformes[p].pos_x + ns_plateformes[p].type) >> 3] == p_hd) {ns_plateformes[p].dep_x = 1; ns_plateformes[p].dep_y = -1;}
	else if (collisions_map[ns_plateformes[p].pos_y >> 3][(ns_plateformes[p].pos_x + ns_plateformes[p].type) >> 3] == p_bg) {ns_plateformes[p].dep_x = -1; ns_plateformes[p].dep_y = 1;}
	else if (collisions_map[ns_plateformes[p].pos_y >> 3][(ns_plateformes[p].pos_x + ns_plateformes[p].type) >> 3] == p_hg) {ns_plateformes[p].dep_x = -1; ns_plateformes[p].dep_y = -1;}
	else if (collisions_map[(ns_plateformes[p].pos_y + 7) >> 3][(ns_plateformes[p].pos_x + ns_plateformes[p].type) >> 3] == p_bd) {ns_plateformes[p].dep_x = 1; ns_plateformes[p].dep_y = 1;}*/

	/*
	if (collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 7) >> 3)] == p_droite) {sprite[f].dep_x = 1; sprite[f].dep_y = 0;}
	if (collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_gauche) {sprite[f].dep_x = -1; sprite[f].dep_y = 0;}
	if (collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_haut) {sprite[f].dep_y = -1; sprite[f].ecran_delta_y *= -1; sprite[f].dep_x = 0;}
	if (collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_bas) {sprite[f].dep_y = 1; sprite[f].ecran_delta_y *= -1; sprite[f].dep_x = 0;}
	if (collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_hd) {sprite[f].dep_x = 1; sprite[f].dep_y = -1;}
	if (collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bg) {sprite[f].dep_x = -1; sprite[f].dep_y = 1;}
	if (collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_hg) {sprite[f].dep_x = -1; sprite[f].dep_y = -1;}
	if (collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bd) {sprite[f].dep_x = 1; sprite[f].dep_y = 1;}
	*/
}

/*void GardeFouPlateforme(u8 f)
{
   while (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_haut) sprite[f].pos_y--; //pour les plateformes se d�placant verticalement
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_bas) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 6) >> 3)] == p_hb) sprite[f].pos_x++;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_hb) sprite[f].pos_x--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 6 ) >> 3)] == p_haut) sprite[f].pos_x++;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_haut) sprite[f].pos_x--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 6) >> 3)] == p_bas) sprite[f].pos_x++;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_bas) sprite[f].pos_x--;

   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + 7) >> 3)] == p_droite) sprite[f].pos_x++; //pour les plateformes se d�placant horizontalement
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_gauche) sprite[f].pos_x--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_gd) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_gd) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_droite) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_droite) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_gauche) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x) >> 3)] == p_gauche) sprite[f].pos_y--;

   while (!collisions_map[((Pty + sprite[f].pos_y + sprite[f].dec_bas_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bghd) sprite[f].pos_y--; //le gros morceau : les plateformes se d�placant en diagonale
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bghd) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + sprite[f].dec_bas_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_hd) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_hd) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + sprite[f].dec_bas_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bg) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bg) sprite[f].pos_y++;

   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_hd) sprite[f].pos_x++;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_bg) sprite[f].pos_x--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] == p_hg) sprite[f].pos_x--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_droite_x) >> 3)] == p_bd) sprite[f].pos_x++;

   while ((!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 6) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 5) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 4) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 3) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 2) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 1) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 0) >> 3)] == p_hg)) sprite[f].pos_y--; //tout �a rien que pour les rares plateformes se d�placant en diagonale...

   while ((!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 0) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 1) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 2) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 3) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 4) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 5) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 6) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_hgbd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 0) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 1) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 2) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 3) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 4) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 5) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 6) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_bd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 0) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 0) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 1) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 1) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 2) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 2) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 3) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 3) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 4) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 4) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 5) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 5) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 6) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 6) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_hg)
   || (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 8) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 8) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 9) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 9) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 10) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 10) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 11) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 11) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 12) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 12) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 13) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 13) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 14) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 14) >> 3)] == p_bghd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 8) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 8) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 9) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 9) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 10) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 10) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 11) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 11) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 12) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 12) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 13) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 13) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 14) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 14) >> 3)] == p_bg)
   || (!collisions_map[((Pty + sprite[f].pos_y - 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 7) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 8) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 8) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 9) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 9) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 10) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 10) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 11) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 3) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 11) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 5) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 12) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 2) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 12) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 6) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 13) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 1) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 13) >> 3)] == p_hd)
   || (!collisions_map[((Pty + sprite[f].pos_y - 7) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 14) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 0) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 + 14) >> 3)] == p_hd)) sprite[f].pos_y++; //...ca aussi... pfff

   while (!collisions_map[((Pty + sprite[f].pos_y + sprite[f].dec_bas_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_hgbd) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_hgbd) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + sprite[f].dec_bas_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_bd) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_bd) sprite[f].pos_y++;
   while (!collisions_map[((Pty + sprite[f].pos_y + sprite[f].dec_bas_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_hg) sprite[f].pos_y--;
   while (!collisions_map[((Pty + sprite[f].pos_y) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] && collisions_map[((Pty + sprite[f].pos_y + 4) >> 3)][((Ptx + sprite[f].pos_x + sprite[f].dec_hb_x4 - 7) >> 3)] == p_hg) sprite[f].pos_y++;
}*/

void AfficheTombante(u32 tabrx, u32 tabry)
{
   for (p = tombanted; p <= tombantef; p++)
   {
      if (sprite[p].etat == sprite_inactif) // je n'utilise qu'un sprite non utilis�
      {
         hel_MapGetPosition(2, &Ptx, &Pty);
		 {Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
         {Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

		 //sprite[p].sprite = hel_ObjCreate((void*)tombante_Bitmap,0,1,OBJ_MODE_NORMAL,0,5,0,0,0,2,0,((tabrx << 3) - Ptx),((tabry << 3) - Pty));
         hel_ObjSetVisible(sprite[p].sprite,1);
		 sprite[p].pos_x = tabrx << 3; //je converti en pixels
         sprite[p].pos_y = tabry << 3;

		 sprite[p].tile_origine_x = tabrx; //je stocke l'emplacement originel de la plateforme, ca me servira pour l'effacer tout � l'heure
         sprite[p].tile_origine_y = tabry;

         carte_map[tabry][tabrx] = tile_vide+1; //on "efface" la plateforme de la map (en fait on remplace par une tile transparente)
         carte_map[tabry][tabrx+1] = tile_vide+1;
         carte_map[tabry+1][tabrx] = tile_vide+1;
         carte_map[tabry+1][tabrx+1] = tile_vide+1;
         hel_MapRedraw(2); //on redessine le niveau
         sprite[p].dep_y = 0;
         sprite[p].etat = sprite_vivant;
         sprite[p].temp_course = 0;
         
         p = tombantef + 1; //je sort de la boucle for
      }
   }
}
