#include "gfx/maps/lq/map_1_col.c"
#include "gfx/maps/lq/map_2_col.c"
#include "gfx/maps/lq/map_3_col.c"
#include "gfx/maps/lq/map_4_col.c"
#include "gfx/maps/lq/map_5_col.c"
#include "gfx/maps/lq/map_6_col.c"
#include "gfx/maps/lq/map_7_col.c"
#include "gfx/maps/lq/map_8_col.c"


