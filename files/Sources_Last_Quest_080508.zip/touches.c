#include <mygba.h>
#include "header.h"
#include "Adpcm.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void AppuiTouche()
{
	hel_PadCapture(); //lecture du pad

	if (!varitest && mario.etat != mario_gagne && mario.etat != mario_mort && mario.etat != mario_gp && mario.etat != mario_pg && mario.etat != mario_fleur){ //on bloque les touches quand mario meurt ou est en train de "changer"

      //etat au repos ---
	if (mario.etat != mario_derape && mario.etat != mario_mort && mario.etat != mario_gp
	&& mario.etat != mario_pg  && mario.etat != mario_fleur
	&& ((((!hel_PadQuery()->Held.Down && BlocPresentBas(mario) && !hel_PadQuery()->Held.Left && !hel_PadQuery()->Held.Right)
	|| (BlocPresentBas(mario) && ((hel_PadQuery()->Held.Left && BlocPresentGauche(mario))
	|| (hel_PadQuery()->Held.Right && BlocPresentDroite(mario)))))))) mario.etat = mario_stop;

      // inertie de mario ---
	if (hel_PadQuery()->Held.Right) // appui sur droite
	{
		if (mario.etat != mario_derape) // seulement si il n'est pas en train de d�raper
		{
			if (mario.pos_tab_saut > 0 && !inert_saut) {}
			else
			{
				if (hel_PadQuery()->Held.B && inertie_droite <= inertie_double) inertie_droite++; // l'inertie est plus grande si mario cours...
				else if (inertie_droite <= inertie_standard) inertie_droite++;
				if (!hel_PadQuery()->Held.B && inertie_droite > inertie_standard) inertie_droite = inertie_standard; //...retour a une inertie normale sinon
			}
		}
		if (inertie_gauche > 0) // si il etait d�ja en train d'aller � gauche
		{
			mario.etat = mario_derape;
			inertie_gauche--;
			if (!BlocPresentBas(mario) && mario.pos_tab_saut <= 18 && !mario.saut) inertie_bloc = 1; // on empeche que mario fasse demi-tour trop vite quand il saute (controle pr�cis du point de chute)
		}
		else mario.etat = mario_stop;
	}
	if (hel_PadQuery()->Held.Left) // appui sur gauche
	{
		if (mario.etat != mario_derape) // seulement si il n'est pas en train de d�raper
		{
			if (mario.pos_tab_saut > 0 && !inert_saut) {}
			else
			{
				if (hel_PadQuery()->Held.B && inertie_gauche <= inertie_double) inertie_gauche++; // l'inertie est plus grande si mario cours...
				else if (inertie_gauche <= inertie_standard) inertie_gauche++;
				if (!hel_PadQuery()->Held.B && inertie_gauche > inertie_standard) inertie_gauche = inertie_standard; //...retour a une inertie normale sinon
			}
		}
		if (inertie_droite > 0) // si il etait d�ja en train d'aller � droite
		{
			mario.etat = mario_derape;
			inertie_droite--;
			if (!BlocPresentBas(mario) && mario.pos_tab_saut <= 18 && !mario.saut) inertie_bloc = 1; // on empeche que mario fasse demi-tour trop vite quand il saute (controle pr�cis du point de chute)
		}
		else mario.etat = mario_stop;
	}
	if (mario.etat == mario_derape && !hel_PadQuery()->Held.Left && !hel_PadQuery()->Held.Right) {mario.etat = mario_stop; inertie_droite = 0; inertie_gauche = 0;} // retour � l'etat statique de mario en cas d'appui bref sur la touche (si trop bref : mario reste en position d�rapage)


      // D�placement vers la droite --->
	if ((hel_PadQuery()->Held.Right || inertie_droite > 0) && mario.etat != mario_derape && !inertie_gauche && !inertie_bloc) // mario bouge aussi si il y a de l'inertie mais s'arrete quand il derape ou si il y a de l'inertie contraire
	{
		hel_ObjSetHFlip(mario.sprite,0); // flip du sprite de mario
		sens_mario = 0; //pour la direction du tir
		if (!BlocPresentDroite(mario)) // si pas d'obstacle � droite
		{
			if (BlocPresentBas(mario)) //si mario est sur le sol
			{
				if (inertie_droite > 0 && !hel_PadQuery()->Held.Right) {inertie = 1; inertie_droite--;} // si il reste de l'inertie et que la touche n'est pas appuy�e on fait descendre cette derniere
				else inertie = 0;
				mario.etat = mario_marche;  // animation marche/course
			}

			if (BlocPresentBas(mario) && hel_PadQuery()->Held.Down && power != petit_mario) {} //quand mario grand se baisse, il n'avance plus
			else
			{
				for (v = 0; v < vitesse; v++) // la vitesse est d�compos�e pour eviter les bugs de collision
				{
					if (!BlocPresentDroite(mario))
					{						
						if (Ptx < retry[2][1]) //si mario est pas dans la zone bonus (sinon �a active le checkpoint 4 trop t�t)
						{
							if (Ptx >= retry[5][0] && checkpoint < 4) checkpoint = 4;
							else if (Ptx >= retry[4][0] && checkpoint < 3) checkpoint = 3;
							else if (Ptx >= retry[1][0] && checkpoint < 2) checkpoint = 2;
							else if (Ptx >= retry[0][0] && checkpoint == 0) checkpoint = 1;
						}
						
						if (Ptx > retry[2][1]) //si mario est dans une zone secrete ou alors � la fin du niveau
						{
							mario.pos_x++;
							if (BlocPresentBas(mario)) mario.delta_course++; //pour l'�lan
							if (mario.delta_course > 127) mario.delta_course = 127;
						}						

						else if (mario.pos_x >= limite_x) // on defile la map vers la gauche si mario atteind une certaine distance (environ le milieu de l'�cran : mario ne bouge plus mais tout le niveau � sa place : la th�orie de la relativit� restreinte d'Einstein appliqu�e au jeux vid�os ^^)
						{
							hel_MapScroll(2,FIXED_FROMINT(1),0);
							hel_MapGetPosition(2, &Ptx, &Pty);
							{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
							{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

							//scrolling du BG
							scroll++;
							if (scroll == 3)
							{
								scroll = 0;
								hel_MapScroll(3,FIXED_FROMINT(1),0);
							}

							if (BlocPresentBas(mario)) mario.delta_course++; //pour l'�lan
							if (mario.delta_course > 127) mario.delta_course = 127;
						}

						else if (mario.pos_x < limite_x) // sinon on ne change que l'abscisse de mario
						{
							mario.pos_x++;
							if (BlocPresentBas(mario)) mario.delta_course++;
							if (mario.delta_course > 127) mario.delta_course = 127;
						}                  
					}
				}
			}
		}
		else if (SecretZonePresent()) ExitSecretZone();
	}

      // D�placement vers la gauche <---
	if ((hel_PadQuery()->Held.Left || inertie_gauche > 0) && mario.etat != mario_derape && !inertie_droite && !inertie_bloc) // mario bouge aussi si il y a de l'inertie mais s'arrete quand il derape ou si il y a de l'inertie contraire
	{
		hel_ObjSetHFlip(mario.sprite,1); // flip du sprite de mario
		sens_mario = 1; //pour la direction du tir
		if (!BlocPresentGauche(mario)) // si pas d'obstacle � gauche
		{
			if (BlocPresentBas(mario)) //si mario est sur le sol
			{
				if (inertie_gauche > 0 && !hel_PadQuery()->Held.Left) {inertie = 1; inertie_gauche--;} // si il reste de l'inertie et que la touche n'est pas appuy�e on fait descendre cette derniere
				else inertie = 0;
				mario.etat = mario_marche;  // animation marche/course
			}

			if (BlocPresentBas(mario) && hel_PadQuery()->Held.Down && power != petit_mario) {} //quand mario grand se baisse, il n'avance plus
			else
			{
				for (v = 0; v < vitesse; v++) // la vitesse est d�compos�e pour eviter les bugs de collision
				{
					if (!BlocPresentGauche(mario))
					{
						if (Ptx == 0 || Ptx > 7631)  // gestion de la gauche du niveau
						{
							mario.pos_x--;
							if (BlocPresentBas(mario)) mario.delta_course++; //pour l'�lan
							if (mario.delta_course > 127) mario.delta_course = 127;                     
						}
                  
						else if (mario.pos_x <= limite_x) // on defile la map vers la droite si mario atteind une certaine distance (environ le milieu de l'�cran : mario ne bouge plus mais tout le niveau � sa place : la th�orie de la relativit� restreinte d'Einstein appliqu�e au jeux vid�os ^^)
						{
							hel_MapScroll(2,FIXED_FROMINT(-1),0);
							hel_MapGetPosition(2, &Ptx, &Pty);
							{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
							{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

							scroll--;
							if (scroll == -3)
							{
								scroll = 0;
								hel_MapScroll(3,FIXED_FROMINT(-1),0);
							}

							if (BlocPresentBas(mario)) mario.delta_course++; //pour l'�lan
							if (mario.delta_course > 127) mario.delta_course = 127;
						}

						else if (mario.pos_x > limite_x)  // sinon on ne change que l'abscisse de mario
						{
							mario.pos_x--;
							if (BlocPresentBas(mario)) mario.delta_course++;
							if (mario.delta_course > 127) mario.delta_course = 127;
						}
					}
				}
			}
		}
	}

      // initialisation du saut ---
	if (hel_PadQuery()->Pressed.A && BlocPresentBas(mario)) //appui sur A
	{
		AdpcmStart(&ADPCM_saut,1,1); //son du saut
		mario.saut = 1;
		mario.pos_tab_saut = 0;
		if (hel_PadQuery()->Held.Left || hel_PadQuery()->Held.Right) inert_saut = 1;
		else {inertie_droite = 0; inertie_gauche = 0;}
	}
	if (hel_PadQuery()->Held.A)
	{
		A_presse = 1; //si A est maintenu
		if (mario.pos_tab_saut < 6 && ((inertie_droite > 0 && hel_PadQuery()->Held.Left) || (inertie_gauche > 0 && hel_PadQuery()->Held.Right))) inertie_bloc = 1;
	}
	else A_presse = 0;

	if (A_oldpresse && !A_presse) A_relache = 1; //je teste le relachement du bouton A
	else A_relache = 0;
	A_oldpresse = A_presse;

      //appui sur bas fait se baisser le grand mario
	if (hel_PadQuery()->Held.Down && BlocPresentBas(mario)) // appui sur bas et mario au sol ?
	{
		if (power != petit_mario) // si mario est grand...
		{
			mario.etat = mario_baisse;
			saut_maximum = saut_max; //quand mario se baisse, il saute plus haut
			mario.dec_haut_y = dec_mario_baisse_haut_y; //les nouvelles limites de collision
			mario.dec_dg_y1 = dec_mario_baisse_dg_y1;
		}
		else if (!hel_PadQuery()->Held.Right && !hel_PadQuery()->Held.Left) mario.etat = mario_stop; // ...sinon on fait rien
	}
	else if (power != petit_mario) // on remet les bonnes limites de collision si mario n'est pas petit quand bas n'est pas press�
	{
		mario.dec_haut_y = dec_grand_mario_haut_y;
		mario.dec_dg_y1 = dec_grand_mario_dg_y1;
	}
	if (hel_PadQuery()->Pressed.Down)
	{
		if (SecretZonePresent())
		{
			if (TuyauFin() && num_niveau != 8) ChangeNiveau();
			else if (!bonus_tuyau) EnterSecretZone();
		}
	}   

      //Appui bref sur B
	if (hel_PadQuery()->Pressed.B && puissance == 2 && balle.etat == sprite_inactif) // tir de la balle en mario flower et si pas de balle lanc�e
	{
		if (!sens_mario)
		{
			balle.pos_x = mario.pos_x + 20 + Ptx;
			balle.dep_x = 1;
		}
		else
		{
			balle.pos_x = mario.pos_x + 4 + Ptx;
			balle.dep_x = -1;
		}
		balle.pos_y = mario.pos_y + 16 + Pty;
		balle.dep_y = 1;
		hel_ObjSetVisible(balle.sprite,1);
		balle.etat = sprite_vivant;
		balle.ecran_delta_y = 0;
		AdpcmStart(&ADPCM_tir,1,1); //son du tir
	}

       //appui sur B donc la vitesse augmente et le saut est plus haut
	if (hel_PadQuery()->Held.B)
	{
		mario_temp_course = tempo_course; // on accel�re l'anim de marche de mario
		if (mario.temp_course > tempo_course) mario.temp_course = tempo_course - 1; // ptit d�bug �vident
		if (vitesse == lent && (!BlocPresentBas(mario) || inertie)) {} // si mario est en plein saut au moment de l'appui, rien ne change
		else
		{
			vitesse = rapide;
			if (mario.delta_course > 5) saut_maximum = saut_max; // saut max seulement si il y a un petit �lan
		}
		if (mario.etat == mario_stop && BlocPresentBas(mario))
		{
			saut_maximum = saut_normal; //si mario n'avance pas, pas de saut max (�lan)
			mario.dec_hb_x4 = dec_mario_hb_x4; //on remet les bonnes limites �galement
		}
		if (mario.delta_course > 8 && BlocPresentBas(mario) && !BlocPresentDroite(mario) && !BlocPresentGauche(mario)) mario.dec_hb_x4 = dec_mario_hb_x4c; //pour eviter que mario ne tombe entre 2 blocs
		else mario.dec_hb_x4 = dec_mario_hb_x4; //on remet les bonnes limites
	}
	else
	{
		mario_temp_course = tempo_marche; // on ralenti l'anim de marche de mario
		mario.dec_hb_x4 = dec_mario_hb_x4; //on remet les bonnes limites
		if (vitesse == rapide && (!BlocPresentBas(mario) || inertie)) {} // si mario est en plein saut au moment du relachement, rien ne change
		else
		{
			vitesse = lent;
			if (!mario.saut && !BlocPresentDroite(mario) && !BlocPresentGauche(mario)) saut_maximum = saut_normal; //retour au saut normal si mario n'est pas en train de sauter et immobile
		}
	}}

	if (hel_PadQuery()->Pressed.L)
	{
	   
		/*if (puissance == 0)
		{
			mario.etat = mario_pg;
			mario.temp_mort = 0;
			mario.anim_mort = 22;
		}
		if (puissance == 1) //si il est en super mario
		{
			mario.etat = mario_fleur; //hop, en mario fleur et plus vite que ca
			mario.temp_mort = 0;
			mario.anim_mort = 0;
		}*/
	}
	if (hel_PadQuery()->Held.R)
	{
		//if (num_niveau < 8) ChangeNiveau();
		//else hel_MapSetPosition(2,FIXED_FROMINT(920*8),FIXED_FROMINT(60));	  
	}
	if (hel_PadQuery()->Pressed.Select)
	{
		/*if (puissance != 0)
		{
			mario.etat = mario_gp;
			mario.temp_mort = 0;
			mario.anim_mort = 0;
		}  */ 

		

	}
	if (hel_PadQuery()->Pressed.Start)
	{
		AdpcmPause(0);

		AdpcmStart(&ADPCM_pause,1,1);

		title_temp = 1;
		while (title_temp > 0) 
		{	
			hel_BgTextPrintF(0,1,18,0,"PAUSE");
			hel_PadCapture();
			title_temp++;
			if (title_temp > 100) title_temp = 1;
			if (hel_PadQuery()->Pressed.Start) title_temp = 0;
		}
		
		AdpcmPause(0);

		hel_BgTextPrintF(0,1,18,0,"     ");		
	}


	if (varitest){ //just for test


   

	TestSprite(flyn);

	if (F_CTRLINPUT_L_PRESSED) {hel_MapScroll(2,FIXED_FROMINT(-1),0); if (F_CTRLINPUT_B_PRESSED) while (F_CTRLINPUT_L_PRESSED){}}
	if (F_CTRLINPUT_R_PRESSED) {hel_MapScroll(2,FIXED_FROMINT(1),0); if (F_CTRLINPUT_B_PRESSED) while (F_CTRLINPUT_R_PRESSED){}}
	}
}

void TestSprite(u8 f)
{
	sprite[f].etat = sprite_vivant; 
	hel_ObjSetVisible(sprite[f].sprite,1);

	if (F_CTRLINPUT_UP_PRESSED && !BlocPresentHaut(sprite[f])) {sprite[f].pos_y--; if (F_CTRLINPUT_B_PRESSED) while (F_CTRLINPUT_UP_PRESSED){}}
	if (F_CTRLINPUT_DOWN_PRESSED && !BlocPresentBas(sprite[f])) {sprite[f].pos_y++; if (F_CTRLINPUT_B_PRESSED) while (F_CTRLINPUT_DOWN_PRESSED){}}
	if (F_CTRLINPUT_RIGHT_PRESSED && !BlocPresentDroite(sprite[f])) {sprite[f].pos_x++; if (F_CTRLINPUT_B_PRESSED) while (F_CTRLINPUT_RIGHT_PRESSED){}}
	if (F_CTRLINPUT_LEFT_PRESSED && !BlocPresentGauche(sprite[f])) {sprite[f].pos_x--; if (F_CTRLINPUT_B_PRESSED) while (F_CTRLINPUT_LEFT_PRESSED){}}

	hel_ObjSetXY(sprite[f].sprite,sprite[f].pos_x,sprite[f].pos_y);   
}

