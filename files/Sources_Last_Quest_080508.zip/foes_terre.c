#include <mygba.h>
#include "header.h"


unsigned short tab_foes_saut[18] = {4,3,3,3,3,2,2,2,2,2,2,2,2,1,1,1,0,0}; // le tableau de saut des ennemis


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void AfficheGoomba(u32 tabrx, u32 tabry)
{
	for (b = goombad; b <= goombaf; b++)
	{
		if (sprite[b].etat == sprite_inactif) // je n'utilise qu'un sprite non utilis�
		{			
			sprite[b].pos_x = tabrx << 3; //je converti en pixels
			sprite[b].pos_y = tabry << 3;
			hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));
			if ((sprite[b].pos_x-Ptx) < -54 || (sprite[b].pos_x-Ptx) > 240 || (sprite[b].pos_y-Pty) < -54 || (sprite[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[b].sprite,240,160);
			hel_ObjSetVisible(sprite[b].sprite,1);
			hel_ObjUpdateGfx(sprite[b].sprite,(void*)&goomba_Bitmap[0]);
			hel_ObjSetVFlip(sprite[b].sprite,0);
			hel_ObjSetHFlip(sprite[b].sprite,0);
			sprite[b].dep_x = -1; //si c'est un goomba allant � gauche
			carte_map[tabry][tabrx] = 0; //et j'efface les tiles
			hel_MapRedraw(2); //on redessine le niveau
			sprite[b].vitesse = 0;
			sprite[b].anim_mort = 0;
			sprite[b].temp_mort = 0;
			sprite[b].limite = 1;
			sprite[b].temp_course = 0;
			sprite[b].etat = sprite_vivant;
			b = goombaf + 1; //je sort de la boucle for
		}
	}
}

void GestionGoomba()
{
	for (b = goombad; b <= goombaf; b++)
	{
		if (sprite[b].etat == sprite_vivant)
		{
			AnimeGoomba();
			if (!mario_clignote && mario.etat != mario_gp)
			{
				//sprite[b].pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
				//sprite[b].pos_y += Pty;
				if (CollisionSprite(balle,sprite[b])) CollisionFoesBalle(b);
				//sprite[b].pos_x -= Ptx;
				//sprite[b].pos_y -= Pty;
				if (CollisionSprite(mario,sprite[b])) CollisionFoesMario(b);
			}

			sprite[b].pos_x -= Ptx;
			sprite[b].pos_y -= Pty;
			for (g = 0; g < 3; g++) if (!BlocPresentBas(sprite[b]) && sprite[b].etat != sprite_mort2) sprite[b].pos_y++; //gravit�
			sprite[b].pos_x += Ptx;
			sprite[b].pos_y += Pty;
		}
		else if (sprite[b].etat == sprite_mort) EcraseGoomba(b);
		else if (sprite[b].etat == sprite_mort2) AnimMortFoes2(b);		
	}
}

void AnimeGoomba()
{
	sprite[b].pos_x -= Ptx;
	sprite[b].pos_y -= Pty;

	ExtractionFoes(b);

	AnimMarcheGoomba();

	sprite[b].vitesse++;
	if (sprite[b].vitesse >= 2) //je d�place mon ennemi
	{
		if (BlocPresentDroite(sprite[b]))
		{
			hel_ObjSetHFlip(sprite[b].sprite,0);
			sprite[b].dep_x = -1;
		}
		if (BlocPresentGauche(sprite[b]))
		{
			hel_ObjSetHFlip(sprite[b].sprite,1);
			sprite[b].dep_x = 1;
		}
		if (BlocPresentBas(sprite[b])) sprite[b].pos_x += sprite[b].dep_x;
		sprite[b].vitesse = 0;
	}

	if (sprite[b].pos_y > 180 && !BlocPresentBas(sprite[b])) //si le goomba tombe
	{
		sprite[b].etat = sprite_inactif; //paix � son ame
		sprite[b].dep_x = 0;
		sprite[b].pos_x = 0;
		sprite[b].pos_y = 320;
		hel_ObjSetVisible(sprite[b].sprite,0);
	}

	sprite[b].pos_x += Ptx;
	sprite[b].pos_y += Pty;

	//�loignement
	if (Pt.X != 0 && (((sprite[b].pos_x - Ptx) <= (mario.pos_x - 300)) || ((sprite[b].pos_x - Ptx) >= (mario.pos_x + 300)))) //si le goomba est trop loin de mario
	{
		
		sprite[b].pos_x -= Ptx;
		sprite[b].pos_y -= Pty;
		FixeGoomba(b);
		sprite[b].pos_x += Ptx;
		sprite[b].pos_y += Pty;
		
	}

	//if (hel_ObjExists(sprite[b].sprite))
	{
		hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));
		if ((sprite[b].pos_x-Ptx) < -54 || (sprite[b].pos_x-Ptx) > 240 || (sprite[b].pos_y-Pty) < -54 || (sprite[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[b].sprite,240,160);		
	}
}

void FixeGoomba(u8 f) //inscrit le sprite du goomba dans la map
{
	sprite[f].dep_x = 0;
	sprite[f].etat = sprite_inactif;
	sprite[f].pos_x = 0;
	sprite[f].pos_y = 320;
	hel_ObjSetVisible(sprite[f].sprite,0);
}
      

void EcraseGoomba(u8 f)
{
	sprite[f].temp_mort++;
	if (sprite[f].temp_mort == 1)
	{
		score += sprite[f].score * multiple_score; //on ajoute le score
		AffichePoints((sprite[f].pos_x-Ptx),(sprite[f].pos_y-Pty),(sprite[f].score * multiple_score));
		multiple_score *= 2; //je multiplie par 2 le score du prochain ennemi si mario ne touche pas le sol entre temps
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //le bruit de la mort de l'ennemi �cras�
	}
	if (sprite[f].temp_mort == 30)
	{
		sprite[f].etat = sprite_inactif;
		sprite[f].temp_mort = 0;
		sprite[f].dep_x = 0;
		sprite[f].pos_x = 0;
		sprite[f].pos_y = 320;
		hel_ObjSetVisible(sprite[f].sprite,0);
	}
	{
		if (num_niveau == 2 || num_niveau == 5 || num_niveau == 7) {hel_ObjSetPalette(sprite[f].sprite,15); hel_ObjUpdateGfx(sprite[f].sprite,(void*)&shiggy_Bitmap[256]);}
		else {hel_ObjSetPalette(sprite[f].sprite,5); hel_ObjUpdateGfx(sprite[f].sprite,(void*)&goomba_Bitmap[256]);}
		hel_ObjSetXY(sprite[f].sprite,(sprite[f].pos_x-Ptx),(sprite[f].pos_y-Pty));
		if ((sprite[f].pos_x-Ptx) < -54 || (sprite[f].pos_x-Ptx) > 240 || (sprite[f].pos_y-Pty) < -54 || (sprite[f].pos_y-Pty) > 160) hel_ObjSetXY(sprite[f].sprite,240,160);		
	}
}


void AfficheFly(u32 tabrx, u32 tabry) 
{
	fly.pos_x = (tabrx << 3); //je converti en pixels
	fly.pos_y = (tabry << 3);
	hel_ObjSetXY(fly.sprite,(fly.pos_x-Ptx),(fly.pos_y-Pty));
	if ((fly.pos_x-Ptx) < -54 || (fly.pos_x-Ptx) > 240 || (fly.pos_y-Pty) < -54 || (fly.pos_y-Pty) > 160) hel_ObjSetXY(fly.sprite,240,160);
	hel_ObjSetVisible(fly.sprite,1);
	hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[0]);
	hel_ObjSetVFlip(fly.sprite,0);
	hel_ObjSetHFlip(fly.sprite,0);
	fly.pos_x -= Ptx;
	fly.pos_y -= Pty;
	while (BlocPresentBas(fly)) fly.pos_y--; //j'empeche � mon ennemi d'etre cr�e dans le sol
	while (!BlocPresentBas(fly)) fly.pos_y++; //gravit�
	fly.pos_x += Ptx;
	fly.pos_y += Pty;
	carte_map[tabry][tabrx] = 0;
	hel_MapRedraw(2); //on redessine le niveau
	fly.dep_x = 0; //r�initialisation des variables
	fly.saut = 0;
	fly.pos_tab_saut = 0;
	fly.vitesse = 0;
	fly.anim_mort = 0;
	fly.temp_course = 0;
	fly.temp_course = 0;
	fly.temp_mort = 0;
	fly.limite = 2;
	fly.etat = sprite_vivant;
}

void GestionFly()
{
	if (fly.etat == sprite_vivant)
	{
		//if (hel_ObjExists(fly.sprite)) 
		AnimeFly();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//fly.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//fly.pos_y += Pty;
			if (CollisionSprite(balle,fly)) CollisionFoesBalle(flyn);
			//fly.pos_x -= Ptx;
			//fly.pos_y -= Pty;
			if (CollisionSprite(mario,fly)) CollisionFoesMario(flyn);
		}
	}
	else if (fly.etat == sprite_mort) 
	{
		EcraseFly();
		fly.pos_x -= Ptx;
		fly.pos_y -= Pty;
		if (!BlocPresentBas(fly)) fly.pos_y += 2;  //petite gravit� uniquement lors de la mort
		hel_ObjSetY(fly.sprite,fly.pos_y);
		fly.pos_x += Ptx;
		fly.pos_y += Pty;
	}
	else if (fly.etat == sprite_mort2) AnimMortFoes2(flyn);
}

void AnimeFly()
{
	fly.pos_x -= Ptx;
	fly.pos_y -= Pty;
   
	ExtractionFoes(flyn);

	fly.vitesse++;
	if (fly.vitesse >= 60) //petite tempo au sol avant de ressauter
	{
		fly.vitesse = 0;
		fly.saut = 1;
		if (mario.pos_x < fly.pos_x) fly.dep_x = -1; //le sens est d�cid� selon la position de mario
		else fly.dep_x = 1;
		fly.temp_course = 0;
	}

	if (fly.saut) //saut
	{
		fly.gravite = tab_foes_saut[fly.pos_tab_saut];
		for (g = 0; g < fly.gravite; g++) // on l'applique en la d�composant pour eviter les bugs de collision
		{
			if (!BlocPresentHaut(fly)) fly.pos_y--; // si pas d'obstacle en haut
			else fly.saut = 0; // collision avec un plafond
		}
		fly.pos_tab_saut++;
		if (fly.pos_tab_saut == 18) //sommet du saut
		{
			fly.saut = 0; // mario ne saute plus, donc...
			fly.pos_tab_saut--; // on commence d�j� � descendre
		}
	}
	else //gravit�
	{
		fly.gravite = tab_foes_saut[fly.pos_tab_saut];
		for (g = 0; g < fly.gravite; g++) // on l'applique en la d�composant pour eviter les bugs de collision
		{
			if (!BlocPresentBas(fly)) fly.pos_y++; // si pas d'obstacle en haut
		}
		fly.pos_tab_saut--;
		if (!fly.pos_tab_saut) fly.dep_x = 0;
		if (fly.pos_tab_saut == -1) fly.pos_tab_saut = 0;  // la position finale (enfin 1ere) du tableau
	}

	fly.pos_x += fly.dep_x;

	AnimAilesFly();

	if (fly.pos_y > 180 && !BlocPresentBas(fly)) //si le fly tombe
	{
		fly.etat = sprite_inactif; //paix � son ame
		fly.dep_x = 0;
		fly.pos_x = 0;
		fly.pos_y = 320;
		//if (hel_ObjExists(fly.sprite)) hel_ObjDelete(fly.sprite);
		hel_ObjSetVisible(fly.sprite,0);
	}	

	//�loignement
	if (Pt.X != 0 && !fly.dep_x && ((fly.pos_x <= (mario.pos_x - 400)) || (fly.pos_x >= (mario.pos_x + 300)))) //si le fly est trop loin de mario
	{
		FixeFly();
	}

	fly.pos_x += Ptx;
	fly.pos_y += Pty;

	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjSetXY(fly.sprite,(fly.pos_x-Ptx),(fly.pos_y-Pty));
		if ((fly.pos_x-Ptx) < -54 || (fly.pos_x-Ptx) > 240 || (fly.pos_y-Pty) < -54 || (fly.pos_y-Pty) > 160) hel_ObjSetXY(fly.sprite,240,160);		
	}

}

void FixeFly()
{
	fly.dep_x = 0;
	fly.etat = sprite_inactif;
	fly.pos_x = 0;
	fly.pos_y = 320;
	//if (hel_ObjExists(fly.sprite)) hel_ObjDelete(fly.sprite);
	hel_ObjSetVisible(fly.sprite,0);
}
      
void EcraseFly()
{
	fly.temp_mort++;
	if (fly.temp_mort == 1)
	{
		score += fly.score * multiple_score;
		AffichePoints((fly.pos_x-Ptx),(fly.pos_y-Pty),(fly.score * multiple_score));
		multiple_score *= 2;
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�
	}
	if (fly.temp_mort == 50)
	{
		AdpcmStart(&ADPCM_mort2,1,1); //mort2
		fly.etat = sprite_mort2;
		fly.temp_mort = 0;
	}
	{
		hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[3072]);
		hel_ObjSetXY(fly.sprite,(fly.pos_x-Ptx),(fly.pos_y-Pty));
		if ((fly.pos_x-Ptx) < -54 || (fly.pos_x-Ptx) > 240 || (fly.pos_y-Pty) < -54 || (fly.pos_y-Pty) > 160) hel_ObjSetXY(fly.sprite,240,160);		
	}
}

void AfficheKoopa(u32 tabrx, u32 tabry)
{
	//if (koopa.etat == sprite_inactif) // je n'utilise qu'un sprite non utilis�
	{
		koopa.pos_x = tabrx << 3; //je converti en pixels
		koopa.pos_y = tabry << 3;
		hel_ObjSetXY(koopa.sprite,(koopa.pos_x-Ptx),(koopa.pos_y-Pty));
		if ((koopa.pos_x-Ptx) < -54 || (koopa.pos_x-Ptx) > 240 || (koopa.pos_y-Pty) < -54 || (koopa.pos_y-Pty) > 160) hel_ObjSetXY(koopa.sprite,240,160);
		hel_ObjSetVisible(koopa.sprite,1);
		hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[0]);
		hel_ObjSetVFlip(koopa.sprite,0);
		hel_ObjSetHFlip(koopa.sprite,0);
		koopa.pos_x -= Ptx;
		koopa.pos_y -= Pty;
		while (BlocPresentBas(koopa)) koopa.pos_y--; //j'empeche � mon ennemi d'etre cr�e dans le sol
		for (g = 0; g < 3; g++) if (!BlocPresentBas(koopa) && koopa.etat != sprite_mort2) koopa.pos_y++; //gravit�
		koopa.pos_x += Ptx;
		koopa.pos_y += Pty;
		koopa.dep_x = -1; 
		hel_ObjSetHFlip(koopa.sprite,1); //si c'est un goomba allant � gauche
		carte_map[tabry][tabrx] = 0; //et j'efface les tiles
		hel_MapRedraw(2); //on redessine le niveau
		koopa.vitesse = 0;
		koopa.anim_mort = 0;
		koopa.temp_mort = 0;
		koopa.temp_course = 0;
		koopa.etat = sprite_vivant;
	}
}

void GestionKoopa()
{
	if (koopa.etat == sprite_vivant)
	{
		//if (hel_ObjExists(koopa.sprite)) 
		AnimeKoopa();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//koopa.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//koopa.pos_y += Pty;
			if (CollisionSprite(balle,koopa)) CollisionFoesBalle(koopan);
			//koopa.pos_x -= Ptx;
			//koopa.pos_y -= Pty;
			if (CollisionSprite(mario,koopa)) CollisionFoesMario(koopan);
		}
	}
	else if (koopa.etat == sprite_mort) EcraseKoopa();
	else if (koopa.etat == sprite_mort2) AnimMortFoes2(koopan);
	if (boum.etat == sprite_vivant) AnimExplosionKoopa();
}

void AnimeKoopa()
{
	koopa.pos_x -= Ptx;
	koopa.pos_y -= Pty;

	//ExtractionFoes(koopan);

	AnimMarcheKoopa();

	koopa.vitesse++;
	if (koopa.vitesse >= 2) //je d�place mon ennemi
	{
		if (BlocPresentDroite(koopa)) { koopa.dep_x = -1; hel_ObjSetHFlip(koopa.sprite,1);}
		if (BlocPresentGauche(koopa)) { koopa.dep_x = 1; hel_ObjSetHFlip(koopa.sprite,0);}
		if (BlocPresentBas(koopa)) koopa.pos_x += koopa.dep_x;
		
		//detection vide pour lui faire faire demi tour
		if ( ( carte_map[((Pty + koopa.pos_y + koopa.dec_bas_y) >> 3)][((Ptx + koopa.pos_x + koopa.dec_hb_x1) >> 3)] <= tile_vide+1 ) || ( carte_map[((Pty + koopa.pos_y + koopa.dec_bas_y) >> 3)][((Ptx + koopa.pos_x + koopa.dec_hb_x4) >> 3)] <= tile_vide+1 ) )
		{
			koopa.pos_x -= 2*koopa.dep_x;
			if (koopa.dep_x == -1) { koopa.dep_x = 1; hel_ObjSetHFlip(koopa.sprite,0);}
			else { koopa.dep_x = -1; hel_ObjSetHFlip(koopa.sprite,1);}
			hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[2*256]);
			koopa.temp_course = 0;
		}
		koopa.vitesse = 0;
	}

	//�loignement
	if (Pt.X != 0 && ((koopa.pos_x <= (mario.pos_x - 400)) || (koopa.pos_x >= (mario.pos_x + 300)))) //si le goomba est trop loin de mario
	{
		//koopa.etat = sprite_inactif;
		//hel_ObjSetVisible(koopa.sprite,0);
		FixeKoopa();
	}

	koopa.pos_x += Ptx; 
	koopa.pos_y += Pty;

	//if (hel_ObjExists(koopa.sprite))
	{
		hel_ObjSetXY(koopa.sprite,(koopa.pos_x-Ptx),(koopa.pos_y-Pty));
		if ((koopa.pos_x-Ptx) < -54 || (koopa.pos_x-Ptx) > 240 || (koopa.pos_y-Pty) < -54 || (koopa.pos_y-Pty) > 160) hel_ObjSetXY(koopa.sprite,240,160);		
	}
}

void FixeKoopa()
{
	koopa.dep_x = 0;
	koopa.etat = sprite_inactif;
	koopa.pos_x = 0;
	koopa.pos_y = 320;
	hel_ObjSetVisible(koopa.sprite,0);
}

void EcraseKoopa()
{
	koopa.temp_mort++;
	if (koopa.anim_mort == 0)
	{
		koopa.anim_mort++;
		score += koopa.score * multiple_score; //on ajoute le score
		AffichePoints((koopa.pos_x-Ptx),(koopa.pos_y-Pty),(koopa.score * multiple_score));
		multiple_score *= 2; //je multiplie par 2 le score du prochain ennemi si mario ne touche pas le sol entre temps
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //le bruit de la mort de l'ennemi �cras�
		koopa.dep_x = 1;
		hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[3*256]);
	}
	if (koopa.temp_mort >= 5)
	{
		koopa.temp_mort = 0;
		koopa.anim_mort++;
      
		koopa.dep_x *= -1;
		if (koopa.dep_x == -1) hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[4*256]);
		if (koopa.dep_x == 1) hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[3*256]);
      
		if (koopa.anim_mort == 13) //fin de l'anim du koopa qui clignote et lancement du "boum"
		{
			AdpcmStart(&ADPCM_boum,1,1);
			boum.etat = sprite_vivant;
			hel_ObjSetVisible(boum.sprite,1);
			boum.pos_x = koopa.pos_x - 16;
			boum.pos_y = koopa.pos_y + 8;
			boum.dep_x = 1;
			boum.temp_mort = 0;
			boum.anim_mort = 0;
			         
			koopa.dep_x = 0;
			koopa.etat = sprite_inactif;
			koopa.pos_x = 0;
			koopa.pos_y = 320;
			hel_ObjSetVisible(koopa.sprite,0);
		}
	}

	//if (hel_ObjExists(koopa.sprite))
	{
		hel_ObjSetXY(koopa.sprite,(koopa.pos_x-Ptx),(koopa.pos_y-Pty));
		if ((koopa.pos_x-Ptx) < -54 || (koopa.pos_x-Ptx) > 240 || (koopa.pos_y-Pty) < -54 || (koopa.pos_y-Pty) > 160) hel_ObjSetXY(koopa.sprite,240,160);		
	}
}


void AfficheBoulet(u32 tabrx, u32 tabry) 
{
	if (boulet.etat == sprite_inactif)
	{
		boulet.pos_x = (tabrx << 3) - 9; //je converti en pixels
		boulet.pos_y = (tabry << 3) - 3;
		boulet.tile_origine_x = boulet.pos_x;
		boulet.tile_origine_y = boulet.pos_y;
		hel_ObjSetXY(boulet.sprite,(boulet.pos_x-Ptx),(boulet.pos_y-Pty));
		if ((boulet.pos_x-Ptx) < -54 || (boulet.pos_x-Ptx) > 240 || (boulet.pos_y-Pty) < -54 || (boulet.pos_y-Pty) > 160) hel_ObjSetXY(boulet.sprite,240,160);
		hel_ObjSetVisible(boulet.sprite,1);
		if (mario.pos_x < boulet.pos_x-Ptx) {boulet.dep_x = -2; hel_ObjSetHFlip(boulet.sprite,0);}//r�initialisation des variables
		else {boulet.dep_x = 2; hel_ObjSetHFlip(boulet.sprite,1);}
		hel_ObjSetVFlip(boulet.sprite,0);
		boulet.temp_course = 0;
		boulet.limite = 2;
		boulet.course = 0;
		boulet.etat = sprite_vivant;
		hel_ObjSetPrio(boulet.sprite,3);
		AdpcmStart(&ADPCM_boulet,1,1);
	}
}

void GestionBoulet()
{
	if (boulet.etat == sprite_vivant)
	{
		AnimeBoulet();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//boulet.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//boulet.pos_y += Pty;
			if (CollisionSprite(balle,boulet)) CollisionFoesBalle(bouletn);
			//boulet.pos_x -= Ptx;
			//boulet.pos_y -= Pty;
			if (CollisionSprite(mario,boulet)) CollisionFoesMario(bouletn);
		}
	}
	else if (boulet.etat == sprite_mort) EcraseBoulet();
	else if (boulet.etat == sprite_mort2) AnimMortFoes2(bouletn);
}

void AnimeBoulet()
{
	boulet.pos_x -= Ptx;
	boulet.pos_y -= Pty;
   
	boulet.pos_x += boulet.dep_x;

	AnimBoulet();
	
	//�loignement du boulet
	if (((boulet.pos_x <= (mario.pos_x - 300)) || (boulet.pos_x >= (mario.pos_x + 300)))) //si le boulet est trop loin de mario
	{
		boulet.pos_x = boulet.tile_origine_x-Ptx;
		boulet.pos_y = boulet.tile_origine_y-Pty;
		if (mario.pos_x < boulet.pos_x) 
		{
			hel_ObjSetHFlip(boulet.sprite,0);
			boulet.dep_x = -2; //r�initialisation des variables
		}
		else 
		{
			boulet.dep_x = 2;
			hel_ObjSetHFlip(boulet.sprite,1);
		}
		boulet.temp_course = 0;
		boulet.limite = 2;
		boulet.course = 0;
		hel_ObjSetPrio(boulet.sprite,3);
		AdpcmStart(&ADPCM_boulet,1,1);
	}

	boulet.pos_x += Ptx;
	boulet.pos_y += Pty;

	if ((((boulet.tile_origine_x-Ptx) <= (mario.pos_x - 300)) || ((boulet.tile_origine_x-Ptx) >= (mario.pos_x + 300)))) //si le canon est trop loin de mario
	{
		FixeBoulet();
	}

	{
		hel_ObjSetXY(boulet.sprite,(boulet.pos_x-Ptx),(boulet.pos_y-Pty));
		if ((boulet.pos_x-Ptx) < -54 || (boulet.pos_x-Ptx) > 240 || (boulet.pos_y-Pty) < -54 || (boulet.pos_y-Pty) > 160) hel_ObjSetXY(boulet.sprite,240,160);		
	}

}

void FixeBoulet()
{
	boulet.dep_x = 0;
	boulet.etat = sprite_inactif;
	boulet.pos_x = 0;
	boulet.pos_y = 320;
	hel_ObjSetVisible(boulet.sprite,0);
}
      
void EcraseBoulet()
{
	boulet.temp_mort++;
	if (boulet.temp_mort == 1)
	{
		score += boulet.score * multiple_score;
		AffichePoints((boulet.pos_x-Ptx),(boulet.pos_y-Pty),(boulet.score * multiple_score));
		multiple_score *= 2;
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�
		boulet.etat = sprite_mort2;
		boulet.temp_mort = 0;
	}
	{
		hel_ObjSetXY(boulet.sprite,(boulet.pos_x-Ptx),(boulet.pos_y-Pty));
		if ((boulet.pos_x-Ptx) < -54 || (boulet.pos_x-Ptx) > 240 || (boulet.pos_y-Pty) < -54 || (boulet.pos_y-Pty) > 160) hel_ObjSetXY(boulet.sprite,240,160);		
	}
}

void AfficheSphinx(u32 tabrx, u32 tabry) 
{
	sphinx.pos_x = (tabrx << 3); //je converti en pixels
	sphinx.pos_y = (tabry << 3);
	hel_ObjSetXY(sphinx.sprite,(sphinx.pos_x-Ptx),(sphinx.pos_y-Pty));
	if ((sphinx.pos_x-Ptx) < -54 || (sphinx.pos_x-Ptx) > 240 || (sphinx.pos_y-Pty) < -54 || (sphinx.pos_y-Pty) > 160) hel_ObjSetXY(sphinx.sprite,240,160);
	hel_ObjSetVisible(sphinx.sprite,1);
	hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[2*512]);
	hel_ObjSetVFlip(sphinx.sprite,0);
	hel_ObjSetHFlip(sphinx.sprite,0);
	carte_map[tabry][tabrx] = 0; //et j'efface les tiles
	hel_MapRedraw(2); //on redessine le niveau
	sphinx.pos_tab_saut = 0;
	sphinx.anim_mort = 0;
	sphinx.temp_course = 0;
	sphinx.temp_course = 0;
	sphinx.delta_course = 0;
	sphinx.temp_mort = 0;
	sphinx.limite = 2;
	sphinx.etat = sprite_vivant;
}

void GestionSphinx()
{
	if (sphinx.etat == sprite_vivant)
	{
		AnimeSphinx();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//sphinx.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//sphinx.pos_y += Pty;
			if (CollisionSprite(balle,sphinx)) CollisionFoesBalle(sphinxn);
			//sphinx.pos_x -= Ptx;
			//sphinx.pos_y -= Pty;
			if (CollisionSprite(mario,sphinx)) CollisionFoesMario(sphinxn);
		}
	}
	else if (sphinx.etat == sprite_mort) 
	{
		EcraseSphinx();
		sphinx.pos_x -= Ptx;
		sphinx.pos_y -= Pty;
		if (!BlocPresentBas(sphinx)) sphinx.pos_y += 2;  //petite gravit� uniquement lors de la mort
		hel_ObjSetY(sphinx.sprite,sphinx.pos_y);
		sphinx.pos_x += Ptx;
		sphinx.pos_y += Pty;
	}
	else if (sphinx.etat == sprite_mort2) AnimMortFoes2(sphinxn);
	if (fireball.etat == sprite_vivant && !mario_invincible)
	{
		fireball.pos_y = fireball.ecran_delta_y;
		if (CollisionSprite(mario,fireball)) CollisionFoesMario(fireballn);
	}
	//if (fireball.etat == sprite_inactif) {fireball.pos_x = 0; fireball.ecran_delta_y = 320; hel_ObjSetXY(fireball.sprite,(fireball.pos_x-Ptx),(fireball.ecran_delta_y-Pty));}
}

void AnimeSphinx()
{
	sphinx.pos_x -= Ptx;
	sphinx.pos_y -= Pty;
   
	ExtractionFoes(sphinxn);

	if (!sphinx.saut) sphinx.vitesse++;
	if (sphinx.vitesse >= 60) //petite tempo avant de re-tirer
	{
		sphinx.vitesse = 0;
		sphinx.saut = 1;		
	}

	if (sphinx.saut && Ptx < retry[2][1]) //le tir en fait
	{
		sphinx.temp_course++;
		if (sphinx.temp_course >= 5)
		{
			sphinx.temp_course = 0;

			if (sphinx.delta_course == 0) hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[3*512]);
			if (sphinx.delta_course == 1) hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[4*512]);
			if (sphinx.delta_course == 2)
			{
				hel_ObjSetVisible(fireball.sprite,1);
				fireball.pos_x = sphinx.pos_x + 2 + Ptx;
				fireball.ecran_delta_y = sphinx.pos_y + 15 + Pty;
			}
			if (sphinx.delta_course == 3)
			{
				fireball.dep_x = -3;
				if (mario.pos_y <= sphinx.pos_y) fireball.dep_y = -1;
				else fireball.dep_y = 1;
			}
			if (sphinx.delta_course == 4)
			{
				AdpcmStart(&ADPCM_sphinxtir,1,1);
				fireball.etat = sprite_vivant;
			}
			if (sphinx.delta_course == 5) hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[3*512]);
			if (sphinx.delta_course == 6) {hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[2*512]); sphinx.saut = 0;}

			sphinx.delta_course++;
		}		
	}
	else AnimSphinx();

	if (fireball.etat == sprite_vivant) 
	{
		AnimFireball();
		fireball.pos_x += fireball.dep_x;
		fireball.ecran_delta_y += fireball.dep_y;
		if (sphinx.delta_course >= 7 && fireball.pos_x-Ptx <= sphinx.pos_x - 400)
		{
			sphinx.saut = 1; 
			sphinx.delta_course = 0;
			fireball.dep_x = 0;
			fireball.dep_y = 0;
			fireball.pos_x = 0;
			fireball.ecran_delta_y = 320;
			fireball.etat = sprite_inactif;
		}
	}

	//�loignement
	if (Pt.X != 0 && !sphinx.dep_x && ((sphinx.pos_x <= (mario.pos_x - 400)) || (sphinx.pos_x >= (mario.pos_x + 300)))) //si le sphinx est trop loin de mario
	{
		FixeSphinx();
	}

	sphinx.pos_x += Ptx;
	sphinx.pos_y += Pty;

	{
		hel_ObjSetXY(sphinx.sprite,(sphinx.pos_x-Ptx),(sphinx.pos_y-Pty));
		if ((sphinx.pos_x-Ptx) < -54 || (sphinx.pos_x-Ptx) > 240 || (sphinx.pos_y-Pty) < -54 || (sphinx.pos_y-Pty) > 160) hel_ObjSetXY(sphinx.sprite,240,160);		
	
		hel_ObjSetXY(fireball.sprite,(fireball.pos_x-Ptx),(fireball.ecran_delta_y-Pty));
		if ((fireball.pos_x-Ptx) < -54 || (fireball.pos_x-Ptx) > 240 || (fireball.ecran_delta_y-Pty) < -54 || (fireball.ecran_delta_y-Pty) > 160) hel_ObjSetXY(fireball.sprite,240,160);
	}

}

void FixeSphinx()
{
	sphinx.etat = sprite_inactif;
	sphinx.pos_x = 0;
	sphinx.pos_y = 320;
	hel_ObjSetVisible(sphinx.sprite,0);
	fireball.dep_x = 0;
	fireball.dep_y = 0;
	hel_ObjSetVisible(fireball.sprite,0);
	fireball.pos_x = 0;
	fireball.pos_x = 320;
	fireball.ecran_delta_y = 320;
	fireball.etat = sprite_inactif;
}
      
void EcraseSphinx()
{
	sphinx.temp_mort++;
	if (sphinx.temp_mort == 1)
	{
		score += sphinx.score * multiple_score;
		AffichePoints((sphinx.pos_x-Ptx),(sphinx.pos_y-Pty),(sphinx.score * multiple_score));
		multiple_score *= 2;
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�

		if (fireball.etat == sprite_vivant)
		{
			fireball.dep_x = 0;
			fireball.dep_y = 0;
			hel_ObjSetVisible(fireball.sprite,0);
			fireball.pos_x = 0;
			fireball.ecran_delta_y = 320;
			fireball.etat = sprite_inactif;
		}
	}
	if (sphinx.temp_mort == 50)
	{
		AdpcmStart(&ADPCM_mort2,1,1); //mort2
		sphinx.etat = sprite_mort2;
		sphinx.temp_mort = 0;
		if (mario.pos_x < sphinx.pos_x-Ptx) sphinx.dep_x = 1; //le sens est d�cid� selon la position de mario
		else sphinx.dep_x = -1;
	}
	{
		hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[5*512]);
		hel_ObjSetXY(sphinx.sprite,(sphinx.pos_x-Ptx),(sphinx.pos_y-Pty));
		if ((sphinx.pos_x-Ptx) < -54 || (sphinx.pos_x-Ptx) > 240 || (sphinx.pos_y-Pty) < -54 || (sphinx.pos_y-Pty) > 160) hel_ObjSetXY(sphinx.sprite,240,160);		
	}
}

void AfficheBoss(u32 tabrx, u32 tabry) 
{
	abeille.pos_x = (tabrx << 3); //je converti en pixels
	abeille.pos_y = (tabry << 3);
	//fly.sprite = hel_ObjCreate((void*)fly_Bitmap,0,2,OBJ_MODE_NORMAL,0,7,0,0,0,2,0,(fly.pos_x - Ptx),(fly.pos_y - Pty));
	hel_ObjSetVisible(fly.sprite,1);
	hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[0]);
	hel_ObjSetVFlip(fly.sprite,0);
	fly.pos_x -= Ptx;
	fly.pos_y -= Pty;
	while (BlocPresentBas(fly)) fly.pos_y--; //j'empeche � mon ennemi d'etre cr�e dans le sol
	while (!BlocPresentBas(fly)) fly.pos_y++; //gravit�
	fly.pos_x += Ptx;
	fly.pos_y += Pty;
	carte_map[tabry-1][tabrx] = 0; //et j'efface les tiles
	carte_map[tabry-1][tabrx+1] = 0;
	carte_map[tabry-1][tabrx+2] = 0;
	carte_map[tabry-1][tabrx+3] = 0;
	carte_map[tabry][tabrx] = 0;
	carte_map[tabry][tabrx+1] = 0;
	carte_map[tabry][tabrx+2] = 0;
	carte_map[tabry][tabrx+3] = 0;
	carte_map[tabry+1][tabrx] = 0;
	carte_map[tabry+1][tabrx+1] = 0;
	carte_map[tabry+1][tabrx+2] = 0;
	carte_map[tabry+1][tabrx+3] = 0;
	carte_map[tabry+2][tabrx] = 0;
	carte_map[tabry+2][tabrx+1] = 0;
	carte_map[tabry+2][tabrx+2] = 0;
	carte_map[tabry+2][tabrx+3] = 0;
	hel_MapRedraw(2); //on redessine le niveau
	fly.dep_x = 0; //r�initialisation des variables
	fly.saut = 0;
	fly.pos_tab_saut = 0;
	fly.vitesse = 0;
	fly.anim_mort = 0;
	fly.temp_course = 0;
	fly.temp_course = 0;
	fly.temp_mort = 0;
	fly.limite = 2;
	fly.etat = sprite_vivant;
}

void GestionBoss()
{
	if (bossgoomba.etat == sprite_vivant)
	{
		AnimeBoss();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//bossgoomba.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//bossgoomba.pos_y += Pty;
			if (CollisionSprite(balle,bossgoomba)) CollisionFoesBalle(bossgoomban);
			//bossgoomba.pos_x -= Ptx;
			//bossgoomba.pos_y -= Pty;
			if (CollisionSprite(mario,bossgoomba)) CollisionFoesMario(bossgoomban);
		}
	}
	else if (bossgoomba.etat == sprite_mort || bossgoomba.etat == sprite_mort2) 
	{
		EcraseBoss();
		bossgoomba.pos_x -= Ptx;
		bossgoomba.pos_y -= Pty;
		if (!BlocPresentBas(bossgoomba)) bossgoomba.pos_y += 2;  //petite gravit� uniquement lors de la mort
		hel_ObjSetY(bossgoomba.sprite,bossgoomba.pos_y);
		bossgoomba.pos_x += Ptx;
		bossgoomba.pos_y += Pty;
	}
	//else if (bossgoomba.etat == sprite_mort2) AnimMortFoes2(bossgoomban);
}

void AnimeBoss()
{
	bossgoomba.pos_x -= Ptx;
	bossgoomba.pos_y -= Pty;

	if (BlocPresentDroite(bossgoomba)) {bossgoomba.dep_x = -1; hel_ObjSetHFlip(bossgoomba.sprite,0);}
	if (BlocPresentGauche(bossgoomba)) {bossgoomba.dep_x = 1; hel_ObjSetHFlip(bossgoomba.sprite,1);}

	bossgoomba.pos_x += bossgoomba.dep_x * bossgoomba.vitesse;  //je d�place mon ennemi

	AnimMarcheBoss();

	//�loignement
	if (Pt.X != 0 && !bossgoomba.dep_x && ((bossgoomba.pos_x <= (mario.pos_x - 400)) || (bossgoomba.pos_x >= (mario.pos_x + 300)))) //si le bossgoomba est trop loin de mario
	{
		FixeBoss();
	}

	bossgoomba.pos_x += Ptx;
	bossgoomba.pos_y += Pty;

	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjSetXY(bossgoomba.sprite,(bossgoomba.pos_x-Ptx),(bossgoomba.pos_y-Pty));
		if ((bossgoomba.pos_x-Ptx) < -54 || (bossgoomba.pos_x-Ptx) > 240 || (bossgoomba.pos_y-Pty) < -54 || (bossgoomba.pos_y-Pty) > 160) hel_ObjSetXY(bossgoomba.sprite,240,160);		
	}

}

void FixeBoss()
{
	bossgoomba.dep_x = 0;
	bossgoomba.etat = sprite_inactif;
	bossgoomba.pos_x = 0;
	bossgoomba.pos_y = 320;
	hel_ObjSetVisible(bossgoomba.sprite,0);
}
      
void EcraseBoss()
{
	bossgoomba.temp_mort++;
	if (bossgoomba.temp_mort == 1)
	{
		if (bossgoomba.etat != sprite_mort2)
		{
			mario.saut = 1; //je fais rebondir mario
			mario.pos_tab_saut = 6;
		}
		hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[8*2048]);		
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�
	}
	if (bossgoomba.temp_mort == 3) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 6) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 9) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 12) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 15) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 18) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 21) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 24) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 27) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 30) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 33) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 36) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 39) hel_ObjSetVisible(bossgoomba.sprite,0);
	if (bossgoomba.temp_mort == 42) hel_ObjSetVisible(bossgoomba.sprite,1);
	if (bossgoomba.temp_mort == 45 && bossgoomba.gravite != 0) 
	{
		bossgoomba.etat = sprite_vivant; 
		if (bossgoomba.vitesse > 3) bossgoomba.pos_tab_saut = 1; 
		bossgoomba.limite = 5;
		bossgoomba.gravite--;
		bossgoomba.vitesse++;
	}
	else if (bossgoomba.temp_mort >= 45 && !bossgoomba.gravite)
	{
		play_music = 0;
		AdpcmStop(0);
		if (bossgoomba.temp_mort == 45) {hel_ObjSetVisible(bossgoomba.sprite,0); hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[4*2048]);}
		if (bossgoomba.temp_mort == 48) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 51) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 54) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 57) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 60) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 63) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 66) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 69) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 72) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 75) {hel_ObjSetVisible(bossgoomba.sprite,0); hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[9*2048]);}
		if (bossgoomba.temp_mort == 78) hel_ObjSetVisible(bossgoomba.sprite,1);		
		if (bossgoomba.temp_mort == 81) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 84) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 87) {hel_ObjSetVisible(bossgoomba.sprite,0); hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[10*2048]);}
		if (bossgoomba.temp_mort == 90) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 93) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 96) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 99) {hel_ObjSetVisible(bossgoomba.sprite,0); hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[11*2048]);}
		if (bossgoomba.temp_mort == 102) hel_ObjSetVisible(bossgoomba.sprite,1);
		if (bossgoomba.temp_mort == 105) hel_ObjSetVisible(bossgoomba.sprite,0);
		if (bossgoomba.temp_mort == 108) hel_ObjSetVisible(bossgoomba.sprite,1);
	}

	if (bossgoomba.temp_mort == 111)
	{
		bossgoomba.etat = sprite_inactif;
		bossgoomba.temp_mort = 0;
		bossgoomba.dep_y = 0;
		bossgoomba.pos_x = 0;
		bossgoomba.pos_y = 320;
		hel_ObjSetVisible(bossgoomba.sprite,0);
		mario.anim_mort = 0; 
		mario.etat = mario_gagne;
		AdpcmStart(&ADPCM_bosshs,1,0);
	}
	{
		hel_ObjSetXY(bossgoomba.sprite,(bossgoomba.pos_x-Ptx),(bossgoomba.pos_y-Pty));
		if ((bossgoomba.pos_x-Ptx) < -54 || (bossgoomba.pos_x-Ptx) > 240 || (bossgoomba.pos_y-Pty) < -54 || (bossgoomba.pos_y-Pty) > 160) hel_ObjSetXY(bossgoomba.sprite,240,160);		
	}
}



