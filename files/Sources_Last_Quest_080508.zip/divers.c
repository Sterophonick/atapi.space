#include <mygba.h>
#include "header.h"
#include "divers.h"
#include "Adpcm.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void Intro()
{
	AdpcmStart(&ADPCM_intro,-1,0);

	hel_PalBgLoad256((void*)splash_palette); //chargement de la palette des bg
	ham_bg[0].ti = ham_InitTileSet((void*)&splash_tiles,SIZEOF_16BIT(splash_tiles),1,1);
	hel_MapCreate(0, 30, 20, (void*)splash_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(0,1,1,0);

	title_temp = 1;
	while (title_temp > 0) 
	{
		hel_PadCapture();
		title_temp++;
		if (title_temp > 105000) title_temp = 0;
		if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) title_temp = 0;
	}

	Fading();

	ham_DeInitTileSet(ham_bg[0].ti);
    ham_ResetBg();

	hel_PalBgLoad256((void*)title_palette);
	ham_bg[0].ti = ham_InitTileSet((void*)&title_tiles,SIZEOF_16BIT(title_tiles),1,1);
	hel_MapCreate(0, 30, 20, (void*)title_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(0,1,1,0);

	FadingExit();

	title_temp = 1;
	while (title_temp > 0) 
	{
		hel_PadCapture();
		title_temp++;
		if (title_temp > 100) title_temp = 1;
		if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) title_temp = 0;
	}	

	ham_SetFxMode(FX_LAYER_SELECT(0,1,0,0,1,0),FX_LAYER_SELECT(0,1,0,0,1,0),FX_MODE_DARKEN);
    ham_SetFxBrightnessLevel(0);
	ham_SetFxMode(FX_LAYER_SELECT(1,0,0,0,1,0),FX_LAYER_SELECT(1,0,0,0,1,0),FX_MODE_DARKEN);
    ham_SetFxBrightnessLevel(12);	

	InitTexteIntro();

	AdpcmStart(&ADPCM_bipmenu,1,1);

	hel_BgTextPrintF(1,0,19,0,"2008");
	hel_BgTextPrintF(1,28,19,0,"v2");

	if (quete <= 10000000)
	{
		hel_BgTextPrintF(1,10,6,0,"!NEW GAME!"); 
		hel_BgTextPrintF(1,10,9,0," continue ");
		t = 0;
	}
	else
	{
		hel_BgTextPrintF(1,10,6,0," new game "); 
		hel_BgTextPrintF(1,10,9,0,"!CONTINUE!");
		t = 1;
	}
	hel_BgTextPrintF(1,9,12,0," sound test "); 
	hel_BgTextPrintF(1,11,15,0," credit ");

	title_temp = 1;
	while (title_temp > 0) 
	{
		hel_PadCapture();
		title_temp++;
		if (title_temp > 10) title_temp = 1;
		if (hel_PadQuery()->Pressed.Down)
		{
			if (t == 3) {t = 0; AdpcmStart(&ADPCM_bipmenu,1,1);}
			else if (t < 3) {t++; AdpcmStart(&ADPCM_bipmenu,1,1);}
		}
		if (hel_PadQuery()->Pressed.Up)
		{
			if (t == 0) {t = 3; AdpcmStart(&ADPCM_bipmenu,1,1);}
			else if (t > 0) {t--; AdpcmStart(&ADPCM_bipmenu,1,1);}
		}
		
		if (!t)
		{
			hel_BgTextPrintF(1,10,6,0,"!NEW GAME!"); 
			hel_BgTextPrintF(1,10,9,0," continue ");
			hel_BgTextPrintF(1,9,12,0," sound test "); 
			hel_BgTextPrintF(1,11,15,0," credit ");			
			quete = 10000000;
			total_levels = 0;
			num_niveau = 0;
			if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) title_temp = 0;
		}		
		else if (t == 1)
		{
			hel_BgTextPrintF(1,10,6,0," new game "); 
			hel_BgTextPrintF(1,10,9,0,"!CONTINUE!");
			hel_BgTextPrintF(1,9,12,0," sound test "); 
			hel_BgTextPrintF(1,11,15,0," credit ");
			ham_LoadIntFromRAM("quete",&quete);
			ham_LoadIntFromRAM("total_levels",&total_levels);
			num_niveau = 0;
			if ((hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) && quete > 10000000) title_temp = 0;
		}
		else if (t == 2)
		{
			hel_BgTextPrintF(1,10,6,0," new game "); 
			hel_BgTextPrintF(1,10,9,0," continue ");
			hel_BgTextPrintF(1,9,12,0,"!SOUND TEST!"); 
			hel_BgTextPrintF(1,11,15,0," credit ");
			if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) SoundTest();
		}
		else if (t == 3)
		{
			hel_BgTextPrintF(1,10,6,0," new game "); 
			hel_BgTextPrintF(1,10,9,0," continue ");
			hel_BgTextPrintF(1,9,12,0," sound test "); 
			hel_BgTextPrintF(1,11,15,0,"!CREDIT!");
			if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) AfficheCredits();
		}
		
	}

	AdpcmStart(&ADPCM_startmenu,1,1);

	int lum = 12;
	int temp_lum = 0;

	while (lum < 16)
    {
		temp_lum++;
        if (temp_lum == 10000)
        {
			temp_lum = 0;
            lum++;
            ham_SetFxMode(FX_LAYER_SELECT(1,1,0,0,1,0),FX_LAYER_SELECT(1,1,0,0,1,0),FX_MODE_DARKEN);
            ham_SetFxBrightnessLevel(lum);
        }
    }

	ham_DeInitTileSet(ham_bg[0].ti);
	ham_DeInitTileSet(ham_bg[1].ti);
    ham_ResetBg();	

	WorldMap();
}

void AfficheCredits()
{
	hel_BgTextPrintF(1,10,6,0,"          "); 
	hel_BgTextPrintF(1,10,9,0,"          ");
	hel_BgTextPrintF(1,9,12,0,"            "); 
	hel_BgTextPrintF(1,11,15,0,"        ");

	AdpcmStart(&ADPCM_bipmenu,1,1);
	
	score = 1;
	while (score > 0)
	{
		hel_PadCapture();
		score++;
		if (score > 10) score = 1;
		
		hel_BgTextPrintF(1,2,2,0,"CODE/ YODAJR");
		hel_BgTextPrintF(1,2,4,0,"MUSIC/ ARCHILOLO");
		hel_BgTextPrintF(1,2,6,0,"GFX \" LEVEL DESIGN/ OMG");
		hel_BgTextPrintF(1,2,9,0,"SPECIAL THANKS/");
		hel_BgTextPrintF(1,2,11,0,"EMMANUEL FOR HAM LIB");
		hel_BgTextPrintF(1,2,13,0,"PETER FOR HEL LIB");
		hel_BgTextPrintF(1,2,15,0,"NRX FOR ADPCM LIB");
		hel_BgTextPrintF(1,2,17,0,"BRUNNI FOR GBA GRAPHICS");
		if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A || hel_PadQuery()->Pressed.B) score = 0;
	}

	AdpcmStart(&ADPCM_bipmenu,1,1);

	hel_BgTextPrintF(1,2,2,0,"                  ");
	hel_BgTextPrintF(1,2,4,0,"                   ");
	hel_BgTextPrintF(1,2,6,0,"                       ");
	hel_BgTextPrintF(1,2,9,0,"                        ");
	hel_BgTextPrintF(1,2,11,0,"                    ");
	hel_BgTextPrintF(1,2,13,0,"                    ");
	hel_BgTextPrintF(1,2,15,0,"                    ");
	hel_BgTextPrintF(1,2,17,0,"                       ");
	hel_BgTextPrintF(1,10,6,0," new game "); 
	hel_BgTextPrintF(1,10,9,0," continue ");
	hel_BgTextPrintF(1,9,12,0," sound test "); 
	hel_BgTextPrintF(1,11,15,0,"!CREDIT!");
}

void SoundTest()
{
	hel_BgTextPrintF(1,10,6,0,"          "); 
	hel_BgTextPrintF(1,10,9,0,"          ");
	hel_BgTextPrintF(1,9,12,0,"            "); 
	hel_BgTextPrintF(1,11,15,0,"        ");

	AdpcmStart(&ADPCM_bipmenu,1,1);
	play_music = 1; 
	num_niveau = 1;
	AdpcmStop(0);
	
	p = 0;
	score = 1;
	while (score > 0)
	{
		hel_PadCapture();
		score++;
		if (score > 10) score = 1;
		if (hel_PadQuery()->Pressed.Down)
		{
			if (p == 15) {p = 0; AdpcmStart(&ADPCM_bipmenu,1,1);}
			else if (p < 15) {p++; AdpcmStart(&ADPCM_bipmenu,1,1);}
			AdpcmStop(0);
			play_music = 0;
		}
		if (hel_PadQuery()->Pressed.Up)
		{
			if (p == 0) {p = 15; AdpcmStart(&ADPCM_bipmenu,1,1);}
			else if (p > 0) {p--; AdpcmStart(&ADPCM_bipmenu,1,1);}
			AdpcmStop(0);
			play_music = 0;
		}

		if (p == 0) {hel_BgTextPrintF(1,2,2,0,"!LEVEL 1"); if (!play_music) {play_music = 1;} num_niveau = 1;} else hel_BgTextPrintF(1,2,2,0," level 1");
		if (p == 1) {hel_BgTextPrintF(1,2,4,0,"!LEVEL 2"); if (!play_music) {play_music = 1;} num_niveau = 2;} else hel_BgTextPrintF(1,2,4,0," level 2");
		if (p == 2) {hel_BgTextPrintF(1,2,6,0,"!LEVEL 3"); if (!play_music) {play_music = 1;} num_niveau = 3;} else hel_BgTextPrintF(1,2,6,0," level 3");
		if (p == 3) {hel_BgTextPrintF(1,2,8,0,"!LEVEL 4"); if (!play_music) {play_music = 1;} num_niveau = 4;} else hel_BgTextPrintF(1,2,8,0," level 4");
		if (p == 4) {hel_BgTextPrintF(1,2,10,0,"!LEVEL 5"); if (!play_music) {play_music = 1;} num_niveau = 5;} else hel_BgTextPrintF(1,2,10,0," level 5");
		if (p == 5) {hel_BgTextPrintF(1,2,12,0,"!LEVEL 6"); if (!play_music) {play_music = 1;} num_niveau = 6;} else hel_BgTextPrintF(1,2,12,0," level 6");
		if (p == 6) {hel_BgTextPrintF(1,2,14,0,"!LEVEL 7"); if (!play_music) {play_music = 1;} num_niveau = 7;} else hel_BgTextPrintF(1,2,14,0," level 7");
		if (p == 7) {hel_BgTextPrintF(1,2,16,0,"!LEVEL 8"); if (!play_music) {play_music = 1;} num_niveau = 8;} else hel_BgTextPrintF(1,2,16,0," level 8");
		if (p == 8) {hel_BgTextPrintF(1,15,2,0,"!INTRODUCTION"); } else hel_BgTextPrintF(1,15,2,0," introduction");
		if (p == 9) {hel_BgTextPrintF(1,15,4,0,"!WORLD MAP"); } else hel_BgTextPrintF(1,15,4,0," world map");
		if (p == 10) {hel_BgTextPrintF(1,15,6,0,"!BONUS ROOM"); } else hel_BgTextPrintF(1,15,6,0," bonus room");
		if (p == 11) {hel_BgTextPrintF(1,15,8,0,"!GAME OVER"); } else hel_BgTextPrintF(1,15,8,0," game over");
		if (p == 12) {hel_BgTextPrintF(1,15,10,0,"!BOSS INTRO"); } else hel_BgTextPrintF(1,15,10,0," boss intro");
		if (p == 13) {hel_BgTextPrintF(1,15,12,0,"!BOSS BATTLE"); } else hel_BgTextPrintF(1,15,12,0," boss battle");
		if (p == 14) {hel_BgTextPrintF(1,15,14,0,"!BOSS DEAD"); } else hel_BgTextPrintF(1,15,14,0," boss dead");
		if (p == 15) {hel_BgTextPrintF(1,15,16,0,"!ENDING"); } else hel_BgTextPrintF(1,15,16,0," ending");

		if (AdpcmStatus(0) == 0) //silence ?
		{
			if (play_music == 1) //on joue d'abord l'intro
			{
				if (num_niveau == 1) AdpcmStart(&ADPCM_monde1_intro,1,0); 
				else if (num_niveau == 2) AdpcmStart(&ADPCM_monde2_intro,1,0);
				else if (num_niveau == 3) AdpcmStart(&ADPCM_monde3_intro,1,0);
				else if (num_niveau == 4) AdpcmStart(&ADPCM_monde4_intro,1,0);
				else if (num_niveau == 5) AdpcmStart(&ADPCM_monde5_intro,1,0);
				else if (num_niveau == 6) AdpcmStart(&ADPCM_monde6_intro,1,0);
				else if (num_niveau == 7) AdpcmStart(&ADPCM_monde7_intro,1,0);
				else if (num_niveau == 8) AdpcmStart(&ADPCM_monde8_intro,1,0);

				play_music = 2;
			}
			else if (play_music == 2) //puis la musique
			{
				if (num_niveau == 1) AdpcmStart(&ADPCM_monde1,1,0);
				else if (num_niveau == 2) AdpcmStart(&ADPCM_monde2,1,0);
				else if (num_niveau == 3) AdpcmStart(&ADPCM_monde3,1,0);
				else if (num_niveau == 4) AdpcmStart(&ADPCM_monde4,1,0);
				else if (num_niveau == 5) AdpcmStart(&ADPCM_monde5,1,0);
				else if (num_niveau == 6) AdpcmStart(&ADPCM_monde6,1,0);
				else if (num_niveau == 7) AdpcmStart(&ADPCM_monde7,1,0);
				else if (num_niveau == 8) AdpcmStart(&ADPCM_monde8,1,0);
				
				play_music = 0;
			}
			else if (p == 8) AdpcmStart(&ADPCM_intro,-1,0);
			else if (p == 9) AdpcmStart(&ADPCM_carte,-1,0);
			else if (p == 10) AdpcmStart(&ADPCM_bonusm,-1,0);
			else if (p == 11) AdpcmStart(&ADPCM_gameover,-1,0);
			else if (p == 12) AdpcmStart(&ADPCM_bossintro,-1,0);
			else if (p == 13) AdpcmStart(&ADPCM_boss,-1,0);
			else if (p == 14) AdpcmStart(&ADPCM_bosshs,-1,0);
			else if (p == 15) AdpcmStart(&ADPCM_finm,-1,0);
		}
		
		if (hel_PadQuery()->Pressed.B) score = 0;
	}

	AdpcmStart(&ADPCM_intro,-1,0);

	hel_BgTextPrintF(1,2,2,0,"        ");
	hel_BgTextPrintF(1,2,4,0,"        ");
	hel_BgTextPrintF(1,2,6,0,"        ");
	hel_BgTextPrintF(1,2,8,0,"        ");
	hel_BgTextPrintF(1,2,10,0,"        ");
	hel_BgTextPrintF(1,2,12,0,"        ");
	hel_BgTextPrintF(1,2,14,0,"        ");
	hel_BgTextPrintF(1,2,16,0,"        ");
	hel_BgTextPrintF(1,15,2,0,"             ");
	hel_BgTextPrintF(1,15,4,0,"          ");
	hel_BgTextPrintF(1,15,6,0,"           ");
	hel_BgTextPrintF(1,15,8,0,"          ");
	hel_BgTextPrintF(1,15,10,0,"           ");
	hel_BgTextPrintF(1,15,12,0,"            ");
	hel_BgTextPrintF(1,15,14,0,"          ");
	hel_BgTextPrintF(1,15,16,0,"       ");
	hel_BgTextPrintF(1,10,6,0," new game "); 
	hel_BgTextPrintF(1,10,9,0," continue ");
	hel_BgTextPrintF(1,9,12,0,"!SOUND TEST!"); 
	hel_BgTextPrintF(1,11,15,0," credit ");
}

void Fading()
{
	int lum = 0;
	int temp_lum = 0;

	while (lum < 16)
    {
		temp_lum++;
        if (temp_lum == 10000)
        {
			temp_lum = 0;
            lum++;
            ham_SetFxMode(FX_LAYER_SELECT(1,1,0,0,1,0),FX_LAYER_SELECT(1,1,0,0,1,0),FX_MODE_DARKEN);
            ham_SetFxBrightnessLevel(lum);
        }
    } 
}

void FadingExit()
{
    int lum = 16;
	int temp_lum = 0;

    while (lum > 0)
    {
        temp_lum++;
        if (temp_lum == 10000)
        {
            temp_lum = 0;
            lum--;
            ham_SetFxMode(FX_LAYER_SELECT(1,1,0,0,1,0),FX_LAYER_SELECT(1,1,0,0,1,0),FX_MODE_DARKEN);
            ham_SetFxBrightnessLevel(lum);
        }
    } 
}

void Pause(int temp)
{
   tempo = 0;
   while (tempo < temp) //pause
   {
      tempo++;
      tempo2 = 0;
      while (tempo2 < temp) {tempo2++;}
   }
}


void EcoulementTemps()
{
   temp_temps++;
   if (temp_temps >= 55)
   {
      temp_temps = 0;
      if (!temps)
      {
         mario.etat = mario_mort;
         mario.temp_mort = 0;
         mario.anim_mort = 0;
         mario.dep_y = 1;
      }
      if (temps > 0) temps--;
   }
}


void AffichePoints(s16 pos_x, s16 pos_y, u16 points)
{
	for (b = points1n; b <= points3n; b++)
	{
		if (sprite[b].etat == sprite_inactif)
		{
			//sprite[b].sprite = hel_ObjCreate((void*)score_Bitmap,1,0,OBJ_MODE_NORMAL,0,6,0,0,0,2,0,(pos_x + 5),(pos_y));
			hel_ObjSetVisible(sprite[b].sprite,1);
			sprite[b].etat = sprite_vivant;
			sprite[b].pos_x = pos_x + 5 + Ptx;
			sprite[b].pos_y = pos_y + Pty;
			hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));

			switch (points)
			{
				case 100:
					hel_ObjUpdateGfx(sprite[b].sprite,(void*)&score_Bitmap[0]);
				break;

				case 200:
					hel_ObjUpdateGfx(sprite[b].sprite,(void*)&score_Bitmap[64]);
				break;

				case 400:
					hel_ObjUpdateGfx(sprite[b].sprite,(void*)&score_Bitmap[128]);
				break;

				case 800:
					hel_ObjUpdateGfx(sprite[b].sprite,(void*)&score_Bitmap[192]);
				break;

				case 1000:
					hel_ObjUpdateGfx(sprite[b].sprite,(void*)&score_Bitmap[256]);
				break;

				case 5000:
					hel_ObjUpdateGfx(sprite[b].sprite,(void*)&score_Bitmap[320]);
				break;
			}

			b = points3n + 1;  //je sort de la boucle for
		}
	}
}


void PreNiveau()
{
   hel_BgSetMosaic(0,TRUE); //activation du mode mosaique pour les BG
   hel_BgSetMosaic(1,TRUE);
   hel_BgSetMosaic(2,TRUE);
   hel_BgSetMosaic(3,TRUE);

   mosaique = 15;
   while (mosaique >= 0)
   {
      hel_BgSetMosaicSize(mosaique,mosaique);
      mosaique--;
      Pause(230);
   }
}

void PostNiveau()
{
   hel_BgSetMosaic(0,TRUE); //activation du mode mosaique pour les BG
   hel_BgSetMosaic(1,TRUE);
   hel_BgSetMosaic(2,TRUE);
   hel_BgSetMosaic(3,TRUE);

   mosaique = 0;
   while (mosaique <= 15)
   {
      hel_BgSetMosaicSize(mosaique,mosaique);
      mosaique++;
      Pause(230);
   }
}

void CacheSprites()
{
	hel_ObjHideAll();	

	hel_ObjSetVisible(mario.sprite,1);
}

void FinNiveau()
{
	mario.anim_mort++;

	if (mario.anim_mort == 1)
	{
		inertie_droite = 0;
		hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(2560 + power) * am]); //frame de mario "I win !"
		hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y); // on applique les changements de suite, histoire d'etre le + discret possible
	}

	while (AdpcmStatus(0) != 0) {};

    //if (mario.anim_mort == 400)
	{
		hel_ObjHideAll();
		PostNiveau();
		FinduJeu();
	}
}

void ChangeNiveau()
{
	while ( collisions_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 9) >> 3)] == 21) mario.pos_x--; //je centre mario sur le tuyau
    while ( collisions_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + 24) >> 3)] == 21) mario.pos_x++;
	hel_ObjSetPrio(mario.sprite,3); //je met mario derriere le bg0 pour le cacher derriere le tuyau lors de sa descente
    hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(3072 + power) * am]); //frame de mario "je rentre dans un tuyau"
    mario.anim_mort = 0;
	AdpcmStart(&ADPCM_finniveau,1,0);
    while (mario.anim_mort < 32) 
    {
       Pause(200);
       {
          mario.anim_mort++;
          mario.pos_y++;
          hel_ObjSetY(mario.sprite,mario.pos_y);
       }
    }
	CacheSprites();
	hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[0]);
    hel_ObjSetHFlip(mario.sprite,0);
    PostNiveau();
	Initialisation();
	mario.pos_y = 160;
	hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y); // on applique les changements de suite, histoire d'etre le + discret possible
	hel_ObjTransmit();
	ham_DeInitTileSet(ham_bg[0].ti);
	ham_DeInitTileSet(ham_bg[3].ti);
    ham_ResetBg();
	Fading();

	mario_map.pos_x = ((num_niveau-1)*30)+5;
	WorldMap();

	if (!num_niveau) AfficheNiveau11();
    else if (num_niveau == 1) AfficheNiveau12();
    else if (num_niveau == 2) AfficheNiveau13();
	else if (num_niveau == 3) AfficheNiveau14();
	else if (num_niveau == 4) AfficheNiveau15();
	else if (num_niveau == 5) AfficheNiveau16();
	else if (num_niveau == 6) AfficheNiveau17();
	else if (num_niveau == 7) AfficheNiveau18();
    else if (num_niveau == 8) FinduJeu();   
	temps = 400;
	mario.anim_mort = 0;
	mario.pos_y = retry[2][2];
    hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
	hel_ObjTransmit();
	hel_ObjSetPrio(mario.sprite,0);
	inertie_droite = 0;
	SuperTestEcran();
}

void FinduJeu()
{
	AdpcmStart(&ADPCM_finm,1,0);

	ham_DeInitTileSet(ham_bg[0].ti);
	ham_DeInitTileSet(ham_bg[3].ti);
    ham_ResetBg();

	AfficheFin();
}

void GameOver()
{
	Pause(1000);

	CacheSprites();

	AdpcmStart(&ADPCM_gameover,1,0);

	ham_DeInitTileSet(ham_bg[0].ti);
	ham_DeInitTileSet(ham_bg[3].ti);
    ham_ResetBg();

	hel_PalBgLoad256((void*)gameover1_palette); //chargement de la palette des bg
	ham_bg[1].ti = ham_InitTileSet((void*)&gameover1_tiles,SIZEOF_16BIT(gameover1_tiles),1,1);
	hel_MapCreate(1, 30, 20, (void*)gameover1_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(1,1,1,0);

	Pause(1900);	

	ham_bg[0].ti = ham_InitTileSet((void*)&gameover2_tiles,SIZEOF_16BIT(gameover2_tiles),1,1);
	hel_MapCreate(0, 30, 20, (void*)gameover2_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(0,1,1,0);	

	title_temp = 1;
	while (title_temp > 0) 
	{
		hel_PadCapture();
		title_temp++;
		if (title_temp > 100) title_temp = 1;
		if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) title_temp = 0;
	}	

	Fading();

	ham_DeInitTileSet(ham_bg[0].ti);
	ham_DeInitTileSet(ham_bg[1].ti);
    ham_ResetBg();

	num_niveau = 0;
	mario_map.pos_x = 5;
	mario_map.pos_y = 73;
	
	WorldMap();

	if (!num_niveau) AfficheNiveau11();
    else if (num_niveau == 1) AfficheNiveau12();
    else if (num_niveau == 2) AfficheNiveau13();
	else if (num_niveau == 3) AfficheNiveau14();
	else if (num_niveau == 4) AfficheNiveau15();
	else if (num_niveau == 5) AfficheNiveau16();
	else if (num_niveau == 6) AfficheNiveau17();
	else if (num_niveau == 7) AfficheNiveau18();
    else if (num_niveau == 8) FinduJeu();	

	Initialisation(); // init des variables

	mario.pos_y = retry[2][2];
    hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
    vies = 5;
}

void ObjUpdateOAM(THandle sprite, s32 posx, s32 posy) //marche pas
{
	//u32 OamSpot = hel_ObjGetOamSlot(sprite);
	//hel_BgTextPrintF(0,1,2,0,"x: %d  ",OamSpot);
	//if(OamSpot != HANDLE_INVALID)
	{
		TOOL_OAM_OBJ_SET_XPOS(1, posx);
		TOOL_OAM_OBJ_SET_YPOS(1, posy);
	}
}

void JoueMusique()
{
	if (play_music > 0 && AdpcmStatus(0) == 0) //silence ?
	{
		if (play_music == 1) //on joue d'abord l'intro
		{
			if (num_niveau == 1) AdpcmStart(&ADPCM_monde1_intro,1,0); 
			else if (num_niveau == 2) AdpcmStart(&ADPCM_monde2_intro,1,0);
			else if (num_niveau == 3) AdpcmStart(&ADPCM_monde3_intro,1,0);
			else if (num_niveau == 4) AdpcmStart(&ADPCM_monde4_intro,1,0);
			else if (num_niveau == 5) AdpcmStart(&ADPCM_monde5_intro,1,0);
			else if (num_niveau == 6) AdpcmStart(&ADPCM_monde6_intro,1,0);
			else if (num_niveau == 7) AdpcmStart(&ADPCM_monde7_intro,1,0);
			else if (num_niveau == 8) AdpcmStart(&ADPCM_monde8_intro,1,0);

			play_music = 2;
		}
		else //puis la musique
		{
			if (num_niveau == 1) AdpcmStart(&ADPCM_monde1,-1,0);
			else if (num_niveau == 2) AdpcmStart(&ADPCM_monde2,-1,0);
			else if (num_niveau == 3) AdpcmStart(&ADPCM_monde3,-1,0);
			else if (num_niveau == 4) AdpcmStart(&ADPCM_monde4,-1,0);
			else if (num_niveau == 5) AdpcmStart(&ADPCM_monde5,-1,0);
			else if (num_niveau == 6) AdpcmStart(&ADPCM_monde6,-1,0);
			else if (num_niveau == 7) {AdpcmStart(&ADPCM_monde7,1,0); play_music = 1;}
			else if (num_niveau == 8) AdpcmStart(&ADPCM_monde8,-1,0);
		}
	}	
}
