#include <mygba.h>
#include <hel2.h>
#include <stdlib.h>
#include <math.h>
//#include "modules.h"
#include "Adpcm.h"



// = = DEFINE = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
#define UtilCPU() (R_TIM2COUNT)
#define EN_IWRAM __attribute__ ((section (".iwram")))
#define EN_EWRAM __attribute__ ((section (".ewram")))

void (*pRoutineLointaine)();
#define Exec(a,b...) ({ pRoutineLointaine = a; pRoutineLointaine(b); })

#define Tbl_pcos(x)  Tbl_cos[x]        // D�finition du tableau de cosinus
#define Tbl_psin(x)  Tbl_cos[x+64]     // D�finition du tableau des sinus

#define mario sprite[0]
#define balle sprite[15] //+ 9 blocs pieces + 5 bloc (faut pas les oublier, ils sont cr��s eux aussi)
#define ballen 15
#define cache sprite[16] //le "nom" des sprites dans la grande structure des sprites
#define cachen 16
#define bonus sprite[17]
#define bonusn 17
#define points1 sprite[18]
#define points2 sprite[19]
#define points3 sprite[20]
#define points1n 18
#define points2n 19
#define points3n 20 //ces 2 l�...
#define unevie sprite[21] //... doivent rester coll�s
#define unevien 21

#define goombad 22   // les num�ros des sprites dans la grande structure des sprites
#define goombaf 26 //(+4)
#define fly sprite[27]
#define flyn 27
#define plateforme1 sprite[28]
#define plateforme2 sprite[29]
#define plateforme3 sprite[30]
#define plateforme1n 28
#define plateforme2n 29
#define plateforme3n 30
#define koopa sprite[31]
#define koopan 31
#define boum sprite[32]
#define boumn 32
#define tombanted 33
#define tombantef 38 //(+5)
#define ascenseur sprite[39]
#define ascenseurn 39
#define bossgoomba sprite[40]
#define bossgoomban 40
#define vide sprite[41]
#define abeille sprite[42]
#define abeillen 42
#define fleche sprite[43]
#define flechen 43
#define boulet sprite[44]
#define bouletn 44
#define hippocampe sprite[45]
#define hippocampen 45
#define poisson_osd 46
#define poisson_osf 49
#define sphinx sprite[50]
#define sphinxn 50
#define bulle sprite[51]
#define bullen 51
#define fireball sprite[64]
#define fireballn 64
#define lvl1 sprite[54]
#define lvl2 sprite[55]
#define lvl3 sprite[56]
#define lvl4 sprite[57]
#define lvl5 sprite[58]
#define lvl6 sprite[59]
#define lvl7 sprite[60]
#define lvl8 sprite[61]
#define mario_map sprite[62]
#define path sprite[63]

#define Map_longueur 128
#define Map_hauteur 40
#define limite_x 90
#define limite_y 29 //19

#define obstacle 5  // bgCollision
#define bloc 6
#define bloc2 10
#define bloc_gauche 7
#define bloc_droite 8
#define b_piece 9
#define b_invisible 12
#define b_bonus 14
#define b_vie 15
#define b_etoile 16
#define b_pieceplus 17
#define b_std 18
#define b_ascenseur 19
#define piece_hg 1
#define piece_hd 2
#define piece_bg 3
#define piece_bd 4
#define p_haut 22
#define p_bas 23
#define p_hg 24
#define p_hd 25
#define p_bg 26
#define p_bd 27
#define p_droite 28
#define p_gauche 29
#define p_hgbd 30
#define p_bghd 31
#define p_hb 32
#define p_gd 33
#define p_simple 14
#define p_double 15
#define p_triple 16
#define t_secret 11

#define bloc_query 46 //65 // bgMap
#define bloc_marron 62 //81
#define piece 4 //87
#define goomba_tile 34
#define goomba_g 104 //105
#define goomba_d 106 //107
#define fly_tile 36 //113
#define bloc_jaune 66 //141
#define tile_vide 1
#define plateforme_tile 28 //148
#define koopa_tile 35 //161
#define koopa_g 160 //172
#define koopa_d 158 //170
#define tombante_tile 24 //186
#define pique_b_tile 20 //194
#define pique_h_tile 23 //197
#define pacoin_tile 138
#define sphinx_tile 37
#define abeille_tile 38
#define poisson_os_tile 39
#define hippocampe_tile 40
#define bossgoomba_tile 41
#define boulet_tile 36

#define s_piece 0
#define s_bloc 1
#define petite_plateforme 24
#define grande_plateforme 40

#define gravite_std 4   // gravit� standard
#define lent 1     // vitesse de mario et d�filement de la map
#define rapide 2
#define saut_normal 0  // gestion de la hauteur normale du saut
#define saut_max 1 // hauteur max du saut
#define inertie_standard 6 // inertie de mario marchant
#define inertie_double 10 // inertie de mario courant
#define tempo_marche 5
#define tempo_course 3

#define mario_stop 0
#define mario_marche 1
#define mario_tombe 2
#define mario_saut 3
#define mario_derape 4
#define mario_gagne 5
#define mario_tuyau 6
#define mario_baisse 7
#define mario_mort 8
#define mario_gp 9
#define mario_pg 10
#define mario_fleur 11
#define sprite_inactif 0
#define sprite_vivant 6
#define sprite_mort 7
#define sprite_mort2 8

#define champignon 0
#define fleur 1
#define vie 2
#define etoile 3
#define ascens 4

#define petit_mario 512
#define super_mario 4608 //8 * 1024

#define dec_mario_bas_y 32 //limites de collision avec la map
#define dec_mario_dg_y4 31
#define dec_mario_hb_x1 12
#define dec_mario_hb_x2 15
#define dec_mario_hb_x3 17
#define dec_mario_hb_x4 19
#define dec_mario_hb_x4c 20 //pour eviter que mario ne tombe entre 2 blocs
#define dec_mario_gauche_x 11
#define dec_mario_droite_x 20

#define dec_petit_mario_haut_y 16
#define dec_petit_mario_dg_y1 17
#define dec_petit_mario_dg_y2 22
#define dec_petit_mario_dg_y3 27

#define dec_grand_mario_haut_y 6
#define dec_grand_mario_dg_y1 7
#define dec_grand_mario_dg_y2 15
#define dec_grand_mario_dg_y3 23

#define dec_mario_baisse_haut_y 13
#define dec_mario_baisse_dg_y1 14


// = = EXTERN = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
extern const unsigned char mario_Bitmap[9216];
extern const unsigned char bloc_piece_Bitmap[51200];
extern const unsigned char bloc_piece2_Bitmap[51200];
extern const unsigned char goomba_Bitmap[384];
extern const unsigned char balle_Bitmap[32];
extern const unsigned char fly_Bitmap[3584];
extern const unsigned char bonus_Bitmap[896];
extern const unsigned char bloc_Bitmap[3584];
extern const unsigned char bloc_std_Bitmap[3584];
extern const unsigned char plateforme_Bitmap[2048];
extern const unsigned char score_Bitmap[384];
extern const unsigned char morceau_bloc_Bitmap[192];
extern const unsigned char koopa_Bitmap[1536];
extern const unsigned char unevie_Bitmap[256];
extern const unsigned char boum_Bitmap[2048];
extern const unsigned char tombante_Bitmap[128];
extern const unsigned char ascenseur_Bitmap[128];
extern const unsigned char bossgoomba_Bitmap[24576];
extern const unsigned char vide_Bitmap[32];
extern const unsigned char abeille_Bitmap[6656];
extern const unsigned char boulet_Bitmap[768];
extern const unsigned char fleche_Bitmap[128];
extern const unsigned char hippocampe_Bitmap[768];
extern const unsigned char poisson_os_Bitmap[768];
extern const unsigned char sphinx_Bitmap[3072];
extern const unsigned char bulle_Bitmap[64];
extern const unsigned char shiggy_Bitmap[384];
extern const unsigned char fireball_Bitmap[64];
extern const unsigned char plateforme_nuage_Bitmap[2048];
extern const unsigned char plateforme_rouge_Bitmap[2048];
extern const unsigned char dot_map_Bitmap[96];
extern const unsigned char mario_map_Bitmap[768];
extern const unsigned char path_Bitmap[256];

extern TPoint32 Pt;

extern sfp32 Ptx;
extern sfp32 Pty;

extern const s8 Tbl_cos [320];

extern const unsigned short (*collisions_map)[1024];

extern unsigned short EN_EWRAM end_map[20][30];
extern unsigned short EN_EWRAM carte_map[40][1024];
//extern unsigned short EN_EWRAM carte_back[40][1024];
extern unsigned short retry[6][4];

extern bool EN_EWRAM t_blocs[20][512];
extern bool EN_EWRAM t_pieces[20][512];
extern bool EN_EWRAM t_ennemis[20][512];

extern const unsigned short map_1_col_map[40][1024];
extern const unsigned short map_2_col_map[40][1024];
extern const unsigned short map_3_col_map[40][1024];
extern const unsigned short map_4_col_map[40][1024];
extern const unsigned short map_5_col_map[40][1024];
extern const unsigned short map_6_col_map[40][1024];
extern const unsigned short map_7_col_map[40][1024];
extern const unsigned short map_8_col_map[40][1024];

extern volatile bool NouvelleFrame;

extern const Sound ADPCM_monde1_intro;
extern const Sound ADPCM_monde2_intro;
extern const Sound ADPCM_monde3_intro;
extern const Sound ADPCM_monde4_intro;
extern const Sound ADPCM_monde5_intro;
extern const Sound ADPCM_monde6_intro;
extern const Sound ADPCM_monde7_intro;
extern const Sound ADPCM_monde8_intro;
extern const Sound ADPCM_monde1;
extern const Sound ADPCM_monde2;
extern const Sound ADPCM_monde3;
extern const Sound ADPCM_monde4;
extern const Sound ADPCM_monde5;
extern const Sound ADPCM_monde6;
extern const Sound ADPCM_monde7;
extern const Sound ADPCM_monde8;
extern const Sound ADPCM_bonusm;
extern const Sound ADPCM_boss;
extern const Sound ADPCM_bossintro;
extern const Sound ADPCM_carte;
extern const Sound ADPCM_finm;
extern const Sound ADPCM_intro;
extern const Sound ADPCM_bonuss;
extern const Sound ADPCM_boum;
extern const Sound ADPCM_bump;
extern const Sound ADPCM_ennemi;
extern const Sound ADPCM_frein;
extern const Sound ADPCM_grandir;
extern const Sound ADPCM_rapetir;
extern const Sound ADPCM_piece;
extern const Sound ADPCM_saut;
extern const Sound ADPCM_tir;
extern const Sound ADPCM_vie;
extern const Sound ADPCM_mort;
extern const Sound ADPCM_mort2;
extern const Sound ADPCM_invincible;
extern const Sound ADPCM_expl_bloc;
extern const Sound ADPCM_pause;
extern const Sound ADPCM_tuyau;
extern const Sound ADPCM_bipmap;
extern const Sound ADPCM_bipmenu;
extern const Sound ADPCM_startmap;
extern const Sound ADPCM_startmenu;
extern const Sound ADPCM_finniveau;
extern const Sound ADPCM_gameover;
extern const Sound ADPCM_bosshs;
extern const Sound ADPCM_boulet;
extern const Sound ADPCM_sphinxtir;
extern const Sound ADPCM_hippo;

// === VARIABLES =====================
bool A_presse;
bool A_oldpresse;
bool A_relache;
bool B_presse;
bool B_oldpresse;
bool saut_maximum;
bool inert_saut;
bool inertie;
bool inertie_bloc;
bool mario_clignote;
bool mario_invincible;
bool sens_mario;
bool am; // Affiche Mario
bool varitest;
int sortie_champignon;
bool sortie_fleur;
int sortie_vie;
bool sortie_etoile;
bool t_bonus; //je ne comprend pas, ca merde quand je l'enl�ve

s8 scroll;
u8 bonus_tuyau;
s8 sens_coin;
int face_coin;
u8 pacoin;
u8 num_niveau;
u16 pacoin_tile_x;
u16 pacoin_tile_y;
bool pacoin_etat;
u8 checkpoint;

u16 b;
s8 g;
u8 p;
u8 v;
u8 t;
u8 num_goomba;
u8 moy_cpu;
u8 t_moy_cpu;
u8 vitesse;
int inertie_droite;
int inertie_gauche;
u8 t_inertie_droite;
u8 t_inertie_gauche;
u8 mario_temp_course;
u8 mario_temp_clignote;
s16 mario_anim_clignote;
u8 puissance;
u8 face_piece;
u8 face_bloc;
u16 face_mer1;
u8 total_piece;
u8 vies;
u8 temp_temps;
u8 multiple_score;
u8 niveau;
u8 play_music;

s8 mosaique;

u16 zoom;
u16 temps;

int nbr_pieces;
int nbr_bloc;
int nbr_ennemis;
int nbr_plateforme;
int quete;
int total_levels;

int cpu;
int cpu1;
int tempo;
int tempo2;
int tabx;
int taby;
int tabpy;
int tabpx;
int temp_test_ecran;
int power;

int title_temp;
int score;

int test;

int compteur;


// === STRUCTURES ========================
typedef struct
{
   bool saut;
   THandle sprite; // n� du sprite
   u16 score;
   int pos_x;
   int pos_y;
   u8 etat;
   s8 course;
   u8 temp_course;
   u8 delta_course;
   s32 ecran_delta_y;
   s32 ecran_delta_x;
   u8 gravite;
   u8 vitesse;
   u8 temp_mort;
   s16 anim_mort;
   s8 dep_x;
   s8 dep_y;
   u8 limite;
   s8 pos_tab_saut;
   u8 dec_bas_y;
   s8 dec_haut_y;
   u8 dec_hb_x1;
   u8 dec_hb_x2;
   u8 dec_hb_x3;
   u8 dec_hb_x4;
   u8 dec_droite_x;
   s8 dec_gauche_x;
   u8 dec_dg_y1;
   u8 dec_dg_y2;
   u8 dec_dg_y3;
   u8 dec_dg_y4;
   s32 tile_origine_x;
   s32 tile_origine_y;
} Sprite;
Sprite sprite[64];

typedef struct
{
   bool cote;
   u8 sprite;
   u8 choc;
   u8 ecran_delta_y;
   s16 pos_y;
   s16 pos_x;
   int tile_pos_x;
   int tile_pos_y;
} Bloc_piece;
Bloc_piece bloc_piece[7];

typedef struct
{
   bool cote;
   u8 sprite;
   u8 choc;
   u8 type;
   u8 ecran_delta_y;
   s16 pos_y;
   s16 pos_x;
   int tile_pos_x;
   int tile_pos_y;
} B_bloc;
B_bloc b_bloc[0];

typedef struct
{
   bool bug;
   bool cote;
   u8 sprite;
   u8 choc;
   u16 temp;
   u8 ecran_delta_y;
   s16 pos_y;
   s16 pos_x;
   int tile_pos_x;
   int tile_pos_y;
} Bloc_piece_plus;
Bloc_piece_plus bloc_piece_plus[0];

typedef struct
{
   bool bug2;
   bool cote;
   u8 sprite;
   u8 choc;
   u8 ecran_delta_y;
   s16 pos_y;
   s16 pos_x;
   int tile_pos_x;
   int tile_pos_y;
} Bloc_std;
Bloc_std bloc_std[4];

typedef struct
{
   bool bug3;
   bool cote;
   u8 sprite;
   u8 choc;
   u8 ecran_delta_y;
   s16 pos_y;
   s16 pos_x;
   int tile_pos_x;
   int tile_pos_y;
} Bloc_ascenseur;
Bloc_ascenseur bloc_ascenseur[0];

typedef struct
{
   u8 temp_anim;
   u8 anim;
   u8 ecran_delta_y;
   
   u8 morceau1_sprite;
   u8 morceau1_ecran_delta_y;
   u8 morceau1_etat;
   s16 morceau1_pos_x;
   s16 morceau1_pos_y;

   u8 morceau2_sprite;
   u8 morceau2_ecran_delta_y;
   u8 morceau2_etat;
   s16 morceau2_pos_x;
   s16 morceau2_pos_y;

   u8 morceau3_sprite;
   u8 morceau3_ecran_delta_y;
   u8 morceau3_etat;
   s16 morceau3_pos_x;
   s16 morceau3_pos_y;

   u8 morceau4_sprite;
   u8 morceau4_ecran_delta_y;
   u8 morceau4_etat;
   s16 morceau4_pos_x;
   s16 morceau4_pos_y;
} Bloc_morceaux;
Bloc_morceaux bloc_morceaux[5];

typedef struct Ns_pieces
{
	u16 tile_x;
	u16 tile_y;
} Ns_pieces;
extern Ns_pieces EN_EWRAM ns_pieces[500];

typedef struct Ns_blocs
{
	u16 tile_x;
	u16 tile_y;
} Ns_blocs;
extern Ns_blocs EN_EWRAM ns_blocs[500];

/*typedef struct Ns_ennemis
{
	u16 tile_x;
	u16 tile_y;
	u8 type;
} Ns_ennemis;
extern Ns_ennemis EN_EWRAM ns_ennemis[500];*/

typedef struct Ns_plateformes
{
	u8 sprite;
	s32 pos_x;
	s32 pos_y;
	s8 dep_x;
	s8 dep_y;
	u8 type;
	u8 temp;
} Ns_plateformes;
extern Ns_plateformes EN_EWRAM ns_plateformes[20];


// === TABLEAUX ======================


// === PROTOTYPE ============================= (ben dis donc, ca en fait, des fonctions...)
void fonction_vbl();

void AfficheInfos();
void AfficheCPU();
void AfficheVariables();
void AfficheBoss(u32 tabrx, u32 tabry);
void AfficheBoulet(u32 tabrx, u32 tabry);
void AfficheGoomba(u32 tabrx, u32 tabry);
void AfficheHippocampe(u32 tabrx, u32 tabry);
void AfficheKoopa(u32 tabrx, u32 tabry);
void AfficheFly(u32 tabrx, u32 tabry);
void AfficheAbeille(u32 tabrx, u32 tabry);
void AffichePoissonV(u32 tabrx, u32 tabry);
void AfficheSphinx(u32 tabrx, u32 tabry);
void AffichePlateforme(u32 tabrx, u32 tabry);
void AffichePoints(s16 pos_x, s16 pos_y, u16 points);
//void AffichePlateformes(int tabrx, int tabry);
void AfficheTombante(u32 tabrx, u32 tabry);
//void AfficheFausseFin();
void AfficheCredits();
void AfficheFin();
void AnimeBoulet();
void AnimeGoomba();
void AnimeKoopa();
void AnimeFly();
void AnimeAbeille();
void AnimeBoss();
void AnimePoints();
void AppuiTouche();
void AnimBoulet();
void AnimBulle();
void AnimEnterSecretZone();
void AnimExplosionKoopa();
void AnimeHippocampe();
void AnimePoissonV();
void AnimeSphinx();
void AnimMarioMapDroite();
void AnimMarioMapGauche();
void AnimMarioGrandPetit();
void AnimMarioPetitGrand();
void AnimMarioFleur();
void AnimMarioInvincible();
void AnimMortMario();
void AnimMortFoes2(u8 f);
void AnimMarioMarche();
void AnimMarcheGoomba();
void AnimMarcheBoss();
void AnimMarcheKoopa();
void AnimMarioClignote();
void AnimMer(u32 tabx, u32 taby);
void AnimPoissonV();
void AnimSphinx();
void AnimFireball();
void AnimeVieChampignon();
void AnimeFleur();
void AnimAilesFly();
void AnimAilesAbeille();
void AnimFleur();
void AnimEtoile();
void AnimExplosion();
void AnimExitSecretZone();

void CacheSprites(); //cache bien tous les sprites qui ne sont pas cens�s etre affich�s (encore du debug de suret�, pourtant combien on parie que ca ne suffira pas ?)
void CollisionBloc();
void CollisionPiece(Sprite s);
void CollisionPAcoin(Sprite s);
void CollisionFoesBalle(u8 f);
void CollisionFoesMario(u8 f);
void CollisionFoesMarioPrecis();
void CollisionMarioPiques();
void CollisionMarioFlotte();
void CollisionTombante(Sprite s);
void ChocBlocPiece(s16 pos_x, s16 pos_y, u8 num);
void ChocBlocPiecePlus();
void ChocBloc(s16 pos_x, s16 pos_y);
void ChocBlocStd(s16 pos_x, s16 pos_y, u8 num);
void ChoppePAcoin();
void ChangeNiveau();

void DecaleEcranHaut();
void DecaleEcranBas();
void DecaleEcranGauche();
void DecaleEcranDroite();
void DE_Haut(u8 f);
void DE_Bas(u8 f);
void DE_Gauche(u8 f);
void DE_Droite(u8 f);
void DE_Blocs_Haut();
void DE_Blocs_Bas();
void DE_Blocs_Gauche();
void DE_Blocs_Droite();
void DE_Plateformes_Haut();
void DE_Plateformes_Bas();
void DE_Plateformes_Gauche();
void DE_Plateformes_Droite();

void ExtractionFoes(u8 f);
void EcraseBoss();
void EcraseGoomba(u8 f);
void EcraseKoopa();
void EcraseFly();
void EcraseAbeille();
void EcraseBoulet();
void EcraseHippocampe();
void EcrasePoissonV();
void EcraseSphinx();
void EcoulementTemps();
void EnterSecretZone();
void ExitSecretZone();

void Fading();
void FadingExit();
void FinNiveau();
void FixeBoulet();
void FixeBoss();
void FixeEnnemis();
void FixeFly();
void FixeAbeille();
void FixeGoomba(u8 f);
void FixeHippocampe();
void FixeKoopa();
void FixePlateforme(u8 f);
void FixePoissonV();
void FixeSphinx();
void FinduJeu();

void GameOver();
void GardeFouPlateforme(u8 f);
void GestionBoss();
void GestionGoomba();
void GestionKoopa();
void GestionFly();
void GestionAbeille();
void GestionFoes();
void GestionHippocampe();
void GestionPoissonV();
void GestionPlateformes();
void GestionBonus();
void GestionBoulet();
void GestionSphinx();

void MortMario(u16 temp);

void NouvelleTrame(); //le timer pour le test CPU
void NouvellePosition();

void Initialisation();
void Intro();
void InitTexte(u8 level);
void InitTexteIntro();
void InitSpritesLvl1();
void InitSpritesLvl2();
void InitSpritesLvl3();
void InitSpritesLvl4();
void InitSpritesLvl5();
void InitSpritesLvl6();
void InitSpritesLvl7();
void InitSpritesLvl8();
void InitSprites();
void InitCollisionsSprites();
void InitAdpcmVbl();

void JoueMusique();

void ObjUpdateOAM(THandle sprite, s32 posx, s32 posy);

void Pause();
void PreNiveau(); //ptite anim de mosaique
void PostNiveau();

void RotationBlocs();
void RotationPiece();
void RotationPAcoin();
void RebondPlateforme();

void ScanEcran();
void SortieChampignon();
void SortieFleur();
void SortieVie();
void SortieEtoile();
void SuperTestEcran();
void SoundTest();

void TestEcran();
void TirBalle();

void UpdateAffichageMario();

void VBLInterruptHandler();

void WorldMap();

void AfficheNiveau11();
void ReAfficheNiveau11();
void AfficheNiveau12();
void ReAfficheNiveau12();
void AfficheNiveau13();
void ReAfficheNiveau13();
void AfficheNiveau14();
void ReAfficheNiveau14();
void AfficheNiveau15();
void ReAfficheNiveau15();
void AfficheNiveau16();
void ReAfficheNiveau16();
void AfficheNiveau17();
void ReAfficheNiveau17();
void AfficheNiveau18();
void ReAfficheNiveau18();

u8 BlocPresentBas(Sprite s); // V�rifie qu'il n'y ai pas de bloc en dessous
u8 VraiBlocPresentBas(Sprite s); // V�rifie qu'il n'y ai pas de "vrai" bloc en dessous (d�cors)
u8 BlocPresentHaut(Sprite s); // V�rifie qu'il n'y ai pas de bloc au dessus
u8 BlocPresentDroite(Sprite s); // V�rifie qu'il n'y ai pas de bloc � droite
u8 BlocPresentGauche(Sprite s); // V�rifie qu'il n'y ai pas de bloc � gauche
u8 InterieurBloc(Sprite s); //V�rifie si le sprite est "dans" un bloc
u8 CollisionMarioPlateforme(Sprite s);
u8 CollisionSprite(Sprite s1, Sprite s2); //V�rifie les collisions inter-sprites
u8 SecretZonePresent(); //V�rifie si mario est sur un tuyau secret
u8 TuyauFin();

void TestSprite(u8 f); //just for test, � virer une fois le dev fini
u8 Testcol (u8 f);

