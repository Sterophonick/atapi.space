#include <mygba.h>
#include <hel2.h>
#include <stdlib.h>
#include "header.h"
#include "graphs.h"


const char CHARORDER[] = 
    " BCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"\
    "opqrstuvwxyz0123456789?������,.-;:�#^+*@"\
    "!\"A%\%&/()=?|\\<>[]{}����";

u16 ATTR_EWRAM g_CharLUT[256]; //pour le texte

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void Initialisation()
{
   varitest = 0;

   mario.course = 1;
   mario.saut = 0;
   am = 1;
   mario.etat = mario_stop;
   mario_invincible = 0;
   hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[512]);
   hel_ObjSetHFlip(mario.sprite,0);
   mario.temp_course = 0;
   inertie_droite = 0;
   inertie_gauche = 0;
   mario.delta_course = 0;
   mario.pos_tab_saut = 0;
   inert_saut = 0;
   inertie = 0;
   inertie_bloc = 0;
   vitesse = lent;
   mario.gravite = gravite_std;
   face_piece = piece;
   face_bloc = bloc_query;
   temp_temps = 0;
   sens_coin = 4;

   if (!puissance)
   {
	   power = petit_mario; //on change l'aspect de mario
	   mario.dec_haut_y = dec_petit_mario_haut_y; //les limites de collision du sprite de mario petit
	   mario.dec_dg_y1 = dec_petit_mario_dg_y1;
	   mario.dec_dg_y2 = dec_petit_mario_dg_y2;
	   mario.dec_dg_y3 = dec_petit_mario_dg_y3;
   }

   for (b = goombad; b <= goombaf; b++)
   {
      sprite[b].score = 100;
      sprite[b].course = 1;
      sprite[b].etat = sprite_inactif;      
   }

   for (b = poisson_osd; b <= poisson_osf; b++)
   {
      sprite[b].score = 100;
      sprite[b].course = 1;
      sprite[b].etat = sprite_inactif;      
   }
   
   koopa.score = 100;
   koopa.course = 1;
   koopa.etat = sprite_inactif;
   
   boum.pos_x = 240;
   boum.pos_y = 160;
   boum.etat = sprite_inactif;
   
   balle.etat = sprite_inactif;
   
   fly.score = 400;
   fly.course = 1;
   fly.etat = sprite_inactif;
   fly.limite = 2;

   abeille.score = 800;
   abeille.etat = sprite_inactif;
   abeille.limite = 2;

   boulet.score = 400;
   boulet.etat = sprite_inactif;
   boulet.limite = 30;
   
   bossgoomba.course = 1;
   bossgoomba.etat = sprite_inactif;
   bossgoomba.limite = 5;
   bossgoomba.gravite = 4;

   hippocampe.score = 400;
   hippocampe.etat = sprite_inactif;
   hippocampe.limite = 2;

   sphinx.score = 800;
   sphinx.etat = sprite_inactif;
   sphinx.limite = 2;
   
   bonus.course = 1;
   bonus.etat = sprite_inactif;

   bulle.course = 1;
   bulle.etat = sprite_inactif;

   fireball.etat = sprite_inactif;
   
   for (b = plateforme1n; b <= plateforme3n; b++)
   {
      sprite[b].etat = sprite_inactif;  
   }
   
   for (b = points1n; b <= points3n; b++)
   {
      sprite[b].etat = sprite_inactif;
      sprite[b].temp_course = 0;
      sprite[b].delta_course = 0;      
   }
   
   for (b = tombanted; b <= tombantef; b++)
   {
      sprite[b].etat = sprite_inactif;
   }
}

void InitSprites()
{
	hel_PalObjLoad16((void*)mario_Palette,0); //chargement des palettes des sprites
	hel_PalObjLoad16((void*)mario_flower_Palette,1);
	hel_PalObjLoad16((void*)mario_invincible1_Palette,2);
	hel_PalObjLoad16((void*)mario_invincible2_Palette,3);
	hel_PalObjLoad16((void*)bloc_piece_Palette,4);	
	hel_PalObjLoad16((void*)balle_Palette,6);	
	hel_PalObjLoad16((void*)bonus_Palette,8);	
	hel_PalObjLoad16((void*)morceau_bloc_Palette,10);	


	for (b = 0; b < 5; b++)
	{
		bloc_morceaux[b].morceau1_sprite = hel_ObjCreate((void*)morceau_bloc_Bitmap,0,0,OBJ_MODE_NORMAL,0,10,0,0,0,2,0,240,160);
		bloc_morceaux[b].morceau2_sprite = hel_ObjCreate((void*)morceau_bloc_Bitmap,0,0,OBJ_MODE_NORMAL,0,10,0,0,0,2,0,240,160);
		bloc_morceaux[b].morceau3_sprite = hel_ObjCreate((void*)morceau_bloc_Bitmap,0,0,OBJ_MODE_NORMAL,0,10,0,0,0,2,0,240,160);
		bloc_morceaux[b].morceau4_sprite = hel_ObjCreate((void*)morceau_bloc_Bitmap,0,0,OBJ_MODE_NORMAL,0,10,0,0,0,2,0,240,160);
	}
	balle.sprite = hel_ObjCreate((void*)balle_Bitmap,0,0,OBJ_MODE_NORMAL,0,6,0,0,0,2,0,240,160);
	cache.sprite = hel_ObjCreate((void*)bonus_Bitmap,0,1,OBJ_MODE_NORMAL,0,8,0,0,0,2,0,240,160); hel_ObjUpdateGfx(cache.sprite,(void*)&bonus_Bitmap[768]);
	bonus.sprite = hel_ObjCreate((void*)bonus_Bitmap,0,1,OBJ_MODE_NORMAL,0,8,0,0,0,2,0,240,160);	
	ascenseur.sprite = hel_ObjCreate((void*)ascenseur_Bitmap,0,1,OBJ_MODE_NORMAL,0,6,0,0,0,2,0,240,160);
	for (b = tombanted; b <= tombantef; b++) sprite[b].sprite = hel_ObjCreate((void*)tombante_Bitmap,0,1,OBJ_MODE_NORMAL,0,5,0,0,0,2,0,240,160);
	for (b = points1n; b <= points3n; b++) sprite[b].sprite = hel_ObjCreate((void*)score_Bitmap,1,0,OBJ_MODE_NORMAL,0,6,0,0,0,2,0,240,160);
	unevie.sprite = hel_ObjCreate((void*)unevie_Bitmap,1,2,OBJ_MODE_NORMAL,0,1,0,0,0,2,0,240,160);
	b_bloc[0].sprite = hel_ObjCreate((void*)bloc_Bitmap,2,2,OBJ_MODE_NORMAL,0,8,0,0,0,2,0,240,160);
	for (b = 0; b < 4; b++) bloc_std[b].sprite = hel_ObjCreate((void*)bloc_std_Bitmap,2,2,OBJ_MODE_NORMAL,0,4,0,0,0,2,0,240,160);
	bloc_piece_plus[0].sprite = hel_ObjCreate((void*)bloc_piece2_Bitmap,2,3,OBJ_MODE_NORMAL,0,4,0,0,0,2,0,240,160);
	for (b = 0; b < 7; b++) bloc_piece[b].sprite = hel_ObjCreate((void*)bloc_piece_Bitmap,2,3,OBJ_MODE_NORMAL,0,4,0,0,0,2,0,240,160);

	mario.sprite = hel_ObjCreate((void*)mario_Bitmap,0,2,OBJ_MODE_NORMAL,0,0,0,0,0,2,0,mario.pos_x,160); //j'affiche mario	

	InitCollisionsSprites();
}

void InitSpritesLvl1()
{
	hel_PalObjLoad16((void*)goomba_Palette,5);
	hel_PalObjLoad16((void*)abeille_Palette,7);
	hel_PalObjLoad16((void*)plateforme_Palette,9);
	hel_PalObjLoad16((void*)koopa_Palette,11);
	hel_PalObjLoad16((void*)bossgoomba_Palette,12);
	hel_PalObjLoad16((void*)sphinx_Palette,13);
	hel_PalObjLoad16((void*)boulet_Palette,14);
	hel_PalObjLoad16((void*)shiggy_Palette,15);


	for (b = goombad; b <= goombaf; b++) sprite[b].sprite = hel_ObjCreate((void*)goomba_Bitmap,0,1,OBJ_MODE_NORMAL,0,5,0,0,0,2,0,240,160);	
	
	abeille.sprite = hel_ObjCreate((void*)abeille_Bitmap,0,2,OBJ_MODE_NORMAL,0,7,0,0,0,2,0,240,160);
	fleche.sprite = hel_ObjCreate((void*)fleche_Bitmap,2,1,OBJ_MODE_NORMAL,0,7,0,0,0,2,0,240,160);

	fly.sprite = hel_ObjCreate((void*)fly_Bitmap,0,2,OBJ_MODE_NORMAL,0,7,0,0,0,2,0,240,160);
	
	sphinx.sprite = hel_ObjCreate((void*)sphinx_Bitmap,0,2,OBJ_MODE_NORMAL,0,13,0,0,0,2,0,240,160);

	bossgoomba.sprite = hel_ObjCreate((void*)bossgoomba_Bitmap,0,3,OBJ_MODE_NORMAL,0,12,0,0,0,2,0,240,160);	
	 
	boulet.sprite = hel_ObjCreate((void*)boulet_Bitmap,1,2,OBJ_MODE_NORMAL,0,14,0,0,0,3,0,240,160);

	koopa.sprite = hel_ObjCreate((void*)koopa_Bitmap,2,2,OBJ_MODE_NORMAL,0,11,0,0,0,2,0,240,160);
	boum.sprite = hel_ObjCreate((void*)boum_Bitmap,1,3,OBJ_MODE_NORMAL,0,11,0,0,0,2,0,240,160);	
	
	for (b = plateforme1n; b <= plateforme3n; b++) sprite[b].sprite = hel_ObjCreate((void*)plateforme_Bitmap,1,3,OBJ_MODE_NORMAL,0,9,0,0,0,2,0,240,160);

	hippocampe.sprite = hel_ObjCreate((void*)hippocampe_Bitmap,2,2,OBJ_MODE_NORMAL,0,9,0,0,0,2,0,240,160);
	
	for (b = poisson_osd; b <= poisson_osf; b++) sprite[b].sprite = hel_ObjCreate((void*)poisson_os_Bitmap,2,2,OBJ_MODE_NORMAL,0,14,0,0,0,2,0,240,160);
	
	bulle.sprite = hel_ObjCreate((void*)bulle_Bitmap,0,0,OBJ_MODE_NORMAL,0,9,0,0,0,2,0,240,160);

	fireball.sprite = hel_ObjCreate((void*)fireball_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,2,0,240,160);		

	mario_map.sprite = hel_ObjCreate((void*)mario_map_Bitmap,2,2,OBJ_MODE_NORMAL,0,13,0,0,0,0,0,0,0);
	hel_ObjUpdateGfx(mario_map.sprite,(void*)&mario_map_Bitmap[512]);
	lvl1.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,9,93);
	lvl2.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,39,93);	
	lvl3.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,69,93);
	lvl4.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,99,93);
	lvl5.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,129,93);
	lvl6.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,159,93);
	lvl7.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,189,93);
	lvl8.sprite = hel_ObjCreate((void*)dot_map_Bitmap,0,0,OBJ_MODE_NORMAL,0,15,0,0,0,0,0,219,93);
	path.sprite = hel_ObjCreate((void*)path_Bitmap,1,1,OBJ_MODE_NORMAL,0,14,0,0,0,0,0,189,94);
	hel_ObjUpdateGfx(path.sprite,(void*)&path_Bitmap[128]);

	
	hel_ObjSetVisibleAll(0);
	hel_ObjSetVisible(mario.sprite,1);	
}

void InitCollisionsSprites() //limites de collisions des sprites
{
	mario.dec_bas_y = dec_mario_bas_y; //limites standard de collision mario <> map
	mario.dec_dg_y4 = dec_mario_dg_y4;
	mario.dec_hb_x1 = dec_mario_hb_x1;
	mario.dec_hb_x2 = dec_mario_hb_x2;
	mario.dec_hb_x3 = dec_mario_hb_x3;
	mario.dec_hb_x4 = dec_mario_hb_x4;
	mario.dec_gauche_x = dec_mario_gauche_x;
	mario.dec_droite_x = dec_mario_droite_x;
	mario.dec_haut_y = dec_petit_mario_haut_y; //les limites de collision du sprite de mario petit
	mario.dec_dg_y1 = dec_petit_mario_dg_y1;
	mario.dec_dg_y2 = dec_petit_mario_dg_y2;
	mario.dec_dg_y3 = dec_petit_mario_dg_y3;

	for (b = goombad; b <= goombaf; b++)
	{
		sprite[b].dec_bas_y = 16;
		sprite[b].dec_dg_y4 = 15;
		sprite[b].dec_hb_x1 = 0;
		sprite[b].dec_hb_x2 = 5;
		sprite[b].dec_hb_x3 = 10;
		sprite[b].dec_hb_x4 = 14;
		sprite[b].dec_gauche_x = 0;
		sprite[b].dec_droite_x = 15;
		sprite[b].dec_haut_y = 1;
		sprite[b].dec_dg_y1 = 0;
		sprite[b].dec_dg_y2 = 7;
		sprite[b].dec_dg_y3 = 10;
	}
   
	koopa.dec_bas_y = 32;
	koopa.dec_dg_y4 = 31;
	koopa.dec_hb_x1 = 0;
	koopa.dec_hb_x2 = 5;
	koopa.dec_hb_x3 = 10;
	koopa.dec_hb_x4 = 14;
	koopa.dec_gauche_x = 0;
	koopa.dec_droite_x = 15;
	koopa.dec_haut_y = 5;
	koopa.dec_dg_y1 = 7;
	koopa.dec_dg_y2 = 15;
	koopa.dec_dg_y3 = 23;
   
	boum.dec_bas_y = 29;
	boum.dec_dg_y4 = 28;
	boum.dec_hb_x1 = 5;
	boum.dec_hb_x2 = 14;
	boum.dec_hb_x3 = 24;
	boum.dec_hb_x4 = 34;
	boum.dec_gauche_x = 4;
	boum.dec_droite_x = 43;
	boum.dec_haut_y = 3;
	boum.dec_dg_y1 = 4;
	boum.dec_dg_y2 = 12;
	boum.dec_dg_y3 = 20;

	balle.dec_bas_y = 8;
	balle.dec_dg_y4 = 7;
	balle.dec_hb_x1 = 0;
	balle.dec_hb_x2 = 3;
	balle.dec_hb_x3 = 5;
	balle.dec_hb_x4 = 7;
	balle.dec_gauche_x = -1;
	balle.dec_droite_x = 8;
	balle.dec_haut_y = -1;
	balle.dec_dg_y1 = 0;
	balle.dec_dg_y2 = 3;
	balle.dec_dg_y3 = 5;

	bulle.dec_bas_y = 8;
	bulle.dec_dg_y4 = 7;
	bulle.dec_hb_x1 = 0;
	bulle.dec_hb_x2 = 3;
	bulle.dec_hb_x3 = 5;
	bulle.dec_hb_x4 = 7;
	bulle.dec_gauche_x = -1;
	bulle.dec_droite_x = 8;
	bulle.dec_haut_y = -1;
	bulle.dec_dg_y1 = 0;
	bulle.dec_dg_y2 = 3;
	bulle.dec_dg_y3 = 5;

	fireball.dec_bas_y = 8;
	fireball.dec_dg_y4 = 7;
	fireball.dec_hb_x1 = 0;
	fireball.dec_hb_x2 = 3;
	fireball.dec_hb_x3 = 5;
	fireball.dec_hb_x4 = 7;
	fireball.dec_gauche_x = -1;
	fireball.dec_droite_x = 8;
	fireball.dec_haut_y = -1;
	fireball.dec_dg_y1 = 0;
	fireball.dec_dg_y2 = 3;
	fireball.dec_dg_y3 = 5;

	fly.dec_bas_y = 32;
	fly.dec_dg_y4 = 31;
	fly.dec_hb_x1 = 6;
	fly.dec_hb_x2 = 12;
	fly.dec_hb_x3 = 20;
	fly.dec_hb_x4 = 24;
	fly.dec_gauche_x = 5;
	fly.dec_droite_x = 25;
	fly.dec_haut_y = 8;
	fly.dec_dg_y1 = 9;
	fly.dec_dg_y2 = 15;
	fly.dec_dg_y3 = 23;

	bossgoomba.dec_bas_y = 64;
	bossgoomba.dec_dg_y4 = 63;
	bossgoomba.dec_hb_x1 = 13;
	bossgoomba.dec_hb_x2 = 24;
	bossgoomba.dec_hb_x3 = 36;
	bossgoomba.dec_hb_x4 = 48;
	bossgoomba.dec_gauche_x = 12;
	bossgoomba.dec_droite_x = 51;
	bossgoomba.dec_haut_y = 19;
	bossgoomba.dec_dg_y1 = 20;
	bossgoomba.dec_dg_y2 = 35;
	bossgoomba.dec_dg_y3 = 50;
   
	bonus.dec_bas_y = 16;
	bonus.dec_dg_y4 = 15;
	bonus.dec_hb_x1 = 0;
	bonus.dec_hb_x2 = 5;
	bonus.dec_hb_x3 = 10;
	bonus.dec_hb_x4 = 15;
	bonus.dec_gauche_x = -1;
	bonus.dec_droite_x = 16;
	bonus.dec_haut_y = -1;
	bonus.dec_dg_y1 = 0;
	bonus.dec_dg_y2 = 7;
	bonus.dec_dg_y3 = 10;

	ascenseur.dec_bas_y = 10;
	ascenseur.dec_dg_y4 = 9;
	ascenseur.dec_hb_x1 = 0;
	ascenseur.dec_hb_x2 = 5;
	ascenseur.dec_hb_x3 = 10;
	ascenseur.dec_hb_x4 = 15;
	ascenseur.dec_gauche_x = -1;
	ascenseur.dec_droite_x = 16;
	ascenseur.dec_haut_y = -1;
	ascenseur.dec_dg_y1 = 0;
	ascenseur.dec_dg_y2 = 4;
	ascenseur.dec_dg_y3 = 7;

	for (b = plateforme1n; b <= plateforme3n; b++)
	{
		sprite[b].dec_bas_y = 11;
		sprite[b].dec_dg_y4 = 10;
		sprite[b].dec_hb_x1 = 0;
		sprite[b].dec_hb_x2 = 16;
		//sprite[b].dec_hb_x3 = 32;
		//sprite[b].dec_hb_x4 = 40;
		sprite[b].dec_gauche_x = -1;
		//sprite[b].dec_droite_x = 48;
		sprite[b].dec_haut_y = -1;
		sprite[b].dec_dg_y1 = 0;
		sprite[b].dec_dg_y2 = 3;
		sprite[b].dec_dg_y3 = 6;
	}
   
	for (b = tombanted; b <= tombantef; b++)
	{
		sprite[b].dec_bas_y = 16;
		sprite[b].dec_dg_y4 = 15;
		sprite[b].dec_hb_x1 = 0;
		sprite[b].dec_hb_x2 = 5;
		sprite[b].dec_hb_x3 = 10;
		sprite[b].dec_hb_x4 = 15;
		sprite[b].dec_gauche_x = -1;
		sprite[b].dec_droite_x = 16;
		sprite[b].dec_haut_y = -1;
		sprite[b].dec_dg_y1 = 0;
		sprite[b].dec_dg_y2 = 5;
		sprite[b].dec_dg_y3 = 10;
	}

	abeille.dec_bas_y = 28;
	abeille.dec_dg_y4 = 27;
	abeille.dec_hb_x1 = 3;
	abeille.dec_hb_x2 = 12;
	abeille.dec_hb_x3 = 20;
	abeille.dec_hb_x4 = 27;
	abeille.dec_gauche_x = 2;
	abeille.dec_droite_x = 28;
	abeille.dec_haut_y = 4;
	abeille.dec_dg_y1 = 5;
	abeille.dec_dg_y2 = 13;
	abeille.dec_dg_y3 = 23;

	fleche.dec_bas_y = 27;
	fleche.dec_dg_y4 = 26;
	fleche.dec_hb_x1 = 0;
	fleche.dec_hb_x2 = 3;
	fleche.dec_hb_x3 = 4;
	fleche.dec_hb_x4 = 5;
	fleche.dec_gauche_x = -1;
	fleche.dec_droite_x = 6;
	fleche.dec_haut_y = 0;
	fleche.dec_dg_y1 = 1;
	fleche.dec_dg_y2 = 13;
	fleche.dec_dg_y3 = 23;

	boulet.dec_bas_y = 16;
	boulet.dec_dg_y4 = 15;
	boulet.dec_hb_x1 = 0;
	boulet.dec_hb_x2 = 7;
	boulet.dec_hb_x3 = 14;
	boulet.dec_hb_x4 = 19;
	boulet.dec_gauche_x = -1;
	boulet.dec_droite_x = 20;
	boulet.dec_haut_y = 5;
	boulet.dec_dg_y1 = 6;
	boulet.dec_dg_y2 = 13;
	boulet.dec_dg_y3 = 14;

	hippocampe.dec_bas_y = 29;
	hippocampe.dec_dg_y4 = 28;
	hippocampe.dec_hb_x1 = 3;
	hippocampe.dec_hb_x2 = 7;
	hippocampe.dec_hb_x3 = 11;
	hippocampe.dec_hb_x4 = 15;
	hippocampe.dec_gauche_x = 2;
	hippocampe.dec_droite_x = 16;
	hippocampe.dec_haut_y = 2;
	hippocampe.dec_dg_y1 = 3;
	hippocampe.dec_dg_y2 = 13;
	hippocampe.dec_dg_y3 = 23;

	for (b = poisson_osd; b <= poisson_osf; b++)
	{
		sprite[b].dec_bas_y = 32;
		sprite[b].dec_dg_y4 = 31;
		sprite[b].dec_hb_x1 = 3;
		sprite[b].dec_hb_x2 = 7;
		sprite[b].dec_hb_x3 = 9;
		sprite[b].dec_hb_x4 = 11;
		sprite[b].dec_gauche_x = 2;
		sprite[b].dec_droite_x = 12;
		sprite[b].dec_haut_y = 4;
		sprite[b].dec_dg_y1 = 5;
		sprite[b].dec_dg_y2 = 13;
		sprite[b].dec_dg_y3 = 23;
	}

	sphinx.dec_bas_y = 32;
	sphinx.dec_dg_y4 = 31;
	sphinx.dec_hb_x1 = 3;
	sphinx.dec_hb_x2 = 12;
	sphinx.dec_hb_x3 = 20;
	sphinx.dec_hb_x4 = 29;
	sphinx.dec_gauche_x = 2;
	sphinx.dec_droite_x = 30;
	sphinx.dec_haut_y = 0;
	sphinx.dec_dg_y1 = 1;
	sphinx.dec_dg_y2 = 13;
	sphinx.dec_dg_y3 = 23;
}


void InitAdpcmVbl()
{
   hel_IntrStartHandler(INT_TYPE_VBL, (void*)VBLInterruptHandler);

   AdpcmInit(2);
}


void InitTexte(u8 level)
{
	if (level == 1) ham_bg[0].ti = ham_InitTileSet((void*)charset1_tiles, SIZEOF_16BIT(charset1_tiles), 1, 1);
	else if (level == 2) ham_bg[0].ti = ham_InitTileSet((void*)charset2_tiles, SIZEOF_16BIT(charset2_tiles), 1, 1);
	else if (level == 3) ham_bg[0].ti = ham_InitTileSet((void*)charset3_tiles, SIZEOF_16BIT(charset3_tiles), 1, 1);
	else if (level == 4) ham_bg[0].ti = ham_InitTileSet((void*)charset4_tiles, SIZEOF_16BIT(charset4_tiles), 1, 1);
	else if (level == 5) ham_bg[0].ti = ham_InitTileSet((void*)charset5_tiles, SIZEOF_16BIT(charset5_tiles), 1, 1);
	else if (level == 6) ham_bg[0].ti = ham_InitTileSet((void*)charset6_tiles, SIZEOF_16BIT(charset6_tiles), 1, 1);
	else if (level == 7) ham_bg[0].ti = ham_InitTileSet((void*)charset7_tiles, SIZEOF_16BIT(charset7_tiles), 1, 1);
	else if (level == 8) ham_bg[0].ti = ham_InitTileSet((void*)charset8_tiles, SIZEOF_16BIT(charset8_tiles), 1, 1);

    ham_bg[0].mi = ham_InitMapEmptySet(MAP_SIZE_32X32, FALSE);

	hel_BgTextCreate(0,1,1,(void*)charset2_map,CHARORDER,g_CharLUT,BGTEXT_FLAGS_GENERATELUT);  
	ham_InitBg(0, TRUE, 0, FALSE);
   
    hel_BgTextPrintF(0,1,0,0,"#^;"); //le M de mario
    hel_BgTextPrintF(0,7,0,0,"�"); //le dessin de la pi�ce
    hel_BgTextPrintF(0,11,0,0,":"); //le dessin de l'horloge
    hel_BgTextPrintF(0,16,0,0,"+*@"); //monde
    //hel_BgTextPrintF(3,21,0,80); //le "-"
   
    //hel_BgTextPrintF(3,20,0,63); //les 2 "1"
    //hel_BgTextPrintF(3,22,0,63);
}

void InitTexteIntro()
{
	ham_bg[1].ti = ham_InitTileSet((void*)charset_intro_tiles, SIZEOF_16BIT(charset_intro_tiles), 1, 1);
	ham_bg[1].mi = ham_InitMapEmptySet(MAP_SIZE_32X32, FALSE);

	hel_BgTextCreate(1,1,1,(void*)charset_intro_map,CHARORDER,g_CharLUT,BGTEXT_FLAGS_GENERATELUT);  
	ham_InitBg(1, TRUE, 0, FALSE);
}

void WorldMap()
{	
	hel_PalObjLoad16((void*)mario_map_Palette,13);
	hel_PalObjLoad16((void*)path_Palette,14);
	hel_PalObjLoad16((void*)dot_map_Palette,15);

	//on ajoute 1 si on a fini le niveau
	if (num_niveau == 1 && ((quete%10000000 - quete%1000000)/1000000 == 0)) {quete += 1000000; total_levels = 1;}
	if (num_niveau == 2 && ((quete%1000000 - quete%100000)/100000 == 0)) {quete += 100000; total_levels = 2;}
	if (num_niveau == 3 && ((quete%100000 - quete%10000)/10000 == 0)) {quete += 10000; total_levels = 3;}
	if (num_niveau == 4 && ((quete%10000 - quete%1000)/1000 == 0)) {quete += 1000; total_levels = 4;}
	if (num_niveau == 5 && ((quete%1000 - quete%100)/100 == 0)) {quete += 100; total_levels = 5;}
	if (num_niveau == 6 && ((quete%100 - quete%10)/10 == 0)) {quete += 10; total_levels = 6;}
	if (quete == 22222220) {quete += 2; total_levels = 7;}
	if (total_levels == 7) hel_ObjUpdateGfx(path.sprite,(void*)&path_Bitmap[0]);

	ham_SaveIntToRAM("total_levels",total_levels); //on sauvegarde
	ham_SaveIntToRAM("quete",quete);
	
	if ((quete%100000000 - quete%10000000)/10000000 == 0) hel_ObjUpdateGfx(lvl1.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%100000000 - quete%10000000)/10000000 == 1) hel_ObjUpdateGfx(lvl1.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%100000000 - quete%10000000)/10000000 == 2) hel_ObjUpdateGfx(lvl1.sprite,(void*)&dot_map_Bitmap[64]);

	if ((quete%10000000 - quete%1000000)/1000000 == 0) hel_ObjUpdateGfx(lvl2.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%10000000 - quete%1000000)/1000000 == 1) hel_ObjUpdateGfx(lvl2.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%10000000 - quete%1000000)/1000000 == 2) hel_ObjUpdateGfx(lvl2.sprite,(void*)&dot_map_Bitmap[64]);

	if ((quete%1000000 - quete%100000)/100000 == 0) hel_ObjUpdateGfx(lvl3.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%1000000 - quete%100000)/100000 == 1) hel_ObjUpdateGfx(lvl3.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%1000000 - quete%100000)/100000 == 2) hel_ObjUpdateGfx(lvl3.sprite,(void*)&dot_map_Bitmap[64]);

	if ((quete%100000 - quete%10000)/10000 == 0) hel_ObjUpdateGfx(lvl4.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%100000 - quete%10000)/10000 == 1) hel_ObjUpdateGfx(lvl4.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%100000 - quete%10000)/10000 == 2) hel_ObjUpdateGfx(lvl4.sprite,(void*)&dot_map_Bitmap[64]);

	if ((quete%10000 - quete%1000)/1000 == 0) hel_ObjUpdateGfx(lvl5.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%10000 - quete%1000)/1000 == 1) hel_ObjUpdateGfx(lvl5.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%10000 - quete%1000)/1000 == 2) hel_ObjUpdateGfx(lvl5.sprite,(void*)&dot_map_Bitmap[64]);
	
	if ((quete%1000 - quete%100)/100 == 0) hel_ObjUpdateGfx(lvl6.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%1000 - quete%100)/100 == 1) hel_ObjUpdateGfx(lvl6.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%1000 - quete%100)/100 == 2) hel_ObjUpdateGfx(lvl6.sprite,(void*)&dot_map_Bitmap[64]);

	if ((quete%100 - quete%10)/10 == 0) hel_ObjUpdateGfx(lvl7.sprite,(void*)&dot_map_Bitmap[32]);
	else if ((quete%100 - quete%10)/10 == 1) hel_ObjUpdateGfx(lvl7.sprite,(void*)&dot_map_Bitmap[0]);
	else if ((quete%100 - quete%10)/10 == 2) hel_ObjUpdateGfx(lvl7.sprite,(void*)&dot_map_Bitmap[64]);

	if (quete%10 == 0) hel_ObjUpdateGfx(lvl8.sprite,(void*)&dot_map_Bitmap[32]);
	else if (quete%10 == 1) hel_ObjUpdateGfx(lvl8.sprite,(void*)&dot_map_Bitmap[0]);
	else if (quete%10 == 2) hel_ObjUpdateGfx(lvl8.sprite,(void*)&dot_map_Bitmap[64]);

	if (!puissance) hel_ObjUpdateGfx(mario_map.sprite,(void*)&mario_map_Bitmap[512]);
	else if (puissance == 1) hel_ObjUpdateGfx(mario_map.sprite,(void*)&mario_map_Bitmap[256]);
	else if (puissance == 2) hel_ObjUpdateGfx(mario_map.sprite,(void*)&mario_map_Bitmap[0]);
	hel_ObjSetXY(mario_map.sprite,mario_map.pos_x,mario_map.pos_y);

	hel_ObjSetVisible(lvl1.sprite,1);
	hel_ObjSetVisible(lvl2.sprite,1);
	hel_ObjSetVisible(lvl3.sprite,1);
	hel_ObjSetVisible(lvl4.sprite,1);
	hel_ObjSetVisible(lvl5.sprite,1);
	hel_ObjSetVisible(lvl6.sprite,1);
	hel_ObjSetVisible(lvl7.sprite,1);
	hel_ObjSetVisible(lvl8.sprite,1);
	hel_ObjSetVisible(mario_map.sprite,1);
	hel_ObjSetVisible(path.sprite,1);

	hel_PalBgLoad256((void*)world_map_palette);
	ham_bg[0].ti = ham_InitTileSet((void*)&world_map_tiles,SIZEOF_16BIT(world_map_tiles),1,1);
	hel_MapCreate(0, 30, 20, (void*)world_map_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(0,1,1,0);

	AdpcmStart(&ADPCM_carte,-1,0);

	FadingExit();

	//on d�place mario que si il a le droit
	if (num_niveau > 0 && num_niveau < 7 && num_niveau <= total_levels) AnimMarioMapDroite();
	else if (num_niveau == 7 && quete == 22222222) AnimMarioMapDroite();
	else if (num_niveau == 7 && quete != 22222222) num_niveau--;

	title_temp = 1;
	while (title_temp > 0) 
	{
		hel_PadCapture();
		title_temp++;
		if (title_temp > 100) title_temp = 1;
		if (hel_PadQuery()->Pressed.Left && num_niveau > 0) {AnimMarioMapGauche(); num_niveau--;}
		if (hel_PadQuery()->Pressed.Right && num_niveau < total_levels) {AnimMarioMapDroite(); num_niveau++;}
		if (hel_PadQuery()->Pressed.Start || hel_PadQuery()->Pressed.A) {title_temp = 0; AdpcmStart(&ADPCM_startmap,1,1);}
	}

	Fading();

	AdpcmStop(0);	

	ham_DeInitTileSet(ham_bg[0].ti);
    ham_ResetBg();
	hel_ObjSetVisibleAll(0);
	hel_ObjSetVisible(mario.sprite,1);
	hel_PalObjLoad16((void*)sphinx_Palette,13);
	hel_PalObjLoad16((void*)boulet_Palette,14);
	hel_PalObjLoad16((void*)shiggy_Palette,15);

	FadingExit();	
}

void ChoppePAcoin()
{
	if (num_niveau == 1 && ((quete%100000000 - quete%10000000)/10000000 < 2)) quete += 10000000;
	if (num_niveau == 2 && ((quete%10000000 - quete%1000000)/1000000 < 2)) quete += 1000000;
	if (num_niveau == 3 && ((quete%1000000 - quete%100000)/100000 < 2)) quete += 100000;
	if (num_niveau == 4 && ((quete%100000 - quete%10000)/10000 < 2)) quete += 10000;
	if (num_niveau == 5 && ((quete%10000 - quete%1000)/1000 < 2)) quete += 1000;
	if (num_niveau == 6 && ((quete%1000 - quete%100)/100 < 2)) quete += 100;
	if (num_niveau == 7 && ((quete%100 - quete%10)/10 < 2)) quete += 10;
}

void AnimMarioMapDroite()
{
	//anim de mario se d�pla�ant de gauche � droite
	temps = 0;
	while (temps < 30)
	{
		temps++;
		mario_map.pos_x++;
		Pause(150);
		hel_ObjSetXY(mario_map.sprite,mario_map.pos_x,mario_map.pos_y);
	}
	AdpcmStart(&ADPCM_bipmap,1,1);
}

void AnimMarioMapGauche()
{
	//anim de mario se d�pla�ant de droite � gauche
	temps = 0;
	while (temps < 30)
	{
		temps++;
		mario_map.pos_x--;
		Pause(150);
		hel_ObjSetXY(mario_map.sprite,mario_map.pos_x,mario_map.pos_y);
	}
	AdpcmStart(&ADPCM_bipmap,1,1);
}
