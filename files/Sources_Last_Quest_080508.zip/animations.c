#include <mygba.h>
#include "header.h"


const unsigned short tab_mort[27] = {5,5,4,4,4,4,4,4,4,3,3,3,3,3,3,2,2,2,2,2,2,2,1,1,1,0,0}; // le tableau de mort
const unsigned short tab_anim_gp[23] = {0,17,0,9,0,17,0,9,0,17,0,1,0,17,0,1,0,17,0,1,0,17,0};
const unsigned short tab_anim_fleur[28] = {1,3,0,1,3,0,1,3,0,1,3,0,1,3,0,1,3,0,1,3,0,1,3,0,1,3,0,1};
const unsigned short tab_anim_invincible[220] = {2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0,2,3,2,0};
const signed short tab_bonus[80] = {0,-3,1,-3,0,-3,1,-3,0,-3,1,-3,0,-2,1,-2,0,-2,1,-2,0,-2,1,-1,0,-1,1,-1,0,-1,1,-1,0,0,1,-1,0,0,1,0,0,0,1,1,0,0,1,1,0,1,1,1,0,2,1,1,0,2,1,3,0,2,1,3,0,2,1,3,0,3,1,3,0,3,1,3,0,4,1,4};
const bool tab_anim_clignote[32] = {0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1};
const signed short tab_anim_explo_y12[36] = {0,-5,-5,-5,-4,-4,-4,-4,-3,-3,-3,-3,-2,-2,-2,-2,-1,-1,-1,-1,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4};
const signed short tab_anim_explo_y34[36] = {0,-3,-3,-3,-2,-2,-2,-2,-1,-1,-1,-1,0,0,0,0,1,1,1,1,2,2,2,5,3,3,3,4,4,4,4,5,5,5,5,6};
const unsigned short tab_anim_explo_x[36] = {0,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1,1,1,0,1,1,1,0,1,1,1,0,1};
const unsigned short tab_anim_explo_etat[16] = {0,0,1,1,5,5,5,5,2,2,3,3,4,4,4,4};


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void AnimMarioMarche()
{
   if (mario_clignote) // si mario clignote, on s'en fout de la tempo, affiche mon sprite maintenant !
   {
      if (mario.course == -1) hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(512 + power) * am]);
      else hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(0 + power) * am]);
   }

   mario.temp_course++; // petite tempo d'anim de la course
   if (mario.temp_course == mario_temp_course)
   {
      mario.course *= -1; // il n'y a que 2 positions dans l'anim donc...
      if (mario.course == -1) hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(512 + power) * am]);
      else hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(0 + power) * am]);
      mario.temp_course = 0;
   }
}

void AnimMortMario()
{
   hel_ObjSetPalette(mario.sprite,0); //on remet la bonne palette
   hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[4096]);
   mario.temp_mort++;
   if (mario.temp_mort == 1) AdpcmStart(&ADPCM_frein,1,0); //on arrete la musique avec un petit son
   if (mario.temp_mort == 47) AdpcmStart(&ADPCM_mort,1,1); //la petite musique de la mort
   if (mario.temp_mort > 48)
   {
      mario.temp_mort = 49;
      if (mario.anim_mort < 27) mario.anim_mort += mario.dep_y;
      if (mario.anim_mort == 26) mario.dep_y = -1;
      if (mario.anim_mort < 2) mario.anim_mort = 2;
      mario.pos_y -= mario.dep_y * tab_mort[mario.anim_mort];
      if (mario.pos_y > 180) MortMario(600);
      hel_ObjSetY(mario.sprite,mario.pos_y);
   }
}

void AnimMarioGrandPetit()
{
   hel_ObjSetPalette(mario.sprite,0); //on remet la bonne palette
   mario.temp_mort++;
   if (mario.temp_mort >= 2)
   {
      mario.temp_mort = 0;
	  if (!mario.anim_mort) AdpcmStart(&ADPCM_rapetir,1,1);
      hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[tab_anim_gp[mario.anim_mort] * 512]);
      mario.anim_mort++;
      if (mario.anim_mort == 23)
      {
         mario.etat = mario_stop;
         power = petit_mario; //on change l'aspect de mario
         puissance = 0;
         mario.dec_haut_y = dec_petit_mario_haut_y; //les limites de collision du sprite de mario petit
         mario.dec_dg_y1 = dec_petit_mario_dg_y1;
         mario.dec_dg_y2 = dec_petit_mario_dg_y2;
         mario.dec_dg_y3 = dec_petit_mario_dg_y3;

         mario.anim_mort = 0; //fin de l'anim de retrecissement, mario peut bouger et est invincible (clignote)
         mario_clignote = 1;
         mario_temp_clignote = 0;
         mario_anim_clignote = 0;
      }
   }
}

void AnimMarioPetitGrand()
{
   mario.temp_mort++;
   if (mario.temp_mort >= 2)
   {
      mario.temp_mort = 0;
      if (mario.anim_mort == 22) AdpcmStart(&ADPCM_grandir,1,1);
      if (tab_anim_gp[mario.anim_mort] != 0) hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[tab_anim_gp[mario.anim_mort] * 512]); //je lis le tableau du retrecissement � l'envers en �vitant les valeurs "vides"
      mario.anim_mort--;
      if (mario.anim_mort == -1)
      {
         mario.etat = mario_stop;
         power = super_mario; //on change l'aspect de mario
         puissance = 1;
         mario.dec_haut_y = dec_grand_mario_haut_y; //les limites de collision du sprite de mario grand debout
         mario.dec_dg_y1 = dec_grand_mario_dg_y1;
         mario.dec_dg_y2 = dec_grand_mario_dg_y2;
         mario.dec_dg_y3 = dec_grand_mario_dg_y3;

         mario.anim_mort = 0;
      }
   }
}

void AnimMarioFleur()
{
   mario.temp_mort++;
   if (mario.temp_mort >= 2)
   {
      mario.temp_mort = 0;
      if (!mario.anim_mort) AdpcmStart(&ADPCM_grandir,1,1);
      hel_ObjSetPalette(mario.sprite,tab_anim_fleur[mario.anim_mort]); //pour cette anim je modifie juste la palette
      mario.anim_mort++;
      if (mario.anim_mort == 28)
      {
         puissance = 2; //mario flower
         mario.etat = mario_stop;
         mario.anim_mort = 0;
      }
   }
}

void AnimMarioClignote()
{
   mario_temp_clignote++;
   if (mario_temp_clignote >= 2)
   {
      mario_temp_clignote = 0;
      am = tab_anim_clignote[mario_anim_clignote]; // 0 -> "j'efface" mario en affichant la premiere frame du spriteset : rien / 1 -> je l'affiche en affichant ce qui est cens� etre affich� a ce moment
      mario_anim_clignote++;
      if (mario_anim_clignote == 32) mario_clignote = 0;
   }
}

void AnimMarioInvincible()
{
   mario_temp_clignote++;
   if (mario_temp_clignote >= 4)
   {
      mario_temp_clignote = 0;
      hel_ObjSetPalette(mario.sprite,tab_anim_invincible[mario_anim_clignote]); //pour cette anim je modifie juste la palette
      mario_anim_clignote++;
      if (mario_anim_clignote == 220)
      {
         play_music = 1; // on balance la musique du niveau
         mario_invincible = 0; //on stoppe l'anim
         if (puissance == 2) hel_ObjSetPalette(mario.sprite,1); //et on met la bonne palette au cas mario flower
      }
   }
}


void AnimMarcheGoomba()
{
   if (BlocPresentBas(sprite[b]) && sprite[b].etat == sprite_vivant) sprite[b].temp_course++;
   if (sprite[b].temp_course >= 8) //animation de la marche des goombas
   {
      sprite[b].course *= -1; //toujours que 2 anims pour la marche des goombas
      if (sprite[b].course == -1) 
	  {
		  if (num_niveau == 2 || num_niveau == 5 || num_niveau == 7) {hel_ObjSetPalette(sprite[b].sprite,15); hel_ObjUpdateGfx(sprite[b].sprite,(void*)&shiggy_Bitmap[0]);}
		  else {hel_ObjSetPalette(sprite[b].sprite,5); hel_ObjUpdateGfx(sprite[b].sprite,(void*)&goomba_Bitmap[0]);}
	  }
      else 
	  {
		  if (num_niveau == 2 || num_niveau == 5 || num_niveau == 7) {hel_ObjSetPalette(sprite[b].sprite,15); hel_ObjUpdateGfx(sprite[b].sprite,(void*)&shiggy_Bitmap[128]);}
		  else {hel_ObjSetPalette(sprite[b].sprite,5); hel_ObjUpdateGfx(sprite[b].sprite,(void*)&goomba_Bitmap[128]);}
	  }
      sprite[b].temp_course = 0;
   }
}

void AnimMarcheKoopa()
{
   if (koopa.etat == sprite_vivant) koopa.temp_course++;
   if (koopa.temp_course >= 12) //animation de la marche des koopas
   {
      koopa.course *= -1; //toujours que 2 anims pour la marche des koopas
      if (koopa.course == -1) hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[0]);
      else hel_ObjUpdateGfx(koopa.sprite,(void*)&koopa_Bitmap[256]);
      koopa.temp_course = 0;
   }
}

void AnimExplosionKoopa()
{
   boum.temp_mort++;
   if (boum.temp_mort >= 5)
   {
      boum.temp_mort = 0;
      boum.anim_mort++;
      
      if (boum.anim_mort < 10) //clignotement du "boum"
      {
          boum.dep_x *= -1;
          if (boum.dep_x == -1) hel_ObjUpdateGfx(boum.sprite,(void*)&boum_Bitmap[0]);
          if (boum.dep_x == 1) hel_ObjUpdateGfx(boum.sprite,(void*)&boum_Bitmap[1024]);
       }
       if (boum.anim_mort >= 10) //fin d'anim du "boum"
       {
          boum.dep_x = 0;
          boum.etat = sprite_inactif;
		  boum.pos_x = 240;
		  boum.pos_y = 160;
          hel_ObjSetVisible(boum.sprite,0);
       }
    }
    if (!mario_clignote && mario.etat != mario_gp && CollisionSprite(mario,boum)) //si mario se cogne � une explosion...
    {
       if (!puissance) //...mario meurt...
       {
          mario.etat = mario_mort;
          mario.temp_mort = 0;
          mario.anim_mort = 0;
          mario.dep_y = 1;
       }
       else //...ou retrecit
       {
          mario.etat = mario_gp;
          mario.temp_mort = 0;
          mario.anim_mort = 0;
       }
    }

	//if (hel_ObjExists(boum.sprite))
	{
		hel_ObjSetXY(boum.sprite,(boum.pos_x-Ptx),(boum.pos_y-Pty));
		if ((boum.pos_x-Ptx) < -54 || (boum.pos_x-Ptx) > 240 || (boum.pos_y-Pty) < -54 || (boum.pos_y-Pty) > 160) hel_ObjSetXY(boum.sprite,240,160);		
	}
}
      
void AnimAilesFly()
{
	if (fly.etat == sprite_vivant) fly.temp_course++;
	if (fly.temp_course >= 10)
	{
		fly.course *= -1;
		if (!fly.pos_tab_saut)
		{
			if (fly.course == -1) hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[512]);
			else hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[0]);
		}
		else
		{
			if (fly.dep_x == -1)
			{
				if (fly.course == -1) hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[1536]);
				else hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[1024]);
			}
			if (fly.dep_x == 1)
			{
				if (fly.course == -1) hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[2560]);
				else hel_ObjUpdateGfx(fly.sprite,(void*)&fly_Bitmap[2048]);
			}
		}
		fly.temp_course = 0;
	}
}

void AnimAilesAbeille()
{
	if (abeille.etat == sprite_vivant) abeille.temp_course++;
	if (abeille.temp_course >= 10)
	{
		hel_ObjUpdateGfx(abeille.sprite,(void*)&abeille_Bitmap[(abeille.pos_tab_saut*1536)+(abeille.course*512)]);
		abeille.course++;
		if (abeille.course >= 3) abeille.course = 0;
		abeille.temp_course = 0;
	}
}

void AnimMarcheBoss()
{
	if (bossgoomba.etat == sprite_vivant) bossgoomba.temp_course++;
	if (bossgoomba.temp_course >= (9-bossgoomba.vitesse))
	{
		hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[(bossgoomba.pos_tab_saut*8192)+(bossgoomba.course*2048)]);
		bossgoomba.course++;
		if (bossgoomba.course >= 4) bossgoomba.course = 0;
		bossgoomba.temp_course = 0;
	}
}

void AnimBulle()
{
	bulle.delta_course++;
	if (bulle.delta_course >= 10)
	{
		bulle.delta_course = 0;
		bulle.course *= -1;
		if (bulle.course == -1) hel_ObjUpdateGfx(bulle.sprite,(void*)&bulle_Bitmap[32]);
		else {hel_ObjUpdateGfx(bulle.sprite,(void*)&bulle_Bitmap[0]); bulle.delta_course = 5;}
	}
}

void AnimPoissonV()
{
	sprite[b].delta_course++;
	if (sprite[b].delta_course >= 5)
	{
		sprite[b].delta_course = 0;
		sprite[b].course *= -1;
		if (sprite[b].course == -1) hel_ObjUpdateGfx(sprite[b].sprite,(void*)&poisson_os_Bitmap[256]);
		else hel_ObjUpdateGfx(sprite[b].sprite,(void*)&poisson_os_Bitmap[0]);
	}
}

void AnimBoulet()
{
	if (boulet.etat == sprite_vivant) boulet.temp_course++;
	if (boulet.temp_course >= 3)
	{
		hel_ObjUpdateGfx(boulet.sprite,(void*)&boulet_Bitmap[boulet.course*256]);
		boulet.course++;
		if (boulet.course >= 3) {boulet.course = 0; hel_ObjSetPrio(boulet.sprite,0);}
		boulet.temp_course = 0;
	}
}

void AnimFireball()
{
	if (fireball.etat == sprite_vivant) fireball.temp_course++;
	if (fireball.temp_course >= 5)
	{
		hel_ObjUpdateGfx(fireball.sprite,(void*)&fireball_Bitmap[fireball.course*32]);
		fireball.course++;
		if (fireball.course > 1) fireball.course = 0;
		fireball.temp_course = 0;
	}
}

void AnimSphinx()
{
	if (sphinx.etat == sprite_vivant) sphinx.pos_tab_saut++;
	if (sphinx.pos_tab_saut >= 8)
	{
		sphinx.pos_tab_saut = 0;
		hel_ObjUpdateGfx(sphinx.sprite,(void*)&sphinx_Bitmap[sphinx.course*512]);
		sphinx.course++;
		if (sphinx.course >= 3) {sphinx.course = 0; sphinx.pos_tab_saut = -90;}
		
	}
}

void AnimMortFoes2(u8 f)
{	
	if (sprite[f].anim_mort == 0) hel_ObjSetVFlip(sprite[f].sprite,1); //je le renverse
	sprite[f].anim_mort += 2; //toujours cette histoire de 2 valeurs � lire dans un seul tableau
	if (sprite[f].anim_mort == 80) sprite[f].anim_mort = 76; //je conserve la derniere case du tableau
	sprite[f].pos_x += sprite[f].dep_x * tab_bonus[sprite[f].anim_mort];
	sprite[f].pos_y += tab_bonus[sprite[f].anim_mort + 1]; //+1 car j'ai un seul tableau mais 2 valeurs � lire
	if ((sprite[f].pos_y-Pty) >= 180)  //si il sort de l'�cran
	{
		hel_ObjSetVFlip(sprite[f].sprite,0); //je le remet dans le bon sens
		sprite[f].etat = sprite_inactif;
		sprite[f].anim_mort = 0;
		sprite[f].pos_y = 320;
		hel_ObjSetVisible(sprite[f].sprite,0);
		//SuperTestEcran();
	}
	//if (hel_ObjExists(sprite[f].sprite))
	{
		hel_ObjSetXY(sprite[f].sprite,(sprite[f].pos_x-Ptx),(sprite[f].pos_y-Pty));
		if ((sprite[f].pos_x-Ptx) < -54 || (sprite[f].pos_x-Ptx) > 240 || (sprite[f].pos_y-Pty) < -54 || (sprite[f].pos_y-Pty) > 160) hel_ObjSetXY(sprite[f].sprite,240,160);		
	}
}

void AnimFleur()
{
   bonus.temp_mort++;
   if (bonus.temp_mort >= 8) //animation de la fleur
   {
      bonus.course *= -1; //toujours que 2 anims
      if (bonus.course == -1) hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[128]);
      else hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[256]);
      bonus.temp_mort = 0;
   }
}

void AnimEtoile()
{
   bonus.temp_mort++;
   if (bonus.temp_mort == 2) hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[512]);
   if (bonus.temp_mort > 6) //clignotement de l'�toile
   {
      hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[640]);
      bonus.temp_mort = 0;
   }
}


void RotationBlocs() //les blocs query doivent tourner ? c'est ici ! //EN_IWRAM
{
    for (b = 0; b < nbr_bloc; b++)
	{
		carte_map[ns_blocs[b].tile_y][ns_blocs[b].tile_x] = (t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * face_bloc) + (!t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * carte_map[ns_blocs[b].tile_y][ns_blocs[b].tile_x]); //on affiche face_bloc qui tourne OU on change rien
		carte_map[ns_blocs[b].tile_y][ns_blocs[b].tile_x+1] = (t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * (face_bloc + 1)) + (!t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * carte_map[ns_blocs[b].tile_y][ns_blocs[b].tile_x+1]);
		carte_map[ns_blocs[b].tile_y+1][ns_blocs[b].tile_x] = (t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * (face_bloc + 2)) + (!t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * carte_map[ns_blocs[b].tile_y+1][ns_blocs[b].tile_x]);
		carte_map[ns_blocs[b].tile_y+1][ns_blocs[b].tile_x+1] = (t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * (face_bloc + 3)) + (!t_blocs[ns_blocs[b].tile_y>>1][ns_blocs[b].tile_x>>1] * carte_map[ns_blocs[b].tile_y+1][ns_blocs[b].tile_x+1]);
	}
}

void RotationPiece() //les pi�ces doivent tourner ? c'est ici ! //EN_IWRAM
{
	for (b = 0; b < nbr_pieces; b++)
	{
		carte_map[ns_pieces[b].tile_y][ns_pieces[b].tile_x] = t_pieces[ns_pieces[b].tile_y>>1][ns_pieces[b].tile_x>>1] * face_piece;
		carte_map[ns_pieces[b].tile_y][ns_pieces[b].tile_x+1] = t_pieces[ns_pieces[b].tile_y>>1][ns_pieces[b].tile_x>>1] * (face_piece+1);
		carte_map[ns_pieces[b].tile_y+1][ns_pieces[b].tile_x] = t_pieces[ns_pieces[b].tile_y>>1][ns_pieces[b].tile_x>>1] * (face_piece+2);
		carte_map[ns_pieces[b].tile_y+1][ns_pieces[b].tile_x+1] = t_pieces[ns_pieces[b].tile_y>>1][ns_pieces[b].tile_x>>1] * (face_piece+3);
	}
}

void RotationPAcoin() //les pi�ces PA doivent tourner ? c'est ici !
{
	carte_map[pacoin_tile_y][pacoin_tile_x] = pacoin_etat * face_coin;
    carte_map[pacoin_tile_y][pacoin_tile_x+1] = pacoin_etat * (face_coin+1);
    carte_map[pacoin_tile_y+1][pacoin_tile_x] = pacoin_etat * (face_coin+2);
    carte_map[pacoin_tile_y+1][pacoin_tile_x+1] = pacoin_etat * (face_coin+3);
}

void ChocBloc(s16 pos_x, s16 pos_y) //ici l'anim d'un bloc simple cogn� par mario
{
	if (b_bloc[0].choc == 1) 
	{
		b_bloc[0].pos_x += Ptx;
		b_bloc[0].pos_y += Pty;		
	}
	if (b_bloc[0].choc == 2) hel_ObjSetVisible(b_bloc[0].sprite,1);

	{
		hel_ObjSetXY(b_bloc[0].sprite,(pos_x-Ptx),(pos_y-Pty));
		if ((pos_x-Ptx) < -54 || (pos_x-Ptx) > 240 || (pos_y-Pty) < -54 || (pos_y-Pty) > 160) hel_ObjSetXY(b_bloc[0].sprite,240,160);
	}

    b_bloc[0].choc++;

    if (b_bloc[0].choc == 13)
    {
		if (b_bloc[0].cote) //je redessine le bloc, mais tout d�pend du tile de d�part
        {
			carte_map[(b_bloc[0].tile_pos_y >> 3)-1][(b_bloc[0].tile_pos_x >> 3)] = bloc_marron;
            carte_map[(b_bloc[0].tile_pos_y >> 3)-1][(b_bloc[0].tile_pos_x >> 3)+1] = bloc_marron+1;
            carte_map[(b_bloc[0].tile_pos_y >> 3)][(b_bloc[0].tile_pos_x >> 3)] = bloc_marron+2;
            carte_map[(b_bloc[0].tile_pos_y >> 3)][(b_bloc[0].tile_pos_x >> 3)+1] = bloc_marron+3;
        }
        else
        {
            carte_map[(b_bloc[0].tile_pos_y >> 3)-1][(b_bloc[0].tile_pos_x >> 3)-1] = bloc_marron;
            carte_map[(b_bloc[0].tile_pos_y >> 3)-1][(b_bloc[0].tile_pos_x >> 3)] = bloc_marron+1;
            carte_map[(b_bloc[0].tile_pos_y >> 3)][(b_bloc[0].tile_pos_x >> 3)-1] = bloc_marron+2;
            carte_map[(b_bloc[0].tile_pos_y >> 3)][(b_bloc[0].tile_pos_x >> 3)] = bloc_marron+3;
        }
        hel_MapRedraw(2);
    }

	hel_ObjUpdateGfx(b_bloc[0].sprite,(void*)&bloc_Bitmap[256 * b_bloc[0].choc]);

    if (b_bloc[0].choc >= 14)
    {
		b_bloc[0].choc = 0;
        hel_ObjSetVisible(b_bloc[0].sprite,0); //je le cache

	    if (b_bloc[0].type != ascens) //si c'est pas un ascenseur
	    {
			//je pr�pare l'anim de sortie du bonus
		    bonus.temp_course = 0;
		    bonus.delta_course = 0;
		    bonus.temp_mort = 0;			
		    bonus.etat = sprite_vivant;
		    cache.etat = sprite_vivant;
		    bonus.pos_x = pos_x;  //je place le bonus et le cache pile au bon endroit
		    bonus.pos_y = pos_y + 16;
		    cache.pos_x = pos_x;
		    cache.pos_y = pos_y + 16;
			hel_ObjSetVisible(cache.sprite,1);
		    hel_ObjSetVisible(bonus.sprite,1);
	    }
	    else //si c'est un ascenseur, on va juste l'afficher
	    {			
		    ascenseur.etat = sprite_vivant;
		    ascenseur.pos_x = pos_x;
		    ascenseur.pos_y = pos_y + 6;
			hel_ObjSetVisible(ascenseur.sprite,1);
	    }

        AdpcmStart(&ADPCM_bonuss,1,1); //je produis le son du bonus

        if (b_bloc[0].type == champignon)  //et un champignon, un !
        {
            hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[0]); //le champignon...
            bonus.dep_x = 1; //... et ses caract�ristiques (l�, il devra avancer)
            bonus.limite = champignon;
            sortie_champignon = 1;
        }
        if (b_bloc[0].type == fleur)  //une fleur pour la 15 !
        {
            hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[128]); //1ere frame de la fleur
            bonus.limite = fleur;
            sortie_fleur = 1;
        }
        if (b_bloc[0].type == vie)  //gar�on ! une vie s'il vous plait
        {
            hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[384]); //la vie...
            bonus.dep_x = 1; //... et ses caract�ristiques (l�, elle devra avancer)
            bonus.limite = vie;
            sortie_vie = 1;
        }
        if (b_bloc[0].type == etoile)  //pas trop d'�toile, c'est un peu gras
        {
            hel_ObjUpdateGfx(bonus.sprite,(void*)&bonus_Bitmap[512]); //1ere frame de l'�toile
            bonus.limite = etoile;
            sortie_etoile = 1;
        }

		{
			hel_ObjSetXY(cache.sprite,(cache.pos_x-Ptx),(cache.pos_y-Pty));
			if ((cache.pos_x-Ptx) < -54 || (cache.pos_x-Ptx) > 240 || (cache.pos_y-Pty) < -54 || (cache.pos_y-Pty) > 160) hel_ObjSetXY(cache.sprite,240,160);
		}
		{
			hel_ObjSetXY(bonus.sprite,(bonus.pos_x-Ptx),(bonus.pos_y-Pty));
			if ((bonus.pos_x-Ptx) < -54 || (bonus.pos_x-Ptx) > 240 || (bonus.pos_y-Pty) < -54 || (bonus.pos_y-Pty) > 160) hel_ObjSetXY(bonus.sprite,240,160);
		}
    }	
}

void ChocBlocStd(s16 pos_x, s16 pos_y, u8 num) //ici l'anim d'un bloc jaune cogn� par mario
{
    if (bloc_std[num].choc == 1) 
	{
		bloc_std[num].pos_x += Ptx;
		bloc_std[num].pos_y += Pty;		
	}
	if (bloc_std[num].choc == 2) hel_ObjSetVisible(bloc_std[num].sprite,1);

	hel_ObjSetXY(bloc_std[num].sprite,(pos_x-Ptx),(pos_y-Pty));
	if ((pos_x-Ptx) < -54 || (pos_x-Ptx) > 240 || (pos_y-Pty) < -54 || (pos_y-Pty) > 160) hel_ObjSetXY(bloc_std[num].sprite,240,160);
	

    bloc_std[num].choc++;
   
    //collisions du bloc avec un ennemi qui serait au dessus
    if (bloc_std[num].choc < 11 && koopa.pos_y > (pos_y - 20) && koopa.pos_y < pos_y && (koopa.pos_x+16) >= pos_x && koopa.pos_x <= (pos_x+16) && koopa.etat != sprite_mort2) 
	{
		AdpcmStart(&ADPCM_mort2,1,1); 
		koopa.etat = sprite_mort2;
	} //elimination de l'ennemi qui marchais tranquillement sur le bloc au moment de l'impact
   
    if (bloc_std[num].choc == 13)
    {
       if (bloc_std[num].cote) //je redessine le bloc, mais tout d�pend du tile de d�part
       {
		   carte_map[(bloc_std[num].tile_pos_y >> 3)-1][(bloc_std[num].tile_pos_x >> 3)] = bloc_jaune;
		   carte_map[(bloc_std[num].tile_pos_y >> 3)-1][(bloc_std[num].tile_pos_x >> 3)+1] = bloc_jaune+1;
           carte_map[(bloc_std[num].tile_pos_y >> 3)][(bloc_std[num].tile_pos_x >> 3)] = bloc_jaune+2;
           carte_map[(bloc_std[num].tile_pos_y >> 3)][(bloc_std[num].tile_pos_x >> 3)+1] = bloc_jaune+3;
       }
       else
       {
           carte_map[(bloc_std[num].tile_pos_y >> 3)-1][(bloc_std[num].tile_pos_x >> 3)-1] = bloc_jaune;
           carte_map[(bloc_std[num].tile_pos_y >> 3)-1][(bloc_std[num].tile_pos_x >> 3)] = bloc_jaune+1;
           carte_map[(bloc_std[num].tile_pos_y >> 3)][(bloc_std[num].tile_pos_x >> 3)-1] = bloc_jaune+2;
           carte_map[(bloc_std[num].tile_pos_y >> 3)][(bloc_std[num].tile_pos_x >> 3)] = bloc_jaune+3;
       }
       hel_MapRedraw(2);
    }
    
    hel_ObjUpdateGfx(bloc_std[num].sprite,(void*)&bloc_std_Bitmap[256 * bloc_std[num].choc]);
	
	if (bloc_std[num].choc == 14)
    {
        bloc_std[num].choc = 0;
        //if (hel_ObjExists(bloc_std[num].sprite)) hel_ObjDelete(bloc_std[num].sprite); //je le cache
		hel_ObjSetVisible(bloc_std[num].sprite,0);
    }
}

void ChocBlocPiece(s16 pos_x, s16 pos_y, u8 num) //ici c'est l'anim du sprite du bloc pi�ce
{
	if (bloc_piece[num].choc == 1) 
	{
		bloc_piece[num].pos_x += Ptx;
		bloc_piece[num].pos_y += Pty;		
	}
	if (bloc_piece[num].choc == 2) hel_ObjSetVisible(bloc_piece[num].sprite,1);
	
	{
		hel_ObjSetXY(bloc_piece[num].sprite,(pos_x-Ptx),(pos_y-Pty));
		if ((pos_x-Ptx) < -54 || (pos_x-Ptx) > 240 || (pos_y-Pty) < -54 || (pos_y-Pty) > 160) hel_ObjSetXY(bloc_piece[num].sprite,240,160);
	}

    bloc_piece[num].choc++;
	
    //collisions du bloc avec un ennemi qui serait au dessus
    if (bloc_piece[num].choc < 11 && koopa.pos_y > pos_y && koopa.pos_y < (pos_y + 30) && (koopa.pos_x+16) >= pos_x && koopa.pos_x <= (pos_x+16) && koopa.etat != sprite_mort2) 
	{
		AdpcmStart(&ADPCM_mort2,1,1); 
		koopa.etat = sprite_mort2;
	} //elimination de l'ennemi qui marchais tranquillement sur le bloc au moment de l'impact

    if (bloc_piece[num].choc == 4) AdpcmStart(&ADPCM_piece,1,1); //son d'une piece
    if (bloc_piece[num].choc == 14)
    {
		if (bloc_piece[num].cote) //je redessine le bloc, mais tout d�pend du tile de d�part
        {
			carte_map[(bloc_piece[num].tile_pos_y >> 3)-1][(bloc_piece[num].tile_pos_x >> 3)] = bloc_marron;
            carte_map[(bloc_piece[num].tile_pos_y >> 3)-1][(bloc_piece[num].tile_pos_x >> 3)+1] = bloc_marron+1;
            carte_map[(bloc_piece[num].tile_pos_y >> 3)][(bloc_piece[num].tile_pos_x >> 3)] = bloc_marron+2;
            carte_map[(bloc_piece[num].tile_pos_y >> 3)][(bloc_piece[num].tile_pos_x >> 3)+1] = bloc_marron+3;
        }
        else
        {
            carte_map[(bloc_piece[num].tile_pos_y >> 3)-1][(bloc_piece[num].tile_pos_x >> 3)-1] = bloc_marron;
            carte_map[(bloc_piece[num].tile_pos_y >> 3)-1][(bloc_piece[num].tile_pos_x >> 3)] = bloc_marron+1;
            carte_map[(bloc_piece[num].tile_pos_y >> 3)][(bloc_piece[num].tile_pos_x >> 3)-1] = bloc_marron+2;
            carte_map[(bloc_piece[num].tile_pos_y >> 3)][(bloc_piece[num].tile_pos_x >> 3)] = bloc_marron+3;
        }
        hel_MapRedraw(2);
    }

	//if (hel_ObjExists(bloc_piece[num].sprite))
	{
		hel_ObjUpdateGfx(bloc_piece[num].sprite,(void*)&bloc_piece_Bitmap[1024 * bloc_piece[num].choc]);
		if (bloc_piece[num].choc == 49) {bloc_piece[num].choc = 0; hel_ObjSetVisible(bloc_piece[num].sprite,0);} //quand l'anim est finie, je cache le sprite
	}
}

void ChocBlocPiecePlus() //ici c'est l'anim du sprite du bloc pi�ce plus
{
    if (bloc_piece_plus[0].choc == 1) 
	{
		bloc_piece_plus[0].pos_x += Ptx;
		bloc_piece_plus[0].pos_y += Pty;		
	}
	if (bloc_piece_plus[0].choc == 2) hel_ObjSetVisible(bloc_piece_plus[0].sprite,1);
	
	//if (hel_ObjExists(bloc_piece_plus[0].sprite)) 
	{
		hel_ObjSetXY(bloc_piece_plus[0].sprite,(bloc_piece_plus[0].pos_x-Ptx),(bloc_piece_plus[0].pos_y-Pty));
		if (bloc_piece_plus[0].temp >= 250) hel_ObjUpdateGfx(bloc_piece_plus[0].sprite,(void*)&bloc_piece_Bitmap[1024 * bloc_piece_plus[0].choc]); //je modifie l'affichage du bloc piece plus au moment de la fin (il passe couleur marron)
		else hel_ObjUpdateGfx(bloc_piece_plus[0].sprite,(void*)&bloc_piece2_Bitmap[1024 * bloc_piece_plus[0].choc]);
		if ((bloc_piece_plus[0].pos_x-Ptx) < -54 || (bloc_piece_plus[0].pos_x-Ptx) > 240 || (bloc_piece_plus[0].pos_y-Pty) < -54 || (bloc_piece_plus[0].pos_y-Pty) > 160) hel_ObjSetXY(bloc_piece_plus[0].sprite,240,160);
	}	
	
	bloc_piece_plus[0].choc++;
   
    //collisions du bloc avec un ennemi qui serait au dessus
    if (bloc_piece_plus[0].choc < 11 && koopa.pos_y > bloc_piece_plus[0].pos_y && koopa.pos_y < (bloc_piece_plus[0].pos_y + 30) && (koopa.pos_x+16) >= bloc_piece_plus[0].pos_x && koopa.pos_x <= (bloc_piece_plus[0].pos_x+16) && koopa.etat != sprite_mort2) 
	{
		AdpcmStart(&ADPCM_mort2,1,1); 
		koopa.etat = sprite_mort2;
	} //elimination de l'ennemi qui marchais tranquillement sur le bloc au moment de l'impact
   
    if (bloc_piece_plus[0].choc == 4) AdpcmStart(&ADPCM_piece,1,1); //son d'une piece
    if (bloc_piece_plus[0].choc == 12)
    {
       if (bloc_piece_plus[0].temp >= 240) //si la tempo est finie
       {
          if (bloc_piece_plus[0].cote) //je redessine le bloc marron, mais tout d�pend du tile de d�part (c'est fini)
          {
			  carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)+1] = bloc_marron+1;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron+2;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)+1] = bloc_marron+3;
          }
          else
          {
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)-1] = bloc_marron;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron+1;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)-1] = bloc_marron+2;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron+3;
          }
       }
       else
       {
          if (bloc_piece_plus[0].cote) //je redessine le bloc jaune, mais tout d�pend du tile de d�part (on peut continuer)
          {
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_jaune;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)+1] = bloc_jaune+1;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_jaune+2;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)+1] = bloc_jaune+3;
          }
          else
          {
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)-1] = bloc_jaune;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_jaune+1;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)-1] = bloc_jaune+2;
              carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_jaune+3;
          }
       }
       hel_MapRedraw(2);
    }        
	
	if (bloc_piece_plus[0].choc == 49) //quand l'anim est finie, je cache le sprite
    {
		if (bloc_piece_plus[0].temp >= 250) 
		{
			if (bloc_piece_plus[0].cote) //je redessine le bloc marron, mais tout d�pend du tile de d�part (c'est fini)
            {
				carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron;
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)+1] = bloc_marron+1;
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron+2;
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)+1] = bloc_marron+3;
            }
            else
            {
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)-1] = bloc_marron;
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)-1][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron+1;
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)-1] = bloc_marron+2;
                carte_map[(bloc_piece_plus[0].tile_pos_y >> 3)][(bloc_piece_plus[0].tile_pos_x >> 3)] = bloc_marron+3;
            }
			bloc_piece_plus[0].temp = 0; //sans oublier de remettre la tempo � 0
		}
        bloc_piece_plus[0].choc = 0;
		//if (hel_ObjExists(bloc_piece_plus[0].sprite)) {
		hel_ObjSetVisible(bloc_piece_plus[0].sprite,0);
    }
}

void SortieChampignon() //ici l'anim de "sortie" du champignon
{
	bonus.temp_course++;
    if (bonus.temp_course >= 4)
    {
		if (bonus.delta_course < 16) //il sort d'abord verticalement
        {
			bonus.delta_course++;
			bonus.pos_y--;
			bonus.anim_mort = 0;
			bonus.temp_course = 0; //assez lentement
		}
		else if (bonus.delta_course == 16) //puis une fois le champignon sorti
		{
			bonus.delta_course++;
			cache.etat = sprite_inactif;
			//if (hel_ObjExists(cache.sprite)) hel_ObjDelete(cache.sprite);
			hel_ObjSetVisible(cache.sprite,0);
			bonus.temp_course = 0;
		}
		else //enfin decris une courbe...
		{
			bonus.pos_x++;
			bonus.pos_y += tab_bonus[bonus.anim_mort + 1]; //+1 car j'ai un seul tableau mais 2 valeurs � lire (en l'occurence je ne lit que la 2eme)
			bonus.anim_mort += 2; //toujours cette histoire de 2 valeurs � lire dans un seul tableau
			if (bonus.anim_mort == 80) bonus.anim_mort = 76; //je conserve la derniere case du tableau
			if ((bonus.pos_y - Pty) >= 180) //si il sort de l'�cran
			{
				bonus.anim_mort = 0;
				sortie_champignon = 0;
				bonus.dep_x = 0;
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				bonus.etat = sprite_inactif;
				//if (hel_ObjExists(bonus.sprite)) hel_ObjDelete(bonus.sprite);
				hel_ObjSetVisible(bonus.sprite,0);
			}
			bonus.pos_x -= Ptx;
			bonus.pos_y -= Pty;
			if (BlocPresentBas(bonus)) sortie_champignon = 0; //si le champignon touche le sol, on stoppe l'anim pr�calcul�e
			bonus.pos_x += Ptx;
			bonus.pos_y += Pty;
			bonus.temp_course = 2; //...en allant l�g�rement plus vite
        }
    }
    
	//if (hel_ObjExists(cache.sprite))
	{
		hel_ObjSetXY(cache.sprite,(cache.pos_x-Ptx),(cache.pos_y-Pty));
		if ((cache.pos_x-Ptx) < -54 || (cache.pos_x-Ptx) > 240 || (cache.pos_y-Pty) < -54 || (cache.pos_y-Pty) > 160) hel_ObjSetXY(cache.sprite,240,160);		
	}
	//if (hel_ObjExists(bonus.sprite))
	{
		hel_ObjSetXY(bonus.sprite,(bonus.pos_x-Ptx),(bonus.pos_y-Pty));
		if ((bonus.pos_x-Ptx) < -54 || (bonus.pos_x-Ptx) > 240 || (bonus.pos_y-Pty) < -54 || (bonus.pos_y-Pty) > 160) hel_ObjSetXY(bonus.sprite,240,160);
	}
}

void SortieFleur() //ici l'anim de "sortie" de la fleur
{
	bonus.temp_course++;
	if (bonus.temp_course >= 4)
	{
		if (bonus.delta_course < 16) //elle sort verticalement
		{
			bonus.delta_course++;
			bonus.pos_y--;
			bonus.temp_course = 0; //assez lentement
		}
		else //puis une fois la fleur sortie
		{
			cache.etat = sprite_inactif;
			//if (hel_ObjExists(cache.sprite)) hel_ObjDelete(cache.sprite);
			hel_ObjSetVisible(cache.sprite,0);
			sortie_fleur = 0; //c'est fini
		}
	}
   
	//if (hel_ObjExists(cache.sprite))
	{
		hel_ObjSetXY(cache.sprite,(cache.pos_x-Ptx),(cache.pos_y-Pty));
		if ((cache.pos_x-Ptx) < -54 || (cache.pos_x-Ptx) > 240 || (cache.pos_y-Pty) < -54 || (cache.pos_y-Pty) > 160) hel_ObjSetXY(cache.sprite,240,160);		
	}
	//if (hel_ObjExists(bonus.sprite))
	{
		hel_ObjSetXY(bonus.sprite,(bonus.pos_x-Ptx),(bonus.pos_y-Pty));
		if ((bonus.pos_x-Ptx) < -54 || (bonus.pos_x-Ptx) > 240 || (bonus.pos_y-Pty) < -54 || (bonus.pos_y-Pty) > 160) hel_ObjSetXY(bonus.sprite,240,160);
	}
}

void SortieVie() //ici l'anim de "sortie" de la vie
{
	bonus.temp_course++;
    if (bonus.temp_course >= 4)
    {
		if (bonus.delta_course < 16) //elle sort d'abord verticalement
		{
			bonus.delta_course++;
			bonus.pos_y--;
			bonus.anim_mort = 0;
			bonus.temp_course = 0; //assez lentement
		}
		else if (bonus.delta_course == 16) //puis une fois la vie sortie
		{
			bonus.delta_course++;
			cache.etat = sprite_inactif;
			//if (hel_ObjExists(cache.sprite)) hel_ObjDelete(cache.sprite);
			hel_ObjSetVisible(cache.sprite,0);
			bonus.temp_course = 0;
		}
		else //enfin decris une courbe...
		{
			bonus.pos_x++;
			bonus.pos_y += tab_bonus[bonus.anim_mort + 1]; //+1 car j'ai un seul tableau mais 2 valeurs � lire (en l'occurence je ne lit que la 2eme)
			bonus.anim_mort += 2; //toujours cette histoire de 2 valeurs � lire dans un seul tableau
			if (bonus.anim_mort == 80) bonus.anim_mort = 76; //je conserve la derniere case du tableau
			if ((bonus.pos_y - Pty) >= 180) //si elle sort de l'�cran
			{
				bonus.anim_mort = 0;
				sortie_vie = 0;
				bonus.dep_x = 0;
				bonus.etat = sprite_inactif;
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				//if (hel_ObjExists(bonus.sprite)) hel_ObjDelete(bonus.sprite);
				hel_ObjSetVisible(bonus.sprite,0);
			}
			bonus.pos_x -= Ptx;
			bonus.pos_y -= Pty;
			if (BlocPresentBas(bonus)) sortie_vie = 0; //si la vie touche le sol, on stoppe l'anim pr�calcul�e
			bonus.pos_x += Ptx;
			bonus.pos_y += Pty;
			bonus.temp_course = 2; //...en allant l�g�rement plus vite
		}
	}

	//if (hel_ObjExists(cache.sprite))
	{
		hel_ObjSetXY(cache.sprite,(cache.pos_x-Ptx),(cache.pos_y-Pty));
		if ((cache.pos_x-Ptx) < -54 || (cache.pos_x-Ptx) > 240 || (cache.pos_y-Pty) < -54 || (cache.pos_y-Pty) > 160) hel_ObjSetXY(cache.sprite,240,160);		
	}
	//if (hel_ObjExists(bonus.sprite))
	{
		hel_ObjSetXY(bonus.sprite,(bonus.pos_x-Ptx),(bonus.pos_y-Pty));
		if ((bonus.pos_x-Ptx) < -54 || (bonus.pos_x-Ptx) > 240 || (bonus.pos_y-Pty) < -54 || (bonus.pos_y-Pty) > 160) hel_ObjSetXY(bonus.sprite,240,160);
	}
}

void SortieEtoile() //ici l'anim de "sortie" de l'�toile
{
	bonus.temp_course++;
	if (bonus.temp_course >= 4)
	{
		if (bonus.delta_course < 16) //elle sort d'abord verticalement
		{
			bonus.delta_course++;
			bonus.pos_y--;
			bonus.anim_mort = 0;
			bonus.temp_course = 0; //assez lentement
		}
		else if (bonus.delta_course == 16) //puis une fois l'�toile sortie
		{
			bonus.delta_course++;
			cache.etat = sprite_inactif;
			//if (hel_ObjExists(cache.sprite)) hel_ObjDelete(cache.sprite);
			hel_ObjSetVisible(cache.sprite,0);
			bonus.temp_course = 0;
		}
		else //enfin decris une courbe...
		{
			bonus.pos_x++;
			bonus.pos_y += tab_bonus[bonus.anim_mort + 1]; //+1 car j'ai un seul tableau mais 2 valeurs � lire (en l'occurence je ne lit que la 2eme)
			bonus.anim_mort += 2; //toujours cette histoire de 2 valeurs � lire dans un seul tableau
			if (bonus.anim_mort == 80) bonus.anim_mort = 76; //je conserve la derniere case du tableau
			if ((bonus.pos_y - Pty) >= 180) //si elle sort de l'�cran
			{
				bonus.anim_mort = 0;
				sortie_etoile = 0;
				bonus.dep_x = 0;
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				bonus.etat = sprite_inactif;
				//if (hel_ObjExists(bonus.sprite)) hel_ObjDelete(bonus.sprite);
				hel_ObjSetVisible(bonus.sprite,0);
			}
			bonus.temp_course = 2; //...en allant l�g�rement plus vite
		}
	}

	//if (hel_ObjExists(cache.sprite))
	{
		hel_ObjSetXY(cache.sprite,(cache.pos_x-Ptx),(cache.pos_y-Pty));
		if ((cache.pos_x-Ptx) < -54 || (cache.pos_x-Ptx) > 240 || (cache.pos_y-Pty) < -54 || (cache.pos_y-Pty) > 160) hel_ObjSetXY(cache.sprite,240,160);		
	}
	//if (hel_ObjExists(bonus.sprite))
	{
		hel_ObjSetXY(bonus.sprite,(bonus.pos_x-Ptx),(bonus.pos_y-Pty));
		if ((bonus.pos_x-Ptx) < -54 || (bonus.pos_x-Ptx) > 240 || (bonus.pos_y-Pty) < -54 || (bonus.pos_y-Pty) > 160) hel_ObjSetXY(bonus.sprite,240,160);
	}

}

void AnimePoints() //ici c'est l'anim de mont�e des points quand on �limine un ennemi
{
	for (b = points1n; b <= unevien; b++)
	{
		if (sprite[b].etat == sprite_vivant)
		{
			sprite[b].temp_course++;
			if (sprite[b].temp_course > 3)
			{
				sprite[b].temp_course = 0;
				sprite[b].delta_course++;
				sprite[b].pos_y--;				

				if (sprite[b].delta_course == 20) //arriv� � la fin de l'anim, on efface
				{
					sprite[b].etat = sprite_inactif;
					sprite[b].delta_course = 0;
					//if (hel_ObjExists(sprite[b].sprite)) hel_ObjDelete(sprite[b].sprite);
					hel_ObjSetVisible(sprite[b].sprite,0);
				}				
			}

			//if (hel_ObjExists(sprite[b].sprite))
			{
				hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));
				if ((sprite[b].pos_x-Ptx) < -54 || (sprite[b].pos_x-Ptx) > 240 || (sprite[b].pos_y-Pty) < -54 || (sprite[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[b].sprite,240,160);
			}
		}
	}
}

void AnimExplosion() //l'anim d'un bloc simple d�truit par super mario
{
	for (b = 0; b < 5; b++)
    {
		if (bloc_morceaux[b].temp_anim > 0)
        {
			bloc_morceaux[b].temp_anim++;
            if (bloc_morceaux[b].temp_anim >= 2)
            {
				bloc_morceaux[b].temp_anim = 1;
            
				bloc_morceaux[b].morceau1_pos_x -= tab_anim_explo_x[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau1_pos_y += tab_anim_explo_y12[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau1_etat++;
				if (bloc_morceaux[b].morceau1_etat == 16) bloc_morceaux[b].morceau1_etat = 0;

				bloc_morceaux[b].morceau2_pos_x += tab_anim_explo_x[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau2_pos_y += tab_anim_explo_y12[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau2_etat++;
				if (bloc_morceaux[b].morceau2_etat == 16) bloc_morceaux[b].morceau2_etat = 0;

				bloc_morceaux[b].morceau3_pos_x -= tab_anim_explo_x[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau3_pos_y += tab_anim_explo_y34[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau3_etat++;
				if (bloc_morceaux[b].morceau3_etat == 16) bloc_morceaux[b].morceau3_etat = 0;

				bloc_morceaux[b].morceau4_pos_x += tab_anim_explo_x[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau4_pos_y += tab_anim_explo_y34[bloc_morceaux[b].anim];
				bloc_morceaux[b].morceau4_etat++;
				if (bloc_morceaux[b].morceau4_etat == 16) bloc_morceaux[b].morceau4_etat = 0;
	            
				bloc_morceaux[b].anim++;

				//collisions du bloc avec un ennemi qui serait au dessus
				if (bloc_morceaux[b].anim == 2 && koopa.pos_y > (bloc_morceaux[b].morceau1_pos_y - 32) && koopa.pos_y < bloc_morceaux[b].morceau1_pos_y && (koopa.pos_x+16) >= bloc_morceaux[b].morceau1_pos_x && koopa.pos_x <= (bloc_morceaux[b].morceau1_pos_x+16) && koopa.etat != sprite_mort2) 
				{
					AdpcmStart(&ADPCM_mort2,1,1);
					koopa.etat = sprite_mort2;
				} //elimination de l'ennemi qui marchais tranquillement sur le bloc au moment de l'impact
	            
				if (bloc_morceaux[b].anim == 2) AdpcmStart(&ADPCM_expl_bloc,1,1); //le son d'un bloc qui explose  

				if (bloc_morceaux[b].anim == 1) 
				{
					hel_ObjSetVisible(bloc_morceaux[b].morceau1_sprite,1);
					hel_ObjSetVisible(bloc_morceaux[b].morceau2_sprite,1);
					hel_ObjSetVisible(bloc_morceaux[b].morceau3_sprite,1);
					hel_ObjSetVisible(bloc_morceaux[b].morceau4_sprite,1);

					bloc_morceaux[b].morceau1_pos_x += Ptx;
					bloc_morceaux[b].morceau1_pos_y += Pty;	
					bloc_morceaux[b].morceau2_pos_x += Ptx;
					bloc_morceaux[b].morceau2_pos_y += Pty;
					bloc_morceaux[b].morceau3_pos_x += Ptx;
					bloc_morceaux[b].morceau3_pos_y += Pty;
					bloc_morceaux[b].morceau4_pos_x += Ptx;
					bloc_morceaux[b].morceau4_pos_y += Pty;
				}
	
				//if (hel_ObjExists(bloc_morceaux[b].morceau1_sprite)) 
				{
					hel_ObjSetXY(bloc_morceaux[b].morceau1_sprite,bloc_morceaux[b].morceau1_pos_x-Ptx,bloc_morceaux[b].morceau1_pos_y-Pty);
					if ((bloc_morceaux[b].morceau1_pos_x-Ptx) < -54 || (bloc_morceaux[b].morceau1_pos_x-Ptx) > 240 || (bloc_morceaux[b].morceau1_pos_y-Pty) < -54 || (bloc_morceaux[b].morceau1_pos_y-Pty) > 160) hel_ObjSetXY(bloc_morceaux[b].morceau1_sprite,240,160);
					hel_ObjUpdateGfx(bloc_morceaux[b].morceau1_sprite,(void*)&morceau_bloc_Bitmap[tab_anim_explo_etat[bloc_morceaux[b].morceau1_etat]*32]);            
				}
				//if (hel_ObjExists(bloc_morceaux[b].morceau2_sprite)) 
				{
					hel_ObjSetXY(bloc_morceaux[b].morceau2_sprite,bloc_morceaux[b].morceau2_pos_x-Ptx,bloc_morceaux[b].morceau2_pos_y-Pty);
					if ((bloc_morceaux[b].morceau2_pos_x-Ptx) < -54 || (bloc_morceaux[b].morceau2_pos_x-Ptx) > 240 || (bloc_morceaux[b].morceau2_pos_y-Pty) < -54 || (bloc_morceaux[b].morceau2_pos_y-Pty) > 160) hel_ObjSetXY(bloc_morceaux[b].morceau2_sprite,240,160);
					hel_ObjUpdateGfx(bloc_morceaux[b].morceau2_sprite,(void*)&morceau_bloc_Bitmap[tab_anim_explo_etat[bloc_morceaux[b].morceau2_etat]*32]);            
				}
				//if (hel_ObjExists(bloc_morceaux[b].morceau3_sprite))
				{
					hel_ObjSetXY(bloc_morceaux[b].morceau3_sprite,bloc_morceaux[b].morceau3_pos_x-Ptx,bloc_morceaux[b].morceau3_pos_y-Pty);
					if ((bloc_morceaux[b].morceau3_pos_x-Ptx) < -54 || (bloc_morceaux[b].morceau3_pos_x-Ptx) > 240 || (bloc_morceaux[b].morceau3_pos_y-Pty) < -54 || (bloc_morceaux[b].morceau3_pos_y-Pty) > 160) hel_ObjSetXY(bloc_morceaux[b].morceau3_sprite,240,160);
					hel_ObjUpdateGfx(bloc_morceaux[b].morceau3_sprite,(void*)&morceau_bloc_Bitmap[tab_anim_explo_etat[bloc_morceaux[b].morceau3_etat]*32]);            
				}
				//if (hel_ObjExists(bloc_morceaux[b].morceau4_sprite))
				{
					hel_ObjSetXY(bloc_morceaux[b].morceau4_sprite,bloc_morceaux[b].morceau4_pos_x-Ptx,bloc_morceaux[b].morceau4_pos_y-Pty);
					if ((bloc_morceaux[b].morceau4_pos_x-Ptx) < -54 || (bloc_morceaux[b].morceau4_pos_x-Ptx) > 240 || (bloc_morceaux[b].morceau4_pos_y-Pty) < -54 || (bloc_morceaux[b].morceau4_pos_y-Pty) > 160) hel_ObjSetXY(bloc_morceaux[b].morceau4_sprite,240,160);
					hel_ObjUpdateGfx(bloc_morceaux[b].morceau4_sprite,(void*)&morceau_bloc_Bitmap[tab_anim_explo_etat[bloc_morceaux[b].morceau4_etat]*32]);
				}

				if (bloc_morceaux[b].anim == 35) //quand l'anim est finie
				{
					bloc_morceaux[b].anim = 0;
					bloc_morceaux[b].temp_anim = 0;
	               
					//if (hel_ObjExists(bloc_morceaux[b].morceau1_sprite)) 
					hel_ObjSetVisible(bloc_morceaux[b].morceau1_sprite,0);
					//if (hel_ObjExists(bloc_morceaux[b].morceau2_sprite)) 
					hel_ObjSetVisible(bloc_morceaux[b].morceau2_sprite,0);
					//if (hel_ObjExists(bloc_morceaux[b].morceau3_sprite)) 
					hel_ObjSetVisible(bloc_morceaux[b].morceau3_sprite,0);
					//if (hel_ObjExists(bloc_morceaux[b].morceau4_sprite)) 
					hel_ObjSetVisible(bloc_morceaux[b].morceau4_sprite,0);
				}
			}
		}
	}
}


void AnimEnterSecretZone() //anim de rentr�e dans le tuyau vertical
{
	hel_ObjSetPrio(mario.sprite,3); //je met mario derriere le bg0 pour le cacher derriere le tuyau lors de sa descente
	hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(3072 + power) * am]); //frame de mario "je rentre dans un tuyau"
	mario.anim_mort = 0;
	AdpcmStart(&ADPCM_tuyau,1,1);
	while (mario.anim_mort < 32) 
	{
		Pause(200);
		{
			mario.anim_mort++;
			mario.pos_y++;
			hel_ObjSetY(mario.sprite,mario.pos_y); 
		}
	}
	hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[0]);
	hel_ObjSetHFlip(mario.sprite,0);   
	CacheSprites();   
	PostNiveau();
	AdpcmStop(0);	
	hel_MapSetPosition(2,FIXED_FROMINT(989<<3),FIXED_FROMINT(160)); //on d�place la map vers la zone secrete (ici on multiplie par 8)
	hel_MapGetPosition(2, &Ptx, &Pty); // update des coord de la map en pixel
	{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
	{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
	PreNiveau();
	mario.pos_x = 16;
	mario.pos_y = 0; //0

	hel_ObjSetPrio(mario.sprite,0); //faut pas oublier de replacer mario devant tous les bgs	

	if (num_niveau == 8) //si c'est le niveau 8, on va au boss
	{
		bossgoomba.vitesse = 1;	
		bossgoomba.dep_x = -1*bossgoomba.vitesse;
		bossgoomba.pos_tab_saut = 0;
		hel_ObjUpdateGfx(bossgoomba.sprite,(void*)&bossgoomba_Bitmap[0]);
		bossgoomba.etat = sprite_vivant;
		hel_ObjSetHFlip(bossgoomba.sprite,0);
		hel_ObjSetVisible(bossgoomba.sprite,1);
		bossgoomba.limite = 5;
		bossgoomba.gravite = 4;
		bossgoomba.pos_x = 8075;
		bossgoomba.pos_y = 248;
		hel_ObjSetXY(bossgoomba.sprite,(bossgoomba.pos_x-Ptx),(bossgoomba.pos_y-Pty));

		mario.pos_y = 120;
		hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
		hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(0 + power) * am]);
		hel_ObjSetPrio(mario.sprite,0); //faut pas oublier de replacer mario devant tous les bgs

		AdpcmStart(&ADPCM_bossintro,1,0);
		while (AdpcmStatus(0) != 0) {};
		AdpcmStart(&ADPCM_boss,-1,0);
	}
	else AdpcmStart(&ADPCM_bonusm,-1,0);
}

void AnimExitSecretZone()
{
	bonus_tuyau = 1; //empeche mario de revenir dans le tuyau

	hel_ObjSetPrio(mario.sprite,3); //je met mario derriere le bg0 pour le cacher derriere le tuyau lors de sa descente
	mario.anim_mort = 0;
	AdpcmStart(&ADPCM_tuyau,1,1);
	while (mario.anim_mort < 15) //rentre dans le tuyau horizontal
	{
		Pause(320);
		{
			mario.anim_mort++;
			mario.pos_x++;
			hel_ObjSetX(mario.sprite,mario.pos_x); // on applique les changements de suite, histoire d'etre le + discret possible
			mario.course *= -1; // il n'y a que 2 positions dans l'anim donc...
			if (mario.course == -1) hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(512 + power) * am]);
			else hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(0 + power) * am]);
		}
	}
	hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[0]);
	hel_ObjSetHFlip(mario.sprite,0); 
	CacheSprites();
	PostNiveau();
	AdpcmStop(0);	
	if (num_niveau == 1) ReAfficheNiveau11();
	else if (num_niveau == 2) ReAfficheNiveau12();
	else if (num_niveau == 3) ReAfficheNiveau13();
	else if (num_niveau == 4) ReAfficheNiveau14();
	else if (num_niveau == 5) ReAfficheNiveau15();
	else if (num_niveau == 6) ReAfficheNiveau16();
	else if (num_niveau == 7) ReAfficheNiveau17();
	else if (num_niveau == 8) ReAfficheNiveau18();
	hel_MapSetPosition(2,FIXED_FROMINT(retry[3][0]),FIXED_FROMINT(retry[3][1])); //on d�place la map vers la sortie   
	PreNiveau();
	//SuperTestEcran();   
	//GestionFoes();
	//GestionPlateformes();   
	mario.pos_x = retry[3][2];
	mario.pos_y = retry[3][3];
	hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
	hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(0 + power) * am]);
	mario.anim_mort = 32;
	AdpcmStart(&ADPCM_tuyau,1,1);
	while (mario.anim_mort > 0) //sort du tuyau vertical
	{
		Pause(200);
		{
			mario.anim_mort--;
			mario.pos_y--;
			hel_ObjSetY(mario.sprite,mario.pos_y);
		}
	}
	hel_ObjSetPrio(mario.sprite,0); //faut pas oublier de replacer mario devant tous les bgs
	inertie_droite = 0;
}

void AnimMer(u32 tabx, u32 taby)
{
	carte_map[taby][tabx] = face_mer1;
	if (face_mer1 == 401) carte_map[taby][tabx+1] = face_mer1+1;
	else carte_map[taby][tabx+1] = face_mer1-1;
}
   
   
            
