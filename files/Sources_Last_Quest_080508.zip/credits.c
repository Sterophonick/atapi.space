#include <mygba.h>
#include "header.h"
#include "credits.h"


void AfficheCredits()
{
	//krapPlay(&mod_credit,KRAP_MODE_SONG,1); //ptite musique

	hel_PalBgLoad256((void*)credit_palette); //chargement de la palette des bg	

	ham_bg[0].ti = ham_InitTileSet((void*)&credit_tiles,SIZEOF_16BIT(credit_tiles),1,1);
	hel_MapCreate(0, 30, 20, (void*)credit_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(0,1,1,0);
	
	while (1) {}
}




