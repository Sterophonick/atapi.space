#include <mygba.h>
#include "header.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void GestionFoes()
{
	if (mario.etat != mario_mort && mario.etat != mario_pg && mario.etat != mario_fleur)  //on bloque les ennemis quand mario meurt ou est en train de "changer"
	{
		GestionGoomba();
		GestionKoopa();
		GestionFly();
		GestionAbeille();
		GestionBoulet();
		GestionHippocampe();
		GestionPoissonV();
		GestionSphinx();
		GestionBoss();
	}
}

void ExtractionFoes(u8 f)
{
	if (sprite[f].etat == sprite_vivant && InterieurBloc(sprite[f])) //si il rentre dans un bloc
	{
		while (InterieurBloc(sprite[f])) //si il rentre dans un bloc, je le fait sortir du bon cot�
		{
			if (!BlocPresentDroite(sprite[f]) && BlocPresentGauche(sprite[f])) {sprite[f].pos_x++; sprite[f].dep_x = 1;}// par la droite et j'oublie pas de le faire rebondir
			else if (!BlocPresentGauche(sprite[f]) && BlocPresentDroite(sprite[f])) {sprite[f].pos_x--; sprite[f].dep_x = -1;}//par la gauche et j'oublie pas de le faire rebondir
			else sprite[f].pos_y--; //par le haut
		}
		//if (hel_ObjExists(sprite[f].sprite)) 
		hel_ObjSetXY(sprite[f].sprite,sprite[f].pos_x,sprite[f].pos_y);
	}
}

void FixeEnnemis()
{
	for (b = goombad; b <= goombaf; b++) if (sprite[b].etat == sprite_vivant) FixeGoomba(b);
	if (fly.etat == sprite_vivant) FixeFly();
	if (koopa.etat == sprite_vivant) FixeKoopa();
}
