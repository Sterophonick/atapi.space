#include <mygba.h>
#include "header.h"
#include "collisions.h"


const unsigned short (*collisions_map)[1024];

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


u8 BlocPresentHaut(Sprite s) //EN_IWRAM // return 1 si il y a un obstacle en haut
{
   return ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > 0 )
   || ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > 0 )
   || ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > 0 )
   || ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > 0 );
}

u8 EN_IWRAM BlocPresentBas(Sprite s) //EN_IWRAM // return 1 si il y a un obstacle en dessous
{
   return ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > tile_vide )
   || (s.sprite == mario.sprite && (CollisionMarioPlateforme(sprite[tombanted]) || CollisionMarioPlateforme(sprite[tombanted+1]) || CollisionMarioPlateforme(sprite[tombanted+2]) || CollisionMarioPlateforme(sprite[tombanted+3]) || CollisionMarioPlateforme(sprite[tombanted+4]) || CollisionMarioPlateforme(sprite[tombanted+5]))) //plateformes tombantes
   || ( (CollisionMarioPlateforme(plateforme1) || CollisionMarioPlateforme(plateforme2) || CollisionMarioPlateforme(plateforme3)) && s.sprite == mario.sprite) //ce OU teste les collisions avec les plateformes mobiles et le tout dernier ET est l� pour du debug, mario doit descendre automatiquement quand le plafond arrive (la collision s'annule si mario cogne quelque chose avec sa t�te)
   || (CollisionMarioPlateforme(ascenseur) && s.sprite == mario.sprite && !carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)]);
}

u8 VraiBlocPresentBas(Sprite s) //EN_IWRAM // return 1 si il y a un "vrai" obstacle en dessous (d�cors)
{
   return ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > tile_vide );
}

u8 BlocPresentGauche(Sprite s) //EN_IWRAM // return 1 si il y a un obstacle � gauche
{
   return ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] > tile_vide );
}

u8 BlocPresentDroite(Sprite s)  // EN_IWRAM // return 1 si il y a un obstacle � droite
{
   return ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > tile_vide )
   || ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] > tile_vide );
}

u8 InterieurBloc(Sprite s) //EN_IWRAM // return 1 si le sprite est -dans- le d�cors
{
   return ( collisions_map[((Pty + s.pos_y + s.dec_bas_y - 1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x + 1) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y - 1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x + 1) >> 3)] > 0 )
   || ( collisions_map[((Pty + s.pos_y + s.dec_bas_y - 1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x - 1) >> 3)] > 4 && carte_map[((Pty + s.pos_y + s.dec_bas_y - 1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x - 1) >> 3)] > 0 );
}


void ScanEcran() //EN_IWRAM
{
	nbr_pieces = 0;
	nbr_bloc = 0;
	nbr_ennemis = 0;
	nbr_plateforme = 0;

	for (taby = 0; taby < 40; taby++)
	{
		for (tabx = 0; tabx < 1024; tabx++)
		{
			if (carte_map[taby][tabx] == pacoin_tile && num_niveau != 8)
			{
				pacoin_tile_x = tabx;
				pacoin_tile_y = taby;
				pacoin_etat = 1;
			}
			else if (carte_map[taby][tabx] == plateforme_tile)
			{				
				ns_plateformes[nbr_plateforme].pos_x = tabx << 3;
				ns_plateformes[nbr_plateforme].pos_y = taby << 3;
				ns_plateformes[nbr_plateforme].dep_x = 0;
				ns_plateformes[nbr_plateforme].dep_y = 0;

				ns_plateformes[nbr_plateforme].sprite = 0; //Cette variable indique qu'il n'y a pas de sprite affect� a cette plateforme

				if (!carte_map[taby][tabx+4]) //dans le cas d'une mini plateforme
				{
					ns_plateformes[nbr_plateforme].type = petite_plateforme;
				}
				else 
				{
					ns_plateformes[nbr_plateforme].type = grande_plateforme;
					carte_map[taby][tabx+4] = 0; //on efface la plateforme (ici ce qui d�passe) de la map
					carte_map[taby][tabx+5] = 0;
					carte_map[taby+1][tabx+4] = 0;
					carte_map[taby+1][tabx+5] = 0;
				}

				carte_map[taby][tabx] = 0; //on efface la plateforme de la map
				carte_map[taby][tabx+1] = 0;
				carte_map[taby][tabx+2] = 0;
				carte_map[taby][tabx+3] = 0;				
				carte_map[taby+1][tabx] = 0;
				carte_map[taby+1][tabx+1] = 0;
				carte_map[taby+1][tabx+2] = 0;
				carte_map[taby+1][tabx+3] = 0;
				
				hel_MapRedraw(2); //on redessine le niveau

				nbr_plateforme++;
			}
			if (collisions_map[taby][tabx] == piece_hg)			
			{
				ns_pieces[nbr_pieces].tile_x = tabx;
				ns_pieces[nbr_pieces].tile_y = taby;
				t_pieces[taby>>1][tabx>>1] = 1;
				nbr_pieces++;
			}			
			else if (collisions_map[taby][tabx] == bloc)
			{
				ns_blocs[nbr_bloc].tile_x = tabx;
				ns_blocs[nbr_bloc].tile_y = taby;
				t_blocs[taby>>1][tabx>>1] = 1;
				nbr_bloc++;
			}
		}
	}
}


void TestEcran() //ici je teste 2 colonnes en avance (et en retard) pour donner vie aux ennemis
{
	hel_MapGetPosition(2, &Ptx, &Pty);
	{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
	{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

	temp_test_ecran++;
	if (temp_test_ecran == 8) //non seulement ca me fait une tempo pour les trucs anim�s � l'�cran, mais en plus ca soulage le CPU qui va moins souvent tester des tiles
	{
		temp_test_ecran = 0;
		for (taby = Pt.Y - 10; taby < (Pt.Y + 30); taby++) //tout les tiles (+4) en hauteur
		{
			for (tabx = Pt.X - 10; tabx < Pt.X + 40; tabx++) //sur une colonne � droite...
			{
				if (carte_map[taby][tabx] == 0) {}
				else if (collisions_map[taby][tabx] == goomba_tile) AfficheGoomba(tabx,taby); //si c'est un goomba
				else if (collisions_map[taby][tabx] == koopa_tile) AfficheKoopa(tabx,taby); //si c'est un koopa
				else if (collisions_map[taby][tabx] == fly_tile) AfficheFly(tabx,taby); //si c'est un fly
				else if (num_niveau != 1 && collisions_map[taby][tabx] == sphinx_tile) AfficheSphinx(tabx,taby); //si c'est un sphinx
				else if (collisions_map[taby][tabx] == abeille_tile) AfficheAbeille(tabx,taby); //si c'est une abeille
				else if (collisions_map[taby][tabx] == poisson_os_tile) AffichePoissonV(tabx,taby); //si c'est un poisson
				else if (collisions_map[taby][tabx] == hippocampe_tile) AfficheHippocampe(tabx,taby); //si c'est un poisson
				else if (collisions_map[taby][tabx] == bossgoomba_tile) AfficheBoss(tabx,taby); //si c'est un boss
				else if (carte_map[taby][tabx] == boulet_tile) AfficheBoulet(tabx,taby); //si c'est un boulet
				else if (num_niveau == 6 && collisions_map[taby][tabx] == 21) AnimMer(tabx,taby);

				if (collisions_map[taby][tabx] == p_bas || collisions_map[taby][tabx] == p_haut) AffichePlateforme(tabx,taby); //si c'est une plateforme mobile
				else if (collisions_map[taby][tabx] == p_droite || collisions_map[taby][tabx] == p_gauche) AffichePlateforme(tabx,taby); //si c'est une plateforme mobile
			}			
		}

		RotationPiece();
		RotationBlocs();
		if (num_niveau != 8) RotationPAcoin();		
		face_piece += 4;  //on d�file les frames de la pi�ce
		face_coin += sens_coin;
		face_bloc += 4;  //on d�file les frames du bloc query		
		if (face_piece >= piece + 16) face_piece = piece; //hop on boucle
		if (face_bloc >= bloc_marron) face_bloc = bloc_query; //hop on boucle
		if (face_coin >= pacoin_tile + 24) sens_coin = -4;
		else if (face_coin <= pacoin_tile) sens_coin = 4;
		if (face_piece >= piece + 8)  face_mer1++;
		if (face_mer1 > 402) face_mer1 = 401;
	}
}

void SuperTestEcran() //ici je teste l'ensemble des tiles affich�s (et plein d'autres) pour donner vie aux ennemis
{
	hel_MapGetPosition(2, &Ptx, &Pty);
	{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
	{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

	for (taby = Pt.Y - 10; taby < (Pt.Y + 30); taby++) //tous les tiles en hauteur
	{
		for (tabx = Pt.X - 10; tabx < Pt.X + 40; tabx++) //tous les tiles en largeur
		{
			if (carte_map[taby][tabx] <= tile_vide) {}
			else if (collisions_map[taby][tabx] == goomba_tile) AfficheGoomba(tabx,taby); //si c'est un goomba
			else if (collisions_map[taby][tabx] == koopa_tile) AfficheKoopa(tabx,taby); //si c'est un koopa
			else if (collisions_map[taby][tabx] == fly_tile) AfficheFly(tabx,taby); //si c'est un fly
			else if (collisions_map[taby][tabx] == sphinx_tile) AfficheSphinx(tabx,taby); //si c'est un sphinx
			else if (collisions_map[taby][tabx] == abeille_tile) AfficheAbeille(tabx,taby); //si c'est une abeille
			else if (collisions_map[taby][tabx] == poisson_os_tile) AffichePoissonV(tabx,taby); //si c'est un poisson
			else if (collisions_map[taby][tabx] == hippocampe_tile) AfficheHippocampe(tabx,taby); //si c'est un poisson
			else if (collisions_map[taby][tabx] == bossgoomba_tile) AfficheBoss(tabx,taby); //si c'est un boss
			else if (carte_map[taby][tabx] == boulet_tile) AfficheBoulet(tabx,taby); //si c'est un boulet
			
			if (collisions_map[taby][tabx] == p_bas || collisions_map[taby][tabx] == p_haut) AffichePlateforme(tabx,taby); //si c'est une plateforme mobile
			else if (collisions_map[taby][tabx] == p_droite || collisions_map[taby][tabx] == p_gauche) AffichePlateforme(tabx,taby); //si c'est une plateforme mobile
		}
	}
}

void CollisionBloc(Sprite s) //ici je teste les collisions de mario avec un bloc (c'est tr�s long, r�p�titif et tr�s chiant, z'etes prevenus)
{
	hel_MapGetPosition(2, &Ptx, &Pty);
   {Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
   {Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}

   if (mario.etat != mario_mort){

   AnimExplosion(); //l'animation de destruction des blocs
   for (b = 0; b < 7; b++) { if (bloc_piece[b].choc > 0) ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b); } // j'anime le bloc pi�ce
   if (b_bloc[0].choc > 0) ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y); //j'anime le bloc marron cogn� par mario
   if (bloc_piece_plus[0].choc > 0) ChocBlocPiecePlus(); //j'anime le bloc jaune piece cogn� par mario
   for (b = 0; b < 4; b++) { if (bloc_std[b].choc > 0) ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b); } //j'anime le bloc jaune cogn� par mario

   if (mario.etat != mario_tombe) {

   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == bloc_gauche && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_invisible) s.pos_y++;

      //ham_DrawText(1,6,"X1a");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 1;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
			   ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
               b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 1;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
	  //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_ascenseur)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
		 b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_bonus)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_vie)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_etoile)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 1;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;
               bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x1 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;			   
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x1) >> 3)>>1)] = 0;
      }
   }
   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == bloc_gauche && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_invisible) s.pos_y++;

      //ham_DrawText(1,6,"X2a");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 1;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 1;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_ascenseur)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_bonus)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_vie)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_etoile)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 1;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;
               bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x2 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x2) >> 3)>>1)] = 0;
      }
   }
   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == bloc_gauche && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_invisible) s.pos_y++;

      //hel_BgTextPrintF(0,1,6,"X3a");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 1;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 1;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_ascenseur)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_bonus)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_vie)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_etoile)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 1;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;
			   bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x3 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x3) >> 3)>>1)] = 0;
      }
   }
   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == bloc_gauche && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_invisible) s.pos_y++;

      //hel_BgTextPrintF(0,1,6,"X4a");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 1;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 1;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_ascenseur)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_bonus)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_vie)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_etoile)
      {
         b_bloc[0].cote = 1;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 1;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;
			   bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x4 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x4) >> 3)>>1)] = 0;
      }
   }


   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == bloc_droite && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] == b_invisible) s.pos_y++;

      //ham_DrawText(1,6,"X1b");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 0;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 0;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y  - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_ascenseur)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_bonus)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_vie)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_etoile)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 0;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x1;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;
               bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x1 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1)>>1] = 0;
      }
   }
   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == bloc_droite && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] == b_invisible) s.pos_y++;

      //ham_DrawText(1,6,"X2b");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 0;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 0;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y  - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_ascenseur)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_bonus)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_vie)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_etoile)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 0;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x2;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;               
               bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x2 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1)>>1] = 0;
      }
   }
   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == bloc_droite && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] == b_invisible) s.pos_y++;

      //ham_DrawText(1,6,"X3b");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 0;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 0;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y  - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_ascenseur)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_bonus)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_vie)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_etoile)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 0;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x3;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;               
               bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x3 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1)>>1] = 0;
      }
   }
   else if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == bloc_droite && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] != bloc_marron)
   {
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] == b_invisible) s.pos_y++;

      //ham_DrawText(1,6,"X4b");
      //piece
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_piece && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 7; b++) //anim du bloc piece
         {
            if (!bloc_piece[b].choc) //je balance un autre sprite si il y en a d�ja occup�
            {
               total_piece++;
               score = score + 100;
               bloc_piece[b].cote = 0;
               bloc_piece[b].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_piece[b].pos_y = s.pos_y + s.dec_haut_y  - 63;
               bloc_piece[b].choc = 1;
               bloc_piece[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_piece[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
               ChocBlocPiece(bloc_piece[b].pos_x,bloc_piece[b].pos_y,b);
			   b=8;
            }
         }
      }
      //piece_plus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_pieceplus && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] >= tile_vide)
      {
         total_piece++;
         score = score + 100;
         bloc_piece_plus[0].cote = 0;
         bloc_piece_plus[0].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         bloc_piece_plus[0].pos_y = s.pos_y + s.dec_haut_y  - 63;
         bloc_piece_plus[0].choc = 1;
         bloc_piece_plus[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         bloc_piece_plus[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         if (!bloc_piece_plus[0].temp) bloc_piece_plus[0].temp = 1; //je balance la tempo de ce bloc seulement si c'est le premier choc
		 ChocBlocPiecePlus();
      }
      //ascenseur
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_ascenseur)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         b_bloc[0].type = ascens;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
	  //bonus
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_bonus)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         if (puissance == 0) b_bloc[0].type = champignon;
         else b_bloc[0].type = fleur;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //vie
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_vie)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         b_bloc[0].type = vie;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //etoile
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_etoile)
      {
         b_bloc[0].cote = 0;
         b_bloc[0].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
         b_bloc[0].pos_y = s.pos_y + s.dec_haut_y - 31;
         b_bloc[0].choc = 1;
         b_bloc[0].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
         b_bloc[0].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
         b_bloc[0].type = etoile;
		 ChocBloc(b_bloc[0].pos_x,b_bloc[0].pos_y);
      }
      //bloc standard
      if (collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == b_std && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] >= tile_vide)
      {
         for (b = 0; b < 4; b++) //anims du bloc standard
         {
            //anim bloc cogn� par mario
            if (!bloc_std[b].choc && power == petit_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est petit
            {
               bloc_std[b].cote = 0;
               bloc_std[b].pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3));
               bloc_std[b].pos_y = s.pos_y + s.dec_haut_y - 31;
               bloc_std[b].choc = 1;
               bloc_std[b].tile_pos_y = Pty + s.pos_y + s.dec_haut_y;
               bloc_std[b].tile_pos_x = Ptx + s.pos_x + s.dec_hb_x4;
			   ChocBlocStd(bloc_std[b].pos_x,bloc_std[b].pos_y,b);
               b = 5;
            }
            //anim bloc cogn� par super mario
            if (!bloc_morceaux[b].temp_anim && power == super_mario) //je balance un autre sprite si il y en a d�ja occup� et je v�rifie bien que mario est grand
            {
			   score = score + 50;               
               bloc_morceaux[b].temp_anim = 1;
               bloc_morceaux[b].anim = 0;
               bloc_morceaux[b].morceau1_pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau1_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau1_etat = 1;
               bloc_morceaux[b].morceau2_pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau2_pos_y = s.pos_y + s.dec_haut_y - 16;
               bloc_morceaux[b].morceau2_etat = 3;
               bloc_morceaux[b].morceau3_pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) - 1;
               bloc_morceaux[b].morceau3_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau3_etat = 5;
               bloc_morceaux[b].morceau4_pos_x = ((((s.pos_x + s.dec_hb_x4 - 8 + (Ptx - (Pt.X << 3))) >> 3)) << 3) - (Ptx - (Pt.X << 3)) + 9;
               bloc_morceaux[b].morceau4_pos_y = s.pos_y + s.dec_haut_y - 6;
               bloc_morceaux[b].morceau4_etat = 7;
               b = 5;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
               carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
            }
         }
      }

      if (carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] > 0)
      {
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = tile_vide;
         carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = tile_vide;

		 t_blocs[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1)>>1] = 0;
      }
   }}}
}


void CollisionPiece(Sprite s)  //ici je teste les collisions avec une piece (c'est encore plus long et chiant qu'avec les blocs !)
{
   if (mario.etat != mario_mort){

   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1); //son d'une piece
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)>>1] = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_haut_y) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1)>>1] = 0;
      return;
   }

   //bas
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)>>1] = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][(((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][(((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][(((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_bas_y) >> 3)>>1][(((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1)>>1] = 0;
      return;
   }

   //droite
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y1) >> 3)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y2) >> 3)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y3) >> 3)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y4) >> 3)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1)>>1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)>>1] = 0;
      return;
   }

   //gauche
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y1) >> 3)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y2) >> 3)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y3) >> 3)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[((Pty + s.pos_y + s.dec_dg_y4) >> 3)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      total_piece++;
      score = score + 100;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  t_pieces[(((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1)>>1][(((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1)>>1] = 0;
      return;
   }}
}


void CollisionPAcoin(Sprite s)  //ici je teste les collisions avec une piece PA (c'est encore plus long et chiant qu'avec les blocs !)
{
   if (mario.etat != mario_mort && pacoin_etat){

   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)-1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }

   //bas
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x3) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)+1][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }

   //droite
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_hg && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] == piece_bg && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_droite_x) >> 3)+1] = 0;
	  pacoin_etat = 0;
      return;
   }

   //gauche
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
	  AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_hd && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)+1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;	  
	  pacoin_etat = 0;
      return;
   }

   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y1) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y2) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y3) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }
   if ( collisions_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] == piece_bd && carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] != 0)
   {
      pacoin++;
	  ChoppePAcoin();
      score = score + 500;
      AdpcmStart(&ADPCM_piece,1,1);
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)-1] = 0;
      carte_map[((Pty + s.pos_y + s.dec_dg_y4) >> 3)-1][((Ptx + s.pos_x + s.dec_gauche_x) >> 3)] = 0;
	  pacoin_etat = 0;
      return;
   }}
}


void CollisionTombante(Sprite s)
{
   if ( carte_map[((Pty + s.pos_y + s.dec_haut_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x2) >> 3)] == tombante_tile ) {}
   else if ( carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == tombante_tile ) //alors le +2, c'est pour remplacer par le sprite un peu avant que mario n'y pose les pieds
   {
      AfficheTombante(((Ptx + s.pos_x + s.dec_hb_x1) >> 3),((Pty + s.pos_y + s.dec_bas_y) >> 3));
   }
   else if ( carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == tombante_tile )
   {
      AfficheTombante(((Ptx + s.pos_x + s.dec_hb_x4) >> 3),((Pty + s.pos_y + s.dec_bas_y) >> 3));
   }
   else if ( carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x1) >> 3)] == tombante_tile+1 )
   {
      AfficheTombante((((Ptx + s.pos_x + s.dec_hb_x1) >> 3)-1),((Pty + s.pos_y + s.dec_bas_y) >> 3));
   }
   else if ( carte_map[((Pty + s.pos_y + s.dec_bas_y) >> 3)][((Ptx + s.pos_x + s.dec_hb_x4) >> 3)] == tombante_tile+1 )
   {
      AfficheTombante((((Ptx + s.pos_x + s.dec_hb_x4) >> 3)-1),((Pty + s.pos_y + s.dec_bas_y) >> 3));
   }
}


u8 EN_IWRAM CollisionSprite(Sprite s1, Sprite s2) //EN_IWRAM
{
	sfp32 dec_x;
	sfp32 dec_y;

	if (s1.sprite == mario.sprite) {dec_x = Ptx; dec_y = Pty;}
	else {dec_x = 0; dec_y = 0;}

	return ((s1.pos_x + s1.dec_droite_x + dec_x >= s2.pos_x + s2.dec_gauche_x)
	&& (s1.pos_x + s1.dec_gauche_x + dec_x <= s2.pos_x + s2.dec_droite_x)
	&& (s1.pos_y + s1.dec_bas_y + dec_y >= s2.pos_y + s2.dec_haut_y)
	&& (s1.pos_y + s1.dec_haut_y + dec_y <= s2.pos_y + s2.dec_bas_y));
}

u8 CollisionMarioPlateforme(Sprite s) //EN_IWRAM
{
	return ((mario.pos_x + mario.dec_droite_x >= s.pos_x + s.dec_gauche_x - Ptx - s.ecran_delta_x)
	&& (mario.pos_x + mario.dec_gauche_x <= s.pos_x + s.dec_droite_x - Ptx - s.ecran_delta_x)
	&& (mario.pos_y + mario.dec_bas_y >= s.pos_y - Pty - s.ecran_delta_y)
	&& (mario.pos_y + mario.dec_bas_y <= s.pos_y + 4 - Pty - s.ecran_delta_y));
}

void CollisionFoesBalle(u8 f)
{
	//sprite[f].pos_x -= Ptx;
	//sprite[f].pos_y -= Pty;

	if (balle.etat == sprite_vivant)
	{
		if (sprite[f].limite > 0) //dans le cas d'ennemis qui ont besoin de plusieurs tirs pour mourrir
		{
			sprite[f].limite--; //on reduit leur resistance
		}
		if (!sprite[f].limite) //une fois la limite de r�sistance atteinte
		{
			if (f != bossgoomban)
			{
				AffichePoints((sprite[f].pos_x-Ptx),(sprite[f].pos_y-Pty),(sprite[f].score * multiple_score));
				score += sprite[f].score * multiple_score; //on ajoute le score
				if (sprite[f].pos_x < mario.pos_x) sprite[f].dep_x = -1; //si il �tait � gauche de mario, anim vers la gauche
				else sprite[f].dep_x = 1; //et inversement
			}			
			sprite[f].etat = sprite_mort2; //il meurt
			sprite[f].temp_mort = 0;
			AdpcmStart(&ADPCM_ennemi,1,1); //le son de l'ennemi tu� par une balle
		}
		
		balle.dep_x = 0; //et on efface la balle
		balle.dep_y = 0;
		balle.pos_x = 240;
		balle.pos_y = 160;
		balle.etat = sprite_inactif;
		hel_ObjSetVisible(balle.sprite,0);
	}

	//sprite[f].pos_x += Ptx;
	//sprite[f].pos_y += Pty;
}

void EN_IWRAM CollisionFoesMario(u8 f) // EN_IWRAM
{
	if (mario_invincible) //invincible ?
	{
		AffichePoints((sprite[f].pos_x-Ptx),(sprite[f].pos_y-Pty),(sprite[f].score * multiple_score));
		score += sprite[f].score * multiple_score; //on ajoute le score
		if ((sprite[f].pos_x-Ptx) < mario.pos_x) sprite[f].dep_x = -1; //si il �tait � gauche de mario, anim vers la gauche
		else sprite[f].dep_x = 1; //et inversement
		sprite[f].etat = sprite_mort2;
		AdpcmStart(&ADPCM_ennemi,1,1);
	}
	else if (f != bullen && f != fireballn && f != flechen && !mario.saut && !BlocPresentBas(mario) && (mario.pos_y + mario.dec_bas_y >= sprite[f].pos_y + sprite[f].dec_haut_y - Pty) && (mario.pos_y + mario.dec_bas_y <= sprite[f].pos_y + sprite[f].dec_dg_y2 - Pty))
	{
		sprite[f].etat = sprite_mort; //si mario saute sur un ennemi
		sprite[f].anim_mort = 0;
		sprite[f].temp_mort = 0;
	}
	else if (!puissance && !mario_clignote && mario.etat != mario_gp && mario.etat != mario_pg && mario.etat != mario_fleur) //sinon il rate l'ennemi et c'est la mort
	{
		mario.etat = mario_mort;
		mario.temp_mort = 0;
		mario.anim_mort = 0;
		mario.dep_y = 1;
		sprite[f].etat = sprite_inactif;
	}
	else  //ou le retrecissement
	{
		mario.etat = mario_gp;
		mario.temp_mort = 0;
		mario.anim_mort = 0;
	}
}

void EN_IWRAM CollisionFoesMarioPrecis() //EN_IWRAM //rajouter ici tous les ennemis
{
	for (b = goombad; b <= goombaf; b++) {if (sprite[b].etat == sprite_vivant && CollisionSprite(mario,sprite[b])) CollisionFoesMario(b);} //collision avec un ennemi
	if (fly.etat == sprite_vivant && CollisionSprite(mario,fly)) CollisionFoesMario(flyn);
	if (koopa.etat == sprite_vivant && CollisionSprite(mario,koopa)) CollisionFoesMario(koopan);
}

void CollisionMarioPiques()
{
	if ( carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x1) >> 3)] == pique_b_tile 
    || carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x2) >> 3)] == pique_b_tile 
    || carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x3) >> 3)] == pique_b_tile 
    || carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x4) >> 3)] == pique_b_tile 
	|| carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x1) >> 3)] == pique_h_tile 
    || carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x2) >> 3)] == pique_h_tile 
    || carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x3) >> 3)] == pique_h_tile 
    || carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x4) >> 3)] == pique_h_tile ) {mario.etat = mario_mort; mario.temp_mort = 0; mario.anim_mort = 0; mario.dep_y = 1;}
}

void CollisionMarioFlotte()
{
	if ( carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x1) >> 3)] == 401 
    || carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x2) >> 3)] == 401 
    || carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x3) >> 3)] == 401 
    || carte_map[((Pty + mario.pos_y + mario.dec_bas_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x4) >> 3)] == 401 
	|| carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x1) >> 3)] == 402 
    || carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x2) >> 3)] == 402 
    || carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x3) >> 3)] == 402 
    || carte_map[((Pty + mario.pos_y + mario.dec_haut_y) >> 3)][((Ptx + mario.pos_x + mario.dec_hb_x4) >> 3)] == 402 ) {mario.etat = mario_mort; mario.temp_mort = 0; mario.anim_mort = 0; mario.dep_y = 1;}
}
