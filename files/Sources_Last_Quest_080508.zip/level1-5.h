#include "gfx/maps/lq/map_5.til.c"
#include "gfx/maps/lq/map_5.map.c"
#include "gfx/maps/lq/map_5.pal.c"
#include "gfx/maps/lq/map_5bg.map.c"
