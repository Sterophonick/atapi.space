#include <mygba.h>
#include "header.h"



// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

void AfficheAbeille(u32 tabrx, u32 tabry) 
{
	abeille.pos_x = (tabrx << 3); //je converti en pixels
	abeille.pos_y = (tabry << 3);
	hel_ObjSetXY(abeille.sprite,(abeille.pos_x-Ptx),(abeille.pos_y-Pty));
	if ((abeille.pos_x-Ptx) < -54 || (abeille.pos_x-Ptx) > 240 || (abeille.pos_y-Pty) < -54 || (abeille.pos_y-Pty) > 160) hel_ObjSetXY(abeille.sprite,240,160);
	hel_ObjSetVisible(abeille.sprite,1);
	hel_ObjUpdateGfx(abeille.sprite,(void*)&fly_Bitmap[0]);
	hel_ObjSetVFlip(abeille.sprite,0);
	hel_ObjSetHFlip(abeille.sprite,0);
	carte_map[tabry][tabrx] = 0; //et j'efface les tiles
	hel_MapRedraw(2); //on redessine le niveau
	abeille.dep_x = -1; //r�initialisation des variables
	abeille.saut = 0;
	abeille.pos_tab_saut = 0;
	abeille.vitesse = 0;
	abeille.anim_mort = 0;
	abeille.temp_course = 0;
	abeille.temp_mort = 0;
	abeille.limite = 2;
	abeille.etat = sprite_vivant;
}

void GestionAbeille()
{
	if (abeille.etat == sprite_vivant)
	{
		AnimeAbeille();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//abeille.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//abeille.pos_y += Pty;
			if (CollisionSprite(balle,abeille)) CollisionFoesBalle(abeillen);
			//abeille.pos_x -= Ptx;
			//abeille.pos_y -= Pty;
			if (CollisionSprite(mario,abeille)) CollisionFoesMario(abeillen);			
		}
	}
	else if (abeille.etat == sprite_mort) 
	{
		EcraseAbeille();
		abeille.pos_x -= Ptx;
		abeille.pos_y -= Pty;
		if (!BlocPresentBas(abeille)) abeille.pos_y += 2;  //petite gravit� uniquement lors de la mort
		hel_ObjSetY(abeille.sprite,abeille.pos_y);
		abeille.pos_x += Ptx;
		abeille.pos_y += Pty;
	}
	else if (abeille.etat == sprite_mort2) AnimMortFoes2(abeillen);
	if (fleche.etat == sprite_vivant && CollisionSprite(mario,fleche)) CollisionFoesMario(flechen);
}

void AnimeAbeille()
{
	abeille.pos_x -= Ptx;
	abeille.pos_y -= Pty;
   
	//ExtractionFoes(abeillen);	

	if (abeille.saut) //le tir en fait
	{
		abeille.dep_y++;
		if (abeille.dep_y >= 8)
		{
			abeille.dep_y = 0;
			abeille.pos_tab_saut++;
			if (abeille.pos_tab_saut == 2) abeille.dep_y = -15;
			if (abeille.pos_tab_saut == 3) 
			{
				abeille.dep_y = -6;
				fleche.etat = sprite_vivant;
				hel_ObjSetVisible(fleche.sprite,1);
				fleche.pos_x = abeille.pos_x + 16 + Ptx;
				fleche.pos_y = abeille.pos_y + 5 + Pty;				
			}
			if (abeille.pos_tab_saut >= 4) 
			{
				abeille.pos_tab_saut = 0; 
				abeille.saut = 0;				
			}			
		}
	}
	if (fleche.etat == sprite_vivant) fleche.pos_y+=2;

	if (fleche.etat == sprite_inactif && mario.pos_x >= abeille.pos_x && mario.pos_x <= abeille.pos_x+24) {abeille.dep_x = 0; abeille.saut = 1;} //l'abeille est au dessus de mario

	if (fleche.pos_y-Pty > 180)
	{
		fleche.etat = sprite_inactif;
		fleche.pos_x = 0;
		fleche.pos_y = 320;
		hel_ObjSetVisible(fleche.sprite,0);
		abeille.saut = 0;
		abeille.dep_x = -1;
	}

	abeille.pos_x += abeille.dep_x;

	AnimAilesAbeille();
	
	//�loignement
	if (Pt.X != 0 && !abeille.dep_x && ((abeille.pos_x <= (mario.pos_x - 400)) || (abeille.pos_x >= (mario.pos_x + 300)))) //si l'abeille est trop loin de mario
	{
		FixeAbeille();
	}

	abeille.pos_x += Ptx;
	abeille.pos_y += Pty;

	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjSetXY(abeille.sprite,(abeille.pos_x-Ptx),(abeille.pos_y-Pty));
		if ((abeille.pos_x-Ptx) < -54 || (abeille.pos_x-Ptx) > 240 || (abeille.pos_y-Pty) < -54 || (abeille.pos_y-Pty) > 160) hel_ObjSetXY(abeille.sprite,240,160);		
	
		hel_ObjSetXY(fleche.sprite,(fleche.pos_x-Ptx),(fleche.pos_y-Pty));
		if ((fleche.pos_x-Ptx) < -54 || (fleche.pos_x-Ptx) > 240 || (fleche.pos_y-Pty) < -54 || (fleche.pos_y-Pty) > 160) hel_ObjSetXY(fleche.sprite,240,160);
	}

}

void FixeAbeille()
{
	abeille.dep_x = 0;
	abeille.etat = sprite_inactif;
	abeille.pos_x = 0;
	abeille.pos_y = 320;
	hel_ObjSetVisible(abeille.sprite,0);
}
      
void EcraseAbeille()
{
	abeille.temp_mort++;
	if (abeille.temp_mort == 1)
	{
		score += abeille.score * multiple_score;
		AffichePoints((abeille.pos_x-Ptx),(abeille.pos_y-Pty),(abeille.score * multiple_score));
		multiple_score *= 2;
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�
	}
	if (abeille.temp_mort == 50)
	{
		AdpcmStart(&ADPCM_mort2,1,1); //mort2
		abeille.etat = sprite_mort2;
		abeille.temp_mort = 0;
		if (mario.pos_x < abeille.pos_x-Ptx) abeille.dep_x = 1; //le sens est d�cid� selon la position de mario
		else abeille.dep_x = -1;
	}
	{
		hel_ObjUpdateGfx(abeille.sprite,(void*)&abeille_Bitmap[6144]);
		hel_ObjSetXY(abeille.sprite,(abeille.pos_x-Ptx),(abeille.pos_y-Pty));
		if ((abeille.pos_x-Ptx) < -54 || (abeille.pos_x-Ptx) > 240 || (abeille.pos_y-Pty) < -54 || (abeille.pos_y-Pty) > 160) hel_ObjSetXY(abeille.sprite,240,160);		
	}
}

