#include "header.h"
#include "Adpcm.h"


const s8 Tbl_cos [320] = {127,126,126,126,126,126,125,125,124,123,123,122,121,120,119,118,117,116,114,113,111,110,108,107,105,103,101,99,97,95,93,91,89,87,85,82,80,77,75,72,70,67,64,62,59,56,53,51,48,45,42,39,36,33,30,27,24,21,18,14,11,8,5,2,0,-3,-6,-10,-13,-16,-19,-22,-25,-28,-31,-34,-37,-40,-43,-46,-49,-52,-55,-57,-60,-63,-66,-68,-71,-73,-76,-78,-81,-83,-86,-88,-90,-92,-94,-96,-98,-100,-102,-104,-106,-107,-109,-111,-112,-113,-115,-116,-117,-118,-119,-120,-121,-122,-123,-124,-124,-125,-125,-126,-126,-126,-126,-126,-126,-126,-126,-126,-126,-125,-125,-124,-124,-123,-122,-121,-121,-120,-119,-117,-116,-115,-114,-112,-111,-109,-108,-106,-104,-102,-101,-99,-97,-95,-92,-90,-88,-86,-84,-81,-79,-76,-74,-71,-69,-66,-63,-61,-58,-55,-52,-49,-46,-43,-40,-38,-35,-32,-28,-25,-22,-19,-16,-13,-10,-7,-4,-1,2,5,8,11,14,17,20,23,26,29,32,35,38,41,44,47,50,53,56,59,61,64,67,69,72,75,77,79,82,84,87,89,91,93,95,97,99,101,103,105,106,108,110,111,113,114,115,117,118,119,120,121,122,123,123,124,125,125,125,126,126,126,126,127,127,126,126,126,126,125,125,124,124,123,122,121,120,119,118,117,116,115,113,112,110,109,107,106,104,102,100,98,96,94,92,90,88,85,83,81,78,76,73,71,68,65,63,60,57,54,52,49,46,43,40,37,34,31,28,25,22,19,16,12,9,6,3,0};

u8 ATTR_EWRAM ATTR_ALIGNED(4) g_BgTextSystemMemory[HEL_SUBSYSTEM_BGTEXT_REQUIREDMEMORY];
u8 ATTR_EWRAM ATTR_ALIGNED(4) g_ObjSystemBuffer[HEL_SUBSYSTEM_OBJ_REQUIREDMEMORY];
u8 ATTR_EWRAM ATTR_ALIGNED(4) g_MapSystemBuffer[HEL_SUBSYSTEM_MAP_REQUIREDMEMORY];

volatile bool NouvelleFrame = TRUE;

TPoint32 Pt = {0,0};

sfp32 Ptx;
sfp32 Pty;

unsigned short EN_EWRAM carte_map[40][1024];
//unsigned short EN_EWRAM carte_back[40][1024];
unsigned short retry[6][4];

bool EN_EWRAM t_blocs[20][512];
bool EN_EWRAM t_pieces[20][512];
//bool EN_EWRAM t_ennemis[20][512];

Ns_blocs EN_EWRAM ns_blocs[500];
Ns_pieces EN_EWRAM ns_pieces[500];
//Ns_ennemis EN_EWRAM ns_ennemis[500];
Ns_plateformes EN_EWRAM ns_plateformes[20];




// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


int main(void)
{
	*((volatile u32*)0x4000204) = 0x4317;   

    ham_Init();
    hel_SysSetPrefetch(TRUE);
	hel_PadInit(); //initialisation du pad
    hel_PadSetMode(PAD_MODE_DOWN); //detection au moment de l'appui
    hel_MapInit(g_MapSystemBuffer);
    hel_ObjInit(g_ObjSystemBuffer);
    hel_BgTextInit((void*)g_BgTextSystemMemory);

    ham_SetBgMode(0); // mode 0
	InitAdpcmVbl();	
	ham_InitRAM(RAM_TYPE_SRAM_256K); //pour la sauvegarde

	ham_LoadIntFromRAM("quete",&quete);
	ham_LoadIntFromRAM("total_levels",&total_levels);
	if (!quete) quete = 10000000;

	//quete = 22222222;
	//total_levels = 7;

	mario_map.pos_x = 5;
	mario_map.pos_y = 73;

	InitSprites();
	InitSpritesLvl1();

	//WorldMap();
	Intro();
	//AfficheFin();

	if (!num_niveau) AfficheNiveau11();
    else if (num_niveau == 1) AfficheNiveau12();
    else if (num_niveau == 2) AfficheNiveau13();
	else if (num_niveau == 3) AfficheNiveau14();
	else if (num_niveau == 4) AfficheNiveau15();
	else if (num_niveau == 5) AfficheNiveau16();
	else if (num_niveau == 6) AfficheNiveau17();
	else if (num_niveau == 7) AfficheNiveau18();

	Initialisation(); // init des variables	 

	hel_MapGetPosition(2, &Ptx, &Pty);
   {Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
   {Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}	

	SuperTestEcran();
   
    mario.pos_y = retry[2][2];
    hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y);
    vies = 5;


    while(TRUE) //boucle principale
    {
		if(NouvelleFrame)
        {
			//AfficheCPU();
			AppuiTouche();
            TestEcran();
            AfficheInfos();            
			NouvellePosition();
			//AfficheVariables();

			hel_MapRedraw(2); //on redessine le niveau			
            NouvelleFrame = 0;
         }
    }

    return 0;
}


void VBLInterruptHandler()
{
	hel_ObjTransmit();
	hel_MapTransmit();
	
	AdpcmDecodeVbl(0);
	AdpcmDecodeVbl(1);
	
	hel_IntrAcknowledge(INT_TYPE_VBL);
	NouvelleFrame = TRUE;
}
