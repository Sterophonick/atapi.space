//#include "gfx/maps/maps/map_3bg.til.c"
//#include "gfx/maps/maps/map_3_bg.map.c"

#include "gfx/maps/lq/map_3.til.c"
#include "gfx/maps/lq/map_3.map.c"
#include "gfx/maps/lq/map_3.pal.c"
#include "gfx/maps/lq/map_3bg.map.c"
//#include "gfx/maps/maps/map_3bg.til.c"

/*#include "gfx/maps/lv1-2/desert12.map.c"
#include "gfx/maps/lv1-2/blanc12.map.c"
#include "gfx/maps/lv1-2/desert12.til.c"*/



