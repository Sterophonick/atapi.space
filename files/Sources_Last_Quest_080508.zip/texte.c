#include <mygba.h>
#include "header.h"


volatile unsigned short *CompteurScanline = (volatile unsigned short *)0x4000006;


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void AfficheCPU()
{
	cpu = *CompteurScanline;
    if (cpu > 160) cpu1 = cpu - 160;
    else cpu1 = cpu + 70;
    compteur += ((100*cpu1)/230);
    t_moy_cpu++;
    if (t_moy_cpu == 40) {moy_cpu = compteur/40; t_moy_cpu = 0; compteur = 0;}
    if (moy_cpu >= 10) hel_BgTextPrintF(0,22,2,0,"CPU:%d%",moy_cpu);
    else hel_BgTextPrintF(0,22,2,0,"CPU: %d%",moy_cpu);
}


void AfficheInfos()
{
	if (total_piece == 100) 
	{
		total_piece = 0; vies++; 
		AdpcmStart(&ADPCM_vie,1,1);
	}
    if (vies > 99) vies = 99;
	if (score > 9999999) score = 9999999;

    hel_BgTextPrintF(0,4,0,0,"%d ",vies);
    hel_BgTextPrintF(0,8,0,0,"%d ",total_piece); //le total de pi�ces
    hel_BgTextPrintF(0,12,0,0,"%d ",temps);    
    hel_BgTextPrintF(0,22,0,0,"%d ",score);
   
    AnimePoints();
}


void AfficheVariables()
{
	hel_BgTextPrintF(0,1,1,0,"PtX: %d  ",Ptx);
    hel_BgTextPrintF(0,1,2,0,"PtY: %d  ",Pty);
    //hel_BgTextPrintF(0,1,3,0,"mariox: %d  ",mario.pos_x);
    //hel_BgTextPrintF(0,1,4,0,"marioy: %d  ",mario.pos_y);
    //hel_BgTextPrintF(0,1,5,0,"test: %d        ",test);*/

	//hel_BgTextPrintF(0,1,8,0,"test: %d     ",AdpcmStatus(0));
	//hel_BgTextPrintF(0,1,6,0,"test: %d     ",bulle.dep_y);

	//hel_BgTextPrintF(0,1,5,0,"b: %d  ",bonus.course);

	//abeille.etat = sprite_vivant;
	
	/*hel_BgTextPrintF(0,20,5,0,"1: %d    ",((quete%100000000 - quete%10000000)/10000000));
	hel_BgTextPrintF(0,20,6,0,"2: %d    ",((quete%10000000 - quete%1000000)/1000000));
	hel_BgTextPrintF(0,20,7,0,"3: %d    ",((quete%1000000 - quete%100000)/100000));
	hel_BgTextPrintF(0,20,8,0,"4: %d    ",((quete%100000 - quete%10000)/10000));
	hel_BgTextPrintF(0,20,9,0,"5: %d    ",((quete%10000 - quete%1000)/1000));
	hel_BgTextPrintF(0,20,10,0,"6: %d    ",((quete%1000 - quete%100)/100));
	hel_BgTextPrintF(0,20,11,0,"7: %d    ",((quete%100 - quete%10)/10));
	hel_BgTextPrintF(0,1,5,0,"7: %d    ",quete);*/
	hel_BgTextPrintF(0,1,5,0,"2: %d  ",boulet.tile_origine_x);
	hel_BgTextPrintF(0,1,6,0,"3: %d  ",(mario.pos_x - 300));
	//hel_BgTextPrintF(0,1,4,0,"4: %d  ",carte_map[pacoin_tile_y+1][pacoin_tile_x+1]);
	//hel_BgTextPrintF(0,1,2,0,"x: %d  ",sprite[plateforme1n+0].dep_x);
	//hel_BgTextPrintF(0,1,3,0,"y: %d  ",sprite[plateforme1n+0].dep_y);
	//hel_BgTextPrintF(0,1,4,0,"y: %d  ",sprite[plateforme1n+0].ecran_delta_y);
	//hel_BgTextPrintF(0,1,3,0,"ns_x: %d  ",ns_plateformes[0].pos_y);
	//hel_BgTextPrintF(0,1,4,0,"ns_x: %d  ",CollisionMarioPlateforme(plateforme1));
	
	//hel_BgTextPrintF(0,1,5,0,"ec_d: %d  ",sprite[plateforme1n+0].ecran_delta_y);
	hel_BgTextPrintF(0,1,3,0,"ma_x: %d  ",mario.pos_x);
	hel_BgTextPrintF(0,1,4,0,"ma_y: %d  ",mario.pos_y);
	//hel_BgTextPrintF(0,1,6,0,"x: %d  ",sprite[goombad].anim_mort);
	//hel_BgTextPrintF(0,1,7,0,"y: %d  ",sprite[goombad+1].anim_mort);
	//hel_BgTextPrintF(0,1,5,0,"3: %d  ",mario.pos_y);
    //hel_BgTextPrintF(0,1,6,0,"4: %d  ",CollisionMarioPlateforme(sprite[plateforme1n+2]));
	//hel_BgTextPrintF(0,1,5,0,"Bas = %d ",BlocPresentBas(mario));
    //hel_BgTextPrintF(0,1,3,0,"Droite = %d ",BlocPresentDroite(mario));
    //hel_BgTextPrintF(0,1,4,0,"Gauche = %d ",BlocPresentGauche(mario));
   

}

