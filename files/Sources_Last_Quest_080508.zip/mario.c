#include <mygba.h>
#include "header.h"


unsigned short tab_saut[27] = {5,5,4,4,4,4,4,4,4,3,3,3,3,3,3,2,2,2,2,2,2,2,1,1,1,0,0}; // le tableau de saut de mario


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void NouvellePosition() //mario dans tous ses �tats... (et un peu d'autres sprits aussi)
{
	if (!varitest && mario.etat != mario_mort && mario.etat != mario_gp && mario.etat != mario_pg && mario.etat != mario_fleur){ //on bloque tout quand mario meurt ou est en train de "changer"

	if (mario.etat != mario_gagne) EcoulementTemps();

	JoueMusique();

      // gravit� ---
	if(!BlocPresentBas(mario) && !mario.saut) // si mario est en plein saut ou en train de tomber
	{
		mario.etat = mario_tombe; // animation tombe
		mario.gravite = tab_saut[mario.pos_tab_saut]; // on recupere la gravit� dans mon tableau de saut
		//mario.gravite = 3; //test only
		for (g = 0; g < mario.gravite; g++) // on l'applique en la d�composant pour eviter les bugs de collision
		{
			if (!BlocPresentBas(mario)) // si pas d'obstacle en dessous
			{
				if (mario.pos_y >= limite_y && Pty < 160) // on defile la map vers le haut si mario a atteind une certaine hauteur
				{
					if (mario.pos_y >= 60)
					{
						hel_MapScroll(2,0,FIXED_FROMINT(1));
						hel_MapGetPosition(2, &Ptx, &Pty);
						{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
						{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
					}
					else mario.pos_y++;
				}
				else if (mario.pos_y < limite_y) mario.pos_y++; // sinon on ne change que son ordonn�e
				if (Pt.Y == 20) mario.pos_y++; // gestion du bas du niveau

				CollisionFoesMarioPrecis(); // il ne faut pas que mario "rate" l'ennemi
			}
		}
		mario.pos_tab_saut--; // on recule dans le tableau de saut (normal, mario tombe)

		if (mario.pos_y > 180) //faut pas tomber ^^
		{
			AdpcmStart(&ADPCM_frein,1,0); //on arrete la musique avec un petit son
			Pause(800);
			AdpcmStart(&ADPCM_mort,1,1);  //la petite musique de la mort
			MortMario(1100);
		}

		if (mario.pos_tab_saut > 0) //si mario est en phase descendante du saut
		{
			if (inertie_droite > 0 && !BlocPresentDroite(mario)) t_inertie_droite++; //on temporise un peu
			if (inertie_gauche > 0 && !BlocPresentGauche(mario)) t_inertie_gauche++;
		}
		if (t_inertie_droite == 3) {inertie_droite--; t_inertie_droite = 0;} //et on enl�ve de l'inertie
		if (t_inertie_gauche == 3) {inertie_gauche--; t_inertie_gauche = 0;} //le but �tant que mario saute moins loin si on ne maintiens pas une direction

		if (mario.pos_tab_saut == -1) mario.pos_tab_saut = 0; // la position finale (enfin 1ere) du tableau
	}


      // saut ---
	if(mario.saut) // si il a commenc� son saut (appui sur A)
	{
		mario.etat = mario_saut; // animation saut
		mario.gravite = tab_saut[mario.pos_tab_saut]; // on recupere la gravit� dans mon tableau de saut
		for (g = 0; g < mario.gravite; g++) // on l'applique en la d�composant pour eviter les bugs de collision
		{
			if (BlocPresentHaut(mario)) AdpcmStart(&ADPCM_bump,1,1); //bruit quand mario se cogne la tete au plafond
         
			if (!BlocPresentHaut(mario)) // si pas d'obstacle en haut
			{
				if (mario.pos_y <= limite_y && Ptx < 7896) // on defile la map vers le bas si mario a atteind une certaine hauteur pour ne pas qu'il disparaisse de l'�cran
				{
					hel_MapScroll(2,0,FIXED_FROMINT(-1));
					hel_MapGetPosition(2, &Ptx, &Pty);
					{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
					{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
				}
				else if (mario.pos_y > limite_y) mario.pos_y--; // sinon on ne change que son ordonn�e
				else if (Ptx >= 7896) mario.pos_y--;
				if (Pt.Y == 0) mario.pos_y--; //gestion du haut du niveau
			}
			else mario.saut = 0; // collision avec un plafond			
		}
		mario.pos_tab_saut++; // on avance dans mon tableau de saut
		if ((A_relache && mario.pos_tab_saut < 18) || (!saut_maximum && mario.pos_tab_saut == 14)) mario.pos_tab_saut = 18; // arret du saut si on relache A assez tot ou quand mario a atteind la hauteur max (valeur qui change en fonction de l'appui de B ou pas) : on fait tout simplement un bon dans mon tableau de saut
		if (mario.pos_tab_saut == 27) //sommet du saut
		{
			saut_maximum = saut_normal;
			mario.delta_course = 0;
			mario.saut = 0; // mario ne saute plus, donc...
			mario.pos_tab_saut--; // on commence d�ja a descendre
		}
	}
	else mario.saut = 0;
	
	if (mario.pos_y > 0)
	{
		CollisionMarioPiques(); //assez �vident, non ?
		if (num_niveau == 6) CollisionMarioFlotte();
	}
	}

	hel_MapGetPosition(2, &Ptx, &Pty);
	{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
	{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
	
	UpdateAffichageMario(); //les differentes positions et animations de mario
	GestionBonus(); //tout ce qui peut arriver aux bonus
	CollisionBloc(mario); //mario cogne un bloc ?
	if (Ptx <= retry[2][1]) CollisionPiece(mario); //prend une pi�ce ?
	else CollisionPAcoin(mario); //ou une piece PA ?
	CollisionTombante(mario); //survole une plateforme tombante ?   
	GestionPlateformes();
	GestionFoes();
	if (balle.etat == sprite_vivant) TirBalle();
	
}


void UpdateAffichageMario()
{
    if (mario_clignote) AnimMarioClignote();
    if (mario_invincible) AnimMarioInvincible();

    if (BlocPresentBas(mario)) //mario au sol
	{
		if (mario.pos_y < 60 && Ptx < 7896 && Pty > 0 && VraiBlocPresentBas(mario) && mario.etat != mario_mort && mario.etat != mario_gp && mario.etat != mario_pg && mario.etat != mario_fleur)
		{
			hel_MapScroll(2,0,FIXED_FROMINT(-1));
			hel_MapGetPosition(2, &Ptx, &Pty);
			{Ptx = FIXED_TOINT(Ptx); Pty = FIXED_TOINT(Pty);}
			{Pt.X = Ptx >> 3; Pt.Y = Pty >> 3;}
			mario.pos_y++;
		}

		if (VraiBlocPresentBas(mario))
		{
			if (!sprite[plateforme1n+0].ecran_delta_y && !sprite[plateforme1n+0].dep_x && sprite[plateforme1n+0].dep_y != 0) sprite[plateforme1n+0].ecran_delta_y = 100;
			if (!sprite[plateforme1n+1].ecran_delta_y && !sprite[plateforme1n+1].dep_x && sprite[plateforme1n+1].dep_y != 0) sprite[plateforme1n+1].ecran_delta_y = 100;
			if (!sprite[plateforme1n+2].ecran_delta_y && !sprite[plateforme1n+2].dep_x && sprite[plateforme1n+2].dep_y != 0) sprite[plateforme1n+2].ecran_delta_y = 100;			
		}
		//if (mario.pos_x > 200 && mario.etat != mario_gagne) {mario.anim_mort = 0; mario.etat = mario_gagne;} //fin du niveau
		multiple_score = 1; //on stoppe la multiplication du score
	}
    if (mario.etat != mario_mort)
    {
	    for (b = plateforme1n; b <= plateforme3n; b++) {if (CollisionMarioPlateforme(sprite[b]) && (mario.pos_y + mario.dec_bas_y) >= (sprite[b].pos_y-Pty)) mario.pos_y = sprite[b].pos_y - mario.dec_bas_y - Pty;} //debug au cas ou mario "entre" dans la plateforme
	    for (b = tombanted; b <= tombantef; b++) {if (CollisionMarioPlateforme(sprite[b]) && (mario.pos_y + mario.dec_bas_y) >= (sprite[b].pos_y-Pty)) mario.pos_y = sprite[b].pos_y - mario.dec_bas_y - Pty;} //debug au cas ou mario "entre" dans la plateforme tombante
	    if (CollisionMarioPlateforme(ascenseur) && (mario.pos_y + mario.dec_bas_y) >= (ascenseur.pos_y-Pty)) mario.pos_y = ascenseur.pos_y - mario.dec_bas_y - Pty; //debug au cas ou mario "entre" dans l'ascenseur
    }

	switch (mario.etat) //les differentes positions et animations de mario
    {
		case mario_stop:
         hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(0 + power) * am]); //le "am" passe � 0 pour faire "disparaitre" mario pour le faire clignoter facilement
         mario.temp_course = 0;
         inertie_droite = 0;
         inertie_gauche = 0;
         mario.course = 1;
         mario.delta_course = 0;
         mario.pos_tab_saut = 0;
         inert_saut = 0;
         inertie = 0;
         inertie_bloc = 0;
         if (mario.etat != mario_tuyau && InterieurBloc(mario)) //je remet mario en place si il est rentr� dans le d�cors
         {
            while (InterieurBloc(mario))
            {
               if (inertie_gauche > 0) mario.pos_x++; //par la droite
               else if (inertie_droite > 0) mario.pos_x--; //par la gauche
               else mario.pos_y--; //ou par le haut
            }
            hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y); // on applique les changements de suite, histoire d'etre le + discret possible
         }
         break;

        case mario_marche:
         AnimMarioMarche();
         break;

        case mario_tombe:
         hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(1024 + power) * am]);
         break;

        case mario_saut:
         hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(1536 + power) * am]);
         break;

        case mario_derape:
         mario.temp_course = 0;
         hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(2048 + power) * am]);
         break;

        case mario_gagne:
         FinNiveau();
         break;

        /*case mario_tuyau:
         hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(3072 + power) * am]);
         break;*/

        case mario_baisse:
         hel_ObjUpdateGfx(mario.sprite,(void*)&mario_Bitmap[(3584 + power) * am]);
         break;

        case mario_mort:
         AnimMortMario();
         break;

        case mario_gp:
         AnimMarioGrandPetit();
         break;

        case mario_pg:
         AnimMarioPetitGrand();
         break;

        case mario_fleur:
         AnimMarioFleur();
         break;
   }

   hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y); // on applique les changements au sprite de mario
}


void MortMario(u16 temp)
{
	Pause(temp);
	power = petit_mario;
	puissance = 0;
    if (vies > 0) 
	{
		vies--;
		
		Initialisation();
		CacheSprites();
		PostNiveau();
		if (num_niveau == 1) ReAfficheNiveau11();
		else if (num_niveau == 2) ReAfficheNiveau12();
		else if (num_niveau == 3) ReAfficheNiveau13();
		else if (num_niveau == 4) ReAfficheNiveau14();
		else if (num_niveau == 5) ReAfficheNiveau15();
		else if (num_niveau == 6) ReAfficheNiveau16();
		else if (num_niveau == 7) ReAfficheNiveau17();
		else if (num_niveau == 8) ReAfficheNiveau18();
		PreNiveau();
	}
	else if (!vies) GameOver();
	SuperTestEcran();
    temps = 400;
    hel_ObjSetPalette(mario.sprite,0); //on remet la bonne palette
    hel_ObjSetXY(mario.sprite,mario.pos_x,mario.pos_y); // on applique les changements de suite, histoire d'etre le + discret possible
    //hel_ObjUpdateInOAM(mario.sprite);
}
