#ifndef __MODULES_H__
#define __MODULES_H__

#include "mtypes.h"

extern const Module mod_test;
extern const Module mod_invincible;
extern const Module mod_bosshs;
extern const Module mod_boss_intro;
extern const Module mod_boss;
extern const Module mod_m_bonus;
extern const Module mod_m_fin;
extern const Module mod_gameover;
extern const Module mod_m_intro;
extern const Module mod_mainmap;
extern const Module mod_map_1;
extern const Module mod_map_2;
extern const Module mod_map_3;
extern const Module mod_map_4;
extern const Module mod_map_5;
extern const Module mod_map_6;
extern const Module mod_map_7;
extern const Module mod_map_8;

#endif
