#include "gfx/maps/lq/title.til.c"
#include "gfx/maps/lq/title.pal.c"
#include "gfx/maps/lq/title.map.c"

#include "gfx/maps/lq/gameover1.til.c"
#include "gfx/maps/lq/gameover1.pal.c"
#include "gfx/maps/lq/gameover1.map.c"
#include "gfx/maps/lq/gameover2.til.c"
#include "gfx/maps/lq/gameover2.map.c"

#include "gfx/maps/lq/splash.til.c"
#include "gfx/maps/lq/splash.pal.c"
#include "gfx/maps/lq/splash.map.c"







