//map_5bg.png
//Converti avec GBA Graphics par Br�nni
//Palette
//Taille: 12
//M�moire: 24 octets

const unsigned short map_5bg_palette[12]=	{
0x8000, 0x7393, 0x7f95, 0x7ff8, 0x7fdd, 0x0000, 0x77ff, 0x6fde,
0x679c, 0x5f5a, 0x5718, 0x4ed6};
