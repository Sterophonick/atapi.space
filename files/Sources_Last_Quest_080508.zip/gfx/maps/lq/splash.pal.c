//splash.png
//Converti avec GBA Graphics par Br�nni
//Palette
//Taille: 5
//M�moire: 10 octets

const unsigned short __attribute__((aligned(4))) splash_palette[5]=	{
0x8000, 0x7fff, 0x0000, 0x035f, 0x71cb};
