#include "gfx/maps/lq/map_7.til.c"
#include "gfx/maps/lq/map_7.map.c"
#include "gfx/maps/lq/map_7.pal.c"
#include "gfx/maps/lq/map_7bg.map.c"
