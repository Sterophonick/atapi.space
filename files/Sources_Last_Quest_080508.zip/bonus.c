#include <mygba.h>
#include "header.h"


// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void GestionBonus()
{
	if (bonus.etat == sprite_vivant)
	{
		if (bonus.limite == champignon)
		{
			if (sortie_champignon) SortieChampignon(); //sa sortie du bloc
			else AnimeVieChampignon();
			if (CollisionSprite(mario,bonus) && bonus.delta_course > 10) //si mario chope le champignon
			{
				score += 1000;

				mario.etat = mario_pg; //je fais grandir mario
				mario.temp_mort = 0;
				mario.anim_mort = 22;

				bonus.dep_x = 0; //et je cache le champignon
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				bonus.etat = sprite_inactif;
				cache.etat = sprite_inactif;
				//if (hel_ObjExists(cache.sprite)) hel_ObjDelete(cache.sprite);
				//if (hel_ObjExists(bonus.sprite)) hel_ObjDelete(bonus.sprite);
				hel_ObjSetVisible(cache.sprite,0);
				hel_ObjSetVisible(bonus.sprite,0);
				sortie_champignon = 0;
			}
		}

		if (bonus.limite == fleur)
		{
			//if (hel_ObjExists(bonus.sprite)) 
			AnimFleur();
			if (sortie_fleur) SortieFleur(); //sa sortie du bloc
			else AnimeFleur();
			if (CollisionSprite(mario,bonus) && bonus.delta_course > 10) //si mario chope la fleur (pas difficile, elle ne bouge pas... la honte si il n'y arrive pas !)
			{
				if (puissance == 0) //si ce con de mario s'est fait toucher entre temps et est redevenu petit,
				{
					mario.etat = mario_pg; //tant pis pour lui, il ne fera que grandir
					mario.temp_mort = 0;
					mario.anim_mort = 22;
				}
				if (puissance == 1) //si il est en super mario
				{
					mario.etat = mario_fleur; //hop, en mario fleur et plus vite que ca
					mario.temp_mort = 0;
					mario.anim_mort = 0;
				}

				score = score + 1000;

				bonus.dep_x = 0; //et je cache la fleur
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				bonus.etat = sprite_inactif;
				cache.etat = sprite_inactif;
				hel_ObjSetVisible(bonus.sprite,0);
				hel_ObjSetVisible(cache.sprite,0);
				sortie_fleur = 0;
			}
		}

		if (bonus.limite == vie)
		{
			if (sortie_vie) SortieVie(); //sa sortie du bloc
			else AnimeVieChampignon();
			if (CollisionSprite(mario,bonus) && bonus.delta_course > 10) //si mario chope le champignon
			{
				AdpcmStart(&ADPCM_vie,1,1); //son de la vie
				vies++;
				bonus.dep_x = 0; //et je cache la vie
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				bonus.etat = sprite_inactif;
				cache.etat = sprite_inactif;
				hel_ObjSetVisible(cache.sprite,0);
				hel_ObjSetVisible(bonus.sprite,0);
				sortie_vie = 0;
				hel_ObjSetVisible(unevie.sprite,1);
				unevie.pos_x = mario.pos_x + 5 + Ptx; //l'anim du 1up
				unevie.pos_y = mario.pos_y + mario.dec_haut_y - 10 + Pty;
				unevie.etat = sprite_vivant;
			}
		}

		if (bonus.limite == etoile)
		{
			AnimEtoile();
			if (sortie_etoile) SortieEtoile(); //sa sortie du bloc
			if (CollisionSprite(mario,bonus) && bonus.delta_course > 10) //si mario chope l'�toile
			{
				score = score + 1000;

				AdpcmStart(&ADPCM_invincible,1,0); //c'est parti pour un ptit coup d'invincibilit� (je balance ici la musique d'invincibilit�, ce qui coupe automatiquement celle en cours, faut pas que j'oublie de la relancer)
				mario_invincible = 1;
				mario_temp_clignote = 0;
				mario_anim_clignote = 0;

				bonus.dep_x = 0; //et je cache l'�toile
				bonus.pos_x = 240;
				bonus.pos_y = 160;
				bonus.etat = sprite_inactif;
				cache.etat = sprite_inactif;
				hel_ObjSetVisible(cache.sprite,0);
				hel_ObjSetVisible(bonus.sprite,0);
				sortie_etoile = 0;
			}
		}
	}

	if (bloc_piece_plus[0].temp > 0 && bloc_piece_plus[0].temp < 250) bloc_piece_plus[0].temp++; //la tempo des blocs piece plus (fin � 250 = 5secondes)
}


void AnimeVieChampignon()
{
	bonus.pos_x -= Ptx;
	bonus.pos_y -= Pty;

    ExtractionFoes(bonusn);

    for (g = 0; g < 3; g++) if (!BlocPresentBas(bonus)) bonus.pos_y++; //gravit�

    bonus.vitesse++;
    if (bonus.vitesse == 2) //je d�place mon champignon
    {
		if (BlocPresentDroite(bonus)) bonus.dep_x = -1;
		if (BlocPresentGauche(bonus)) bonus.dep_x = 1;
		if (BlocPresentBas(bonus)) bonus.pos_x += bonus.dep_x;
		bonus.vitesse = 0;
    }

    if (bonus.pos_x > 248 || bonus.pos_x < -24 || (Pt.Y == 20 && bonus.pos_y > 168)) //quand le champignon sort de l'�cran
    {
		bonus.dep_x = 0;
		bonus.pos_x = 240;
		bonus.pos_y = 160;
		bonus.etat = sprite_inactif;
		//if (hel_ObjExists(bonus.sprite)) hel_ObjDelete(bonus.sprite);
		hel_ObjSetVisible(bonus.sprite,0);
    }

    //if (hel_ObjExists(bonus.sprite))
	{
		hel_ObjSetXY(bonus.sprite,bonus.pos_x,bonus.pos_y);
		if (bonus.pos_x < -54 || bonus.pos_x > 240 || bonus.pos_y < -54 || bonus.pos_y > 160) hel_ObjSetXY(bonus.sprite,240,160);
	}

    bonus.pos_x += Ptx;
	bonus.pos_y += Pty;
}

void AnimeFleur()
{
	bonus.pos_x -= Ptx;
	bonus.pos_y -= Pty;

	ExtractionFoes(bonusn);

    if (bonus.pos_x > 248 || bonus.pos_x < -24 || (Pt.Y == 20 && bonus.pos_y > 168)) //si la fleur sort de l'�cran
    {
		bonus.etat = sprite_inactif;
		bonus.pos_x = 240;
		bonus.pos_y = 160;
		//if (hel_ObjExists(bonus.sprite)) hel_ObjDelete(bonus.sprite);
		hel_ObjSetVisible(bonus.sprite,0);
    }

    //if (hel_ObjExists(bonus.sprite))
	{
		hel_ObjSetXY(bonus.sprite,bonus.pos_x,bonus.pos_y);
		if (bonus.pos_x < -54 || bonus.pos_x > 240 || bonus.pos_y < -54 || bonus.pos_y > 160) hel_ObjSetXY(bonus.sprite,240,160);
	}

	bonus.pos_x += Ptx;
	bonus.pos_y += Pty;
}


void TirBalle()
{
	balle.pos_x -= Ptx;
	balle.pos_y -= Pty;

	for (b = 0; b < 3; b++)
	{
		if (!BlocPresentBas(balle) && !BlocPresentHaut(balle)) balle.pos_y += balle.dep_y;
		else
		{
			if (BlocPresentBas(balle)) {balle.dep_y = -1; balle.pos_y--;}
			else if (BlocPresentHaut(balle)) {balle.dep_y = 1; balle.pos_y++;}
		}

		if (!BlocPresentGauche(balle) && !BlocPresentDroite(balle)) balle.pos_x += balle.dep_x;
		else
		{
			if (BlocPresentDroite(balle)) {balle.dep_x = -1; balle.pos_x--;}
			else if (BlocPresentGauche(balle)) {balle.dep_x = 1; balle.pos_x++;}
		}
	}

	if (Ptx < 7896) CollisionPiece(balle); //je collisionne la balle avec les pieces que hors de la zone bonus

	//if (hel_ObjExists(balle.sprite)) 
	hel_ObjSetXY(balle.sprite,balle.pos_x,balle.pos_y);
	
	if (balle.pos_x > 245 || balle.pos_x < -13 || balle.pos_y > 165 || balle.pos_y < -13) //quand la balle sort de l'�cran
	{
		balle.dep_x = 0;
		balle.dep_y = 0;
		balle.pos_x = 240;
		balle.pos_y = 160;
		//if (hel_ObjExists(balle.sprite)) hel_ObjDelete(balle.sprite);
		hel_ObjSetVisible(balle.sprite,0);
		balle.etat = sprite_inactif; //balle n'est pas un ennemi, mais bon... �conomie de define lol
	}

	balle.pos_x += Ptx;
	balle.pos_y += Pty;
}
