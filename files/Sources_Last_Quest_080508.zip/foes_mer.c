#include <mygba.h>
#include "header.h"



// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

void AfficheHippocampe(u32 tabrx, u32 tabry) 
{
	if (num_niveau == 6) {
	hippocampe.pos_x = (tabrx << 3); //je converti en pixels
	hippocampe.tile_origine_y = (tabry << 3);
	hippocampe.pos_y = 320;
	hel_ObjSetXY(hippocampe.sprite,(hippocampe.pos_x-Ptx),(hippocampe.pos_y-Pty));
	if ((hippocampe.pos_x-Ptx) < -54 || (hippocampe.pos_x-Ptx) > 240 || (hippocampe.pos_y-Pty) < -54 || (hippocampe.pos_y-Pty) > 160) hel_ObjSetXY(hippocampe.sprite,240,160);
	hel_ObjSetVisible(hippocampe.sprite,1);
	hel_ObjSetVFlip(hippocampe.sprite,0);
	hel_ObjUpdateGfx(hippocampe.sprite,(void*)&hippocampe_Bitmap[0]);
	carte_map[tabry][tabrx] = 0; //et j'efface les tiles
	hel_MapRedraw(2); //on redessine le niveau
	hippocampe.limite = 2;
	hippocampe.dep_y = -3;
	hippocampe.etat = sprite_vivant;
	hippocampe.temp_mort = 0;
	hippocampe.anim_mort = 0;
	if (mario.pos_x <= hippocampe.pos_x - Ptx) 
	{
		hel_ObjSetHFlip(hippocampe.sprite,0);
		bulle.pos_x = hippocampe.pos_x - 7;
		bulle.dep_x = -3;
	}
	else 
	{
		hel_ObjSetHFlip(hippocampe.sprite,1);
		bulle.pos_x = hippocampe.pos_x + 15;
		bulle.dep_x = 3;
	}}
}

void GestionHippocampe()
{
	if (hippocampe.etat == sprite_vivant)
	{
		AnimeHippocampe();
		if (!mario_clignote && mario.etat != mario_gp)
		{
			//hippocampe.pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
			//hippocampe.pos_y += Pty;
			if (CollisionSprite(balle,hippocampe)) CollisionFoesBalle(hippocampen);
			//hippocampe.pos_x -= Ptx;
			//hippocampe.pos_y -= Pty;
			if (CollisionSprite(mario,hippocampe)) CollisionFoesMario(hippocampen);
		}
	}
	else if (hippocampe.etat == sprite_mort) 
	{
		EcraseHippocampe();
		hippocampe.pos_x -= Ptx;
		hippocampe.pos_y -= Pty;
		hippocampe.pos_y += 2;  //petite gravit� uniquement lors de la mort
		hel_ObjSetY(hippocampe.sprite,hippocampe.pos_y);
		hippocampe.pos_x += Ptx;
		hippocampe.pos_y += Pty;
	}
	else if (hippocampe.etat == sprite_mort2) AnimMortFoes2(hippocampen);
	if (bulle.etat == sprite_vivant && !mario_invincible && CollisionSprite(mario,bulle)) CollisionFoesMario(bullen);
}

void AnimeHippocampe()
{
	hippocampe.pos_x -= Ptx;
	hippocampe.pos_y -= Pty;
   
	hippocampe.pos_y += hippocampe.dep_y;

	if (hippocampe.pos_y < hippocampe.tile_origine_y-Pty && hippocampe.dep_y == -3) hippocampe.dep_y = 0;
	
	if (!hippocampe.dep_y) hippocampe.temp_mort++;
	if (!hippocampe.dep_y && hippocampe.temp_mort >= 10)
	{
		hippocampe.temp_mort = 0;
		if (hippocampe.anim_mort == 0) hel_ObjUpdateGfx(hippocampe.sprite,(void*)&hippocampe_Bitmap[512]);
		if (hippocampe.anim_mort == 1)
		{
			AdpcmStart(&ADPCM_hippo,1,1);
			bulle.etat = sprite_vivant;
			hel_ObjSetVisible(bulle.sprite,1);		
			bulle.pos_y = hippocampe.pos_y + 10 + Pty;
			if (mario.pos_y <= hippocampe.pos_y) bulle.dep_y = -2;
			else bulle.dep_y = 2;
			hel_ObjSetXY(bulle.sprite,(bulle.pos_x-Ptx),(bulle.pos_y-Pty));
		}
		if (hippocampe.anim_mort == 2) {hel_ObjUpdateGfx(hippocampe.sprite,(void*)&hippocampe_Bitmap[256]); hippocampe.dep_y = 3;}
		hippocampe.anim_mort++;
	}
	if (hippocampe.dep_y == 3)
	{
		if (hippocampe.pos_y > 320-Pty && !bulle.dep_x) hippocampe.temp_mort++;
		if (hippocampe.temp_mort >= 20) 
		{
			hippocampe.dep_y = -3; 
			hippocampe.temp_mort = 0;
			hippocampe.anim_mort = 0;
			if (mario.pos_x - 20 <= hippocampe.pos_x) 
			{
				hel_ObjSetHFlip(hippocampe.sprite,0);
				bulle.pos_x = hippocampe.pos_x + Ptx - 7;
				bulle.dep_x = -3;
			}
			else 
			{
				hel_ObjSetHFlip(hippocampe.sprite,1);
				bulle.pos_x = hippocampe.pos_x + Ptx + 15;
				bulle.dep_x = 3;
			}
		}
	}

	if (bulle.etat == sprite_vivant) 
	{
		AnimBulle();
		bulle.pos_x += bulle.dep_x;
		bulle.pos_y += bulle.dep_y;
		if (bulle.pos_x-Ptx >= hippocampe.pos_x + 300 || bulle.pos_x-Ptx <= hippocampe.pos_x - 300)
		{
			bulle.dep_x = 0;
			bulle.dep_y = 0;
			bulle.etat = sprite_inactif;
			bulle.pos_x = 0;
			bulle.pos_y = 320;
			hel_ObjSetVisible(bulle.sprite,0);			
		}
	}

	//�loignement
	if (Pt.X != 0 && !hippocampe.dep_x && ((hippocampe.pos_x <= (mario.pos_x - 400)) || (hippocampe.pos_x >= (mario.pos_x + 300)))) //si le boulet est trop loin de mario
	{
		FixeHippocampe();
	}

	hippocampe.pos_x += Ptx;
	hippocampe.pos_y += Pty;

	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjSetXY(hippocampe.sprite,(hippocampe.pos_x-Ptx),(hippocampe.pos_y-Pty));
		if ((hippocampe.pos_x-Ptx) < -54 || (hippocampe.pos_x-Ptx) > 240 || (hippocampe.pos_y-Pty) < -54 || (hippocampe.pos_y-Pty) > 160) hel_ObjSetXY(hippocampe.sprite,240,160);		
	
		hel_ObjSetXY(bulle.sprite,(bulle.pos_x-Ptx),(bulle.pos_y-Pty));
		if ((bulle.pos_x-Ptx) < -54 || (bulle.pos_x-Ptx) > 240 || (bulle.pos_y-Pty) < -54 || (bulle.pos_y-Pty) > 160) hel_ObjSetXY(bulle.sprite,240,160);		
	}

}

void FixeHippocampe()
{
	hippocampe.dep_x = 0;
	hippocampe.etat = sprite_inactif;
	hippocampe.pos_x = 0;
	hippocampe.pos_y = 320;
	hel_ObjSetVisible(hippocampe.sprite,0);
	bulle.dep_x = 0;
	bulle.dep_y = 0;
	hel_ObjSetVisible(bulle.sprite,0);
	bulle.pos_x = 0;
	bulle.pos_y = 320;
	bulle.etat = sprite_inactif;
}
      
void EcraseHippocampe()
{
	hippocampe.temp_mort++;
	if (hippocampe.temp_mort == 1)
	{
		score += hippocampe.score * multiple_score;
		AffichePoints((hippocampe.pos_x-Ptx),(hippocampe.pos_y-Pty),(hippocampe.score * multiple_score));
		multiple_score *= 2;
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�

		if (bulle.etat == sprite_vivant)
		{
			bulle.dep_x = 0;
			bulle.dep_y = 0;
			hel_ObjSetVisible(bulle.sprite,0);
			bulle.pos_x = 0;
			bulle.pos_y = 320;
			bulle.etat = sprite_inactif;
		}
	}
	if (hippocampe.pos_y >= 320)
	{
		hippocampe.etat = sprite_inactif;
		hippocampe.temp_mort = 0;
		hippocampe.dep_y = 0;
		hippocampe.pos_x = 0;
		hippocampe.pos_y = 320;
		hel_ObjSetVisible(hippocampe.sprite,0);
	}
	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjSetVFlip(hippocampe.sprite,1);
		hel_ObjSetXY(hippocampe.sprite,(hippocampe.pos_x-Ptx),(hippocampe.pos_y-Pty));
		if ((hippocampe.pos_x-Ptx) < -54 || (hippocampe.pos_x-Ptx) > 240 || (hippocampe.pos_y-Pty) < -54 || (hippocampe.pos_y-Pty) > 160) hel_ObjSetXY(hippocampe.sprite,240,160);		
	}
}

void AffichePoissonV(u32 tabrx, u32 tabry) 
{
	for (b = poisson_osd; b <= poisson_osf; b++)
	{
		if (sprite[b].etat == sprite_inactif)
		{
			sprite[b].pos_x = (tabrx << 3); //je converti en pixels
			sprite[b].tile_origine_y = (tabry << 3);
			sprite[b].pos_y = 320;
			hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));
			if ((sprite[b].pos_x-Ptx) < -54 || (sprite[b].pos_x-Ptx) > 240 || (sprite[b].pos_y-Pty) < -54 || (sprite[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[b].sprite,240,160);
			hel_ObjSetVisible(sprite[b].sprite,1);
			hel_ObjSetVFlip(sprite[b].sprite,0);
			hel_ObjSetHFlip(sprite[b].sprite,0);
			carte_map[tabry][tabrx] = 0;
			hel_MapRedraw(2); //on redessine le niveau
			sprite[b].temp_mort = 0;
			sprite[b].dep_y = -3;
			sprite[b].limite = 2;
			sprite[b].etat = sprite_vivant;
			b = poisson_osf + 1;
		}
	}
}

void GestionPoissonV()
{
	for (b = poisson_osd; b <= poisson_osf; b++)
	{
		if (sprite[b].etat == sprite_vivant)
		{
			AnimePoissonV();
			if (!mario_clignote && mario.etat != mario_gp)
			{
				//sprite[b].pos_x += Ptx; //j'additionne ici car dans collisionfoesballe je soustrait les Pt au sprite 2
				//sprite[b].pos_y += Pty;
				if (CollisionSprite(balle,sprite[b])) CollisionFoesBalle(b);
				//sprite[b].pos_x -= Ptx;
				//sprite[b].pos_y -= Pty;
				if (CollisionSprite(mario,sprite[b])) CollisionFoesMario(b);
			}
		}
		else if (sprite[b].etat == sprite_mort) 
		{
			EcrasePoissonV();
			sprite[b].pos_x -= Ptx;
			sprite[b].pos_y -= Pty;
			sprite[b].pos_y += 2;  //petite gravit� uniquement lors de la mort
			hel_ObjSetY(sprite[b].sprite,sprite[b].pos_y);
			sprite[b].pos_x += Ptx;
			sprite[b].pos_y += Pty;
		}
		else if (sprite[b].etat == sprite_mort2) AnimMortFoes2(b);
	}
}

void AnimePoissonV()
{
	sprite[b].pos_x -= Ptx;
	sprite[b].pos_y -= Pty;
   
	sprite[b].pos_y += sprite[b].dep_y;

	if (sprite[b].pos_y < sprite[b].tile_origine_y+20-Pty && sprite[b].dep_y == -3) sprite[b].dep_y = -2;
	if (sprite[b].pos_y < sprite[b].tile_origine_y+10-Pty && sprite[b].dep_y == -2) sprite[b].dep_y = -1;
	if (sprite[b].pos_y < sprite[b].tile_origine_y-Pty && sprite[b].dep_y == -1) sprite[b].dep_y = 0;
	if (!sprite[b].dep_y) 
	{
		sprite[b].temp_mort++;
		if (sprite[b].temp_mort >= 10) {sprite[b].dep_y = 1; sprite[b].temp_mort = 0;}
	}
	if (sprite[b].pos_y > sprite[b].tile_origine_y+10-Pty && sprite[b].dep_y == 1) sprite[b].dep_y = 2;
	if (sprite[b].pos_y > sprite[b].tile_origine_y+20-Pty && sprite[b].dep_y == 2) sprite[b].dep_y = 3;
	if (sprite[b].dep_y == 3)
	{
		if (sprite[b].pos_y > 320-Pty) sprite[b].temp_mort++;
		if (sprite[b].temp_mort >= 20) {sprite[b].dep_y = -3; sprite[b].temp_mort = 0;}
	}

	AnimPoissonV();

	//�loignement
	if (Pt.X != 0 && !sprite[b].dep_x && ((sprite[b].pos_x <= (mario.pos_x - 400)) || (sprite[b].pos_x >= (mario.pos_x + 300)))) //si le poisson_os est trop loin de mario
	{
		FixePoissonV();
	}

	sprite[b].pos_x += Ptx;
	sprite[b].pos_y += Pty;

	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));
		if ((sprite[b].pos_x-Ptx) < -54 || (sprite[b].pos_x-Ptx) > 240 || (sprite[b].pos_y-Pty) < -54 || (sprite[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[b].sprite,240,160);		
	
	}

}

void FixePoissonV()
{
	sprite[b].etat = sprite_inactif;
	sprite[b].pos_x = 0;
	sprite[b].pos_y = 320;
	hel_ObjSetVisible(sprite[b].sprite,0);
}
      
void EcrasePoissonV()
{
	sprite[b].temp_mort++;
	if (sprite[b].temp_mort == 1)
	{
		score += sprite[b].score * multiple_score;
		AffichePoints((sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty),(sprite[b].score * multiple_score));
		multiple_score *= 2;
		mario.saut = 1; //je fais rebondir mario
		mario.pos_tab_saut = 6;
		AdpcmStart(&ADPCM_ennemi,1,1); //je fais le bruit de la mort de l'ennemi �cras�
	}
	if (sprite[b].pos_y >= 320)
	{
		sprite[b].etat = sprite_inactif;
		sprite[b].temp_mort = 0;
		sprite[b].dep_y = 0;
		sprite[b].pos_x = 0;
		sprite[b].pos_y = 320;
		hel_ObjSetVisible(sprite[b].sprite,0);
	}
	//if (hel_ObjExists(fly.sprite))
	{
		hel_ObjUpdateGfx(sprite[b].sprite,(void*)&poisson_os_Bitmap[512]);
		hel_ObjSetXY(sprite[b].sprite,(sprite[b].pos_x-Ptx),(sprite[b].pos_y-Pty));
		if ((sprite[b].pos_x-Ptx) < -54 || (sprite[b].pos_x-Ptx) > 240 || (sprite[b].pos_y-Pty) < -54 || (sprite[b].pos_y-Pty) > 160) hel_ObjSetXY(sprite[b].sprite,240,160);		
	}
}

