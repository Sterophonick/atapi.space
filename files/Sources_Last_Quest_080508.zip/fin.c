#include <mygba.h>
#include "header.h"
#include "fin.h"


unsigned short EN_EWRAM end_map[20][30];

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


void AfficheFin()
{
	hel_PalBgLoad256((void*)end_01_palette); //chargement de la palette des bg	
	ham_bg[0].ti = ham_InitTileSet((void*)&end_01_tiles,SIZEOF_16BIT(end_01_tiles),1,1);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_01_map[taby][tabx];}}

	hel_MapCreate(0, 30, 20, (void*)end_map, sizeof(u16), MAP_FLAGS_DEFAULT);
	ham_InitBg(0,1,1,0);

	Pause(1100);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_02_map[taby][tabx];}}
	hel_MapRedraw(0);
	
	Pause(400);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_03_map[taby][tabx];}}
	hel_MapRedraw(0);
	
	Pause(400);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_04_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(400);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_05_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(1100);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_06_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(350);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_07_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(350);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_08_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(400);
	
	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_09_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(400);

	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_10_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(400);

	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_11_map[taby][tabx];}}
	hel_MapRedraw(0);

	Pause(1600);

	for (taby = 0; taby < 20; taby++) {for (tabx = 0; tabx < 30; tabx++) {end_map[taby][tabx] = end_12_map[taby][tabx];}}
	hel_MapRedraw(0);

	while(1);
}


