#include <agb_lib.h>
#include "data.h"
#define us (void*)
#define vsync WaitForVblank();

int main()
{
	Initialize();
	setbg2(us TitleBitmap, us TitlePalette);
	FadeIn(2);
	while(!(keyDown(KEY_START)));
	FadeOut(2);
	while(1)
	{
		vsync
		setbg2(us s1Bitmap, us s1Palette);
		FadeIn(2);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		setbg2(us s2Bitmap, us s2Palette);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		FadeOut(2);
		vsync
		setbg2(us s3Bitmap, us s3Palette);
		FadeIn(2);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		FadeOut(2);
		vsync
		setbg2(us s4Bitmap, us s4Palette);
		FadeIn(2);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		MosaicOut(2);
		vsync
		setbg2(us s5Bitmap, us s5Palette);
		MosaicIn(2);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		FadeOut(2);
		vsync
		setbg2(us s6Bitmap, us s6Palette);
		FadeIn(2);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		FadeOut(2);
		vsync
		setbg2(us s7Bitmap, us s7Palette);
		FadeIn(2);
		while(!(keyDown(KEY_A)));
		while(keyDown(KEY_A));
		REG_DM3SAD = (unsigned long)endBitmap;
		REG_DM3DAD = (unsigned long)VideoBuffer;
		REG_DM3CNT = 0x80000000 | 120*160;
		SetPalette((void*)endPalette);
		while(1);
	}
	return 0;
}