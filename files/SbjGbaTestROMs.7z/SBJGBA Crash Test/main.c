#include <agb_lib.h>
#include "allobjs.h"
#include "l105.c"
#include "backgrounds.h"
int bx,by,fx,fy,fb,g,i,i2;
double x,y;
int boiy,boix;
int i;
int crsh, sram,time,wait,alock,block,dir;
u16 offset=0;



void bottomcol()
{
	if((GetPixel3(bx+1, by+24+y)==0x64c0)OR(GetPixel3(bx+1, by+22+y)==0x64c0)OR(GetPixel3(bx+2, by+24+y)==0x64c0)OR(GetPixel3(bx+2, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+24+y)==0x64c0)OR(GetPixel3(bx+3, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+22+y)==0x64c0)OR(GetPixel3(bx+4, by+24+y)==0x64c0)OR(GetPixel3(bx+4, by+23+y)==0x64c0)OR(GetPixel3(bx+4, by+22+y)==0x64c0)OR(GetPixel3(bx+5, by+24+y)==0x64c0)OR(GetPixel3(bx+5, by+23+y)==0x64c0)OR(GetPixel3(bx+5, by+22+y)==0x64c0)OR(GetPixel3(bx+6, by+24+y)==0x64c0)OR(GetPixel3(bx+6, by+23+y)==0x64c0)OR(GetPixel3(bx+6, by+22+y)==0x64c0)OR(GetPixel3(bx+7, by+24+y)==0x64c0)OR(GetPixel3(bx+7, by+23+y)==0x64c0)OR(GetPixel3(bx+7, by+22+y)==0x64c0)OR(GetPixel3(bx+8, by+24+y)==0x64c0)OR(GetPixel3(bx+8, by+23+y)==0x64c0)OR(GetPixel3(bx+8, by+22+y)==0x64c0)OR(GetPixel3(bx+9, by+24+y)==0x64c0)OR(GetPixel3(bx+9, by+23+y)==0x64c0)OR(GetPixel3(bx+9, by+22+y)==0x64c0)OR(GetPixel3(bx+10, by+24+y)==0x64c0)OR(GetPixel3(bx+10, by+23+y)==0x64c0)OR(GetPixel3(bx+10, by+22+y)==0x64c0)OR(GetPixel3(bx+11, by+24+y)==0x64c0)OR(GetPixel3(bx+12, by+23+y)==0x64c0)OR(GetPixel3(bx+12, by+22+y)==0x64c0)OR(GetPixel3(bx+13, by+24+y)==0x64c0)OR(GetPixel3(bx+13, by+23+y)==0x64c0)OR(GetPixel3(bx+13, by+22+y)==0x64c0)OR(GetPixel3(bx+14, by+24+y)==0x64c0)OR(GetPixel3(bx+14, by+23+y)==0x64c0)OR(GetPixel3(bx+14, by+22+y)==0x64c0)OR(GetPixel3(bx+15, by+24+y)==0x64c0)OR(GetPixel3(bx+16, by+23+y)==0x64c0)OR(GetPixel3(bx+17, by+22+y)==0x64c0)OR(GetPixel3(bx+18, by+24+y)==0x64c0)OR(GetPixel3(bx+19, by+23+y)==0x64c0)OR(GetPixel3(bx+20, by+22+y)==0x64c0)) 
	{
		by-=1;
		y=0;
	}
	if(GetPixel3(bx+21, by+23+y)==0x64c0)
	{
		by-=1;
		y=0;
	}
	if(GetPixel3(bx+22, by+24+y)==0x64c0)
	{
		by-=1;
		y=0;
	}
	if(GetPixel3(bx+24, by+24)==0x64c0)
	{
		bx-=1;
		by-=1;
		y=0;
	}
	if(GetPixel3(bx, by+24)==0x64c0)
	{
		bx+=1;
		by-=1;
		y=0;
	}
}

void rightcol()
{
	if((GetPixel3(bx+24+x, by+22)==0x64c0)OR(GetPixel3(bx+24+x, by+21)==0x64c0)OR(GetPixel3(bx+24+x, by+20)==0x64c0)OR(GetPixel3(bx+24+x, by+19)==0x64c0)OR(GetPixel3(bx+24+x, by+18)==0x64c0)OR(GetPixel3(bx+24+x, by+17)==0x64c0)OR(GetPixel3(bx+24+x, by+16)==0x64c0)OR(GetPixel3(bx+24+x, by+15)==0x64c0)OR(GetPixel3(bx+24+x, by+14)==0x64c0)OR(GetPixel3(bx+24+x, by+13)==0x64c0)OR(GetPixel3(bx+24+x, by+12)==0x64c0)OR(GetPixel3(bx+24+x, by+11)==0x64c0)OR(GetPixel3(bx+24+x, by+10)==0x64c0)OR(GetPixel3(bx+24+x, by+9)==0x64c0)OR(GetPixel3(bx+24+x, by+8)==0x64c0)OR(GetPixel3(bx+24+x, by+7)==0x64c0)OR(GetPixel3(bx+24+x, by+6)==0x64c0)OR(GetPixel3(bx+24+x, by+5)==0x64c0)OR(GetPixel3(bx+24+x, by+4)==0x64c0)OR(GetPixel3(bx+24+x, by+3)==0x64c0)OR(GetPixel3(bx+24+x, by+2)==0x64c0)OR(GetPixel3(bx+24+x, by+1)==0x64c0)OR(GetPixel3(bx+23+x, by+22)==0x64c0)OR(GetPixel3(bx+23+x, by+21)==0x64c0)OR(GetPixel3(bx+23+x, by+20)==0x64c0)OR(GetPixel3(bx+23+x, by+19)==0x64c0)OR(GetPixel3(bx+23+x, by+18)==0x64c0)OR(GetPixel3(bx+23+x, by+17)==0x64c0)OR(GetPixel3(bx+23+x, by+16)==0x64c0)OR(GetPixel3(bx+23+x, by+15)==0x64c0)OR(GetPixel3(bx+23+x, by+14)==0x64c0)OR(GetPixel3(bx+23+x, by+13)==0x64c0)OR(GetPixel3(bx+23+x, by+12)==0x64c0)OR(GetPixel3(bx+23+x, by+11)==0x64c0)OR(GetPixel3(bx+23+x, by+10)==0x64c0)OR(GetPixel3(bx+23+x, by+9)==0x64c0)OR(GetPixel3(bx+23+x, by+8)==0x64c0)OR(GetPixel3(bx+23+x, by+7)==0x64c0)OR(GetPixel3(bx+23+x, by+6)==0x64c0)OR(GetPixel3(bx+23+x, by+5)==0x64c0)OR(GetPixel3(bx+23+x, by+4)==0x64c0)OR(GetPixel3(bx+23+x, by+3)==0x64c0)OR(GetPixel3(bx+23+x, by+2)==0x64c0)OR(GetPixel3(bx+23+x, by+1)==0x64c0))
	{
			x=0;
			if((keyDown(KEY_A))AND(alock==0))	
			{
				y=-3.85;
				x=-5;
				alock=1;
			}else{
				x=0;
			}
			bx-=1;
	}
}

void leftcol()
{
	if((GetPixel3(bx+x, by+22)==0x64c0)OR(GetPixel3(bx+x, by+21)==0x64c0)OR(GetPixel3(bx+x, by+20)==0x64c0)OR(GetPixel3(bx+x, by+19)==0x64c0)OR(GetPixel3(bx+x, by+18)==0x64c0)OR(GetPixel3(bx+x, by+17)==0x64c0)OR(GetPixel3(bx+x, by+16)==0x64c0)OR(GetPixel3(bx+x, by+15)==0x64c0)OR(GetPixel3(bx+x, by+14)==0x64c0)OR(GetPixel3(bx+x, by+13)==0x64c0)OR(GetPixel3(bx+x, by+12)==0x64c0)OR(GetPixel3(bx+x, by+11)==0x64c0)OR(GetPixel3(bx+x, by+10)==0x64c0)OR(GetPixel3(bx+x, by+9)==0x64c0)OR(GetPixel3(bx+x, by+8)==0x64c0)OR(GetPixel3(bx+x, by+7)==0x64c0)OR(GetPixel3(bx+x, by+6)==0x64c0)OR(GetPixel3(bx+x, by+5)==0x64c0)OR(GetPixel3(bx+x, by+4)==0x64c0)OR(GetPixel3(bx+x, by+3)==0x64c0)OR(GetPixel3(bx+x, by+2)==0x64c0)OR(GetPixel3(bx+x, by+1)==0x64c0)OR(GetPixel3(bx+1+x, by+22)==0x64c0)OR(GetPixel3(bx+1+x, by+21)==0x64c0)OR(GetPixel3(bx+1+x, by+20)==0x64c0)OR(GetPixel3(bx+1+x, by+19)==0x64c0)OR(GetPixel3(bx+1+x, by+18)==0x64c0)OR(GetPixel3(bx+1+x, by+17)==0x64c0)OR(GetPixel3(bx+1+x, by+16)==0x64c0)OR(GetPixel3(bx+1+x, by+15)==0x64c0)OR(GetPixel3(bx+1+x, by+14)==0x64c0)OR(GetPixel3(bx+1+x, by+13)==0x64c0)OR(GetPixel3(bx+1+x, by+12)==0x64c0)OR(GetPixel3(bx+1+x, by+11)==0x64c0)OR(GetPixel3(bx+1+x, by+10)==0x64c0)OR(GetPixel3(bx+1+x, by+9)==0x64c0)OR(GetPixel3(bx+1+x, by+8)==0x64c0)OR(GetPixel3(bx+1+x, by+7)==0x64c0)OR(GetPixel3(bx+1+x, by+6)==0x64c0)OR(GetPixel3(bx+1+x, by+5)==0x64c0)OR(GetPixel3(bx+1+x, by+4)==0x64c0)OR(GetPixel3(bx+1+x, by+3)==0x64c0)OR(GetPixel3(bx+1+x, by+2)==0x64c0)OR(GetPixel3(bx+1+x, by+1)==0x64c0)OR(GetPixel3(bx+2+x, by+22)==0x64c0)OR(GetPixel3(bx+2+x, by+21)==0x64c0)OR(GetPixel3(bx+2+x, by+20)==0x64c0)OR(GetPixel3(bx+2+x, by+19)==0x64c0)OR(GetPixel3(bx+2+x, by+18)==0x64c0)OR(GetPixel3(bx+2+x, by+17)==0x64c0)OR(GetPixel3(bx+2+x, by+16)==0x64c0)OR(GetPixel3(bx+2+x, by+15)==0x64c0)OR(GetPixel3(bx+2+x, by+14)==0x64c0)OR(GetPixel3(bx+2+x, by+13)==0x64c0)OR(GetPixel3(bx+2+x, by+12)==0x64c0)OR(GetPixel3(bx+2+x, by+11)==0x64c0)OR(GetPixel3(bx+2+x, by+10)==0x64c0)OR(GetPixel3(bx+2+x, by+9)==0x64c0)OR(GetPixel3(bx+2+x, by+8)==0x64c0)OR(GetPixel3(bx+2+x, by+7)==0x64c0)OR(GetPixel3(bx+2+x, by+6)==0x64c0)OR(GetPixel3(bx+2+x, by+5)==0x64c0)OR(GetPixel3(bx+2+x, by+4)==0x64c0)OR(GetPixel3(bx+2+x, by+3)==0x64c0)OR(GetPixel3(bx+2+x, by+2)==0x64c0)OR(GetPixel3(bx+2+x, by+1)==0x64c0))
	{
			x=0;
			if((keyDown(KEY_A))AND(alock==0))	
			{
				y=-3.85;
				x=5;
				alock=1;
			}else{
				x=0;
			}
			bx+=1;
	}
}

void topcol()
{
	if((GetPixel3(bx+1, by)==0x64c0)OR(GetPixel3(bx+2, by)==0x64c0)OR(GetPixel3(bx+3, by)==0x64c0)OR(GetPixel3(bx+4, by)==0x64c0)OR(GetPixel3(bx+5, by)==0x64c0)OR(GetPixel3(bx+6, by)==0x64c0)OR(GetPixel3(bx+7, by)==0x64c0)OR(GetPixel3(bx+8, by)==0x64c0)OR(GetPixel3(bx+9, by)==0x64c0)OR(GetPixel3(bx+10, by)==0x64c0)OR(GetPixel3(bx+11, by)==0x64c0)OR(GetPixel3(bx+12, by)==0x64c0)OR(GetPixel3(bx+13, by)==0x64c0)OR(GetPixel3(bx+14, by+9)==0x64c0)OR(GetPixel3(bx+15, by+8)==0x64c0)OR(GetPixel3(bx+16, by+7)==0x64c0)OR(GetPixel3(bx+17, by+6)==0x64c0)OR(GetPixel3(bx+18, by)==0x64c0)OR(GetPixel3(bx+19, by)==0x64c0)OR(GetPixel3(bx+20, by)==0x64c0)OR(GetPixel3(bx+21, by)==0x64c0)OR(GetPixel3(bx+22, by)==0x64c0)OR(GetPixel3(bx+23, by)==0x64c0))
	{
		by+=3;
		by-=y;
		y=0;
		y+=0.24;
		MoveSprite(&sprites[1], bx, by);
	}
}

void bottomdcol()
{
	if((GetPixel3(bx+1, by+24+y)==0x001F)OR(GetPixel3(bx+1, by+22+y)==0x001F)OR(GetPixel3(bx+2, by+24+y)==0x001F)OR(GetPixel3(bx+2, by+23+y)==0x001F)OR(GetPixel3(bx+3, by+24+y)==0x001F)OR(GetPixel3(bx+3, by+23+y)==0x001F)OR(GetPixel3(bx+3, by+22+y)==0x001F)OR(GetPixel3(bx+4, by+24+y)==0x001F)OR(GetPixel3(bx+4, by+23+y)==0x001F)OR(GetPixel3(bx+4, by+22+y)==0x001F)OR(GetPixel3(bx+5, by+24+y)==0x001F)OR(GetPixel3(bx+5, by+23+y)==0x001F)OR(GetPixel3(bx+5, by+22+y)==0x001F)OR(GetPixel3(bx+6, by+24+y)==0x001F)OR(GetPixel3(bx+6, by+23+y)==0x001F)OR(GetPixel3(bx+6, by+22+y)==0x001F)OR(GetPixel3(bx+7, by+24+y)==0x001F)OR(GetPixel3(bx+7, by+23+y)==0x001F)OR(GetPixel3(bx+7, by+22+y)==0x001F)OR(GetPixel3(bx+8, by+24+y)==0x001F)OR(GetPixel3(bx+8, by+23+y)==0x001F)OR(GetPixel3(bx+8, by+22+y)==0x001F)OR(GetPixel3(bx+9, by+24+y)==0x001F)OR(GetPixel3(bx+9, by+23+y)==0x001F)OR(GetPixel3(bx+9, by+22+y)==0x001F)OR(GetPixel3(bx+10, by+24+y)==0x001F)OR(GetPixel3(bx+10, by+23+y)==0x001F)OR(GetPixel3(bx+10, by+22+y)==0x001F)OR(GetPixel3(bx+11, by+24+y)==0x001F)OR(GetPixel3(bx+12, by+23+y)==0x001F)OR(GetPixel3(bx+12, by+22+y)==0x001F)OR(GetPixel3(bx+13, by+24+y)==0x001F)OR(GetPixel3(bx+13, by+23+y)==0x001F)OR(GetPixel3(bx+13, by+22+y)==0x001F)OR(GetPixel3(bx+14, by+24+y)==0x001F)OR(GetPixel3(bx+14, by+23+y)==0x001F)OR(GetPixel3(bx+14, by+22+y)==0x001F)OR(GetPixel3(bx+15, by+24+y)==0x001F)OR(GetPixel3(bx+16, by+23+y)==0x001F)OR(GetPixel3(bx+17, by+22+y)==0x001F)OR(GetPixel3(bx+18, by+24+y)==0x001F)OR(GetPixel3(bx+19, by+23+y)==0x001F)OR(GetPixel3(bx+20, by+22+y)==0x001F)) 
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void rightdcol()
{
	if((GetPixel3(bx+24+x, by+22)==0x001F)OR(GetPixel3(bx+24+x, by+21)==0x001F)OR(GetPixel3(bx+24+x, by+20)==0x001F)OR(GetPixel3(bx+24+x, by+19)==0x001F)OR(GetPixel3(bx+24+x, by+18)==0x001F)OR(GetPixel3(bx+24+x, by+17)==0x001F)OR(GetPixel3(bx+24+x, by+16)==0x001F)OR(GetPixel3(bx+24+x, by+15)==0x001F)OR(GetPixel3(bx+24+x, by+14)==0x001F)OR(GetPixel3(bx+24+x, by+13)==0x001F)OR(GetPixel3(bx+24+x, by+12)==0x001F)OR(GetPixel3(bx+24+x, by+11)==0x001F)OR(GetPixel3(bx+24+x, by+10)==0x001F)OR(GetPixel3(bx+24+x, by+9)==0x001F)OR(GetPixel3(bx+24+x, by+8)==0x001F)OR(GetPixel3(bx+24+x, by+7)==0x001F)OR(GetPixel3(bx+24+x, by+6)==0x001F)OR(GetPixel3(bx+24+x, by+5)==0x001F)OR(GetPixel3(bx+24+x, by+4)==0x001F)OR(GetPixel3(bx+24+x, by+3)==0x001F)OR(GetPixel3(bx+24+x, by+2)==0x001F)OR(GetPixel3(bx+24+x, by+1)==0x001F)OR(GetPixel3(bx+23+x, by+22)==0x001F)OR(GetPixel3(bx+23+x, by+21)==0x001F)OR(GetPixel3(bx+23+x, by+20)==0x001F)OR(GetPixel3(bx+23+x, by+19)==0x001F)OR(GetPixel3(bx+23+x, by+18)==0x001F)OR(GetPixel3(bx+23+x, by+17)==0x001F)OR(GetPixel3(bx+23+x, by+16)==0x001F)OR(GetPixel3(bx+23+x, by+15)==0x001F)OR(GetPixel3(bx+23+x, by+14)==0x001F)OR(GetPixel3(bx+23+x, by+13)==0x001F)OR(GetPixel3(bx+23+x, by+12)==0x001F)OR(GetPixel3(bx+23+x, by+11)==0x001F)OR(GetPixel3(bx+23+x, by+10)==0x001F)OR(GetPixel3(bx+23+x, by+9)==0x001F)OR(GetPixel3(bx+23+x, by+8)==0x001F)OR(GetPixel3(bx+23+x, by+7)==0x001F)OR(GetPixel3(bx+23+x, by+6)==0x001F)OR(GetPixel3(bx+23+x, by+5)==0x001F)OR(GetPixel3(bx+23+x, by+4)==0x001F)OR(GetPixel3(bx+23+x, by+3)==0x001F)OR(GetPixel3(bx+23+x, by+2)==0x001F)OR(GetPixel3(bx+23+x, by+1)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void leftdcol()
{
	if((GetPixel3(bx+x, by+22)==0x001F)OR(GetPixel3(bx+x, by+21)==0x001F)OR(GetPixel3(bx+x, by+20)==0x001F)OR(GetPixel3(bx+x, by+19)==0x001F)OR(GetPixel3(bx+x, by+18)==0x001F)OR(GetPixel3(bx+x, by+17)==0x001F)OR(GetPixel3(bx+x, by+16)==0x001F)OR(GetPixel3(bx+x, by+15)==0x001F)OR(GetPixel3(bx+x, by+14)==0x001F)OR(GetPixel3(bx+x, by+13)==0x001F)OR(GetPixel3(bx+x, by+12)==0x001F)OR(GetPixel3(bx+x, by+11)==0x001F)OR(GetPixel3(bx+x, by+10)==0x001F)OR(GetPixel3(bx+x, by+9)==0x001F)OR(GetPixel3(bx+x, by+8)==0x001F)OR(GetPixel3(bx+x, by+7)==0x001F)OR(GetPixel3(bx+x, by+6)==0x001F)OR(GetPixel3(bx+x, by+5)==0x001F)OR(GetPixel3(bx+x, by+4)==0x001F)OR(GetPixel3(bx+x, by+3)==0x001F)OR(GetPixel3(bx+x, by+2)==0x001F)OR(GetPixel3(bx+x, by+1)==0x001F)OR(GetPixel3(bx+1+x, by+22)==0x001F)OR(GetPixel3(bx+1+x, by+21)==0x001F)OR(GetPixel3(bx+1+x, by+20)==0x001F)OR(GetPixel3(bx+1+x, by+19)==0x001F)OR(GetPixel3(bx+1+x, by+18)==0x001F)OR(GetPixel3(bx+1+x, by+17)==0x001F)OR(GetPixel3(bx+1+x, by+16)==0x001F)OR(GetPixel3(bx+1+x, by+15)==0x001F)OR(GetPixel3(bx+1+x, by+14)==0x001F)OR(GetPixel3(bx+1+x, by+13)==0x001F)OR(GetPixel3(bx+1+x, by+12)==0x001F)OR(GetPixel3(bx+1+x, by+11)==0x001F)OR(GetPixel3(bx+1+x, by+10)==0x001F)OR(GetPixel3(bx+1+x, by+9)==0x001F)OR(GetPixel3(bx+1+x, by+8)==0x001F)OR(GetPixel3(bx+1+x, by+7)==0x001F)OR(GetPixel3(bx+1+x, by+6)==0x001F)OR(GetPixel3(bx+1+x, by+5)==0x001F)OR(GetPixel3(bx+1+x, by+4)==0x001F)OR(GetPixel3(bx+1+x, by+3)==0x001F)OR(GetPixel3(bx+1+x, by+2)==0x001F)OR(GetPixel3(bx+1+x, by+1)==0x001F)OR(GetPixel3(bx+2+x, by+22)==0x001F)OR(GetPixel3(bx+2+x, by+21)==0x001F)OR(GetPixel3(bx+2+x, by+20)==0x001F)OR(GetPixel3(bx+2+x, by+19)==0x001F)OR(GetPixel3(bx+2+x, by+18)==0x001F)OR(GetPixel3(bx+2+x, by+17)==0x001F)OR(GetPixel3(bx+2+x, by+16)==0x001F)OR(GetPixel3(bx+2+x, by+15)==0x001F)OR(GetPixel3(bx+2+x, by+14)==0x001F)OR(GetPixel3(bx+2+x, by+13)==0x001F)OR(GetPixel3(bx+2+x, by+12)==0x001F)OR(GetPixel3(bx+2+x, by+11)==0x001F)OR(GetPixel3(bx+2+x, by+10)==0x001F)OR(GetPixel3(bx+2+x, by+9)==0x001F)OR(GetPixel3(bx+2+x, by+8)==0x001F)OR(GetPixel3(bx+2+x, by+7)==0x001F)OR(GetPixel3(bx+2+x, by+6)==0x001F)OR(GetPixel3(bx+2+x, by+5)==0x001F)OR(GetPixel3(bx+2+x, by+4)==0x001F)OR(GetPixel3(bx+2+x, by+3)==0x001F)OR(GetPixel3(bx+2+x, by+2)==0x001F)OR(GetPixel3(bx+2+x, by+1)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void topdcol()
{
	if((GetPixel3(bx+1, by)==0x001F)OR(GetPixel3(bx+2, by)==0x001F)OR(GetPixel3(bx+3, by)==0x001F)OR(GetPixel3(bx+4, by)==0x001F)OR(GetPixel3(bx+5, by)==0x001F)OR(GetPixel3(bx+6, by)==0x001F)OR(GetPixel3(bx+7, by)==0x001F)OR(GetPixel3(bx+8, by)==0x001F)OR(GetPixel3(bx+9, by)==0x001F)OR(GetPixel3(bx+10, by)==0x001F)OR(GetPixel3(bx+11, by)==0x001F)OR(GetPixel3(bx+12, by)==0x001F)OR(GetPixel3(bx+13, by)==0x001F)OR(GetPixel3(bx+14, by+9)==0x001F)OR(GetPixel3(bx+15, by+8)==0x001F)OR(GetPixel3(bx+16, by+7)==0x001F)OR(GetPixel3(bx+17, by+6)==0x001F)OR(GetPixel3(bx+18, by)==0x001F)OR(GetPixel3(bx+19, by)==0x001F)OR(GetPixel3(bx+20, by)==0x001F)OR(GetPixel3(bx+21, by)==0x001F)OR(GetPixel3(bx+22, by)==0x001F)OR(GetPixel3(bx+23, by)==0x001F))
	{
			bx=8;
			by=108;
			y=0;
			x=0;
	}
}

void crshcol()
{
if((GetPixel3(bx+1, by+24+y)==0x4400)OR(GetPixel3(bx+1, by+22+y)==0x4400)OR(GetPixel3(bx+2, by+24+y)==0x4400)OR(GetPixel3(bx+2, by+23+y)==0x4400)OR(GetPixel3(bx+3, by+24+y)==0x4400)OR(GetPixel3(bx+3, by+23+y)==0x4400)OR(GetPixel3(bx+3, by+22+y)==0x4400)OR(GetPixel3(bx+4, by+24+y)==0x4400)OR(GetPixel3(bx+4, by+23+y)==0x4400)OR(GetPixel3(bx+4, by+22+y)==0x4400)OR(GetPixel3(bx+5, by+24+y)==0x4400)OR(GetPixel3(bx+5, by+23+y)==0x4400)OR(GetPixel3(bx+5, by+22+y)==0x4400)OR(GetPixel3(bx+6, by+24+y)==0x4400)OR(GetPixel3(bx+6, by+23+y)==0x4400)OR(GetPixel3(bx+6, by+22+y)==0x4400)OR(GetPixel3(bx+7, by+24+y)==0x4400)OR(GetPixel3(bx+7, by+23+y)==0x4400)OR(GetPixel3(bx+7, by+22+y)==0x4400)OR(GetPixel3(bx+8, by+24+y)==0x4400)OR(GetPixel3(bx+8, by+23+y)==0x4400)OR(GetPixel3(bx+8, by+22+y)==0x4400)OR(GetPixel3(bx+9, by+24+y)==0x4400)OR(GetPixel3(bx+9, by+23+y)==0x4400)OR(GetPixel3(bx+9, by+22+y)==0x4400)OR(GetPixel3(bx+10, by+24+y)==0x4400)OR(GetPixel3(bx+10, by+23+y)==0x4400)OR(GetPixel3(bx+10, by+22+y)==0x4400)OR(GetPixel3(bx+11, by+24+y)==0x4400)OR(GetPixel3(bx+12, by+23+y)==0x4400)OR(GetPixel3(bx+12, by+22+y)==0x4400)OR(GetPixel3(bx+13, by+24+y)==0x4400)OR(GetPixel3(bx+13, by+23+y)==0x4400)OR(GetPixel3(bx+13, by+22+y)==0x4400)OR(GetPixel3(bx+14, by+24+y)==0x4400)OR(GetPixel3(bx+14, by+23+y)==0x4400)OR(GetPixel3(bx+14, by+22+y)==0x4400)OR(GetPixel3(bx+15, by+24+y)==0x4400)OR(GetPixel3(bx+16, by+23+y)==0x4400)OR(GetPixel3(bx+17, by+22+y)==0x4400)OR(GetPixel3(bx+18, by+24+y)==0x4400)OR(GetPixel3(bx+19, by+23+y)==0x4400)OR(GetPixel3(bx+20, by+22+y)==0x4400)OR(GetPixel3(bx+24+x, by+22)==0x4400)OR(GetPixel3(bx+24+x, by+21)==0x4400)OR(GetPixel3(bx+24+x, by+20)==0x4400)OR(GetPixel3(bx+24+x, by+19)==0x4400)OR(GetPixel3(bx+24+x, by+18)==0x4400)OR(GetPixel3(bx+24+x, by+17)==0x4400)OR(GetPixel3(bx+24+x, by+16)==0x4400)OR(GetPixel3(bx+24+x, by+15)==0x4400)OR(GetPixel3(bx+24+x, by+14)==0x4400)OR(GetPixel3(bx+24+x, by+13)==0x4400)OR(GetPixel3(bx+24+x, by+12)==0x4400)OR(GetPixel3(bx+24+x, by+11)==0x4400)OR(GetPixel3(bx+24+x, by+10)==0x4400)OR(GetPixel3(bx+24+x, by+9)==0x4400)OR(GetPixel3(bx+24+x, by+8)==0x4400)OR(GetPixel3(bx+24+x, by+7)==0x4400)OR(GetPixel3(bx+24+x, by+6)==0x4400)OR(GetPixel3(bx+24+x, by+5)==0x4400)OR(GetPixel3(bx+24+x, by+4)==0x4400)OR(GetPixel3(bx+24+x, by+3)==0x4400)OR(GetPixel3(bx+24+x, by+2)==0x4400)OR(GetPixel3(bx+24+x, by+1)==0x4400)OR(GetPixel3(bx+23+x, by+22)==0x4400)OR(GetPixel3(bx+23+x, by+21)==0x4400)OR(GetPixel3(bx+23+x, by+20)==0x4400)OR(GetPixel3(bx+23+x, by+19)==0x4400)OR(GetPixel3(bx+23+x, by+18)==0x4400)OR(GetPixel3(bx+23+x, by+17)==0x4400)OR(GetPixel3(bx+23+x, by+16)==0x4400)OR(GetPixel3(bx+23+x, by+15)==0x4400)OR(GetPixel3(bx+23+x, by+14)==0x4400)OR(GetPixel3(bx+23+x, by+13)==0x4400)OR(GetPixel3(bx+23+x, by+12)==0x4400)OR(GetPixel3(bx+23+x, by+11)==0x4400)OR(GetPixel3(bx+23+x, by+10)==0x4400)OR(GetPixel3(bx+23+x, by+9)==0x4400)OR(GetPixel3(bx+23+x, by+8)==0x4400)OR(GetPixel3(bx+23+x, by+7)==0x4400)OR(GetPixel3(bx+23+x, by+6)==0x4400)OR(GetPixel3(bx+23+x, by+5)==0x4400)OR(GetPixel3(bx+23+x, by+4)==0x4400)OR(GetPixel3(bx+23+x, by+3)==0x4400)OR(GetPixel3(bx+23+x, by+2)==0x4400)OR(GetPixel3(bx+23+x, by+1)==0x4400)OR(GetPixel3(bx+x, by+22)==0x4400)OR(GetPixel3(bx+x, by+21)==0x4400)OR(GetPixel3(bx+x, by+20)==0x4400)OR(GetPixel3(bx+x, by+19)==0x4400)OR(GetPixel3(bx+x, by+18)==0x4400)OR(GetPixel3(bx+x, by+17)==0x4400)OR(GetPixel3(bx+x, by+16)==0x4400)OR(GetPixel3(bx+x, by+15)==0x4400)OR(GetPixel3(bx+x, by+14)==0x4400)OR(GetPixel3(bx+x, by+13)==0x4400)OR(GetPixel3(bx+x, by+12)==0x4400)OR(GetPixel3(bx+x, by+11)==0x4400)OR(GetPixel3(bx+x, by+10)==0x4400)OR(GetPixel3(bx+x, by+9)==0x4400)OR(GetPixel3(bx+x, by+8)==0x4400)OR(GetPixel3(bx+x, by+7)==0x4400)OR(GetPixel3(bx+x, by+6)==0x4400)OR(GetPixel3(bx+x, by+5)==0x4400)OR(GetPixel3(bx+x, by+4)==0x4400)OR(GetPixel3(bx+x, by+3)==0x4400)OR(GetPixel3(bx+x, by+2)==0x4400)OR(GetPixel3(bx+x, by+1)==0x4400)OR(GetPixel3(bx+1+x, by+22)==0x4400)OR(GetPixel3(bx+1+x, by+21)==0x4400)OR(GetPixel3(bx+1+x, by+20)==0x4400)OR(GetPixel3(bx+1+x, by+19)==0x4400)OR(GetPixel3(bx+1+x, by+18)==0x4400)OR(GetPixel3(bx+1+x, by+17)==0x4400)OR(GetPixel3(bx+1+x, by+16)==0x4400)OR(GetPixel3(bx+1+x, by+15)==0x4400)OR(GetPixel3(bx+1+x, by+14)==0x4400)OR(GetPixel3(bx+1+x, by+13)==0x4400)OR(GetPixel3(bx+1+x, by+12)==0x4400)OR(GetPixel3(bx+1+x, by+11)==0x4400)OR(GetPixel3(bx+1+x, by+10)==0x4400)OR(GetPixel3(bx+1+x, by+9)==0x4400)OR(GetPixel3(bx+1+x, by+8)==0x4400)OR(GetPixel3(bx+1+x, by+7)==0x4400)OR(GetPixel3(bx+1+x, by+6)==0x4400)OR(GetPixel3(bx+1+x, by+5)==0x4400)OR(GetPixel3(bx+1+x, by+4)==0x4400)OR(GetPixel3(bx+1+x, by+3)==0x4400)OR(GetPixel3(bx+1+x, by+2)==0x4400)OR(GetPixel3(bx+1+x, by+1)==0x4400)OR(GetPixel3(bx+2+x, by+22)==0x4400)OR(GetPixel3(bx+2+x, by+21)==0x4400)OR(GetPixel3(bx+2+x, by+20)==0x4400)OR(GetPixel3(bx+2+x, by+19)==0x4400)OR(GetPixel3(bx+2+x, by+18)==0x4400)OR(GetPixel3(bx+2+x, by+17)==0x4400)OR(GetPixel3(bx+2+x, by+16)==0x4400)OR(GetPixel3(bx+2+x, by+15)==0x4400)OR(GetPixel3(bx+2+x, by+14)==0x4400)OR(GetPixel3(bx+2+x, by+13)==0x4400)OR(GetPixel3(bx+2+x, by+12)==0x4400)OR(GetPixel3(bx+2+x, by+11)==0x4400)OR(GetPixel3(bx+2+x, by+10)==0x4400)OR(GetPixel3(bx+2+x, by+9)==0x4400)OR(GetPixel3(bx+2+x, by+8)==0x4400)OR(GetPixel3(bx+2+x, by+7)==0x4400)OR(GetPixel3(bx+2+x, by+6)==0x4400)OR(GetPixel3(bx+2+x, by+5)==0x4400)OR(GetPixel3(bx+2+x, by+4)==0x4400)OR(GetPixel3(bx+2+x, by+3)==0x4400)OR(GetPixel3(bx+2+x, by+2)==0x4400)OR(GetPixel3(bx+2+x, by+1)==0x4400)OR(GetPixel3(bx+1, by)==0x4400)OR(GetPixel3(bx+2, by)==0x4400)OR(GetPixel3(bx+3, by)==0x4400)OR(GetPixel3(bx+4, by)==0x4400)OR(GetPixel3(bx+5, by)==0x4400)OR(GetPixel3(bx+6, by)==0x4400)OR(GetPixel3(bx+7, by)==0x4400)OR(GetPixel3(bx+8, by)==0x4400)OR(GetPixel3(bx+9, by)==0x4400)OR(GetPixel3(bx+10, by)==0x4400)OR(GetPixel3(bx+11, by)==0x4400)OR(GetPixel3(bx+12, by)==0x4400)OR(GetPixel3(bx+13, by)==0x4400)OR(GetPixel3(bx+14, by+9)==0x4400)OR(GetPixel3(bx+15, by+8)==0x4400)OR(GetPixel3(bx+16, by+7)==0x4400)OR(GetPixel3(bx+17, by+6)==0x4400)OR(GetPixel3(bx+18, by)==0x4400)OR(GetPixel3(bx+19, by)==0x4400)OR(GetPixel3(bx+20, by)==0x4400)OR(GetPixel3(bx+21, by)==0x4400)OR(GetPixel3(bx+22, by)==0x4400)OR(GetPixel3(bx+23, by)==0x4400))
{
	vsync
	EraseScreen();
	SetMode(MODE_4|BG2_ENABLE);
	drawbg2((void*)killscreenBitmap, (void*)killscreenPalette);
	Sleep(512);
	setbg2((void*)blackBitmap, (void*)black2Palette);
	Sleep(256);
	setbg2((void*)black_finalBitmap, (void*)black_finalPalette);
	Sleep(256);
	SaveInt(offset, 1);
	vsync
	hardreset();
}
}


int main()
{
	Initialize();
	sram = LoadInt(offset);
	if(sram==1)
	{
	bgPic2Buffer((void*)discliamerBitmap); //disclaimer
	bgPal((void*)discliamerPalette);
	bgPic((void*)discliamerBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SetBGPalPoint(1, (void*)GetBGPalPoint(1)+1);
		SleepF(0.50);
		SetBGPalPoint(1, (void*)GetBGPalPoint(1)+1);
		SleepF(0.50);
		SetBGPalPoint(1, (void*)GetBGPalPoint(1)+1);
		SleepF(0.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)thxBitmap); //special thanks
	bgPal((void*)thxPalette);
	bgPic((void*)thxBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)scratchBitmap); //scratch
	bgPal((void*)scratchPalette);
	bgPic((void*)scratchBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)gbadevBitmap); //GBADEV logo
	bgPal((void*)gbadevPalette);
	bgPic((void*)gbadevBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)imadogBitmap); //meh
	bgPal((void*)imadogPalette);
	bgPic((void*)imadogBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	bgPic2Buffer((void*)slyangelBitmap); //meh good brah
	bgPal((void*)slyangelPalette);
	bgPic((void*)slyangelBitmap);
	FadeIn(2);
	time=0;
	while(!(time==255 | keyDown(KEY_A)))
	{
		time++;
		SleepF(1.50);
	}
	FadeOut(2);
	SetMode(MODE_4|BG2_ENABLE);
	setbg2m3(us titlescreenBitmap);
	SetMode(MODE_3|BG2_ENABLE);
	FadeIn(2);
	while(!(keyDown(KEY_START)))
	{
		wait = 0;
	}
	vsync
	SetMode(MODE_4|BG2_ENABLE);
	for(i=0;i<30;i++)
	{
		vsync
		setbg2(us stat1Bitmap, us stat1Palette);
		Sleep(10);
		vsync
		setbg2(us stat2Bitmap, us stat2Palette);
		Sleep(10);
	}
	setbg2(us bsodBitmap, us bsodPalette);
	SaveInt(offset,2);
	while(1);
	}
	if(sram==2)
	{
		SetMode(MODE_3|BG2_ENABLE);
		drawbitmap3(0x0000);
		FadeIn(0);
		Sleep(256);
		Print(8,8,"HAHAHAHAHAHAHAHAHAHAH!",GREEN,BLACK);
		while(!(KEY_ANY_PRESSED));
		SaveInt(offset,0);
		vsync
		hardreset();
	}
	InitializeSprites();
	loadSpritePal((void*)allobjsPalette);
	loadSpriteGraphics((void*)allobjsData, 11904);
	initSprite(1, SIZE_32, 0);
	initSprite(2, SIZE_8, 48);
	sprites[4].attribute0 = COLOR_256 | WIDE | 240;
	sprites[4].attribute1 = SIZE_64 | 160;
	sprites[4].attribute2 = 512 + 280; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

	// set sprite offscreen, and set it up (size,etc)
	sprites[3].attribute0 = COLOR_256 | WIDE | 240;
	sprites[3].attribute1 = SIZE_32 | 160;
	sprites[3].attribute2 = 512 + 32; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
	g=1;
	FadeIn(2);
	drawbitmap3((void*)l105Bitmap);
	SetMode(MODE_3|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	bx=8;by=108;
	MoveSprite(&sprites[4], 0, 152);
	MoveSprite(&sprites[5], 98, 66);
	while(1)
	{
		WaitForVblank();
		CopyOAM();
		MoveSprite(&sprites[1], bx, by);
		MoveSprite(&sprites[2], 223, 128);
		y+=0.24;
		by+=1;
		if(((GetPixel3(bx+1, by+24+y)==0x64c0)OR(GetPixel3(bx+1, by+22+y)==0x64c0)OR(GetPixel3(bx+2, by+24+y)==0x64c0)OR(GetPixel3(bx+2, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+24+y)==0x64c0)OR(GetPixel3(bx+3, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+22+y)==0x64c0)OR(GetPixel3(bx+4, by+24+y)==0x64c0)OR(GetPixel3(bx+4, by+23+y)==0x64c0)OR(GetPixel3(bx+4, by+22+y)==0x64c0)OR(GetPixel3(bx+5, by+24+y)==0x64c0)OR(GetPixel3(bx+5, by+23+y)==0x64c0)OR(GetPixel3(bx+5, by+22+y)==0x64c0)OR(GetPixel3(bx+6, by+24+y)==0x64c0)OR(GetPixel3(bx+6, by+23+y)==0x64c0)OR(GetPixel3(bx+6, by+22+y)==0x64c0)OR(GetPixel3(bx+7, by+24+y)==0x64c0)OR(GetPixel3(bx+7, by+23+y)==0x64c0)OR(GetPixel3(bx+7, by+22+y)==0x64c0)OR(GetPixel3(bx+8, by+24+y)==0x64c0)OR(GetPixel3(bx+8, by+23+y)==0x64c0)OR(GetPixel3(bx+8, by+22+y)==0x64c0)OR(GetPixel3(bx+9, by+24+y)==0x64c0)OR(GetPixel3(bx+9, by+23+y)==0x64c0)OR(GetPixel3(bx+9, by+22+y)==0x64c0)OR(GetPixel3(bx+10, by+24+y)==0x64c0)OR(GetPixel3(bx+10, by+23+y)==0x64c0)OR(GetPixel3(bx+10, by+22+y)==0x64c0)OR(GetPixel3(bx+11, by+24+y)==0x64c0)OR(GetPixel3(bx+12, by+23+y)==0x64c0)OR(GetPixel3(bx+12, by+22+y)==0x64c0)OR(GetPixel3(bx+13, by+24+y)==0x64c0)OR(GetPixel3(bx+13, by+23+y)==0x64c0)OR(GetPixel3(bx+13, by+22+y)==0x64c0)OR(GetPixel3(bx+14, by+24+y)==0x64c0)OR(GetPixel3(bx+14, by+23+y)==0x64c0)OR(GetPixel3(bx+14, by+22+y)==0x64c0)OR(GetPixel3(bx+15, by+24+y)==0x64c0)OR(GetPixel3(bx+16, by+23+y)==0x64c0)OR(GetPixel3(bx+17, by+22+y)==0x64c0)OR(GetPixel3(bx+18, by+24+y)==0x64c0)OR(GetPixel3(bx+19, by+23+y)==0x64c0)OR(GetPixel3(bx+20, by+22+y)==0x64c0)))
		{
			if((keyDown(KEY_A))AND(alock==0))
			{
				y=-3.85;
				alock=1;
			}
		}
		by-=1;
		if(keyDown(KEY_LEFT))
		{
			x-=0.5;
			dir=1;
		}
		if(keyDown(KEY_RIGHT))
		{
			x+=0.5;
			dir=0;
		}
		x*=0.9;
		if((dir==1)AND(NOT(x>0))AND(NOT(keyDown(KEY_LEFT))))
		{
			x+=0.08;
			if(x>0)
			{
				x=0;
			}
		}
		bx+=x;
		by+=y;
		if(by>136)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if(by<0)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if(bx>216)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if(bx<0)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		bottomcol();
		leftcol();
		rightcol();
		topcol();
		bottomdcol();
		leftdcol();
		rightdcol();
		topdcol();
		crshcol();
		if((keyDown(KEY_B))AND(block==0)AND(g==1)AND(crsh==0))
		{
			fb=1;
			fy=by+4;
			fx=bx;
			block=1;
		}
		if((fb==1)AND(NOT(fx>240)))
		{
			fx+=5;
			MoveSprite(&sprites[3], fx, fy);
		}
		if(NOT(keyDown(KEY_A)))
		{
			alock=0;
		}
		if(NOT(keyDown(KEY_B)))
		{
			block=0;
		}

	}
	return 0;
}
