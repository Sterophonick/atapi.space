#include <agb_lib.h>
#include "allobjs.h"
#include "l47.c"
#include "sounds.h"
int bx,by,fx,fy,fb,g,gravity,sellock;
int16 x,y;
int boiy,boix;
int i,dir;
int alock,block,sndtmr,jumpt,deatht;

void playSoundA(int s) {
 REG_SOUNDCNT1_H = 0x3008|0x4000|0x0002|0x300|0x800|0x8000;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 REG_SOUNDCNT1_X = 0x0080;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 REG_SD1SAD      = (unsigned long) sound[s].song;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 REG_SD1DAD      = 0x040000A0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 REG_SD1CNT_H    = 0xB640;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 REG_TM0SD       = 65536-(16777216/sound[s].frequency);                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 REG_TMSDCNT     = 0x00C0;  
}

void bottomcol()
{
	if((GetPixel3(bx+1, by+24+y)==0x64c0)OR(GetPixel3(bx+1, by+22+y)==0x64c0)OR(GetPixel3(bx+2, by+24+y)==0x64c0)OR(GetPixel3(bx+2, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+24+y)==0x64c0)OR(GetPixel3(bx+3, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+22+y)==0x64c0)OR(GetPixel3(bx+4, by+24+y)==0x64c0)OR(GetPixel3(bx+4, by+23+y)==0x64c0)OR(GetPixel3(bx+4, by+22+y)==0x64c0)OR(GetPixel3(bx+5, by+24+y)==0x64c0)OR(GetPixel3(bx+5, by+23+y)==0x64c0)OR(GetPixel3(bx+5, by+22+y)==0x64c0)OR(GetPixel3(bx+6, by+24+y)==0x64c0)OR(GetPixel3(bx+6, by+23+y)==0x64c0)OR(GetPixel3(bx+6, by+22+y)==0x64c0)OR(GetPixel3(bx+7, by+24+y)==0x64c0)OR(GetPixel3(bx+7, by+23+y)==0x64c0)OR(GetPixel3(bx+7, by+22+y)==0x64c0)OR(GetPixel3(bx+8, by+24+y)==0x64c0)OR(GetPixel3(bx+8, by+23+y)==0x64c0)OR(GetPixel3(bx+8, by+22+y)==0x64c0)OR(GetPixel3(bx+9, by+24+y)==0x64c0)OR(GetPixel3(bx+9, by+23+y)==0x64c0)OR(GetPixel3(bx+9, by+22+y)==0x64c0)OR(GetPixel3(bx+10, by+24+y)==0x64c0)OR(GetPixel3(bx+10, by+23+y)==0x64c0)OR(GetPixel3(bx+10, by+22+y)==0x64c0)OR(GetPixel3(bx+11, by+24+y)==0x64c0)OR(GetPixel3(bx+12, by+23+y)==0x64c0)OR(GetPixel3(bx+12, by+22+y)==0x64c0)OR(GetPixel3(bx+13, by+24+y)==0x64c0)OR(GetPixel3(bx+13, by+23+y)==0x64c0)OR(GetPixel3(bx+13, by+22+y)==0x64c0)OR(GetPixel3(bx+14, by+24+y)==0x64c0)OR(GetPixel3(bx+14, by+23+y)==0x64c0)OR(GetPixel3(bx+14, by+22+y)==0x64c0)OR(GetPixel3(bx+15, by+24+y)==0x64c0)OR(GetPixel3(bx+16, by+23+y)==0x64c0)OR(GetPixel3(bx+17, by+22+y)==0x64c0)OR(GetPixel3(bx+18, by+24+y)==0x64c0)OR(GetPixel3(bx+19, by+23+y)==0x64c0)OR(GetPixel3(bx+20, by+22+y)==0x64c0)) 
	{
		if(gravity==0)
		{
			by-=1;
			y=0;
		}else{
			by-=3;
			by+=y;
			y=0;
			y-=0.24;
			MoveSprite(&sprites[1], bx, by);
		}
	}
	if(GetPixel3(bx+21, by+23+y)==0x64c0)
	{
		if(gravity==0)
		{
			by-=1;
			y=0;
		}else{
			by-=3;
			by+=y;
			y=0;
			y-=0.24;
			MoveSprite(&sprites[1], bx, by);
		}
	}
	if(GetPixel3(bx+22, by+24+y)==0x64c0)
	{
		if(gravity==0)
		{
			by-=1;
			y=0;
		}else{
			by-=3;
			by+=y;
			y=0;
			y-=0.24;
			MoveSprite(&sprites[1], bx, by);
		}
	}
	if(GetPixel3(bx+23, by+24)==0x64c0)
	{
		if(gravity==0)
		{
			by-=1;
			y=0;
		}else{
			by-=3;
			by+=y;
			y=0;
			y-=0.24;
			MoveSprite(&sprites[1], bx, by);
		}
	}
	if(GetPixel3(bx, by+24)==0x64c0)
	{
		if(gravity==0)
		{
			by-=1;
			y=0;
		}else{
			by-=3;
			by+=y;
			y=0;
			y-=0.24;
			MoveSprite(&sprites[1], bx, by);
		}
	}
}

void rightcol()
{
	if((GetPixel3(bx+24+x, by+22)==0x64c0)OR(GetPixel3(bx+24+x, by+21)==0x64c0)OR(GetPixel3(bx+24+x, by+20)==0x64c0)OR(GetPixel3(bx+24+x, by+19)==0x64c0)OR(GetPixel3(bx+24+x, by+18)==0x64c0)OR(GetPixel3(bx+24+x, by+17)==0x64c0)OR(GetPixel3(bx+24+x, by+16)==0x64c0)OR(GetPixel3(bx+24+x, by+15)==0x64c0)OR(GetPixel3(bx+24+x, by+14)==0x64c0)OR(GetPixel3(bx+24+x, by+13)==0x64c0)OR(GetPixel3(bx+24+x, by+12)==0x64c0)OR(GetPixel3(bx+24+x, by+11)==0x64c0)OR(GetPixel3(bx+24+x, by+10)==0x64c0)OR(GetPixel3(bx+24+x, by+9)==0x64c0)OR(GetPixel3(bx+24+x, by+8)==0x64c0)OR(GetPixel3(bx+24+x, by+7)==0x64c0)OR(GetPixel3(bx+24+x, by+6)==0x64c0)OR(GetPixel3(bx+24+x, by+5)==0x64c0)OR(GetPixel3(bx+24+x, by+4)==0x64c0)OR(GetPixel3(bx+24+x, by+3)==0x64c0)OR(GetPixel3(bx+24+x, by+2)==0x64c0)OR(GetPixel3(bx+24+x, by+1)==0x64c0)OR(GetPixel3(bx+23+x, by+22)==0x64c0)OR(GetPixel3(bx+23+x, by+21)==0x64c0)OR(GetPixel3(bx+23+x, by+20)==0x64c0)OR(GetPixel3(bx+23+x, by+19)==0x64c0)OR(GetPixel3(bx+23+x, by+18)==0x64c0)OR(GetPixel3(bx+23+x, by+17)==0x64c0)OR(GetPixel3(bx+23+x, by+16)==0x64c0)OR(GetPixel3(bx+23+x, by+15)==0x64c0)OR(GetPixel3(bx+23+x, by+14)==0x64c0)OR(GetPixel3(bx+23+x, by+13)==0x64c0)OR(GetPixel3(bx+23+x, by+12)==0x64c0)OR(GetPixel3(bx+23+x, by+11)==0x64c0)OR(GetPixel3(bx+23+x, by+10)==0x64c0)OR(GetPixel3(bx+23+x, by+9)==0x64c0)OR(GetPixel3(bx+23+x, by+8)==0x64c0)OR(GetPixel3(bx+23+x, by+7)==0x64c0)OR(GetPixel3(bx+23+x, by+6)==0x64c0)OR(GetPixel3(bx+23+x, by+5)==0x64c0)OR(GetPixel3(bx+23+x, by+4)==0x64c0)OR(GetPixel3(bx+23+x, by+3)==0x64c0)OR(GetPixel3(bx+23+x, by+2)==0x64c0)OR(GetPixel3(bx+23+x, by+1)==0x64c0))
	{
			if((keyDown(KEY_A))AND(alock==0))	
			{
				REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 				REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 				REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 				REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  				REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   				REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  				REG_TM0CNT    = 0;  
				if(gravity==0)
				{
					y=-3.85;
				}else{
					y=3.85;
				}
				x=-5;
				alock=1;
				jumpt=1;
				playSoundA(1);
				sndtmr=0;
				deatht=0;
			}else{
				x=0;
				bx-=1;
			}
	}
}

void leftcol()
{
	if((GetPixel3(bx+x, by+22)==0x64c0)OR(GetPixel3(bx+x, by+21)==0x64c0)OR(GetPixel3(bx+x, by+20)==0x64c0)OR(GetPixel3(bx+x, by+19)==0x64c0)OR(GetPixel3(bx+x, by+18)==0x64c0)OR(GetPixel3(bx+x, by+17)==0x64c0)OR(GetPixel3(bx+x, by+16)==0x64c0)OR(GetPixel3(bx+x, by+15)==0x64c0)OR(GetPixel3(bx+x, by+14)==0x64c0)OR(GetPixel3(bx+x, by+13)==0x64c0)OR(GetPixel3(bx+x, by+12)==0x64c0)OR(GetPixel3(bx+x, by+11)==0x64c0)OR(GetPixel3(bx+x, by+10)==0x64c0)OR(GetPixel3(bx+x, by+9)==0x64c0)OR(GetPixel3(bx+x, by+8)==0x64c0)OR(GetPixel3(bx+x, by+7)==0x64c0)OR(GetPixel3(bx+x, by+6)==0x64c0)OR(GetPixel3(bx+x, by+5)==0x64c0)OR(GetPixel3(bx+x, by+4)==0x64c0)OR(GetPixel3(bx+x, by+3)==0x64c0)OR(GetPixel3(bx+x, by+2)==0x64c0)OR(GetPixel3(bx+x, by+1)==0x64c0)OR(GetPixel3(bx+1+x, by+22)==0x64c0)OR(GetPixel3(bx+1+x, by+21)==0x64c0)OR(GetPixel3(bx+1+x, by+20)==0x64c0)OR(GetPixel3(bx+1+x, by+19)==0x64c0)OR(GetPixel3(bx+1+x, by+18)==0x64c0)OR(GetPixel3(bx+1+x, by+17)==0x64c0)OR(GetPixel3(bx+1+x, by+16)==0x64c0)OR(GetPixel3(bx+1+x, by+15)==0x64c0)OR(GetPixel3(bx+1+x, by+14)==0x64c0)OR(GetPixel3(bx+1+x, by+13)==0x64c0)OR(GetPixel3(bx+1+x, by+12)==0x64c0)OR(GetPixel3(bx+1+x, by+11)==0x64c0)OR(GetPixel3(bx+1+x, by+10)==0x64c0)OR(GetPixel3(bx+1+x, by+9)==0x64c0)OR(GetPixel3(bx+1+x, by+8)==0x64c0)OR(GetPixel3(bx+1+x, by+7)==0x64c0)OR(GetPixel3(bx+1+x, by+6)==0x64c0)OR(GetPixel3(bx+1+x, by+5)==0x64c0)OR(GetPixel3(bx+1+x, by+4)==0x64c0)OR(GetPixel3(bx+1+x, by+3)==0x64c0)OR(GetPixel3(bx+1+x, by+2)==0x64c0)OR(GetPixel3(bx+1+x, by+1)==0x64c0)OR(GetPixel3(bx+2+x, by+22)==0x64c0)OR(GetPixel3(bx+2+x, by+21)==0x64c0)OR(GetPixel3(bx+2+x, by+20)==0x64c0)OR(GetPixel3(bx+2+x, by+19)==0x64c0)OR(GetPixel3(bx+2+x, by+18)==0x64c0)OR(GetPixel3(bx+2+x, by+17)==0x64c0)OR(GetPixel3(bx+2+x, by+16)==0x64c0)OR(GetPixel3(bx+2+x, by+15)==0x64c0)OR(GetPixel3(bx+2+x, by+14)==0x64c0)OR(GetPixel3(bx+2+x, by+13)==0x64c0)OR(GetPixel3(bx+2+x, by+12)==0x64c0)OR(GetPixel3(bx+2+x, by+11)==0x64c0)OR(GetPixel3(bx+2+x, by+10)==0x64c0)OR(GetPixel3(bx+2+x, by+9)==0x64c0)OR(GetPixel3(bx+2+x, by+8)==0x64c0)OR(GetPixel3(bx+2+x, by+7)==0x64c0)OR(GetPixel3(bx+2+x, by+6)==0x64c0)OR(GetPixel3(bx+2+x, by+5)==0x64c0)OR(GetPixel3(bx+2+x, by+4)==0x64c0)OR(GetPixel3(bx+2+x, by+3)==0x64c0)OR(GetPixel3(bx+2+x, by+2)==0x64c0)OR(GetPixel3(bx+2+x, by+1)==0x64c0))
	{
			if((keyDown(KEY_A))AND(alock==0))	
			{
				REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 				REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 				REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 				REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  				REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   				REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  				REG_TM0CNT    = 0;  
				if(gravity==0)
				{
					y=-3.85;
				}else{
					y=3.85;
				}
				x=5;
				alock=1;
				jumpt=1;
				playSoundA(1);
				sndtmr=0;
				deatht=0;
			}else{
				x=0;
				bx+=1;
			}
	}
}

void topcol()
{
	if((GetPixel3(bx+1, by+y)==0x64c0)OR(GetPixel3(bx+2, by+y)==0x64c0)OR(GetPixel3(bx+3, by+y)==0x64c0)OR(GetPixel3(bx+4, by+y)==0x64c0)OR(GetPixel3(bx+5, by+y)==0x64c0)OR(GetPixel3(bx+6, by+y)==0x64c0)OR(GetPixel3(bx+7, by+y)==0x64c0)OR(GetPixel3(bx+8, by+y)==0x64c0)OR(GetPixel3(bx+9, by+y)==0x64c0)OR(GetPixel3(bx+10, by+y)==0x64c0)OR(GetPixel3(bx+11, by+y)==0x64c0)OR(GetPixel3(bx+12, by+y)==0x64c0)OR(GetPixel3(bx+13, by+y)==0x64c0)OR(GetPixel3(bx+14, by+y+9)==0x64c0)OR(GetPixel3(bx+15, by+y+8)==0x64c0)OR(GetPixel3(bx+16, by+y+7)==0x64c0)OR(GetPixel3(bx+17, by+y+6)==0x64c0)OR(GetPixel3(bx+18, by+y)==0x64c0)OR(GetPixel3(bx+19, by+y)==0x64c0)OR(GetPixel3(bx+20, by+y)==0x64c0)OR(GetPixel3(bx+21, by+y)==0x64c0)OR(GetPixel3(bx+22, by+y)==0x64c0)OR(GetPixel3(bx+23, by+y)==0x64c0))
	{
		if(gravity==0)
		{
			by+=3;
			by-=y;
			y=0;
			y+=0.24;
			MoveSprite(&sprites[1], bx, by);
		}else{	
			y=0;
			by+=1;
			if((GetPixel3(bx+1, by+y+1)==0x64c0)OR(GetPixel3(bx+2, by+y+1)==0x64c0)OR(GetPixel3(bx+3, by+y+1)==0x64c0)OR(GetPixel3(bx+4, by+y+1)==0x64c0)OR(GetPixel3(bx+5, by+y+1)==0x64c0)OR(GetPixel3(bx+6, by+y+1)==0x64c0)OR(GetPixel3(bx+7, by+y+1)==0x64c0)OR(GetPixel3(bx+8, by+y+1)==0x64c0)OR(GetPixel3(bx+9, by+y+1)==0x64c0)OR(GetPixel3(bx+10, by+y+1)==0x64c0)OR(GetPixel3(bx+11, by+y+1)==0x64c0)OR(GetPixel3(bx+12, by+y+1)==0x64c0)OR(GetPixel3(bx+13, by+y+1)==0x64c0)OR(GetPixel3(bx+14, by+y+1+9)==0x64c0)OR(GetPixel3(bx+15, by+y+1+8)==0x64c0)OR(GetPixel3(bx+16, by+y+1+7)==0x64c0)OR(GetPixel3(bx+17, by+y+1+6)==0x64c0)OR(GetPixel3(bx+18, by+y+1)==0x64c0)OR(GetPixel3(bx+19, by+y+1)==0x64c0)OR(GetPixel3(bx+20, by+y+1)==0x64c0)OR(GetPixel3(bx+21, by+y+1)==0x64c0)OR(GetPixel3(bx+22, by+y+1)==0x64c0)OR(GetPixel3(bx+23, by+y+1)==0x64c0))
			{
				y=0;
				by+=1;
				if((GetPixel3(bx+1, by+y+2)==0x64c0)OR(GetPixel3(bx+2, by+y+2)==0x64c0)OR(GetPixel3(bx+3, by+y+2)==0x64c0)OR(GetPixel3(bx+4, by+y+2)==0x64c0)OR(GetPixel3(bx+5, by+y+2)==0x64c0)OR(GetPixel3(bx+6, by+y+2)==0x64c0)OR(GetPixel3(bx+7, by+y+2)==0x64c0)OR(GetPixel3(bx+8, by+y+2)==0x64c0)OR(GetPixel3(bx+9, by+y+2)==0x64c0)OR(GetPixel3(bx+10, by+y+2)==0x64c0)OR(GetPixel3(bx+11, by+y+2)==0x64c0)OR(GetPixel3(bx+12, by+y+2)==0x64c0)OR(GetPixel3(bx+13, by+y+2)==0x64c0)OR(GetPixel3(bx+14, by+y+2+9)==0x64c0)OR(GetPixel3(bx+15, by+y+2+8)==0x64c0)OR(GetPixel3(bx+16, by+y+2+7)==0x64c0)OR(GetPixel3(bx+17, by+y+2+6)==0x64c0)OR(GetPixel3(bx+18, by+y+2)==0x64c0)OR(GetPixel3(bx+19, by+y+2)==0x64c0)OR(GetPixel3(bx+20, by+y+2)==0x64c0)OR(GetPixel3(bx+21, by+y+2)==0x64c0)OR(GetPixel3(bx+22, by+y+2)==0x64c0)OR(GetPixel3(bx+23, by+y+2)==0x64c0))
				{
					y=0;
					by+=1;
					if((GetPixel3(bx+1, by+y+3)==0x64c0)OR(GetPixel3(bx+2, by+y+3)==0x64c0)OR(GetPixel3(bx+3, by+y+3)==0x64c0)OR(GetPixel3(bx+4, by+y+3)==0x64c0)OR(GetPixel3(bx+5, by+y+3)==0x64c0)OR(GetPixel3(bx+6, by+y+3)==0x64c0)OR(GetPixel3(bx+7, by+y+3)==0x64c0)OR(GetPixel3(bx+8, by+y+3)==0x64c0)OR(GetPixel3(bx+9, by+y+3)==0x64c0)OR(GetPixel3(bx+10, by+y+3)==0x64c0)OR(GetPixel3(bx+11, by+y+3)==0x64c0)OR(GetPixel3(bx+12, by+y+3)==0x64c0)OR(GetPixel3(bx+13, by+y+3)==0x64c0)OR(GetPixel3(bx+14, by+y+3+9)==0x64c0)OR(GetPixel3(bx+15, by+y+3+8)==0x64c0)OR(GetPixel3(bx+16, by+y+3+7)==0x64c0)OR(GetPixel3(bx+17, by+y+3+6)==0x64c0)OR(GetPixel3(bx+18, by+y+3)==0x64c0)OR(GetPixel3(bx+19, by+y+3)==0x64c0)OR(GetPixel3(bx+20, by+y+3)==0x64c0)OR(GetPixel3(bx+21, by+y+3)==0x64c0)OR(GetPixel3(bx+22, by+y+3)==0x64c0)OR(GetPixel3(bx+23, by+y+3)==0x64c0))
					{
						y=0;
						by+=1;
						if((GetPixel3(bx+1, by+y+4)==0x64c0)OR(GetPixel3(bx+2, by+y+4)==0x64c0)OR(GetPixel3(bx+3, by+y+4)==0x64c0)OR(GetPixel3(bx+4, by+y+4)==0x64c0)OR(GetPixel3(bx+5, by+y+4)==0x64c0)OR(GetPixel3(bx+6, by+y+4)==0x64c0)OR(GetPixel3(bx+7, by+y+4)==0x64c0)OR(GetPixel3(bx+8, by+y+4)==0x64c0)OR(GetPixel3(bx+9, by+y+4)==0x64c0)OR(GetPixel3(bx+10, by+y+4)==0x64c0)OR(GetPixel3(bx+11, by+y+4)==0x64c0)OR(GetPixel3(bx+12, by+y+4)==0x64c0)OR(GetPixel3(bx+13, by+y+4)==0x64c0)OR(GetPixel3(bx+14, by+y+4+9)==0x64c0)OR(GetPixel3(bx+15, by+y+4+8)==0x64c0)OR(GetPixel3(bx+16, by+y+4+7)==0x64c0)OR(GetPixel3(bx+17, by+y+4+6)==0x64c0)OR(GetPixel3(bx+18, by+y+4)==0x64c0)OR(GetPixel3(bx+19, by+y+4)==0x64c0)OR(GetPixel3(bx+20, by+y+4)==0x64c0)OR(GetPixel3(bx+21, by+y+4)==0x64c0)OR(GetPixel3(bx+22, by+y+4)==0x64c0)OR(GetPixel3(bx+23, by+y+4)==0x64c0))
						{
							y=0;
							by+=1;
							if((GetPixel3(bx+1, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+2, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+3, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+4, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+5, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+6, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+7, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+8, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+9, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+10, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+11, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+12, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+13, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+14, by+(y*2)+5+9)==0x64c0)OR(GetPixel3(bx+15, by+(y*2)+5+8)==0x64c0)OR(GetPixel3(bx+16, by+(y*2)+5+7)==0x64c0)OR(GetPixel3(bx+17, by+(y*2)+5+6)==0x64c0)OR(GetPixel3(bx+18, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+19, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+20, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+21, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+22, by+(y*2)+5)==0x64c0)OR(GetPixel3(bx+23, by+(y*2)+5)==0x64c0))
							{
								y=0;
								by+=1;
								if((GetPixel3(bx+1, by+y+6)==0x64c0)OR(GetPixel3(bx+2, by+y+6)==0x64c0)OR(GetPixel3(bx+3, by+y+6)==0x64c0)OR(GetPixel3(bx+4, by+y+6)==0x64c0)OR(GetPixel3(bx+5, by+y+6)==0x64c0)OR(GetPixel3(bx+6, by+y+6)==0x64c0)OR(GetPixel3(bx+7, by+y+6)==0x64c0)OR(GetPixel3(bx+8, by+y+6)==0x64c0)OR(GetPixel3(bx+9, by+y+6)==0x64c0)OR(GetPixel3(bx+10, by+y+6)==0x64c0)OR(GetPixel3(bx+11, by+y+6)==0x64c0)OR(GetPixel3(bx+12, by+y+6)==0x64c0)OR(GetPixel3(bx+13, by+y+6)==0x64c0)OR(GetPixel3(bx+14, by+y+6+9)==0x64c0)OR(GetPixel3(bx+15, by+y+6+8)==0x64c0)OR(GetPixel3(bx+16, by+y+6+7)==0x64c0)OR(GetPixel3(bx+17, by+y+6+6)==0x64c0)OR(GetPixel3(bx+18, by+y+6)==0x64c0)OR(GetPixel3(bx+19, by+y+6)==0x64c0)OR(GetPixel3(bx+20, by+y+6)==0x64c0)OR(GetPixel3(bx+21, by+y+6)==0x64c0)OR(GetPixel3(bx+22, by+y+6)==0x64c0)OR(GetPixel3(bx+23, by+y+6)==0x64c0)OR((GetPixel3(bx+1, by+y+7)==0x64c0)OR(GetPixel3(bx+2, by+y+7)==0x64c0)OR(GetPixel3(bx+3, by+y+7)==0x64c0)OR(GetPixel3(bx+4, by+y+7)==0x64c0)OR(GetPixel3(bx+5, by+y+7)==0x64c0)OR(GetPixel3(bx+6, by+y+7)==0x64c0)OR(GetPixel3(bx+7, by+y+7)==0x64c0)OR(GetPixel3(bx+8, by+y+7)==0x64c0)OR(GetPixel3(bx+9, by+y+7)==0x64c0)OR(GetPixel3(bx+10, by+y+7)==0x64c0)OR(GetPixel3(bx+11, by+y+7)==0x64c0)OR(GetPixel3(bx+12, by+y+7)==0x64c0)OR(GetPixel3(bx+13, by+y+7)==0x64c0)OR(GetPixel3(bx+14, by+y+7+9)==0x64c0)OR(GetPixel3(bx+15, by+y+7+8)==0x64c0)OR(GetPixel3(bx+16, by+y+7+7)==0x64c0)OR(GetPixel3(bx+17, by+y+7+6)==0x64c0)OR(GetPixel3(bx+18, by+y+7)==0x64c0)OR(GetPixel3(bx+19, by+y+7)==0x64c0)OR(GetPixel3(bx+20, by+y+7)==0x64c0)OR(GetPixel3(bx+21, by+y+7)==0x64c0)OR(GetPixel3(bx+22, by+y+7)==0x64c0)OR(GetPixel3(bx+23, by+y+7)==0x64c0)OR((GetPixel3(bx+1, by+y+10)==0x64c0)OR(GetPixel3(bx+2, by+y+10)==0x64c0)OR(GetPixel3(bx+3, by+y+10)==0x64c0)OR(GetPixel3(bx+4, by+y+10)==0x64c0)OR(GetPixel3(bx+5, by+y+10)==0x64c0)OR(GetPixel3(bx+6, by+y+10)==0x64c0)OR(GetPixel3(bx+7, by+y+10)==0x64c0)OR(GetPixel3(bx+8, by+y+10)==0x64c0)OR(GetPixel3(bx+9, by+y+10)==0x64c0)OR(GetPixel3(bx+10, by+y+10)==0x64c0)OR(GetPixel3(bx+11, by+y+10)==0x64c0)OR(GetPixel3(bx+12, by+y+10)==0x64c0)OR(GetPixel3(bx+13, by+y+10)==0x64c0)OR(GetPixel3(bx+14, by+y+10+9)==0x64c0)OR(GetPixel3(bx+15, by+y+10+8)==0x64c0)OR(GetPixel3(bx+16, by+y+10+7)==0x64c0)OR(GetPixel3(bx+17, by+y+10+6)==0x64c0)OR(GetPixel3(bx+18, by+y+10)==0x64c0)OR(GetPixel3(bx+19, by+y+10)==0x64c0)OR(GetPixel3(bx+20, by+y+10)==0x64c0)OR(GetPixel3(bx+21, by+y+10)==0x64c0)OR(GetPixel3(bx+22, by+y+10)==0x64c0)OR(GetPixel3(bx+23, by+y+10)==0x64c0))
	))
								{
									y=0;
									by+=2;
								}
							}
						}
					}
				}
			}
		}
	}
}

void bottomdcol()
{
	if((GetPixel3(bx+1, by+24+y)==0x001F)OR(GetPixel3(bx+1, by+22+y)==0x001F)OR(GetPixel3(bx+2, by+24+y)==0x001F)OR(GetPixel3(bx+2, by+23+y)==0x001F)OR(GetPixel3(bx+3, by+24+y)==0x001F)OR(GetPixel3(bx+3, by+23+y)==0x001F)OR(GetPixel3(bx+3, by+22+y)==0x001F)OR(GetPixel3(bx+4, by+24+y)==0x001F)OR(GetPixel3(bx+4, by+23+y)==0x001F)OR(GetPixel3(bx+4, by+22+y)==0x001F)OR(GetPixel3(bx+5, by+24+y)==0x001F)OR(GetPixel3(bx+5, by+23+y)==0x001F)OR(GetPixel3(bx+5, by+22+y)==0x001F)OR(GetPixel3(bx+6, by+24+y)==0x001F)OR(GetPixel3(bx+6, by+23+y)==0x001F)OR(GetPixel3(bx+6, by+22+y)==0x001F)OR(GetPixel3(bx+7, by+24+y)==0x001F)OR(GetPixel3(bx+7, by+23+y)==0x001F)OR(GetPixel3(bx+7, by+22+y)==0x001F)OR(GetPixel3(bx+8, by+24+y)==0x001F)OR(GetPixel3(bx+8, by+23+y)==0x001F)OR(GetPixel3(bx+8, by+22+y)==0x001F)OR(GetPixel3(bx+9, by+24+y)==0x001F)OR(GetPixel3(bx+9, by+23+y)==0x001F)OR(GetPixel3(bx+9, by+22+y)==0x001F)OR(GetPixel3(bx+10, by+24+y)==0x001F)OR(GetPixel3(bx+10, by+23+y)==0x001F)OR(GetPixel3(bx+10, by+22+y)==0x001F)OR(GetPixel3(bx+11, by+24+y)==0x001F)OR(GetPixel3(bx+12, by+23+y)==0x001F)OR(GetPixel3(bx+12, by+22+y)==0x001F)OR(GetPixel3(bx+13, by+24+y)==0x001F)OR(GetPixel3(bx+13, by+23+y)==0x001F)OR(GetPixel3(bx+13, by+22+y)==0x001F)OR(GetPixel3(bx+14, by+24+y)==0x001F)OR(GetPixel3(bx+14, by+23+y)==0x001F)OR(GetPixel3(bx+14, by+22+y)==0x001F)OR(GetPixel3(bx+15, by+24+y)==0x001F)OR(GetPixel3(bx+16, by+23+y)==0x001F)OR(GetPixel3(bx+17, by+22+y)==0x001F)OR(GetPixel3(bx+18, by+24+y)==0x001F)OR(GetPixel3(bx+19, by+23+y)==0x001F)OR(GetPixel3(bx+20, by+22+y)==0x001F)) 
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void rightdcol()
{
	if((GetPixel3(bx+24+x, by+22)==0x001F)OR(GetPixel3(bx+24+x, by+21)==0x001F)OR(GetPixel3(bx+24+x, by+20)==0x001F)OR(GetPixel3(bx+24+x, by+19)==0x001F)OR(GetPixel3(bx+24+x, by+18)==0x001F)OR(GetPixel3(bx+24+x, by+17)==0x001F)OR(GetPixel3(bx+24+x, by+16)==0x001F)OR(GetPixel3(bx+24+x, by+15)==0x001F)OR(GetPixel3(bx+24+x, by+14)==0x001F)OR(GetPixel3(bx+24+x, by+13)==0x001F)OR(GetPixel3(bx+24+x, by+12)==0x001F)OR(GetPixel3(bx+24+x, by+11)==0x001F)OR(GetPixel3(bx+24+x, by+10)==0x001F)OR(GetPixel3(bx+24+x, by+9)==0x001F)OR(GetPixel3(bx+24+x, by+8)==0x001F)OR(GetPixel3(bx+24+x, by+7)==0x001F)OR(GetPixel3(bx+24+x, by+6)==0x001F)OR(GetPixel3(bx+24+x, by+5)==0x001F)OR(GetPixel3(bx+24+x, by+4)==0x001F)OR(GetPixel3(bx+24+x, by+3)==0x001F)OR(GetPixel3(bx+24+x, by+2)==0x001F)OR(GetPixel3(bx+24+x, by+1)==0x001F)OR(GetPixel3(bx+23+x, by+22)==0x001F)OR(GetPixel3(bx+23+x, by+21)==0x001F)OR(GetPixel3(bx+23+x, by+20)==0x001F)OR(GetPixel3(bx+23+x, by+19)==0x001F)OR(GetPixel3(bx+23+x, by+18)==0x001F)OR(GetPixel3(bx+23+x, by+17)==0x001F)OR(GetPixel3(bx+23+x, by+16)==0x001F)OR(GetPixel3(bx+23+x, by+15)==0x001F)OR(GetPixel3(bx+23+x, by+14)==0x001F)OR(GetPixel3(bx+23+x, by+13)==0x001F)OR(GetPixel3(bx+23+x, by+12)==0x001F)OR(GetPixel3(bx+23+x, by+11)==0x001F)OR(GetPixel3(bx+23+x, by+10)==0x001F)OR(GetPixel3(bx+23+x, by+9)==0x001F)OR(GetPixel3(bx+23+x, by+8)==0x001F)OR(GetPixel3(bx+23+x, by+7)==0x001F)OR(GetPixel3(bx+23+x, by+6)==0x001F)OR(GetPixel3(bx+23+x, by+5)==0x001F)OR(GetPixel3(bx+23+x, by+4)==0x001F)OR(GetPixel3(bx+23+x, by+3)==0x001F)OR(GetPixel3(bx+23+x, by+2)==0x001F)OR(GetPixel3(bx+23+x, by+1)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void leftdcol()
{
	if((GetPixel3(bx+x, by+22)==0x001F)OR(GetPixel3(bx+x, by+21)==0x001F)OR(GetPixel3(bx+x, by+20)==0x001F)OR(GetPixel3(bx+x, by+19)==0x001F)OR(GetPixel3(bx+x, by+18)==0x001F)OR(GetPixel3(bx+x, by+17)==0x001F)OR(GetPixel3(bx+x, by+16)==0x001F)OR(GetPixel3(bx+x, by+15)==0x001F)OR(GetPixel3(bx+x, by+14)==0x001F)OR(GetPixel3(bx+x, by+13)==0x001F)OR(GetPixel3(bx+x, by+12)==0x001F)OR(GetPixel3(bx+x, by+11)==0x001F)OR(GetPixel3(bx+x, by+10)==0x001F)OR(GetPixel3(bx+x, by+9)==0x001F)OR(GetPixel3(bx+x, by+8)==0x001F)OR(GetPixel3(bx+x, by+7)==0x001F)OR(GetPixel3(bx+x, by+6)==0x001F)OR(GetPixel3(bx+x, by+5)==0x001F)OR(GetPixel3(bx+x, by+4)==0x001F)OR(GetPixel3(bx+x, by+3)==0x001F)OR(GetPixel3(bx+x, by+2)==0x001F)OR(GetPixel3(bx+x, by+1)==0x001F)OR(GetPixel3(bx+1+x, by+22)==0x001F)OR(GetPixel3(bx+1+x, by+21)==0x001F)OR(GetPixel3(bx+1+x, by+20)==0x001F)OR(GetPixel3(bx+1+x, by+19)==0x001F)OR(GetPixel3(bx+1+x, by+18)==0x001F)OR(GetPixel3(bx+1+x, by+17)==0x001F)OR(GetPixel3(bx+1+x, by+16)==0x001F)OR(GetPixel3(bx+1+x, by+15)==0x001F)OR(GetPixel3(bx+1+x, by+14)==0x001F)OR(GetPixel3(bx+1+x, by+13)==0x001F)OR(GetPixel3(bx+1+x, by+12)==0x001F)OR(GetPixel3(bx+1+x, by+11)==0x001F)OR(GetPixel3(bx+1+x, by+10)==0x001F)OR(GetPixel3(bx+1+x, by+9)==0x001F)OR(GetPixel3(bx+1+x, by+8)==0x001F)OR(GetPixel3(bx+1+x, by+7)==0x001F)OR(GetPixel3(bx+1+x, by+6)==0x001F)OR(GetPixel3(bx+1+x, by+5)==0x001F)OR(GetPixel3(bx+1+x, by+4)==0x001F)OR(GetPixel3(bx+1+x, by+3)==0x001F)OR(GetPixel3(bx+1+x, by+2)==0x001F)OR(GetPixel3(bx+1+x, by+1)==0x001F)OR(GetPixel3(bx+2+x, by+22)==0x001F)OR(GetPixel3(bx+2+x, by+21)==0x001F)OR(GetPixel3(bx+2+x, by+20)==0x001F)OR(GetPixel3(bx+2+x, by+19)==0x001F)OR(GetPixel3(bx+2+x, by+18)==0x001F)OR(GetPixel3(bx+2+x, by+17)==0x001F)OR(GetPixel3(bx+2+x, by+16)==0x001F)OR(GetPixel3(bx+2+x, by+15)==0x001F)OR(GetPixel3(bx+2+x, by+14)==0x001F)OR(GetPixel3(bx+2+x, by+13)==0x001F)OR(GetPixel3(bx+2+x, by+12)==0x001F)OR(GetPixel3(bx+2+x, by+11)==0x001F)OR(GetPixel3(bx+2+x, by+10)==0x001F)OR(GetPixel3(bx+2+x, by+9)==0x001F)OR(GetPixel3(bx+2+x, by+8)==0x001F)OR(GetPixel3(bx+2+x, by+7)==0x001F)OR(GetPixel3(bx+2+x, by+6)==0x001F)OR(GetPixel3(bx+2+x, by+5)==0x001F)OR(GetPixel3(bx+2+x, by+4)==0x001F)OR(GetPixel3(bx+2+x, by+3)==0x001F)OR(GetPixel3(bx+2+x, by+2)==0x001F)OR(GetPixel3(bx+2+x, by+1)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void topdcol()
{
	if((GetPixel3(bx+1, by)==0x001F)OR(GetPixel3(bx+2, by)==0x001F)OR(GetPixel3(bx+3, by)==0x001F)OR(GetPixel3(bx+4, by)==0x001F)OR(GetPixel3(bx+5, by)==0x001F)OR(GetPixel3(bx+6, by)==0x001F)OR(GetPixel3(bx+7, by)==0x001F)OR(GetPixel3(bx+8, by)==0x001F)OR(GetPixel3(bx+9, by)==0x001F)OR(GetPixel3(bx+10, by)==0x001F)OR(GetPixel3(bx+11, by)==0x001F)OR(GetPixel3(bx+12, by)==0x001F)OR(GetPixel3(bx+13, by)==0x001F)OR(GetPixel3(bx+14, by+9)==0x001F)OR(GetPixel3(bx+15, by+8)==0x001F)OR(GetPixel3(bx+16, by+7)==0x001F)OR(GetPixel3(bx+17, by+6)==0x001F)OR(GetPixel3(bx+18, by)==0x001F)OR(GetPixel3(bx+19, by)==0x001F)OR(GetPixel3(bx+20, by)==0x001F)OR(GetPixel3(bx+21, by)==0x001F)OR(GetPixel3(bx+22, by)==0x001F)OR(GetPixel3(bx+23, by)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

int main()
{
	Initialize();
	InitializeSprites();
	loadSpritePal((void*)allobjsPalette);
	loadSpriteGraphics((void*)allobjsData, 11904);
	initSprite(1, SIZE_32, 0);
	initSprite(2, SIZE_8, 48);
	sprites[4].attribute0 = COLOR_256 | WIDE | 240;
	sprites[4].attribute1 = SIZE_64 | 160;
	sprites[4].attribute2 = 512 + 280; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

	// set sprite offscreen, and set it up (size,etc)
	sprites[3].attribute0 = COLOR_256 | WIDE | 240;
	sprites[3].attribute1 = SIZE_32 | 160;
	sprites[3].attribute2 = 512 + 32; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

	FadeIn(2);
	drawbitmap3((void*)l47Bitmap);
	SetMode(MODE_3|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	bx=8;by=108;
	MoveSprite(&sprites[4], 0, 152);
	initsound8(1, 22050, len(jump), (void*)jump);
	initsound8(2, 22050, len(death), (void*)death);
	while(1)
	{
		WaitForVblank();
		CopyOAM();
		MoveSprite(&sprites[1], bx, by);
		MoveSprite(&sprites[2], 223, 128);
		if(gravity==0)
		{
			y+=0.24;
		}else{
			y-=0.24;
		}
		if(gravity==0)
		{
			by+=1;
		}else{
			by-=1;
		}
		if(((GetPixel3(bx+1, by+24+y)==0x64c0)OR(GetPixel3(bx+1, by+22+y)==0x64c0)OR(GetPixel3(bx+2, by+24+y)==0x64c0)OR(GetPixel3(bx+2, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+24+y)==0x64c0)OR(GetPixel3(bx+3, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+22+y)==0x64c0)OR(GetPixel3(bx+4, by+24+y)==0x64c0)OR(GetPixel3(bx+4, by+23+y)==0x64c0)OR(GetPixel3(bx+4, by+22+y)==0x64c0)OR(GetPixel3(bx+5, by+24+y)==0x64c0)OR(GetPixel3(bx+5, by+23+y)==0x64c0)OR(GetPixel3(bx+5, by+22+y)==0x64c0)OR(GetPixel3(bx+6, by+24+y)==0x64c0)OR(GetPixel3(bx+6, by+23+y)==0x64c0)OR(GetPixel3(bx+6, by+22+y)==0x64c0)OR(GetPixel3(bx+7, by+24+y)==0x64c0)OR(GetPixel3(bx+7, by+23+y)==0x64c0)OR(GetPixel3(bx+7, by+22+y)==0x64c0)OR(GetPixel3(bx+8, by+24+y)==0x64c0)OR(GetPixel3(bx+8, by+23+y)==0x64c0)OR(GetPixel3(bx+8, by+22+y)==0x64c0)OR(GetPixel3(bx+9, by+24+y)==0x64c0)OR(GetPixel3(bx+9, by+23+y)==0x64c0)OR(GetPixel3(bx+9, by+22+y)==0x64c0)OR(GetPixel3(bx+10, by+24+y)==0x64c0)OR(GetPixel3(bx+10, by+23+y)==0x64c0)OR(GetPixel3(bx+10, by+22+y)==0x64c0)OR(GetPixel3(bx+11, by+24+y)==0x64c0)OR(GetPixel3(bx+12, by+23+y)==0x64c0)OR(GetPixel3(bx+12, by+22+y)==0x64c0)OR(GetPixel3(bx+13, by+24+y)==0x64c0)OR(GetPixel3(bx+13, by+23+y)==0x64c0)OR(GetPixel3(bx+13, by+22+y)==0x64c0)OR(GetPixel3(bx+14, by+24+y)==0x64c0)OR(GetPixel3(bx+14, by+23+y)==0x64c0)OR(GetPixel3(bx+14, by+22+y)==0x64c0)OR(GetPixel3(bx+15, by+24+y)==0x64c0)OR(GetPixel3(bx+16, by+23+y)==0x64c0)OR(GetPixel3(bx+17, by+22+y)==0x64c0)OR(GetPixel3(bx+18, by+24+y)==0x64c0)OR(GetPixel3(bx+19, by+23+y)==0x64c0)OR(GetPixel3(bx+20, by+22+y)==0x64c0))AND(gravity==0))
		{
			if((keyDown(KEY_A))AND(alock==0))
			{
				REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 				REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 				REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 				REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  				REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   				REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  				REG_TM0CNT    = 0;  
				y=-3.85;
				alock=1;
				jumpt=1;
				playSoundA(1);
				sndtmr=0;
				deatht=0;
			}
		}
		if(((GetPixel3(bx+1, by+y)==0x64c0)OR(GetPixel3(bx+2, by+y)==0x64c0)OR(GetPixel3(bx+3, by+y)==0x64c0)OR(GetPixel3(bx+4, by+y)==0x64c0)OR(GetPixel3(bx+5, by+y)==0x64c0)OR(GetPixel3(bx+6, by+y)==0x64c0)OR(GetPixel3(bx+7, by+y)==0x64c0)OR(GetPixel3(bx+8, by+y)==0x64c0)OR(GetPixel3(bx+9, by+y)==0x64c0)OR(GetPixel3(bx+10, by+y)==0x64c0)OR(GetPixel3(bx+11, by+y)==0x64c0)OR(GetPixel3(bx+12, by+y)==0x64c0)OR(GetPixel3(bx+13, by+y)==0x64c0)OR(GetPixel3(bx+14, by+y+9)==0x64c0)OR(GetPixel3(bx+15, by+y+8)==0x64c0)OR(GetPixel3(bx+16, by+y+7)==0x64c0)OR(GetPixel3(bx+17, by+y+6)==0x64c0)OR(GetPixel3(bx+18, by+y)==0x64c0)OR(GetPixel3(bx+19, by+y)==0x64c0)OR(GetPixel3(bx+20, by+y)==0x64c0)OR(GetPixel3(bx+21, by+y)==0x64c0)OR(GetPixel3(bx+22, by+y)==0x64c0)OR(GetPixel3(bx+23, by+y)==0x64c0))AND(gravity==1)AND(keyDown(KEY_A))AND(alock==0))
		{
				REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 				REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 				REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 				REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  				REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   				REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  				REG_TM0CNT    = 0;  
				y=3.85;
				alock=1;
				jumpt=1;
				playSoundA(1);
				sndtmr=0;
				deatht=0;
		}
		if(gravity==0)
		{
			by-=1;
		}else{
			by+=1;
		}
		if(keyDown(KEY_LEFT))
		{
			x-=0.5;
			dir=1;
		}
		if(keyDown(KEY_RIGHT))
		{
			x+=0.5;
			dir=0;
		}
		if((dir==1)AND(NOT(x>0))AND(NOT(keyDown(KEY_LEFT))))
		{
			x+=0.08;
			if(x>0)
			{
				x=0;
			}
		}
		x=x*0.9;
		bx+=x;
		by+=y;
		if(by>136)
		{
			gravity=0;
 			REG_SOUNDCNT_H = 0;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 			REG_DM1CNT_H    = 0;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 			REG_TM0D       = 0;                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 			REG_TM0CNT     = 0;  
			bx=8;by=108;
			y=0;
			x=0;
			deatht=1;
			playSoundA(2);
			sndtmr=0;
			jumpt=0;
		}
		if(by<0)
		{
			gravity=0;
 			REG_SOUNDCNT_H = 0;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 			REG_DM1CNT_H    = 0;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 			REG_TM0D       = 0;                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 			REG_TM0CNT     = 0;  
			bx=8;by=108;
			y=0;
			x=0;
			deatht=1;
			playSoundA(2);
			sndtmr=0;
			jumpt=0;
		}
		if(bx>216)
		{
			gravity=0;
 			REG_SOUNDCNT_H = 0;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 			REG_DM1CNT_H    = 0;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 			REG_TM0D       = 0;                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 			REG_TM0CNT     = 0;  
			bx=8;by=108;
			y=0;
			x=0;
			deatht=1;
			playSoundA(2);
			sndtmr=0;
			jumpt=0;
		}
		if(bx<0)
		{
			gravity=0;
 			REG_SOUNDCNT_H = 0;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 			REG_DM1CNT_H    = 0;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 			REG_TM0D       = 0;                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 			REG_TM0CNT     = 0;  
			bx=8;by=108;
			y=0;
			x=0;
			deatht=1;
			playSoundA(2);
			sndtmr=0;
			jumpt=0;
		}
		bottomcol();
		leftcol();
		rightcol();
		topcol();
		bottomdcol();
		leftdcol();
		rightdcol();
		topdcol();
		if((keyDown(KEY_B))AND(block==0))
		{
			fb=1;
			fy=by+4;
			fx=bx;
			block=1;
		}
		if((fb==1)AND(NOT(fx>240)))
		{
			fx+=5;
			MoveSprite(&sprites[3], fx, fy);
		}
		if(NOT(keyDown(KEY_B)))
		{
			block=0;
		}
		if((keyDown(KEY_SELECT))AND(sellock==0))
		{
			gravity++;
			if(gravity==2)
			{
				gravity=0;
			}
			sellock=1;
		}
		if(NOT(keyDown(KEY_SELECT)))
		{
			sellock=0;
		}
		if(NOT(keyDown(KEY_A)))
		{
			alock=0;
		}
		if(sndtmr>((len((char*)jump))*7)AND(jumpt==1))
		{
			REG_SOUNDCNT_H = 0;                                                      //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                               //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
  			REG_DM1CNT_H    = 0;                                                    //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
   			REG_TM0D       = 0;                         //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
  			REG_TM0CNT    = 0;   
			jumpt=0;
			sndtmr=0;
		}else{
			sndtmr++;
		}
		if(sndtmr>((len((char*)death))*4.5)AND(deatht==1))
		{
 			REG_SOUNDCNT_H = 0;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
			REG_SOUNDCNT_X = 0;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 			REG_DM1SAD      = 0;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 			REG_DM1DAD      = 0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 			REG_DM1CNT_H    = 0;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 			REG_TM0D       = 0;                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 			REG_TM0CNT     = 0;  
			deatht=0;
			sndtmr=0;
		}else{
			sndtmr++;
		}
	}
	return 0;
}
