#include <agb_lib.h>
#include "allobjs.h"
#include "l61.c"
int bx,by,fx,fy,fb,g,ex=64,ed;
int ea=0;
double x,y;
int boiy,boix;
int i,alock,block,dir;

	

void bottomcol()
{
	if((GetPixel3(bx+1, by+24+y)==0x64c0)OR(GetPixel3(bx+1, by+22+y)==0x64c0)OR(GetPixel3(bx+2, by+24+y)==0x64c0)OR(GetPixel3(bx+2, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+24+y)==0x64c0)OR(GetPixel3(bx+3, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+22+y)==0x64c0)OR(GetPixel3(bx+4, by+24+y)==0x64c0)OR(GetPixel3(bx+4, by+23+y)==0x64c0)OR(GetPixel3(bx+4, by+22+y)==0x64c0)OR(GetPixel3(bx+5, by+24+y)==0x64c0)OR(GetPixel3(bx+5, by+23+y)==0x64c0)OR(GetPixel3(bx+5, by+22+y)==0x64c0)OR(GetPixel3(bx+6, by+24+y)==0x64c0)OR(GetPixel3(bx+6, by+23+y)==0x64c0)OR(GetPixel3(bx+6, by+22+y)==0x64c0)OR(GetPixel3(bx+7, by+24+y)==0x64c0)OR(GetPixel3(bx+7, by+23+y)==0x64c0)OR(GetPixel3(bx+7, by+22+y)==0x64c0)OR(GetPixel3(bx+8, by+24+y)==0x64c0)OR(GetPixel3(bx+8, by+23+y)==0x64c0)OR(GetPixel3(bx+8, by+22+y)==0x64c0)OR(GetPixel3(bx+9, by+24+y)==0x64c0)OR(GetPixel3(bx+9, by+23+y)==0x64c0)OR(GetPixel3(bx+9, by+22+y)==0x64c0)OR(GetPixel3(bx+10, by+24+y)==0x64c0)OR(GetPixel3(bx+10, by+23+y)==0x64c0)OR(GetPixel3(bx+10, by+22+y)==0x64c0)OR(GetPixel3(bx+11, by+24+y)==0x64c0)OR(GetPixel3(bx+12, by+23+y)==0x64c0)OR(GetPixel3(bx+12, by+22+y)==0x64c0)OR(GetPixel3(bx+13, by+24+y)==0x64c0)OR(GetPixel3(bx+13, by+23+y)==0x64c0)OR(GetPixel3(bx+13, by+22+y)==0x64c0)OR(GetPixel3(bx+14, by+24+y)==0x64c0)OR(GetPixel3(bx+14, by+23+y)==0x64c0)OR(GetPixel3(bx+14, by+22+y)==0x64c0)OR(GetPixel3(bx+15, by+24+y)==0x64c0)OR(GetPixel3(bx+16, by+23+y)==0x64c0)OR(GetPixel3(bx+17, by+22+y)==0x64c0)OR(GetPixel3(bx+18, by+24+y)==0x64c0)OR(GetPixel3(bx+19, by+23+y)==0x64c0)OR(GetPixel3(bx+20, by+22+y)==0x64c0)) 
	{
		by-=1;
		y=0;
	}
	if(GetPixel3(bx+21, by+23+y)==0x64c0)
	{
		by-=1;
		y=0;
	}
	if(GetPixel3(bx+22, by+24+y)==0x64c0)
	{
		by-=1;
		y=0;
	}
	if(GetPixel3(bx+24, by+24)==0x64c0)
	{
		bx-=1;
		by-=1;
		y=0;
	}
	if(GetPixel3(bx, by+24)==0x64c0)
	{
		bx+=1;
		by-=1;
		y=0;
	}
}

void rightcol()
{
	if((GetPixel3(bx+24+x, by+22)==0x64c0)OR(GetPixel3(bx+24+x, by+21)==0x64c0)OR(GetPixel3(bx+24+x, by+20)==0x64c0)OR(GetPixel3(bx+24+x, by+19)==0x64c0)OR(GetPixel3(bx+24+x, by+18)==0x64c0)OR(GetPixel3(bx+24+x, by+17)==0x64c0)OR(GetPixel3(bx+24+x, by+16)==0x64c0)OR(GetPixel3(bx+24+x, by+15)==0x64c0)OR(GetPixel3(bx+24+x, by+14)==0x64c0)OR(GetPixel3(bx+24+x, by+13)==0x64c0)OR(GetPixel3(bx+24+x, by+12)==0x64c0)OR(GetPixel3(bx+24+x, by+11)==0x64c0)OR(GetPixel3(bx+24+x, by+10)==0x64c0)OR(GetPixel3(bx+24+x, by+9)==0x64c0)OR(GetPixel3(bx+24+x, by+8)==0x64c0)OR(GetPixel3(bx+24+x, by+7)==0x64c0)OR(GetPixel3(bx+24+x, by+6)==0x64c0)OR(GetPixel3(bx+24+x, by+5)==0x64c0)OR(GetPixel3(bx+24+x, by+4)==0x64c0)OR(GetPixel3(bx+24+x, by+3)==0x64c0)OR(GetPixel3(bx+24+x, by+2)==0x64c0)OR(GetPixel3(bx+24+x, by+1)==0x64c0)OR(GetPixel3(bx+23+x, by+22)==0x64c0)OR(GetPixel3(bx+23+x, by+21)==0x64c0)OR(GetPixel3(bx+23+x, by+20)==0x64c0)OR(GetPixel3(bx+23+x, by+19)==0x64c0)OR(GetPixel3(bx+23+x, by+18)==0x64c0)OR(GetPixel3(bx+23+x, by+17)==0x64c0)OR(GetPixel3(bx+23+x, by+16)==0x64c0)OR(GetPixel3(bx+23+x, by+15)==0x64c0)OR(GetPixel3(bx+23+x, by+14)==0x64c0)OR(GetPixel3(bx+23+x, by+13)==0x64c0)OR(GetPixel3(bx+23+x, by+12)==0x64c0)OR(GetPixel3(bx+23+x, by+11)==0x64c0)OR(GetPixel3(bx+23+x, by+10)==0x64c0)OR(GetPixel3(bx+23+x, by+9)==0x64c0)OR(GetPixel3(bx+23+x, by+8)==0x64c0)OR(GetPixel3(bx+23+x, by+7)==0x64c0)OR(GetPixel3(bx+23+x, by+6)==0x64c0)OR(GetPixel3(bx+23+x, by+5)==0x64c0)OR(GetPixel3(bx+23+x, by+4)==0x64c0)OR(GetPixel3(bx+23+x, by+3)==0x64c0)OR(GetPixel3(bx+23+x, by+2)==0x64c0)OR(GetPixel3(bx+23+x, by+1)==0x64c0))
	{
			x=0;
			if((keyDown(KEY_A))AND(alock==0))	
			{
				y=-3.85;
				x=-5;
				alock=1;
			}else{
				x=0;
			}
			bx-=1;
	}
}

void leftcol()
{
	if((GetPixel3(bx+x, by+22)==0x64c0)OR(GetPixel3(bx+x, by+21)==0x64c0)OR(GetPixel3(bx+x, by+20)==0x64c0)OR(GetPixel3(bx+x, by+19)==0x64c0)OR(GetPixel3(bx+x, by+18)==0x64c0)OR(GetPixel3(bx+x, by+17)==0x64c0)OR(GetPixel3(bx+x, by+16)==0x64c0)OR(GetPixel3(bx+x, by+15)==0x64c0)OR(GetPixel3(bx+x, by+14)==0x64c0)OR(GetPixel3(bx+x, by+13)==0x64c0)OR(GetPixel3(bx+x, by+12)==0x64c0)OR(GetPixel3(bx+x, by+11)==0x64c0)OR(GetPixel3(bx+x, by+10)==0x64c0)OR(GetPixel3(bx+x, by+9)==0x64c0)OR(GetPixel3(bx+x, by+8)==0x64c0)OR(GetPixel3(bx+x, by+7)==0x64c0)OR(GetPixel3(bx+x, by+6)==0x64c0)OR(GetPixel3(bx+x, by+5)==0x64c0)OR(GetPixel3(bx+x, by+4)==0x64c0)OR(GetPixel3(bx+x, by+3)==0x64c0)OR(GetPixel3(bx+x, by+2)==0x64c0)OR(GetPixel3(bx+x, by+1)==0x64c0)OR(GetPixel3(bx+1+x, by+22)==0x64c0)OR(GetPixel3(bx+1+x, by+21)==0x64c0)OR(GetPixel3(bx+1+x, by+20)==0x64c0)OR(GetPixel3(bx+1+x, by+19)==0x64c0)OR(GetPixel3(bx+1+x, by+18)==0x64c0)OR(GetPixel3(bx+1+x, by+17)==0x64c0)OR(GetPixel3(bx+1+x, by+16)==0x64c0)OR(GetPixel3(bx+1+x, by+15)==0x64c0)OR(GetPixel3(bx+1+x, by+14)==0x64c0)OR(GetPixel3(bx+1+x, by+13)==0x64c0)OR(GetPixel3(bx+1+x, by+12)==0x64c0)OR(GetPixel3(bx+1+x, by+11)==0x64c0)OR(GetPixel3(bx+1+x, by+10)==0x64c0)OR(GetPixel3(bx+1+x, by+9)==0x64c0)OR(GetPixel3(bx+1+x, by+8)==0x64c0)OR(GetPixel3(bx+1+x, by+7)==0x64c0)OR(GetPixel3(bx+1+x, by+6)==0x64c0)OR(GetPixel3(bx+1+x, by+5)==0x64c0)OR(GetPixel3(bx+1+x, by+4)==0x64c0)OR(GetPixel3(bx+1+x, by+3)==0x64c0)OR(GetPixel3(bx+1+x, by+2)==0x64c0)OR(GetPixel3(bx+1+x, by+1)==0x64c0)OR(GetPixel3(bx+2+x, by+22)==0x64c0)OR(GetPixel3(bx+2+x, by+21)==0x64c0)OR(GetPixel3(bx+2+x, by+20)==0x64c0)OR(GetPixel3(bx+2+x, by+19)==0x64c0)OR(GetPixel3(bx+2+x, by+18)==0x64c0)OR(GetPixel3(bx+2+x, by+17)==0x64c0)OR(GetPixel3(bx+2+x, by+16)==0x64c0)OR(GetPixel3(bx+2+x, by+15)==0x64c0)OR(GetPixel3(bx+2+x, by+14)==0x64c0)OR(GetPixel3(bx+2+x, by+13)==0x64c0)OR(GetPixel3(bx+2+x, by+12)==0x64c0)OR(GetPixel3(bx+2+x, by+11)==0x64c0)OR(GetPixel3(bx+2+x, by+10)==0x64c0)OR(GetPixel3(bx+2+x, by+9)==0x64c0)OR(GetPixel3(bx+2+x, by+8)==0x64c0)OR(GetPixel3(bx+2+x, by+7)==0x64c0)OR(GetPixel3(bx+2+x, by+6)==0x64c0)OR(GetPixel3(bx+2+x, by+5)==0x64c0)OR(GetPixel3(bx+2+x, by+4)==0x64c0)OR(GetPixel3(bx+2+x, by+3)==0x64c0)OR(GetPixel3(bx+2+x, by+2)==0x64c0)OR(GetPixel3(bx+2+x, by+1)==0x64c0))
	{
			x=0;
			if((keyDown(KEY_A))AND(alock==0))	
			{
				y=-3.85;
				x=5;
				alock=1;
			}else{
				x=0;
			}
			bx+=1;
	}
}

void topcol()
{
	if((GetPixel3(bx+1, by)==0x64c0)OR(GetPixel3(bx+2, by)==0x64c0)OR(GetPixel3(bx+3, by)==0x64c0)OR(GetPixel3(bx+4, by)==0x64c0)OR(GetPixel3(bx+5, by)==0x64c0)OR(GetPixel3(bx+6, by)==0x64c0)OR(GetPixel3(bx+7, by)==0x64c0)OR(GetPixel3(bx+8, by)==0x64c0)OR(GetPixel3(bx+9, by)==0x64c0)OR(GetPixel3(bx+10, by)==0x64c0)OR(GetPixel3(bx+11, by)==0x64c0)OR(GetPixel3(bx+12, by)==0x64c0)OR(GetPixel3(bx+13, by)==0x64c0)OR(GetPixel3(bx+14, by+9)==0x64c0)OR(GetPixel3(bx+15, by+8)==0x64c0)OR(GetPixel3(bx+16, by+7)==0x64c0)OR(GetPixel3(bx+17, by+6)==0x64c0)OR(GetPixel3(bx+18, by)==0x64c0)OR(GetPixel3(bx+19, by)==0x64c0)OR(GetPixel3(bx+20, by)==0x64c0)OR(GetPixel3(bx+21, by)==0x64c0)OR(GetPixel3(bx+22, by)==0x64c0)OR(GetPixel3(bx+23, by)==0x64c0))
	{
		by+=3;
		by-=y;
		y=0;
		y+=0.24;
		MoveSprite(&sprites[1], bx, by);
	}
}

void bottomdcol()
{
	if((GetPixel3(bx+1, by+24+y)==0x001F)OR(GetPixel3(bx+1, by+22+y)==0x001F)OR(GetPixel3(bx+2, by+24+y)==0x001F)OR(GetPixel3(bx+2, by+23+y)==0x001F)OR(GetPixel3(bx+3, by+24+y)==0x001F)OR(GetPixel3(bx+3, by+23+y)==0x001F)OR(GetPixel3(bx+3, by+22+y)==0x001F)OR(GetPixel3(bx+4, by+24+y)==0x001F)OR(GetPixel3(bx+4, by+23+y)==0x001F)OR(GetPixel3(bx+4, by+22+y)==0x001F)OR(GetPixel3(bx+5, by+24+y)==0x001F)OR(GetPixel3(bx+5, by+23+y)==0x001F)OR(GetPixel3(bx+5, by+22+y)==0x001F)OR(GetPixel3(bx+6, by+24+y)==0x001F)OR(GetPixel3(bx+6, by+23+y)==0x001F)OR(GetPixel3(bx+6, by+22+y)==0x001F)OR(GetPixel3(bx+7, by+24+y)==0x001F)OR(GetPixel3(bx+7, by+23+y)==0x001F)OR(GetPixel3(bx+7, by+22+y)==0x001F)OR(GetPixel3(bx+8, by+24+y)==0x001F)OR(GetPixel3(bx+8, by+23+y)==0x001F)OR(GetPixel3(bx+8, by+22+y)==0x001F)OR(GetPixel3(bx+9, by+24+y)==0x001F)OR(GetPixel3(bx+9, by+23+y)==0x001F)OR(GetPixel3(bx+9, by+22+y)==0x001F)OR(GetPixel3(bx+10, by+24+y)==0x001F)OR(GetPixel3(bx+10, by+23+y)==0x001F)OR(GetPixel3(bx+10, by+22+y)==0x001F)OR(GetPixel3(bx+11, by+24+y)==0x001F)OR(GetPixel3(bx+12, by+23+y)==0x001F)OR(GetPixel3(bx+12, by+22+y)==0x001F)OR(GetPixel3(bx+13, by+24+y)==0x001F)OR(GetPixel3(bx+13, by+23+y)==0x001F)OR(GetPixel3(bx+13, by+22+y)==0x001F)OR(GetPixel3(bx+14, by+24+y)==0x001F)OR(GetPixel3(bx+14, by+23+y)==0x001F)OR(GetPixel3(bx+14, by+22+y)==0x001F)OR(GetPixel3(bx+15, by+24+y)==0x001F)OR(GetPixel3(bx+16, by+23+y)==0x001F)OR(GetPixel3(bx+17, by+22+y)==0x001F)OR(GetPixel3(bx+18, by+24+y)==0x001F)OR(GetPixel3(bx+19, by+23+y)==0x001F)OR(GetPixel3(bx+20, by+22+y)==0x001F)) 
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void rightdcol()
{
	if((GetPixel3(bx+24+x, by+22)==0x001F)OR(GetPixel3(bx+24+x, by+21)==0x001F)OR(GetPixel3(bx+24+x, by+20)==0x001F)OR(GetPixel3(bx+24+x, by+19)==0x001F)OR(GetPixel3(bx+24+x, by+18)==0x001F)OR(GetPixel3(bx+24+x, by+17)==0x001F)OR(GetPixel3(bx+24+x, by+16)==0x001F)OR(GetPixel3(bx+24+x, by+15)==0x001F)OR(GetPixel3(bx+24+x, by+14)==0x001F)OR(GetPixel3(bx+24+x, by+13)==0x001F)OR(GetPixel3(bx+24+x, by+12)==0x001F)OR(GetPixel3(bx+24+x, by+11)==0x001F)OR(GetPixel3(bx+24+x, by+10)==0x001F)OR(GetPixel3(bx+24+x, by+9)==0x001F)OR(GetPixel3(bx+24+x, by+8)==0x001F)OR(GetPixel3(bx+24+x, by+7)==0x001F)OR(GetPixel3(bx+24+x, by+6)==0x001F)OR(GetPixel3(bx+24+x, by+5)==0x001F)OR(GetPixel3(bx+24+x, by+4)==0x001F)OR(GetPixel3(bx+24+x, by+3)==0x001F)OR(GetPixel3(bx+24+x, by+2)==0x001F)OR(GetPixel3(bx+24+x, by+1)==0x001F)OR(GetPixel3(bx+23+x, by+22)==0x001F)OR(GetPixel3(bx+23+x, by+21)==0x001F)OR(GetPixel3(bx+23+x, by+20)==0x001F)OR(GetPixel3(bx+23+x, by+19)==0x001F)OR(GetPixel3(bx+23+x, by+18)==0x001F)OR(GetPixel3(bx+23+x, by+17)==0x001F)OR(GetPixel3(bx+23+x, by+16)==0x001F)OR(GetPixel3(bx+23+x, by+15)==0x001F)OR(GetPixel3(bx+23+x, by+14)==0x001F)OR(GetPixel3(bx+23+x, by+13)==0x001F)OR(GetPixel3(bx+23+x, by+12)==0x001F)OR(GetPixel3(bx+23+x, by+11)==0x001F)OR(GetPixel3(bx+23+x, by+10)==0x001F)OR(GetPixel3(bx+23+x, by+9)==0x001F)OR(GetPixel3(bx+23+x, by+8)==0x001F)OR(GetPixel3(bx+23+x, by+7)==0x001F)OR(GetPixel3(bx+23+x, by+6)==0x001F)OR(GetPixel3(bx+23+x, by+5)==0x001F)OR(GetPixel3(bx+23+x, by+4)==0x001F)OR(GetPixel3(bx+23+x, by+3)==0x001F)OR(GetPixel3(bx+23+x, by+2)==0x001F)OR(GetPixel3(bx+23+x, by+1)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void leftdcol()
{
	if((GetPixel3(bx+x, by+22)==0x001F)OR(GetPixel3(bx+x, by+21)==0x001F)OR(GetPixel3(bx+x, by+20)==0x001F)OR(GetPixel3(bx+x, by+19)==0x001F)OR(GetPixel3(bx+x, by+18)==0x001F)OR(GetPixel3(bx+x, by+17)==0x001F)OR(GetPixel3(bx+x, by+16)==0x001F)OR(GetPixel3(bx+x, by+15)==0x001F)OR(GetPixel3(bx+x, by+14)==0x001F)OR(GetPixel3(bx+x, by+13)==0x001F)OR(GetPixel3(bx+x, by+12)==0x001F)OR(GetPixel3(bx+x, by+11)==0x001F)OR(GetPixel3(bx+x, by+10)==0x001F)OR(GetPixel3(bx+x, by+9)==0x001F)OR(GetPixel3(bx+x, by+8)==0x001F)OR(GetPixel3(bx+x, by+7)==0x001F)OR(GetPixel3(bx+x, by+6)==0x001F)OR(GetPixel3(bx+x, by+5)==0x001F)OR(GetPixel3(bx+x, by+4)==0x001F)OR(GetPixel3(bx+x, by+3)==0x001F)OR(GetPixel3(bx+x, by+2)==0x001F)OR(GetPixel3(bx+x, by+1)==0x001F)OR(GetPixel3(bx+1+x, by+22)==0x001F)OR(GetPixel3(bx+1+x, by+21)==0x001F)OR(GetPixel3(bx+1+x, by+20)==0x001F)OR(GetPixel3(bx+1+x, by+19)==0x001F)OR(GetPixel3(bx+1+x, by+18)==0x001F)OR(GetPixel3(bx+1+x, by+17)==0x001F)OR(GetPixel3(bx+1+x, by+16)==0x001F)OR(GetPixel3(bx+1+x, by+15)==0x001F)OR(GetPixel3(bx+1+x, by+14)==0x001F)OR(GetPixel3(bx+1+x, by+13)==0x001F)OR(GetPixel3(bx+1+x, by+12)==0x001F)OR(GetPixel3(bx+1+x, by+11)==0x001F)OR(GetPixel3(bx+1+x, by+10)==0x001F)OR(GetPixel3(bx+1+x, by+9)==0x001F)OR(GetPixel3(bx+1+x, by+8)==0x001F)OR(GetPixel3(bx+1+x, by+7)==0x001F)OR(GetPixel3(bx+1+x, by+6)==0x001F)OR(GetPixel3(bx+1+x, by+5)==0x001F)OR(GetPixel3(bx+1+x, by+4)==0x001F)OR(GetPixel3(bx+1+x, by+3)==0x001F)OR(GetPixel3(bx+1+x, by+2)==0x001F)OR(GetPixel3(bx+1+x, by+1)==0x001F)OR(GetPixel3(bx+2+x, by+22)==0x001F)OR(GetPixel3(bx+2+x, by+21)==0x001F)OR(GetPixel3(bx+2+x, by+20)==0x001F)OR(GetPixel3(bx+2+x, by+19)==0x001F)OR(GetPixel3(bx+2+x, by+18)==0x001F)OR(GetPixel3(bx+2+x, by+17)==0x001F)OR(GetPixel3(bx+2+x, by+16)==0x001F)OR(GetPixel3(bx+2+x, by+15)==0x001F)OR(GetPixel3(bx+2+x, by+14)==0x001F)OR(GetPixel3(bx+2+x, by+13)==0x001F)OR(GetPixel3(bx+2+x, by+12)==0x001F)OR(GetPixel3(bx+2+x, by+11)==0x001F)OR(GetPixel3(bx+2+x, by+10)==0x001F)OR(GetPixel3(bx+2+x, by+9)==0x001F)OR(GetPixel3(bx+2+x, by+8)==0x001F)OR(GetPixel3(bx+2+x, by+7)==0x001F)OR(GetPixel3(bx+2+x, by+6)==0x001F)OR(GetPixel3(bx+2+x, by+5)==0x001F)OR(GetPixel3(bx+2+x, by+4)==0x001F)OR(GetPixel3(bx+2+x, by+3)==0x001F)OR(GetPixel3(bx+2+x, by+2)==0x001F)OR(GetPixel3(bx+2+x, by+1)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

void topdcol()
{
	if((GetPixel3(bx+1, by)==0x001F)OR(GetPixel3(bx+2, by)==0x001F)OR(GetPixel3(bx+3, by)==0x001F)OR(GetPixel3(bx+4, by)==0x001F)OR(GetPixel3(bx+5, by)==0x001F)OR(GetPixel3(bx+6, by)==0x001F)OR(GetPixel3(bx+7, by)==0x001F)OR(GetPixel3(bx+8, by)==0x001F)OR(GetPixel3(bx+9, by)==0x001F)OR(GetPixel3(bx+10, by)==0x001F)OR(GetPixel3(bx+11, by)==0x001F)OR(GetPixel3(bx+12, by)==0x001F)OR(GetPixel3(bx+13, by)==0x001F)OR(GetPixel3(bx+14, by+9)==0x001F)OR(GetPixel3(bx+15, by+8)==0x001F)OR(GetPixel3(bx+16, by+7)==0x001F)OR(GetPixel3(bx+17, by+6)==0x001F)OR(GetPixel3(bx+18, by)==0x001F)OR(GetPixel3(bx+19, by)==0x001F)OR(GetPixel3(bx+20, by)==0x001F)OR(GetPixel3(bx+21, by)==0x001F)OR(GetPixel3(bx+22, by)==0x001F)OR(GetPixel3(bx+23, by)==0x001F))
	{
			bx=8;by=108;
			y=0;
			x=0;
	}
}

int main()
{
	Initialize();
	InitializeSprites();
	loadSpritePal((void*)allobjsPalette);
	loadSpriteGraphics((void*)allobjsData, 11904);
	initSprite(1, SIZE_32, 0);
	initSprite(2, SIZE_8, 48);

	sprites[5].attribute0 = COLOR_256 | SQUARE | 240;
	sprites[5].attribute1 = SIZE_64 | 160;
	sprites[5].attribute2 = 512 + 360; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

	sprites[4].attribute0 = COLOR_256 | WIDE | 240;
	sprites[4].attribute1 = SIZE_64 | 160;
	sprites[4].attribute2 = 512 + 280; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd

	// set sprite offscreen, and set it up (size,etc)
	sprites[3].attribute0 = COLOR_256 | WIDE | 240;
	sprites[3].attribute1 = SIZE_32 | 160;
	sprites[3].attribute2 = 512 + 32; // NOTE: mode4 doesn't support the first tiles, so offset of 512 is requirerd
	FadeIn(2);
	drawbitmap3((void*)l61Bitmap);
	SetMode(MODE_3|BG2_ENABLE|OBJ_MAP_1D|OBJ_ENABLE);
	bx=8;by=108;
	MoveSprite(&sprites[4], 0, 152);
	MoveSprite(&sprites[5], 64, 81);
	fx=0;
	fy=0;
	ex=64;
	while(1)
	{
		SleepF(0.75);
		WaitForVblank();
		CopyOAM();
		MoveSprite(&sprites[1], bx, by);
		MoveSprite(&sprites[2], 223, 128);
		y+=0.24;
		by+=1;
				if(((GetPixel3(bx+1, by+24+y)==0x64c0)OR(GetPixel3(bx+1, by+22+y)==0x64c0)OR(GetPixel3(bx+2, by+24+y)==0x64c0)OR(GetPixel3(bx+2, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+24+y)==0x64c0)OR(GetPixel3(bx+3, by+23+y)==0x64c0)OR(GetPixel3(bx+3, by+22+y)==0x64c0)OR(GetPixel3(bx+4, by+24+y)==0x64c0)OR(GetPixel3(bx+4, by+23+y)==0x64c0)OR(GetPixel3(bx+4, by+22+y)==0x64c0)OR(GetPixel3(bx+5, by+24+y)==0x64c0)OR(GetPixel3(bx+5, by+23+y)==0x64c0)OR(GetPixel3(bx+5, by+22+y)==0x64c0)OR(GetPixel3(bx+6, by+24+y)==0x64c0)OR(GetPixel3(bx+6, by+23+y)==0x64c0)OR(GetPixel3(bx+6, by+22+y)==0x64c0)OR(GetPixel3(bx+7, by+24+y)==0x64c0)OR(GetPixel3(bx+7, by+23+y)==0x64c0)OR(GetPixel3(bx+7, by+22+y)==0x64c0)OR(GetPixel3(bx+8, by+24+y)==0x64c0)OR(GetPixel3(bx+8, by+23+y)==0x64c0)OR(GetPixel3(bx+8, by+22+y)==0x64c0)OR(GetPixel3(bx+9, by+24+y)==0x64c0)OR(GetPixel3(bx+9, by+23+y)==0x64c0)OR(GetPixel3(bx+9, by+22+y)==0x64c0)OR(GetPixel3(bx+10, by+24+y)==0x64c0)OR(GetPixel3(bx+10, by+23+y)==0x64c0)OR(GetPixel3(bx+10, by+22+y)==0x64c0)OR(GetPixel3(bx+11, by+24+y)==0x64c0)OR(GetPixel3(bx+12, by+23+y)==0x64c0)OR(GetPixel3(bx+12, by+22+y)==0x64c0)OR(GetPixel3(bx+13, by+24+y)==0x64c0)OR(GetPixel3(bx+13, by+23+y)==0x64c0)OR(GetPixel3(bx+13, by+22+y)==0x64c0)OR(GetPixel3(bx+14, by+24+y)==0x64c0)OR(GetPixel3(bx+14, by+23+y)==0x64c0)OR(GetPixel3(bx+14, by+22+y)==0x64c0)OR(GetPixel3(bx+15, by+24+y)==0x64c0)OR(GetPixel3(bx+16, by+23+y)==0x64c0)OR(GetPixel3(bx+17, by+22+y)==0x64c0)OR(GetPixel3(bx+18, by+24+y)==0x64c0)OR(GetPixel3(bx+19, by+23+y)==0x64c0)OR(GetPixel3(bx+20, by+22+y)==0x64c0)))
		{
			if((keyDown(KEY_A))AND(alock==0))
			{
				y=-3.85;
				alock=1;
			}
		}
		by-=1;
		if(keyDown(KEY_LEFT))
		{
			x-=0.5;
			dir=1;
		}
		if(keyDown(KEY_RIGHT))
		{
			x+=0.5;
			dir=0;
		}
		x*=0.9;
		if((dir==1)AND(NOT(x>0))AND(NOT(keyDown(KEY_LEFT))))
		{
			x+=0.08;
			if(x>0)
			{
				x=0;
			}
		}
		bx+=x;
		by+=y;
		if(by>136)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if(by<0)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if(bx>216)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if(bx<0)
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		bottomcol();
		leftcol();
		rightcol();
		topcol();
		bottomdcol();
		leftdcol();
		rightdcol();
		topdcol();
		if((keyDown(KEY_B))AND(block==0))
		{
			fb=1;
			fy=by+4;
			fx=bx;
			block=1;
		}
		if((fb==1)AND(NOT(fx>240)))
		{
			fx+=5;
			MoveSprite(&sprites[3], fx, fy);
		}
		if((ed==1)AND(ea==0))
		{
			sprites[5].attribute1 = SIZE_64 | 160;
			MoveSprite(&sprites[5], ex, 81);
			if(NOT(ex<64))
			{
				ex-=3;
			}else{
				ed=0;
			}
		}else if(ea==0){
			sprites[5].attribute1 = SIZE_64 | HORIZONTAL_FLIP | 160;
			MoveSprite(&sprites[5], ex, 81);
			if(NOT(ex>160))
			{
				ex+=3;
			}else{
				ed=1;
			}
		}
		if((bx>ex-24)AND(ea==0))
		{
			bx=8;by=108;
			y=0;
			x=0;
		}
		if((fx>ex-32)AND(NOT(ea==1)))
		{
			fb=0;
			ea=1;
			MoveSprite(&sprites[3], 240, 160);
			MoveSprite(&sprites[5], 240, 160);
		}
		if(NOT(keyDown(KEY_A)))
		{
			alock=0;
		}
		if(NOT(keyDown(KEY_B)))
		{
			block=0;
		}
	}
	return 0;
}
