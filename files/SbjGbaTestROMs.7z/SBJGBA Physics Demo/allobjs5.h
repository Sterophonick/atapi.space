
//{{BLOCK(allobjs5)

//======================================================================
//
//	allobjs5, 32x744@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 23808 = 24320
//
//	Time-stamp: 2016-12-15, 16:14:01
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ALLOBJS5_H
#define GRIT_ALLOBJS5_H

#define allobjs5BitmapLen 23808
extern const unsigned short allobjs5Bitmap[11904];

#define allobjs5PalLen 512
extern const unsigned short allobjs5Pal[256];

#endif // GRIT_ALLOBJS5_H

//}}BLOCK(allobjs5)
