#include <iostream>
#include <windows.h>
#include <cstdio>
#include <fstream>
#include <string>
char command[1024];
int i;

int main(int argc, char* argv[])
{
	for(i=0;i=(sizeof(argv));i++)
	{
		command[i]=argv[i];
	}
	command = sprintf(command, "MakeROMGBA (C)");
	system(command);
	system("pause");
	return 0;
}
