// Transgender Sizecode Test
// Author: Atapi/Sterophonick
// Date: April 28, 2025

.gba
.open "sizecode.gba",0x8000000 //this could be a blank file
.org 0x8000000

.arm

_start:
	b	rom_header_end

	.fill  156,0			// Nintendo Logo Character Data (8000004h)
    .byte   0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
    .byte   0x00,0x00,0x00,0x00
	.byte   0x30,0x31		// Maker Code (80000B0h)
	.byte   0x96			// Fixed Value (80000B2h)
	.byte   0x00			// Main Unit Code (80000B3h)
	.byte   0x00			// Device Type (80000B4h)
	.byte   0x00,0x00,0x00,0x00,0x00,0x00,0x00
	.byte	0x00			// Software Version No (80000BCh)
	.byte	0xf0			// Complement Check (80000BDh)
	.byte	0x00,0x00    		// Checksum (80000BEh)

// 0x7F2B,0x5EBE,0x7FFF,
// blue, pink ,white

perfFill:
    mov r4,r2
_loop:
    cmp r4,r3
    beq _loopEnd

    strh r1,[r0,r4]
    add r4,#2

    b _loop
_loopEnd:
    bx lr

rom_header_end:
    // m3bg2
    ldr r0,=#0x4000000
    ldr r1,=#0x403
    strh r1,[r0]

    ldr r0,=#0x6000000
    ldr r1,=#0x7F2B
    mov r2,#0
    ldr r3,=#7680*2
    bl perfFill

    ldr r1,=#0x5EBe
    mov r2,#7680*2
    ldr r3,=#7680*2*2
    bl perfFill

    ldr r1,=#0x7FFF
    mov r2,#7680*4
    ldr r3,=#7680*6
    bl perfFill

    ldr r1,=#0x5EBe
    mov r2,#7680*6
    ldr r3,=#7680*8
    bl perfFill

    ldr r1,=#0x7F2B
    mov r2,#7680*8
    ldr r3,=#7680*10
    bl perfFill

forever: b forever

.pool
