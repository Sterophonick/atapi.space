
b8 Menu_Main_RequestReloadLinePos;
b8 Menu_Main_RequestReloadFont;
b8 Menu_Main_RequestReloadLineSpace;
b8 Menu_Main_RequestReloadKeyRepeatTime;
b8 Menu_Main_RequestReloadLineTab;

void BG1Fade0(void)
{
  return;
  REG_BLDMOD=BLEND_TOP_BG1 | BLEND_LOW_BG0 | BLEND_MODE_ALPHA;
  REG_COLEV=BLEND_BALANCE(0);
}

void BG1Fade1(void)
{
  return;
  REG_BLDMOD=BLEND_TOP_BG1 | BLEND_LOW_BG0 | BLEND_MODE_ALPHA;
  REG_COLEV=BLEND_BALANCE(16);
}

void BG1FadeIn(void)
{
  return;
  REG_BLDMOD=BLEND_TOP_BG1 | BLEND_LOW_BG0 | BLEND_MODE_ALPHA;
  u32 cnt;
  for(cnt=0;cnt<15;cnt+=2){
    REG_COLEV=BLEND_BALANCE(cnt);
    WaitForVsync();
  }
  REG_COLEV=BLEND_BALANCE(16);
}

void BG1FadeOut(void)
{
  return;
  REG_BLDMOD=BLEND_TOP_BG1 | BLEND_LOW_BG0 | BLEND_MODE_ALPHA;
  u32 cnt;
  for(cnt=16;cnt>1;cnt-=2){
    REG_COLEV=BLEND_BALANCE(cnt);
    WaitForVsync();
  }
  REG_COLEV=BLEND_BALANCE(0);
}

u32 DialogSizeX;
u32 DialogStrCount;
u8 *DialogStr[16];

void ShowDialog(u32 SoundIndex)
{
  TFontPack *BackupFontPack=FontPack;
  
  FontPack_Select(0);
  
  u32 wx,wy,ww,wh;
  u32 winx,winy,winw,winh;
  
  winw=DialogSizeX*5+8;
  winh=(DialogStrCount+0)*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  ww=winw-8;
  wh=winh-8;
  
  BG1Fade0();
  
  FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
  
  u32 cnt;
  for(cnt=0;cnt<DialogStrCount;cnt++){
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(cnt*10),DialogStr[cnt]);
  }
  
  PlaySound(SoundIndex);
  BG1FadeIn();
  
  IconStart(wx+ww-32,wy+wh-32);
  while((*KEYS)!=0x3ff){
    IconNext();
    while (*(volatile u16*)0x4000006 >= 160) {};
    while (*(volatile u16*)0x4000006 < 160) {};
  }
  while((*KEYS)==0x3ff){
    IconNext();
    while (*(volatile u16*)0x4000006 >= 160) {};
    while (*(volatile u16*)0x4000006 < 160) {};
  }
  IconEnd();
  
  BG1FadeOut();
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  BG1Fade1();
  
  FontPack=BackupFontPack;
  
  while((*KEYS)!=0x3ff);
}

b8 ShowDialog_AorNotA(u32 SoundIndex)
{
  TFontPack *BackupFontPack=FontPack;
  
  FontPack_Select(0);
  
  u32 wx,wy,ww,wh;
  u32 winx,winy,winw,winh;
  
  winw=DialogSizeX*5+8;
  winh=(DialogStrCount+0)*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  ww=winw-8;
  wh=winh-8;
  
  FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
  
  u32 cnt;
  for(cnt=0;cnt<DialogStrCount;cnt++){
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(cnt*10),DialogStr[cnt]);
  }
  
  PlaySound(SoundIndex);
  
  u32 NowKey;
  
  while((*KEYS)!=0x3ff);
  NowKey=0;
  while(NowKey==0){
    NowKey=(~*KEYS)&0x3ff;
    if(NowKey==0) WaitForVsync();
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  FontPack=BackupFontPack;

  if(NowKey==KEY_A){
    return(True);
    }else{
    return(False);
  }
}

void Menu_BootDialog(void)
{
  DialogSizeX=32;
  DialogStrCount=5;
  DialogStr[ 0]="TextViewer Ver0.14 [PTXV]";
  DialogStr[ 1]="PogoShell2 Plugin";
  DialogStr[ 2]="";
  DialogStr[ 3]="�Z���N�g�{�^���ŊȈՃw���v";
  DialogStr[ 4]="��\\�����܂��B";
  
  ShowDialog(ISE_FirstBoot);
}

void Menu_HelpDialog(void)
{
  DialogSizeX=32;
  DialogStrCount=8;
  DialogStr[ 0]="�ȈՃw���v [PTXV]";
  DialogStr[ 1]="";
  switch(SRAM_Read32(&SRAM->ReturnPogoShellKeys)){
    case 0:
      DialogStr[ 2]="��/A/��/B �s����/�s�߂�";
      DialogStr[ 3]="��/�� �y�[�W����/�y�[�W�߂�";
      DialogStr[ 4]="L+R PogoShell�ɖ߂�";
      break;
    case 1:
      DialogStr[ 2]="��/�� �s����/�s�߂�";
      DialogStr[ 3]="��/�� �y�[�W����/�y�[�W�߂�";
      DialogStr[ 4]="A+B PogoShell�ɖ߂�";
      break;
    case 2:
      DialogStr[ 2]="A/B �s����/�s�߂�";
      DialogStr[ 3]="R+A/R+B �y�[�W����/�y�[�W�߂�";
      DialogStr[ 4]="L+�����L�[ PogoShell�ɖ߂�";
      break;
  }
  DialogStr[ 5]="";
  DialogStr[ 6]="�X�^�[�g�{�^���ŁA";
  DialogStr[ 7]="���j���[���J���܂��B";
  
  ShowDialog(ISE_DialogInfo);
}

b8 Menu_AutoLoad_ClearDialog();

void Menu_AutoLoad(void)
{
  b8 snd=SRAM_Read32(&SRAM->se_Enabled[ISE_FirstBoot]);
  
  Menu_Main_RequestReloadLinePos=False;
  Menu_Main_RequestReloadFont=False;
  Menu_Main_RequestReloadLineSpace=False;
  Menu_Main_RequestReloadKeyRepeatTime=False;
  Menu_Main_RequestReloadLineTab=False;
  
  TFontPack *BackupFontPack=FontPack;
  FontPack_Select(0);
  
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  
  winw=32*5+8;
  winh=4*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  b8 Startup;
  
  BG1Fade0();
  
  Startup=True;
  
  while(ExitFlag==False){
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�d����؂�����Ԃ𕜌����܂����H");
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(2*10),"�`�{�^�������[�h����");
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(3*10),"�a�{�^�����擪����\\������");
    
    if(Startup==True){
      if(snd==True) PlaySound(ISE_DialogQuestion);
      Startup=False;
      BG1FadeIn();
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==(KEY_R|KEY_L)) ReturnPogoShell2();
    if(NowKey==KEY_A){
      if(snd==True) PlaySound(ISE_MenuSuccess);
      Menu_Main_RequestReloadLinePos=True;
      ExitFlag=True;
    }
    if(NowKey==KEY_B){
      ExitFlag=Menu_AutoLoad_ClearDialog();
    }
  }
  
  BG1FadeOut();
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  BG1Fade1();
  
  FontPack=BackupFontPack;
  
  while((*KEYS)!=0x3ff);
}

b8 Menu_AutoLoad_ClearDialog(void)
{
  b8 snd=SRAM_Read32(&SRAM->se_Enabled[ISE_FirstBoot]);
  u32 sndidx=ISE_Null;
  
  DialogSizeX=32;
  DialogStrCount=4;
  DialogStr[ 0]="�擪�ɖ߂��Ă����ł����H";
  DialogStr[ 1]="";
  DialogStr[ 2]="�`�{�^�����擪����\\������";
  DialogStr[ 3]="�`�{�^���ȊO�����j���[�ɖ߂�";
  
  if(snd==True) sndidx=ISE_DialogWarrning;
  if(ShowDialog_AorNotA(sndidx)==True){
    if(snd==True) PlaySound(ISE_MenuCancel);
    SRAM_Write32(&SRAM_CurrentState->LastPosition,0);
    return(True);
    }else{
    if(snd==True) PlaySound(ISE_DialogQuestion);
    return(False);
  }
}

void Menu_MainHidePanel(void)
{
  FontData_BGCHRFill(BGCHR1,0,160-11,240,1,0);
  FontData_BGCHRFill(BGCHR1,0,160-10,240,10,0);
}

void Menu_MainShowPanel(void)
{
  FontData_BGCHRFill(BGCHR1,0,160-11,240,1,9);
  FontData_BGCHRFill(BGCHR1,0,160-10,240,10,1);
  
  BG1_putpixel4(0,160-10-1,0x0000);
  BG1_putpixel4(0,160-10+0,0x8900);
  BG1_putpixel4(0,160-10+1,0x1190);
  BG1_putpixel4(0,160-10+2,0x1119);
  BG1_putpixel4(0,160-10+3,0x1119);
  
  BG1_putpixel4(240-4,160-10-1,0x0000);
  BG1_putpixel4(240-4,160-10+0,0x0098);
  BG1_putpixel4(240-4,160-10+1,0x0911);
  BG1_putpixel4(240-4,160-10+2,0x9111);
  BG1_putpixel4(240-4,160-10+3,0x9111);

  FontData_BGCHRDrawText(BGCHR1,4,160-10,"�k/�q=���j���[�ړ� �`=���� �a=����");
}

u32 CurrentMenu=0;
u32 MenuMax=7;

b8 Menu_MainLoad(void);
b8 Menu_MainSave(void);
b8 Menu_MainDelete(void);
b8 Menu_MainSelFont(void);
b8 Menu_MainOption(void);
b8 Menu_MainSound(void);
b8 Menu_MainDebug(void);

void Menu_Main(void)
{
  Menu_Main_RequestReloadLinePos=False;
  Menu_Main_RequestReloadFont=False;
  Menu_Main_RequestReloadLineSpace=False;
  Menu_Main_RequestReloadKeyRepeatTime=False;
  Menu_Main_RequestReloadLineTab=False;
  
  TFontPack *BackupFontPack=FontPack;
  FontPack_Select(0);
  
  CurrentMenu=SRAM_Read32(&SRAM->MenuLastPage);
  
  b8 ExitFlag=False;
  
  BG1Fade1();
  Menu_MainShowPanel();
  
  FontData_BGCHRFill(BGCHR1,0,0,240,10,Color_FlameBG);
  FontData_BGCHRFill(BGCHR1,0,10,240,1,Color_FlameBright);
  FontData_BGCHRFill(BGCHR1,0,11,240,1,Color_FlameMask);
  
  u32 xpos[7];
  xpos[0]=0;
  xpos[1]=xpos[0]+7;
  xpos[2]=xpos[1]+7;
  xpos[3]=xpos[2]+6;
  xpos[4]=xpos[3]+7;
  xpos[5]=xpos[4]+6;
  xpos[6]=xpos[5]+7;
  
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[0])*5),0,"LOAD");
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[1])*5),0,"SAVE");
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[2])*5),0,"DEL");
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[3])*5),0,"FONT");
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[4])*5),0,"OPT");
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[5])*5),0,"SND");
  FontData_BGCHRDrawText(BGCHR1,5+((2+xpos[6])*5),0,"DBG");
  
  PlaySound(ISE_MenuOpen);
  
  while(ExitFlag==False){
    u32 cnt;
    for(cnt=0;cnt<MenuMax;cnt++){
      if(cnt==CurrentMenu){
        FontData_BGCHRDrawText(BGCHR1,5+(xpos[cnt]*5),0,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,5+(xpos[cnt]*5),0," ");
      }
    }
    
    switch(CurrentMenu){
      case 0:
        ExitFlag=Menu_MainLoad();
        break;
      case 1:
        ExitFlag=Menu_MainSave();
        break;
      case 2:
        ExitFlag=Menu_MainDelete();
        break;
      case 3:
        ExitFlag=Menu_MainSelFont();
        break;
      case 4:
        ExitFlag=Menu_MainOption();
        break;
      case 5:
        ExitFlag=Menu_MainSound();
        break;
      case 6:
        ExitFlag=Menu_MainDebug();
        break;
    }
  }
  
  FontData_BGCHRFill(BGCHR1,0,0,240,12,Color_FlameClear);
  Menu_MainHidePanel();
  BG1Fade1();
  
  SRAM_Write32(&SRAM->MenuLastPage,CurrentMenu);
  
  FontPack=BackupFontPack;
  
  while((*KEYS)!=0x3ff);
}

void Main_Menu_KeyL(void)
{
  if(CurrentMenu==0){
    CurrentMenu=MenuMax-1;
    }else{
    CurrentMenu--;
  }
  if(SRAM_Read32(&SRAM->se_Enabled[ISE_Page])==True){
    PlaySound(ISE_Page);
    }else{
    PlaySound(ISE_MenuMove);
  }
}

void Main_Menu_KeyR(void)
{
  if(CurrentMenu==(MenuMax-1)){
    CurrentMenu=0;
    }else{
    CurrentMenu++;
  }
  if(SRAM_Read32(&SRAM->se_Enabled[ISE_Page])==True){
    PlaySound(ISE_Page);
    }else{
    PlaySound(ISE_MenuMove);
  }
}

void Menu_MainDrawState(u32 num,u32 x,u32 y)
{
  x+=2*5;
  inttostr(num+1,1);
  FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,res_inttostr);
  
  x+=2*5;
  u32 pos=SRAM_Read32(&SRAM_CurrentState->SavePosition[num]);
  if(pos==0){
    FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�f�[�^������܂���B");
    }else{
    if(pos<TextDataSize){
      FontData_BGCHRDrawTextLimit(BGCHR1,x+(0*5),y,(u8*)&TextData[pos],39,1,False);
      }else{
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�ُ�!! �Ō����ɃZ�[�u����Ă��܂��B");
    }
    
    y+=10;
    inttostr(pos,7);
    FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,res_inttostr);
    FontData_BGCHRDrawText(BGCHR1,x+(7*5),y,"/");
    inttostr(TextDataSize,7);
    FontData_BGCHRDrawText(BGCHR1,x+(8*5),y,res_inttostr);
    FontData_BGCHRDrawText(BGCHR1,x+(15*5),y,"byte.");
  }
}

b8 Menu_MainLoad(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=3;
  
  winw=44*5+8;
  winh=11*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  u32 slotcnt=0;
  u32 slotmax=4;
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"���[�h����X���b�g��I��ł��������B");
    FontData_BGCHRDrawTextLimit(BGCHR1,wx,wy+(1*10),SRAM_GetPtr8(&SRAM_CurrentState->Filename[0]),41,1,False);
    
    u32 ycnt;
    for(ycnt=0;ycnt<slotmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*2)+0)*10);
      Menu_MainDrawState(ycnt,dx,dy);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<slotmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*2)+0)*10);
      if(ycnt==slotcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(slotcnt!=0){
        slotcnt--;
        }else{
        slotcnt=slotmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(slotcnt<(slotmax-1)){
        slotcnt++;
        }else{
        slotcnt=0;
      }
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if(NowKey==KEY_A){
      if(SRAM_Read32(&SRAM_CurrentState->SavePosition[slotcnt])==0){
        DialogSizeX=28;
        DialogStrCount=3;
        DialogStr[ 0]="���̃X���b�g�ɂ�";
        DialogStr[ 1]="�f�[�^������܂���B";
        DialogStr[ 2]="";
        ShowDialog(ISE_DialogInfo);
        }else{
        DialogSizeX=32;
        DialogStrCount=4;
        DialogStr[ 0]="���[�h���܂����H";
        DialogStr[ 1]="";
        DialogStr[ 2]="�`�{�^�������[�h����B";
        DialogStr[ 3]="�`�{�^���ȊO���L�����Z��";
        if(ShowDialog_AorNotA(ISE_DialogQuestion)==True){
          PlaySound(ISE_MenuSuccess);
          Menu_Main_RequestReloadLinePos=True;
          u32 pos;
          pos=SRAM_Read32(&SRAM_CurrentState->SavePosition[slotcnt]);
          SRAM_Write32(&SRAM_CurrentState->LastPosition,pos);
          ExitFlag=True;
          ReturnExitFlag=True;
          }else{
          PlaySound(ISE_MenuCancel);
        }
      }
      if(ExitFlag==False) DrawPage();
    }
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

b8 Menu_MainSave(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=3;
  
  winw=44*5+8;
  winh=11*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  u32 slotcnt=0;
  u32 slotmax=4;
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�Z�[�u����X���b�g��I��ł��������B");
    FontData_BGCHRDrawTextLimit(BGCHR1,wx,wy+(1*10),SRAM_GetPtr8(&SRAM_CurrentState->Filename[0]),41,1,False);
    
    u32 ycnt;
    for(ycnt=0;ycnt<slotmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*2)+0)*10);
      Menu_MainDrawState(ycnt,dx,dy);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<slotmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*2)+0)*10);
      if(ycnt==slotcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(slotcnt!=0){
        slotcnt--;
        }else{
        slotcnt=slotmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(slotcnt<(slotmax-1)){
        slotcnt++;
        }else{
        slotcnt=0;
      }
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if(NowKey==KEY_A){
      if(SRAM_Read32(&SRAM_CurrentState->LastPosition)==0){
        DialogSizeX=30;
        DialogStrCount=3;
        DialogStr[ 0]="�t�@�C���擪�ɂ���̂�";
        DialogStr[ 1]="�Z�[�u���܂���ł����B";
        DialogStr[ 2]="";
        ShowDialog(ISE_DialogInfo);
        }else{
        if(SRAM_Read32(&SRAM_CurrentState->SavePosition[slotcnt])==0){
          PlaySound(ISE_MenuSuccess);
          u32 pos;
          pos=SRAM_Read32(&SRAM_CurrentState->LastPosition);
          SRAM_Write32(&SRAM_CurrentState->SavePosition[slotcnt],pos);
          }else{
          DialogSizeX=32;
          DialogStrCount=4;
          DialogStr[ 0]="�x��!! �㏑�����Ă������ł����H";
          DialogStr[ 1]="";
          DialogStr[ 2]="�`�{�^�����Z�[�u����B";
          DialogStr[ 3]="�`�{�^���ȊO���L�����Z��";
          if(ShowDialog_AorNotA(ISE_DialogWarrning)==True){
            PlaySound(ISE_MenuSuccess);
            u32 pos;
            pos=SRAM_Read32(&SRAM_CurrentState->LastPosition);
            SRAM_Write32(&SRAM_CurrentState->SavePosition[slotcnt],pos);
            }else{
            PlaySound(ISE_MenuCancel);
          }
        }
      }
      DrawPage();
    }
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

b8 Menu_MainDelete(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=3;
  
  winw=44*5+8;
  winh=11*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  u32 slotcnt=0;
  u32 slotmax=4;
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�폜����X���b�g��I��ł��������B");
    FontData_BGCHRDrawTextLimit(BGCHR1,wx,wy+(1*10),SRAM_GetPtr8(&SRAM_CurrentState->Filename[0]),41,1,False);
    
    u32 ycnt;
    for(ycnt=0;ycnt<slotmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*2)+0)*10);
      Menu_MainDrawState(ycnt,dx,dy);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<slotmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*2)+0)*10);
      if(ycnt==slotcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(slotcnt!=0){
        slotcnt--;
        }else{
        slotcnt=slotmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(slotcnt<(slotmax-1)){
        slotcnt++;
        }else{
        slotcnt=0;
      }
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if(NowKey==KEY_A){
      if(SRAM_Read32(&SRAM_CurrentState->SavePosition[slotcnt])==0){
        DialogSizeX=28;
        DialogStrCount=3;
        DialogStr[ 0]="���̃X���b�g�ɂ�";
        DialogStr[ 1]="�f�[�^������܂���B";
        DialogStr[ 2]="";
        ShowDialog(ISE_DialogInfo);
        }else{
        DialogSizeX=32;
        DialogStrCount=4;
        DialogStr[ 0]="�x��!! �폜���Ă������ł����H";
        DialogStr[ 1]="";
        DialogStr[ 2]="�`�{�^�����폜����B";
        DialogStr[ 3]="�`�{�^���ȊO���L�����Z��";
        if(ShowDialog_AorNotA(ISE_DialogWarrning)==True){
          PlaySound(ISE_MenuSuccess);
          SRAM_Write32(&SRAM_CurrentState->SavePosition[slotcnt],0);
          }else{
          PlaySound(ISE_MenuCancel);
        }
      }
      DrawPage();
    }
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

b8 Menu_MainSelFont(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=2;
  
  winw=44*5+8;
  winh=9*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  u32 fontcnt;
  u32 fontmax=7;
  fontcnt=SRAM_Read32(&SRAM->FontPackIndex);
  if(fontcnt!=0) fontcnt--;
  
  void DrawItem(u32 num,u32 x,u32 y)
  {
    x+=2*5;
    inttostr(num+1,1);
    FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,res_inttostr);
    
    x+=2*5;
    if(FontTable->fpk[num+1].Size!=0){
      FontData_BGCHRDrawText(BGCHR1,x,y,FontTable->fpk[num+1].Filename);
      }else{
      FontData_BGCHRDrawText(BGCHR1,x,y,"�t�H���g���o�^");
    }
  }
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�ύX����t�H���g��I��ł��������B");
    
    u32 ycnt;
    for(ycnt=0;ycnt<fontmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+ycnt+0)*10);
      DrawItem(ycnt,dx,dy);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<fontmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+ycnt+0)*10);
      if(ycnt==fontcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(fontcnt!=0){
        fontcnt--;
        }else{
        fontcnt=fontmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(fontcnt<(fontmax-1)){
        fontcnt++;
        }else{
        fontcnt=0;
      }
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if(NowKey==KEY_A){
      if(FontTable->fpk[fontcnt+1].Size==0){
        DialogSizeX=36;
        DialogStrCount=5;
        DialogStr[ 0]="�t�H���g���o�^����Ă��܂���B";
        DialogStr[ 1]="�V�X�e���t�H���g��ǂݍ��݂܂����H";
        DialogStr[ 2]="";
        DialogStr[ 3]="�`�{�^�����V�X�e���t�H���g���g���B";
        DialogStr[ 4]="�`�{�^���ȊO���L�����Z��";
        if(ShowDialog_AorNotA(ISE_DialogQuestion)==True){
          PlaySound(ISE_MenuSuccess);
          Menu_Main_RequestReloadFont=True;
          SRAM_Write32(&SRAM->FontPackIndex,fontcnt+1);
          ExitFlag=True;
          ReturnExitFlag=True;
          }else{
          PlaySound(ISE_MenuCancel);
        }
        DrawPage();
        }else{
        PlaySound(ISE_MenuSuccess);
        Menu_Main_RequestReloadFont=True;
        SRAM_Write32(&SRAM->FontPackIndex,fontcnt+1);
        ExitFlag=True;
        ReturnExitFlag=True;
      }
    }
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

u32 Menu_MainOptionDrawItemX,Menu_MainOptionDrawItemY;

void Menu_MainOptionDrawItem(u32 num)
{
  u32 x=Menu_MainOptionDrawItemX;
  u32 y=Menu_MainOptionDrawItemY+((1+(num*1)+0)*10);
  
  x+=2*5;
  switch(num){
    case 0:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�N�����ɏ�Ԃ𕜌�����");
      if(SRAM_Read32(&SRAM->LoadAutoState)==True){
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"�������[�h");
        }else{
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"�_�C�A���O");
      }
      break;
    case 1:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�s��");
      inttostr(SRAM_Read32(&SRAM->LineSpace),1);
      FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,res_inttostr);
      FontData_BGCHRDrawText(BGCHR1,x+(29*5),y,"pixel(s).");
      break;
    case 2:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�L�[���s�[�g�E�F�C�g");
      inttostr(SRAM_Read32(&SRAM->KeyRepeatTime),4);
      FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,res_inttostr);
      FontData_BGCHRDrawText(BGCHR1,x+(32*5),y,"ms");
      break;
    case 3:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�T�E���h�G�t�F�N�g�S��");
      if(SRAM_Read32(&SRAM->se_AllEnabled)==True){
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"�L��");
        }else{
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"����");
      }
      break;
    case 4:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�Q�{�I�[�o�[�T���v�����O");
      if(SRAM_Read32(&SRAM->se_Linner2x)==True){
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"���`�⊮");
        }else{
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"���Ȃ��@");
      }
      break;
    case 5:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�T�E���h�{�����[��");
      inttostr(SRAM_Read32(&SRAM->se_Volume),3);
      FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,res_inttostr);
      FontData_BGCHRDrawText(BGCHR1,x+(31*5),y,"/128vol");
      break;
    case 6:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�^�u�X�g�b�v��");
      inttostr(SRAM_Read32(&SRAM->LineTabStop),2);
      FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,res_inttostr);
      FontData_BGCHRDrawText(BGCHR1,x+(31*5),y,"char");
      break;
    case 7:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"�^�u������\\������");
      if(SRAM_Read32(&SRAM->LineShowTab)==True){
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"�\\���@");
        }else{
        FontData_BGCHRDrawText(BGCHR1,x+(28*5),y,"��\\��");
      }
      break;
    case 8:
      FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,"BG�w�i����");
      switch(SRAM_Read32(&SRAM->ThemeState)){
        case 0:
          FontData_BGCHRDrawText(BGCHR1,x+(21*5),y,"BG���� ���[�U�[�J���[");
          break;
        case 1:
          FontData_BGCHRDrawText(BGCHR1,x+(21*5),y,"BG�L�� ���[�U�[�J���[");
          break;
        case 2:
          FontData_BGCHRDrawText(BGCHR1,x+(21*5),y,"BG���� ���w�i������  ");
          break;
        case 3:
          FontData_BGCHRDrawText(BGCHR1,x+(21*5),y,"BG���� ���w�i������  ");
          break;
      }
      break;
    case 9:
      switch(SRAM_Read32(&SRAM->ReturnPogoShellKeys)){
        case 0:
          FontData_BGCHRDrawText(BGCHR1,x+(0*5),y+(0*10),"�L�[�J�X�^�}�C�Y Type:0 L+R PogoShell���A ");
          FontData_BGCHRDrawText(BGCHR1,x+(0*5),y+(1*10),"��/A/��/B �s�ړ�  ��/�� �y�[�W�ړ�        ");
          break;
        case 1:
          FontData_BGCHRDrawText(BGCHR1,x+(0*5),y+(0*10),"�L�[�J�X�^�}�C�Y Type:1 A+B PogoShell���A ");
          FontData_BGCHRDrawText(BGCHR1,x+(0*5),y+(1*10),"��/�� �s�ړ�  ��/�� �y�[�W�ړ�  L/R ����  ");
          break;
        case 2:
          FontData_BGCHRDrawText(BGCHR1,x+(0*5),y+(0*10),"�L�[�J�X�^�}�C�Y Type:2 L+���� PogoShell  ");
          FontData_BGCHRDrawText(BGCHR1,x+(0*5),y+(1*10),"A/B �s�ړ�  R+A/R+B �y�[�W�ړ�            ");
          break;
      }
      break;
  }
}

void Menu_MainOptionKey_LoadAutoState(u32 NowKey)
{
  b32 v;
  v=SRAM_Read32(&SRAM->LoadAutoState);
  
  if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
    PlaySound(ISE_MenuMove);
    if(v==True){
      v=False;
      }else{
      v=True;
    }
  }
  
  SRAM_Write32(&SRAM->LoadAutoState,v);
  Menu_MainOptionDrawItem(0);
}

void Menu_MainOptionKey_LineSpace(u32 NowKey)
{
  u32 v;
  v=SRAM_Read32(&SRAM->LineSpace);
  
  if(NowKey==KEY_LEFT){
    PlaySound(ISE_MenuMove);
    if(v>0) v--;
  }
  if(NowKey==KEY_RIGHT){
    PlaySound(ISE_MenuMove);
    if(v<7) v++;
  }
  
  Menu_Main_RequestReloadLineSpace=True;
  SRAM_Write32(&SRAM->LineSpace,v);
  Menu_MainOptionDrawItem(1);
}

void Menu_MainOptionKey_KeyRepeatTime(u32 NowKey)
{
  u32 v;
  v=SRAM_Read32(&SRAM->KeyRepeatTime);
  
  if(NowKey==KEY_LEFT){
    PlaySound(ISE_MenuMove);
    if(v>200) v-=50;
  }
  if(NowKey==KEY_RIGHT){
    PlaySound(ISE_MenuMove);
    if(v<1000) v+=50;
  }
  
  Menu_Main_RequestReloadKeyRepeatTime=True;
  SRAM_Write32(&SRAM->KeyRepeatTime,v);
  Menu_MainOptionDrawItem(2);
}

void Menu_MainOptionKey_SoundAllEnabled(u32 NowKey)
{
  b32 v;
  v=SRAM_Read32(&SRAM->se_AllEnabled);
  
  if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
    PlaySound(ISE_MenuMove);
    if(v==True){
      v=False;
      }else{
      v=True;
    }
  }
  
  SRAM_Write32(&SRAM->se_AllEnabled,v);
  Menu_MainOptionDrawItem(3);
}

void Menu_MainOptionKey_SoundLinner2x(u32 NowKey)
{
  b32 v;
  v=SRAM_Read32(&SRAM->se_Linner2x);
  
  if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
    PlaySound(ISE_MenuMove);
    if(v==True){
      v=False;
      }else{
      v=True;
    }
  }
  
  SRAM_Write32(&SRAM->se_Linner2x,v);
  Menu_MainOptionDrawItem(4);
}

void Menu_MainOptionKey_SoundVolume(u32 NowKey)
{
  u32 v;
  v=SRAM_Read32(&SRAM->se_Volume);
  
  if(NowKey==KEY_LEFT){
    PlaySound(ISE_MenuMove);
    if(v>16) v-=16;
  }
  if(NowKey==KEY_RIGHT){
    PlaySound(ISE_MenuMove);
    if(v<128) v+=16;
  }
  
  SRAM_Write32(&SRAM->se_Volume,v);
  Menu_MainOptionDrawItem(5);
}

void Menu_MainOptionKey_TabStop(u32 NowKey)
{
  u32 v;
  v=SRAM_Read32(&SRAM->LineTabStop);
  
  if(NowKey==KEY_LEFT){
    PlaySound(ISE_MenuMove);
    if(v>1) v--;
  }
  if(NowKey==KEY_RIGHT){
    PlaySound(ISE_MenuMove);
    if(v<16) v++;
  }
  
  Menu_Main_RequestReloadLineTab=True;
  SRAM_Write32(&SRAM->LineTabStop,v);
  Menu_MainOptionDrawItem(6);
}

void Menu_MainOptionKey_ShowTab(u32 NowKey)
{
  b32 v;
  v=SRAM_Read32(&SRAM->LineShowTab);
  
  if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
    PlaySound(ISE_MenuMove);
    if(v==True){
      v=False;
      }else{
      v=True;
    }
  }
  
  Menu_Main_RequestReloadLineTab=True;
  SRAM_Write32(&SRAM->LineShowTab,v);
  Menu_MainOptionDrawItem(7);
}

void Menu_MainOptionKey_ThemeState(u32 NowKey)
{
  b32 v;
  v=SRAM_Read32(&SRAM->ThemeState);
  
  if(NowKey==KEY_LEFT){
    PlaySound(ISE_MenuMove);
    if(v>0) v--;
  }
  if(NowKey==KEY_RIGHT){
    PlaySound(ISE_MenuMove);
    if(v<3) v++;
  }
  
  SRAM_Write32(&SRAM->ThemeState,v);
  SetThemeColor();
  SetOAMBG();
  Menu_MainOptionDrawItem(8);
}

void Menu_MainOptionKey_ReturnPogoShellKeys(u32 NowKey)
{
  b32 v;
  v=SRAM_Read32(&SRAM->ReturnPogoShellKeys);
  
  if(NowKey==KEY_LEFT){
    PlaySound(ISE_MenuMove);
    if(v>0){
      v--;
    }
  }
  if(NowKey==KEY_RIGHT){
    PlaySound(ISE_MenuMove);
    if(v<2){
      v++;
    }
  }
  
  SRAM_Write32(&SRAM->ReturnPogoShellKeys,v);
  Menu_MainOptionDrawItem(9);
}

b8 Menu_MainOption(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=1;
  
  winw=44*5+8;
  winh=11*11+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  Menu_MainOptionDrawItemX=wx;
  Menu_MainOptionDrawItemY=wy;
  
  u32 itemcnt=0;
  u32 itemmax=10;
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�I�v�V�����ݒ� �i��/���L�[�ŕύX�j");
    
    u32 ycnt;
    for(ycnt=0;ycnt<itemmax;ycnt++){
      Menu_MainOptionDrawItem(ycnt);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<itemmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+(ycnt*1)+0)*10);
      if(ycnt==itemcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(itemcnt!=0){
        itemcnt--;
        }else{
        itemcnt=itemmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(itemcnt<(itemmax-1)){
        itemcnt++;
        }else{
        itemcnt=0;
      }
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    if(NowKey==KEY_A){
      PlaySound(ISE_MenuSuccess);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
      switch(itemcnt){
        case 0:
          Menu_MainOptionKey_LoadAutoState(NowKey);
          break;
        case 1:
          Menu_MainOptionKey_LineSpace(NowKey);
          break;
        case 2:
          Menu_MainOptionKey_KeyRepeatTime(NowKey);
          break;
        case 3:
          Menu_MainOptionKey_SoundAllEnabled(NowKey);
          break;
        case 4:
          Menu_MainOptionKey_SoundLinner2x(NowKey);
          break;
        case 5:
          Menu_MainOptionKey_SoundVolume(NowKey);
          break;
        case 6:
          Menu_MainOptionKey_TabStop(NowKey);
          break;
        case 7:
          Menu_MainOptionKey_ShowTab(NowKey);
          break;
        case 8:
          Menu_MainOptionKey_ThemeState(NowKey);
          break;
        case 9:
          Menu_MainOptionKey_ReturnPogoShellKeys(NowKey);
          break;
      }
    }
    
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

b8 Menu_MainSound(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=2;
  
  winw=44*5+8;
  winh=11*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  u32 itemcnt=0;
  u32 itemmax=ISE_Count;
  
  void DrawItem(u32 num,u32 x,u32 y)
  {
    x+=2*5;
    inttostr(num+1,1);
    FontData_BGCHRDrawText(BGCHR1,x+(0*5),y,res_inttostr);
    
    x+=2*5;
    switch(num){
      case ISE_FirstBoot:
        FontData_BGCHRDrawText(BGCHR1,x,y,"����N���X�v���b�V��");
        break;
      case ISE_Page:
        FontData_BGCHRDrawText(BGCHR1,x,y,"�y�[�W����^�߂�");
        break;
      case ISE_DialogInfo:
        FontData_BGCHRDrawText(BGCHR1,x,y,"���_�C�A���O");
        break;
      case ISE_DialogQuestion:
        FontData_BGCHRDrawText(BGCHR1,x,y,"����_�C�A���O");
        break;
      case ISE_DialogWarrning:
        FontData_BGCHRDrawText(BGCHR1,x,y,"�x���_�C�A���O");
        break;
      case ISE_MenuOpen:
        FontData_BGCHRDrawText(BGCHR1,x,y,"���j���[�I�[�v��");
        break;
      case ISE_MenuMove:
        FontData_BGCHRDrawText(BGCHR1,x,y,"���j���[�ړ�");
        break;
      case ISE_MenuCancel:
        FontData_BGCHRDrawText(BGCHR1,x,y,"���j���[�L�����Z��");
        break;
      case ISE_MenuSuccess:
        FontData_BGCHRDrawText(BGCHR1,x,y,"���j���[��������");
        break;
    }
    x+=23*5;
    if(SRAM_Read32(&SRAM->se_Enabled[num])==True){
      FontData_BGCHRDrawText(BGCHR1,x,y,"ON ");
      }else{
      FontData_BGCHRDrawText(BGCHR1,x,y,"OFF");
    }
  }
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�ʃT�E���h�G�t�F�N�g�ݒ� (��/���L�[�ŕύX)");
    
    u32 ycnt;
    for(ycnt=0;ycnt<itemmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+ycnt+0)*10);
      DrawItem(ycnt,dx,dy);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<itemmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+ycnt+0)*10);
      if(ycnt==itemcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(itemcnt!=0){
        itemcnt--;
        }else{
        itemcnt=itemmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(itemcnt<(itemmax-1)){
        itemcnt++;
        }else{
        itemcnt=0;
      }
    }
    
    if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
      PlaySound(ISE_MenuMove);
      b32 now=SRAM_Read32(&SRAM->se_Enabled[itemcnt]);
      if(now==True){
        now=False;
        }else{
        now=True;
      }
      SRAM_Write32(&SRAM->se_Enabled[itemcnt],now);
      
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+itemcnt+0)*10);
      DrawItem(itemcnt,dx,dy);
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if(NowKey==KEY_A){
      b32 now=SRAM_Read32(&SRAM->se_Enabled[itemcnt]);
      SRAM_Write32(&SRAM->se_Enabled[itemcnt],True);
      PlaySound(itemcnt);
      SRAM_Write32(&SRAM->se_Enabled[itemcnt],now);
    }
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

b8 Menu_MainDebugKey_SRAMClear(u32 NowKey)
{
  if(NowKey==KEY_A){
    DialogSizeX=34;
    DialogStrCount=8;
    DialogStr[ 0]="�x��!! SRAM��S�ď��������܂��B";
    DialogStr[ 1]="";
    DialogStr[ 2]="TextViewer�v���O�C�����g�p����A";
    DialogStr[ 3]="�S�ẴZ�[�u�f�[�^���폜����܂��B";
    DialogStr[ 4]="���e�L�X�g�̃Z�[�u���폜�Ώۂł��B";
    DialogStr[ 5]="";
    DialogStr[ 6]="�`�{�^���������������s����B";
    DialogStr[ 7]="�`�{�^���ȊO���L�����Z��";
    if(ShowDialog_AorNotA(ISE_DialogWarrning)==True){
      SRAM_AllClear();
      PlaySound(ISE_MenuSuccess);
      DialogSizeX=34;
      DialogStrCount=4;
      DialogStr[ 0]="���������������܂����B";
      DialogStr[ 1]="";
      DialogStr[ 2]="PogoShell�ɕ��A���܂��B";
      DialogStr[ 3]="�������͓d����؂��ĉ������B";
      ShowDialog(ISE_MenuSuccess);
      ReturnPogoShell2();
      return(True);
      }else{
      PlaySound(ISE_MenuCancel);
    }
  }
  if(NowKey==KEY_LEFT){
  }
  if(NowKey==KEY_RIGHT){
  }
  
  return(False);
}

b8 Menu_MainDebugKey_IWRAMSave(u32 NowKey)
{
  if(NowKey==KEY_A){
    DialogSizeX=42;
    DialogStrCount=7;
    DialogStr[ 0]="�x��!! IWRAM�̓��e��SRAM�ɃR�s�[���܂��B";
    DialogStr[ 1]="";
    DialogStr[ 2]="32767byte�ȏ�SRAM���g���Ă���ꍇ�́A";
    DialogStr[ 3]="�㏑������Ă��܂��̂Œ��ӂ��ĉ������B";
    DialogStr[ 4]="";
    DialogStr[ 5]="�`�{�^���������������s����B";
    DialogStr[ 6]="�`�{�^���ȊO���L�����Z��";
    if(ShowDialog_AorNotA(ISE_DialogWarrning)==True){
      SRAM_SaveIWRAM();
      PlaySound(ISE_MenuSuccess);
      DialogSizeX=30;
      DialogStrCount=4;
      DialogStr[ 0]="IWRAM�ɃR�s�[�������܂����B";
      DialogStr[ 1]="";
      DialogStr[ 2]="PogoShell�ɕ��A���܂��B";
      DialogStr[ 3]="�������͓d����؂��ĉ������B";
      ShowDialog(ISE_MenuSuccess);
      ReturnPogoShell2();
      return(True);
      }else{
      PlaySound(ISE_MenuCancel);
    }
  }
  if(NowKey==KEY_LEFT){
  }
  if(NowKey==KEY_RIGHT){
  }
  
  return(False);
}

b8 Menu_MainDebugKey_IWRAMCodeCheck(u32 NowKey)
{
  if(NowKey==KEY_A){
    u32 adr=memchk();
    if(adr==0){
      DialogSizeX=38;
      DialogStrCount=3;
      DialogStr[ 0]="IWRAM�������`�F�b�N���������܂����B";
      DialogStr[ 1]="�ُ�͌�����܂���ł����B";
      DialogStr[ 2]="";
      ShowDialog(ISE_MenuSuccess);
    }
  }
  if(NowKey==KEY_LEFT){
  }
  if(NowKey==KEY_RIGHT){
  }
  
  return(False);
}

b8 Menu_MainDebug(void)
{
  u32 wx,wy;
  u32 winx,winy,winw,winh;
  
  u32 NowKey;
  b8 ExitFlag=False;
  b8 ReturnExitFlag=False;
  
  u32 yoff=2;
  
  winw=44*5+8;
  winh=12*10+8;
  winx=(240-winw)/2;
  winy=(160-winh)/2;
  wx=winx+4;
  wy=winy+4;
  
  u32 itemcnt=0;
  u32 itemmax=3;
  
  void DrawItem(u32 num,u32 x,u32 y)
  {
    x+=2*5;
    switch(num){
      case 0:
        FontData_BGCHRDrawText(BGCHR1,x,y,"SRAM�S������");
        break;
      case 1:
        FontData_BGCHRDrawText(BGCHR1,x,y,"IWRAM��SRAM�㔼32kb�ɃR�s�[");
        break;
      case 2:
        FontData_BGCHRDrawText(BGCHR1,x,y,"IWRAM�R�[�h�̈搮���`�F�b�N");
        break;
      case 3:
        FontData_BGCHRDrawText(BGCHR1,x,y,"");
        break;
      case 4:
        FontData_BGCHRDrawText(BGCHR1,x,y,"");
        break;
      case 5:
        FontData_BGCHRDrawText(BGCHR1,x,y,"");
        break;
    }
  }
  
  void DrawPage(void)
  {
    FontData_BGCHRFillFlame(BGCHR1,winx,winy,winw,winh,Color_FlameMask,Color_FlameBright,Color_FlameBG);
    FontData_BGCHRDrawText(BGCHR1,wx,wy+(0*10),"�f�o�b�O���[�h");
    
    u32 x=wx;
    u32 y=wy+(6*10);
    
    extern u8 __iwram_break;
    u32 *mem_start=(u32*)&_impure_ptr;
    u32 *mem_end=(u32*)&__iwram_break;
//    u32 mem_size=((u32)mem_end)-((u32)mem_start);
    u32 mem_free=0x03007f00-((u32)mem_end);
    
    FontData_BGCHRDrawText(BGCHR1,x,y,"IWRAM�R�[�h�J�n�A�h���X");
    uprintf("0x%x",(u32)mem_start);
    FontData_BGCHRDrawText(BGCHR1,x+(30*5),y,resprintf);
    y+=10;
    FontData_BGCHRDrawText(BGCHR1,x,y,"IWRAM�R�[�h�I���A�h���X");
    uprintf("0x%x",(u32)mem_end);
    FontData_BGCHRDrawText(BGCHR1,x+(30*5),y,resprintf);
    y+=10;
    FontData_BGCHRDrawText(BGCHR1,x,y,"IWRAM�󂫗e��+UserStack");
    inttostr(mem_free,6);
    FontData_BGCHRDrawText(BGCHR1,x+(29*5),y,res_inttostr);
    FontData_BGCHRDrawText(BGCHR1,x+(35*5),y,"byte");
    y+=10;
    
    // �蔲����˂��B�ڈ��ɂȂ�΂���ŁB
    extern u8 __iwram_overlay_lma;
    u32 rommem_start=0x08000000;
    u32 rommem_end=(u32)&__iwram_overlay_lma;
    u32 rommem_size=rommem_end-rommem_start;

    FontData_BGCHRDrawText(BGCHR1,x,y,"ROM���[�U�[�R�[�h�T�C�Y");
    inttostr(rommem_size,6);
    FontData_BGCHRDrawText(BGCHR1,x+(29*5),y,res_inttostr);
    FontData_BGCHRDrawText(BGCHR1,x+(35*5),y,"byte");
    y+=10;
    
    u32 SRAM_Used=(u32)&SRAM->State[SRAM_Read32(&SRAM->StateCount)];
    u32 SRAM_Free=SRAM_Size-SRAM_Used;
    
    FontData_BGCHRDrawText(BGCHR1,x,y,"SRAM�g�p��");
    inttostr(SRAM_Used,6);
    FontData_BGCHRDrawText(BGCHR1,x+(29*5),y,res_inttostr);
    FontData_BGCHRDrawText(BGCHR1,x+(35*5),y,"byte");
    y+=10;
    FontData_BGCHRDrawText(BGCHR1,x,y,"SRAM��e��");
    inttostr(SRAM_Free,6);
    FontData_BGCHRDrawText(BGCHR1,x+(29*5),y,res_inttostr);
    FontData_BGCHRDrawText(BGCHR1,x+(35*5),y,"byte");
    y+=10;
    
    u32 ycnt;
    for(ycnt=0;ycnt<itemmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+ycnt+0)*10);
      DrawItem(ycnt,dx,dy);
    }
  }
  
  DrawPage();
  
  while(ExitFlag==False){
    u32 ycnt;
    for(ycnt=0;ycnt<itemmax;ycnt++){
      u32 dx,dy;
      dx=wx;
      dy=wy+((yoff+ycnt+0)*10);
      if(ycnt==itemcnt){
        FontData_BGCHRDrawText(BGCHR1,dx,dy,"*");
        }else{
        FontData_BGCHRDrawText(BGCHR1,dx,dy," ");
      }
    }
    
    while((*KEYS)!=0x3ff);
    NowKey=0;
    while(NowKey==0){
      NowKey=(~*KEYS)&0x3ff;
      if(NowKey==0) WaitForVsync();
    }
    
    if(NowKey==KEY_L){
      Main_Menu_KeyL();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    if(NowKey==KEY_R){
      Main_Menu_KeyR();
      ExitFlag=True;
      ReturnExitFlag=False;
    }
    
    if(NowKey==KEY_UP){
      PlaySound(ISE_MenuMove);
      if(itemcnt!=0){
        itemcnt--;
        }else{
        itemcnt=itemmax-1;
      }
    }
    if(NowKey==KEY_DOWN){
      PlaySound(ISE_MenuMove);
      if(itemcnt<(itemmax-1)){
        itemcnt++;
        }else{
        itemcnt=0;
      }
    }
    
    if((NowKey==KEY_LEFT)||(NowKey==KEY_RIGHT)){
    }
    
    if((NowKey==KEY_B)||(NowKey==KEY_START)){
      PlaySound(ISE_MenuCancel);
      ExitFlag=True;
      ReturnExitFlag=True;
    }
    
    if(NowKey==KEY_A){
      switch(itemcnt){
        case 0:
          ExitFlag=Menu_MainDebugKey_SRAMClear(NowKey);
          break;
        case 1:
          ExitFlag=Menu_MainDebugKey_IWRAMSave(NowKey);
          break;
        case 2:
          ExitFlag=Menu_MainDebugKey_IWRAMCodeCheck(NowKey);
          break;
        case 3:
          break;
        case 4:
          break;
        case 5:
          break;
      }
      if(ExitFlag==False) DrawPage();
    }
  }
  
  FontData_BGCHRFill(BGCHR1,winx-1,winy-1,winw+2,winh+2,Color_FlameClear);
  
  return(ReturnExitFlag);
}

