#ifndef pcmstream_h
#define pcmstream_h

#include "boolean.h"

#define sndbuf_size (64<<4)
#define sndbuf_DMA1Timeout (sndbuf_size>>4)
#define sndbuf_PCMType_unknown 0
#define sndbuf_PCMType_Linner8bit 1
#define sndbuf_PCMType_ADPCM4bit 2
#define sndbuf_PCMType_ADPCM4bitLinner2x 3
#define sndbuf_PCMType_YM2608 4

typedef struct {
  u8 *Data;
  u8 PCMType;
  u32 Size;
  u32 Freq;
  u32 Volume;
  b8 Keyon;
  u32 SrcPos;
} Tsndbuf_Channel;

extern u16 sndbuf_playpos;

extern void sndbuf_SetAttribute(Tsndbuf_Channel *tmpch,b8 refDataTypeSize,b8 refSrcPos,b8 resetADPCM);
extern void sndbuf_GetAttribute(Tsndbuf_Channel *tmpch);

extern void sndbuf_SetFreq(s32 Freq);
extern void sndbuf_SetPCM(u8* Data,u8 PCMType,u32 Size);
extern void sndbuf_SetSrcPos(s32 SrcPos);
extern void sndbuf_SetVolume(s32 Volume);
extern void (*sndbuf_SetKeyon)(b8 Keyon);

extern u32 sndbuf_GetFreq(void);
extern u32 sndbuf_GetSize(void);
extern u32 sndbuf_GetSrcPos(void);
extern u32 sndbuf_GetVolume(void);
extern b8 sndbuf_GetKeyon(void);

extern void sndbuf_Init(void);
extern void sndbuf_StartPCM(void);
extern void (*sndbuf_DMA1_Handler)(void);

extern void (*sndbuf_Suspend)(void);
extern void (*sndbuf_Resume)(void);

#endif
