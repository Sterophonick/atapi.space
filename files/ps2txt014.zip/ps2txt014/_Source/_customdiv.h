
#ifndef _customdiv_h
#define _customdiv_h

//extern s32 (*divs32)(s32 s0,s32 s1);
//extern s16 (*divs16)(s16 s0,s16 s1);
extern s32 (*divu32)(s32 s0,s32 s1);

#endif
