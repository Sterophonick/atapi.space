
#include "header\GBA.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\sound.h"
#include "boolean.h"
#include "pcmstream.h"

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

Tsndbuf_Channel sndbuf_ch_body;
Tsndbuf_Channel *sndbuf_ch=&sndbuf_ch_body;

#define sndbuf_REG_DM1CNT_H (DMA_SIZE_32 | DMA_TIMING_FIFO | DMA_REPEAT_ON | \
                             DMA_SAD_INC | DMA_DAD_FIX | DMA_INTR_ON)

#define sndbuf_s16Max (0x7fff)

s8 sndbuf0[sndbuf_size+256];
s8 sndbuf1[sndbuf_size+256];
u8 writebufno;
s8 *writebuf;

b8 ChangePCMProc;

attriwram void farcall_sndbuf_DMA1_Handler(void);
void (*sndbuf_DMA1_Handler)(void)=&farcall_sndbuf_DMA1_Handler;

void farcall_sndbuf_ResetChangePCMProc(void);
void (*sndbuf_ResetChangePCMProc)(void)=farcall_sndbuf_ResetChangePCMProc;

void farcall_sndbuf_SetKeyon(b8 Keyon);
void (*sndbuf_SetKeyon)(b8 Keyon)=farcall_sndbuf_SetKeyon;

#define sndbuf_Handler_PCMProc_size (1024*2)
u32 sndbuf_Handler_PCMProc_data[sndbuf_Handler_PCMProc_size/4];
void (*sndbuf_Handler_PCMProc)(void);
void sndbuf_Handler_PCMProc_Clear(void);
void sndbuf_Handler_PCMProc_Linner8bit(void);
void sndbuf_Handler_PCMProc_ADPCM4bit(void);
void sndbuf_Handler_PCMProc_ADPCM4bitLinner2x(void);
void sndbuf_Handler_PCMProc_YM2608(void);

void fp_sndbuf_Suspend(void);
void (*sndbuf_Suspend)(void)=fp_sndbuf_Suspend;
void fp_sndbuf_Resume(void);
void (*sndbuf_Resume)(void)=fp_sndbuf_Resume;

u16 sndbuf_playpos;

const s32 adpcm_estimstep[16] = {
	-1, -1, -1, -1, 2, 4, 6, 8,
	-1, -1, -1, -1, 2, 4, 6, 8
};

const s32 adpcm_estimindex[16] = {
	 2,  6,  10,  14,  18,  22,  26,  30,
	-2, -6, -10, -14, -18, -22, -26, -30
};

const s32 adpcm_estim_master[49] = {
	 16,  17,  19,  21,  23,  25,  28,  31,  34,  37,
	 41,  45,  50,  55,  60,  66,  73,  80,  88,  97,
	107, 118, 130, 143, 157, 173, 190, 209, 230, 253,
	279, 307, 337, 371, 408, 449, 494, 544, 598, 658,
	724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552
};

const s32 xnTable[16]={
    1,   3,   5,   7,   9,  11,  13,  15,
   -1,  -3,  -5,  -7,  -9, -11, -13, -15,
};

const s32 stepsizeTable[16] ={
  57, 57, 57, 57, 77,102,128,153,
  57, 57, 57, 57, 77,102,128,153
};

s32 adpcm_estim[49];
s32 mc_amp=0,mc_estim=0;
s32 xn=0,stepsize=127;

void sndbuf_Init(void)
{
  Tsndbuf_Channel *tch;
  tch=sndbuf_ch;
  tch->Data=0;
  tch->PCMType=sndbuf_PCMType_unknown;
  tch->Size=0;
  tch->Freq=0;
  tch->Volume=0;
  tch->Keyon=False;
  tch->SrcPos=0;

  ChangePCMProc=True;
}

void fp_sndbuf_Suspend(void)
{
  REG_SGFIF0A=0;
  REG_SGFIFOB=0;
  
  REG_SGCNT1=0;
  REG_SGCNT0_L=0;
  REG_SGCNT0_H=0;
  
  REG_DM1CNT_H=0;
  REG_TM1CNT=0;
}

void fp_sndbuf_Resume(void)
{
  REG_SGFIF0A=0;
  REG_SGFIFOB=0;
  
  REG_SGCNT1  = ENABLE_SOUND_MASTER;
  REG_SGCNT0_L=0x0000;
  REG_SGCNT0_H|=(DSOUND_A_TIMER1 | ENABLE_DSOUND_A_RIGHT | ENABLE_DSOUND_A_LEFT | DSOUND_A_FULL_OUTPUT);
  REG_SGCNT0_H|=(RESET_DSOUND_A);
  
  REG_SGCNT0_L&=~(BIT6|BIT5|BIT4|BIT2|BIT1|BIT0);
  u16 v=2; // BIOS�Đݒ�
  REG_SGCNT0_L|=(v<<4)|v;
  
  REG_DM1CNT_H= 0;
  REG_DM1SAD   = (u32)(sndbuf0);
  REG_DM1DAD   = (u32)SGFIF0A;
  REG_DM1CNT_H= sndbuf_REG_DM1CNT_H;
  
  s8 *twb;
  u32 cnt;
  twb=sndbuf0;
  for(cnt=0;cnt<(sndbuf_size+256);cnt++) twb[cnt]=0;
  twb=sndbuf1;
  for(cnt=0;cnt<(sndbuf_size+256);cnt++) twb[cnt]=0;
  
  REG_DM1CNT_H|= DMA_TRANSFER_ON;
  REG_TM1CNT|= TM_ENABLE | TM_FREQ_PER_1;
}

void sndbuf_SetAttribute(Tsndbuf_Channel *tmpch,b8 refDataTypeSize,b8 refSrcPos,b8 resetADPCM)
{
  if(refDataTypeSize==True){
    sndbuf_ch->Data=tmpch->Data;
    sndbuf_ch->PCMType=tmpch->PCMType;
    sndbuf_ch->Size=tmpch->Size;
    sndbuf_SetPCM(sndbuf_ch->Data,sndbuf_ch->PCMType,sndbuf_ch->Size);
  }
  if(sndbuf_ch->Freq!=tmpch->Freq){
    sndbuf_ch->Freq=tmpch->Freq;
    sndbuf_SetFreq(sndbuf_ch->Freq);
  }
  if(sndbuf_ch->Volume!=tmpch->Volume){
    sndbuf_ch->Volume=tmpch->Volume;
    sndbuf_SetVolume(sndbuf_ch->Volume);
  }
  if(sndbuf_ch->Keyon!=tmpch->Keyon){
    sndbuf_ch->Keyon=tmpch->Keyon;
    sndbuf_SetKeyon(sndbuf_ch->Keyon);
  }
  if(refSrcPos==True){
    sndbuf_ch->SrcPos=tmpch->SrcPos;
    sndbuf_SetSrcPos(sndbuf_ch->SrcPos);
  }
  
  if(resetADPCM==True){
    mc_amp=0;
    mc_estim=0;
    xn=0;
    stepsize=127;
  }
}

void sndbuf_GetAttribute(Tsndbuf_Channel *tmpch)
{
  tmpch->Data=sndbuf_ch->Data;
  tmpch->PCMType=sndbuf_ch->PCMType;
  tmpch->Size=sndbuf_ch->Size;
  tmpch->Freq=sndbuf_ch->Freq;
  tmpch->Volume=sndbuf_ch->Volume;
  tmpch->Keyon=sndbuf_ch->Keyon;
  tmpch->SrcPos=sndbuf_ch->SrcPos;
}

void sndbuf_SetFreq(s32 Freq)
{
  u32 mul=1;
  if(sndbuf_ch->PCMType==sndbuf_PCMType_ADPCM4bitLinner2x) mul=2;
  
  if(Freq<2205) Freq=2205;
  sndbuf_ch->Freq=(u32)Freq;
  u32 TM1CNT=REG_TM1CNT;
  REG_TM1CNT = 0;
  REG_TM1D = -(16.67*1000*1000)/(sndbuf_ch->Freq*mul);
  REG_TM1CNT = TM1CNT;
}

void sndbuf_SetPCM(u8* Data,u8 PCMType,u32 Size)
{
  sndbuf_ch->Data=Data;
  sndbuf_ch->PCMType=PCMType;
  sndbuf_ch->Size=Size;
  sndbuf_SetFreq(sndbuf_ch->Freq);
  ChangePCMProc=True;
}

void sndbuf_SetSrcPos(s32 SrcPos)
{
  sndbuf_ch->SrcPos=(u32)(SrcPos+sndbuf_ch->Size) % sndbuf_ch->Size;
  mc_amp=0;
  mc_estim=0;
  xn=0;
  stepsize=127;
}

void sndbuf_SetVolume(s32 Volume)
{
  if(Volume<0) Volume=0;
  sndbuf_ch->Volume=(u32)Volume;
  
  u32 cnt;
  for(cnt=0;cnt<49;cnt++){
    adpcm_estim[cnt]=adpcm_estim_master[cnt]*Volume/128;
  }
}

void farcall_sndbuf_SetKeyon(b8 Keyon)
{
  sndbuf_ch->Keyon=Keyon;
  ChangePCMProc=True;
  sndbuf_Resume();
}

u32 sndbuf_GetFreq(void)
{
  return(sndbuf_ch->Freq);
}

u32 sndbuf_GetSize(void)
{
  return(sndbuf_ch->Size);
}

u32 sndbuf_GetSrcPos(void)
{
  return(sndbuf_ch->SrcPos);
}

u32 sndbuf_GetVolume(void)
{
  return(sndbuf_ch->Volume);
}

b8 sndbuf_GetKeyon(void)
{
  return(sndbuf_ch->Keyon);
}

void sndbuf_StartPCM(void)
{
  sndbuf_Suspend();
  
  writebuf=sndbuf1;
  writebufno=0;
  sndbuf_playpos=sndbuf_DMA1Timeout-1;
  
  sndbuf_Init();
  sndbuf_Handler_PCMProc=0;
  
  s8 *twb;
  u32 cnt;
  twb=sndbuf0;
  for(cnt=0;cnt<(sndbuf_size+256);cnt++) twb[cnt]=0;
  twb=sndbuf1;
  for(cnt=0;cnt<(sndbuf_size+256);cnt++) twb[cnt]=0;
}

attriwram void farcall_sndbuf_DMA1_Handler(void)
{
  if(sndbuf_playpos!=0){
    sndbuf_playpos--;
    }else{
    sndbuf_playpos=sndbuf_DMA1Timeout-1;
    REG_DM1CNT_H= (sndbuf_REG_DM1CNT_H |DMA_TRANSFER_OFF);
    REG_DM1SAD   = (u32)(writebuf);
    REG_DM1CNT_H= (sndbuf_REG_DM1CNT_H |DMA_TRANSFER_ON);
    if(writebufno==0){
      writebuf=sndbuf0;
      writebufno=1;
      }else{
      writebuf=sndbuf1;
      writebufno=0;
    }
    if(ChangePCMProc==True) sndbuf_ResetChangePCMProc();
    sndbuf_Handler_PCMProc();
  }
}

void farcall_sndbuf_ResetChangePCMProc(void)
{
  ChangePCMProc=False;

  u32 *PCMProcSrc;
  u32 cnt;

  if(sndbuf_ch->Keyon==False){
    PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_Clear;
    }else{
    switch(sndbuf_ch->PCMType){
      case sndbuf_PCMType_unknown:
        PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_Clear;
        break;
      case sndbuf_PCMType_Linner8bit:
        PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_Linner8bit;
        break;
      case sndbuf_PCMType_ADPCM4bit:
        PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_ADPCM4bit;
        break;
      case sndbuf_PCMType_ADPCM4bitLinner2x:
        PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_ADPCM4bitLinner2x;
        break;
      case sndbuf_PCMType_YM2608:
        PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_YM2608;
        break;
      default:
        PCMProcSrc=(u32*)sndbuf_Handler_PCMProc_Clear;
        break;
    }
  }
  for(cnt=0;cnt<sndbuf_Handler_PCMProc_size/4;cnt++){
    sndbuf_Handler_PCMProc_data[cnt]=PCMProcSrc[cnt];
  }
  sndbuf_Handler_PCMProc=(void(*)(void))&sndbuf_Handler_PCMProc_data[0];
//  sndbuf_Handler_PCMProc=(void(*)(void))PCMProcSrc; // ROM��Ŏ��s����
}

void sndbuf_Handler_PCMProc_Clear(void)
{
  s8 *twb;
  u32 cnt;

  twb=writebuf;
  for(cnt=0;cnt<sndbuf_size;cnt++) twb[cnt]=0;
  sndbuf_Suspend();
}

void sndbuf_Handler_PCMProc_Linner8bit(void)
{
  Tsndbuf_Channel *tch=sndbuf_ch;

  u32 cnt;
  s8 *twb;
  u8 *tdata;
  twb=writebuf;
  tdata=(u8*)&tch->Data[tch->SrcPos];

  if((tch->SrcPos+sndbuf_size)>tch->Size){
    for(cnt=0;cnt<(tch->Size-tch->SrcPos);cnt++) twb[cnt]=tdata[cnt];
    for(cnt=(tch->Size-tch->SrcPos);cnt<sndbuf_size;cnt++) twb[cnt]=0;
    tch->SrcPos=0;
    sndbuf_SetKeyon(False);
    }else{
    for(cnt=0;cnt<sndbuf_size;cnt++) twb[cnt]=tdata[cnt];
    tch->SrcPos+=sndbuf_size;
  }
}

#define sndbuf_Handler_PCMProc_ADPCM4bit_Decode(_adpcmdata) {\
  adpcmdata=_adpcmdata;\
  tmc_amp+=tadpcm_estim[tmc_estim]*adpcm_estimindex[adpcmdata];\
  if((u32)(tmc_amp+sndbuf_s16Max)>(u32)(sndbuf_s16Max*2)){\
    if(tmc_amp<0){\
      tmc_amp=-sndbuf_s16Max;\
      }else{\
      tmc_amp=sndbuf_s16Max;\
    }\
  }\
  tmc_estim+=adpcm_estimstep[adpcmdata];\
  if((u32)tmc_estim>48){\
    if(tmc_estim<0){\
      tmc_estim=0;\
      }else{\
      tmc_estim=48;\
    }\
  }\
  *twb=(s8)(tmc_amp>>8);\
  twb++;\
}

void sndbuf_Handler_PCMProc_ADPCM4bit(void)
{
  Tsndbuf_Channel *tch=sndbuf_ch;

  u32 cnt;
  s8 *twb;
  u8 *tdata;
  twb=writebuf;
  tdata=(u8*)&tch->Data[tch->SrcPos];
  u8 adpcmdata;

  s32 *tadpcm_estim;
  s32 tmc_amp,tmc_estim;
  
  tadpcm_estim=adpcm_estim;
  tmc_amp=mc_amp;
  tmc_estim=mc_estim;
  
  if(((tch->Size-tch->SrcPos)*2)<sndbuf_size){
    for(cnt=(tch->Size-tch->SrcPos);cnt!=0;cnt--){
      sndbuf_Handler_PCMProc_ADPCM4bit_Decode(*tdata&0x0f);
      sndbuf_Handler_PCMProc_ADPCM4bit_Decode((*tdata>>4)&0x0f);
      tdata++;
    }
    s32 nullsize=sndbuf_size-((tch->Size-tch->SrcPos)*2);
    s32 release=tmc_amp;
    for(cnt=nullsize;cnt!=0;cnt--){
      if(release<0){
        release+=0x40;
        if(release>0) release=0;
      }
      if(release>0){
        release-=0x40;
        if(release<0) release=0;
      }
      *twb=(s8)(release>>8);
      twb++;
    }
    sndbuf_SetKeyon(False);
    }else{
    for(cnt=(sndbuf_size/2);cnt!=0;cnt--){
      sndbuf_Handler_PCMProc_ADPCM4bit_Decode(*tdata&0x0f);
      sndbuf_Handler_PCMProc_ADPCM4bit_Decode((*tdata>>4)&0x0f);
      tdata++;
    }
    tch->SrcPos+=sndbuf_size/2;
  }

  mc_amp=tmc_amp;
  mc_estim=tmc_estim;
}

#define sndbuf_Handler_PCMProc_ADPCM4bit_DecodeLinner2x(_adpcmdata) {\
  last_amp=tmc_amp;\
  adpcmdata=_adpcmdata;\
  tmc_amp+=tadpcm_estim[tmc_estim]*adpcm_estimindex[adpcmdata];\
  if((u32)(tmc_amp+sndbuf_s16Max)>(u32)(sndbuf_s16Max*2)){\
    if(tmc_amp<0){\
      tmc_amp=-sndbuf_s16Max;\
      }else{\
      tmc_amp=sndbuf_s16Max;\
    }\
  }\
  tmc_estim+=adpcm_estimstep[adpcmdata];\
  if((u32)tmc_estim>48){\
    if(tmc_estim<0){\
      tmc_estim=0;\
      }else{\
      tmc_estim=48;\
    }\
  }\
  *twb=(s8)((last_amp+tmc_amp)>>9);\
  twb++;\
  *twb=(s8)(tmc_amp>>8);\
  twb++;\
}

void sndbuf_Handler_PCMProc_ADPCM4bitLinner2x(void)
{
  Tsndbuf_Channel *tch=sndbuf_ch;

  u32 cnt;
  s8 *twb;
  u8 *tdata;
  twb=writebuf;
  tdata=(u8*)&tch->Data[tch->SrcPos];
  u8 adpcmdata;

  s32 *tadpcm_estim;
  s32 tmc_amp,tmc_estim;
  s32 last_amp;
  
  tadpcm_estim=adpcm_estim;
  tmc_amp=mc_amp;
  tmc_estim=mc_estim;
  
  if(((tch->Size-tch->SrcPos)*4)<sndbuf_size){
    for(cnt=(tch->Size-tch->SrcPos);cnt!=0;cnt--){
      sndbuf_Handler_PCMProc_ADPCM4bit_DecodeLinner2x(*tdata&0x0f);
      sndbuf_Handler_PCMProc_ADPCM4bit_DecodeLinner2x((*tdata>>4)&0x0f);
      tdata++;
    }
    s32 nullsize=sndbuf_size-((tch->Size-tch->SrcPos)*4);
    s32 release=tmc_amp;
    for(cnt=nullsize;cnt!=0;cnt--){
      if(release<0){
        release+=0x40;
        if(release>0) release=0;
      }
      if(release>0){
        release-=0x40;
        if(release<0) release=0;
      }
      *twb=(s8)(release>>8);
      twb++;
    }
    sndbuf_SetKeyon(False);
    }else{
    for(cnt=(sndbuf_size/4);cnt!=0;cnt--){
      sndbuf_Handler_PCMProc_ADPCM4bit_DecodeLinner2x(*tdata&0x0f);
      sndbuf_Handler_PCMProc_ADPCM4bit_DecodeLinner2x((*tdata>>4)&0x0f);
      tdata++;
    }
    tch->SrcPos+=sndbuf_size/4;
  }

  mc_amp=tmc_amp;
  mc_estim=tmc_estim;
}

#define sndbuf_Handler_PCMProc_YM2608_Decode(_adpcmdata) {\
  adpcmdata=_adpcmdata;\
  txn+=xnTable[adpcmdata]*tstepsize/8;\
  if((u32)(txn+sndbuf_s16Max)>(u32)(sndbuf_s16Max*2)){\
    if(txn<0){\
      txn=-sndbuf_s16Max;\
      }else{\
      txn=sndbuf_s16Max;\
    }\
  }\
  tstepsize=tstepsize*stepsizeTable[adpcmdata]/64;\
  if((u32)(tstepsize-127)>(u32)(-127+24576)){\
    if(tstepsize<127){\
      tstepsize=127;\
      }else{\
      tstepsize=24576;\
    }\
  }\
  *twb=(s8)(txn>>8);\
  twb++;\
}

void sndbuf_Handler_PCMProc_YM2608(void)
{
  Tsndbuf_Channel *tch=sndbuf_ch;

  u32 cnt;
  s8 *twb;
  u8 *tdata;
  twb=writebuf;
  tdata=(u8*)&tch->Data[tch->SrcPos];
  u8 adpcmdata;
  
  s32 txn,tstepsize;
  
  txn=xn;
  tstepsize=stepsize;
  
  if((tch->SrcPos+(sndbuf_size/2))>tch->Size){
    for(cnt=(tch->Size-tch->SrcPos);cnt!=0;cnt--){
      sndbuf_Handler_PCMProc_YM2608_Decode((*tdata>>4)&0x0f);
      sndbuf_Handler_PCMProc_YM2608_Decode(*tdata&0x0f);
      tdata++;
    }
    u32 nullsize=sndbuf_size-((tch->Size-tch->SrcPos)*2);
    for(cnt=nullsize;cnt!=0;cnt--){
      *twb=(s8)((txn*cnt/nullsize)>>8);
      twb++;
    }
    tch->SrcPos=0;
    sndbuf_SetKeyon(False);
    }else{
    for(cnt=(sndbuf_size/2);cnt!=0;cnt--){
      sndbuf_Handler_PCMProc_YM2608_Decode((*tdata>>4)&0x0f);
      sndbuf_Handler_PCMProc_YM2608_Decode(*tdata&0x0f);
      tdata++;
    }
    tch->SrcPos+=sndbuf_size/2;
  }

  xn=txn;
  stepsize=tstepsize;
}
