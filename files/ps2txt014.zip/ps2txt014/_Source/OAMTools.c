
#define OAM_DATA_SIZE 8192
#define OAM_PALETTE_SIZE 16
extern const u16 OAM_data[];
extern const u16 OAM_palette[];

u32 IconIdx;

void SetOAM(void)
{
  InitializeSprites();

  SetOAMCHR(0,256/2,(u16*)OAM_data,0,16,(u16*)OAM_palette);
  
  ChangeSprite(3,0);
  SetSpriteSize(3,SP_SIZE_32,SP_SQUARE,SP_COLOR_16);
  SetSpriteMode(3,SP_MODE_TRANSPERANT);
  SetSpriteRotation(3,False);
  SetSpritePriority(3,0);
  MoveSprite(3,240,160);
  
  REG_DISPCNT|=OBJ_ENABLE | OBJ_MAP_1D;
}

void IconStart(u32 x,u32 y)
{
  IconIdx=15;
  MoveSprite(3,x,y);
}

void IconNext(void)
{
  if(IconIdx==0) IconIdx=32;
  IconIdx--;
  ChangeSprite(3,IconIdx/2*16);
}

void IconEnd(void)
{
  MoveSprite(3,240,160);
}

