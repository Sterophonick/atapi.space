
typedef unsigned char du8;
typedef unsigned short du16;
typedef unsigned long du32;

typedef signed char ds8;
typedef signed short ds16;
typedef signed long ds32;
typedef signed long long int ds64;

static ds32 printf_udeci(du32 u,ds8 *s,ds32 i){
	du32 div,flg;
	div=1000000000;
	flg=0;
	for(;;){
		if(u/div){
			s[i++]='0'+(u/div);
			flg=1;
			u-=(u/div)*div;
		}
		else if(flg || (div==1)){
			s[i++]='0';
		}
		div=div/10;
		if(div==0) break;
	}
	return(i);
}

const ds8 printf_hexchar[16]={
'0','1','2','3','4','5','6','7',
'8','9','A','B','C','D','E','F'
};

static ds32 printf_hex(du32 u,ds8 *s,ds32 i){
	du32 div,flg;
	div=0x10000000;
	flg=0;
	for(;;){
		if(u/div){
			s[i++]=printf_hexchar[u/div];
			flg=1;
			u-=(u/div)*div;
		}
		else if(flg || (div==1)){
			s[i++]='0';
		}
		div=div/16;
		if(div==0) break;
	}
	return(i);
}

//	%d:��������P�O�i��
//	%u:�����Ȃ��P�O�i��
//	%x:�P�U�i��
//	%s:������
//	%c:����
//	\n:���s

static du8 resprintf[128];

void uprintf(va_alist) va_dcl{
	va_list args;
	ds32 i,d;
	du32 u;
	ds8 *ss;
	ds8 *fmt;
	ds8 *s;

	s=(du8*)resprintf;
	va_start(args);
	fmt=va_arg(args,char *);
	for(i=0;;){
		if(*fmt=='%'){
			switch(fmt[1]){
			case 'd':		//	%d:��������P�O�i��
				fmt+=2;
				d=va_arg(args,ds32);
				if(d<0){
					s[i++]='-';
					u=-d;
				}
				else{
					u=d;
				}
				i=printf_udeci(u,s,i);
				break;
			case 'u':		//	%u:�����Ȃ��P�O�i��
				fmt+=2;
				u=va_arg(args,du32);
				i=printf_udeci(u,s,i);
				break;
			case 'x':		//	%x:�P�U�i��
				fmt+=2;
				u=va_arg(args,du32);
				i=printf_hex(u,s,i);
				break;
			case 's':		//	%s:������
				fmt+=2;
				ss=va_arg(args,ds8 *);
				for(d=0;;d++){
					if(ss[d]==0) break;
					s[i++]=ss[d];
				}
				break;
			case 'c':		//	%c:����
				fmt+=2;
				d=va_arg(args,ds32);
				s[i++]=d;
				break;
			default:
				s[i++]=*fmt;
				fmt++;
				break;
			}
		}
		else{
			if((i>240)||(*fmt==0)){
				s[i++]=0;
				break;
			}
			s[i++]=*fmt;
			fmt++;
		}
	}
	va_end(args);
	s[i++]=0x00;
}

void dprint(const char *sz)
{
  const du32 port=0xc0ded00d;
//	"ldr r0, =0xc0ded00d\n"
	asm volatile(
	"mov r2, %0\n"
	"mov r0, %1\n"
	"mov r1, #0\n"
	"and r0, r0, r0\n"
  :
  :
  "r" (sz) ,"r" (port):
  "r0", "r1", "r2");
}

extern du8 __iwram_overlay_start;

void memchkinit(void)
{
  du32 *mem_start,*mem_end,*mem_stock;
  du32 mem_size;
  
  mem_start=(du32*)&_impure_ptr;
  mem_end=(du32*)&__iwram_overlay_start;
  mem_stock=(du32*)0x02000000;
  mem_size=((du32)mem_end)-((du32)mem_start);
  
  mem_start+=0x8000*0;
  
  du32 cnt;
  du32 *sp=mem_start;
  du32 *dp=mem_stock;
  
  for(cnt=0;cnt<(mem_size/4);cnt++){
    mem_stock[cnt]=mem_start[cnt];
    sp++;
    dp++;
  }
  
  dprint("\n");
  uprintf("memchk start at 0x%x\n",(du32)mem_start);
  dprint(resprintf);
  uprintf("memchk stock at 0x%x\n",(du32)mem_stock);
  dprint(resprintf);
  uprintf("memchk size=0x%x\n",mem_size);
  dprint(resprintf);
}

du32 memchk(void)
{
  du32 *mem_start,*mem_end,*mem_stock;
  du32 mem_size;
  
  mem_start=(du32*)&_impure_ptr;
  mem_end=(du32*)&__iwram_overlay_start;
  mem_stock=(du32*)0x02000000;
  mem_size=((du32)mem_end)-((du32)mem_start);
  
  mem_start+=0x8000*0;
  
  du32 cnt;
  du32 *sp=mem_start;
  du32 *dp=mem_stock;
  
  for(cnt=0;cnt<(mem_size/4);cnt++){
    if(*sp!=*dp){
      uprintf("iwramerr at 0x%x/%d [0x%x!=0x%x]\n",(du32)sp,cnt,*sp,*dp);
      dprint(resprintf);
      return((du32)sp);
    }
    sp++;
    dp++;
  }
  return(0);
}

