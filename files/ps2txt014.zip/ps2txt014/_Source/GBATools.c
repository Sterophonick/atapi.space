#ifndef	GBATools_H
#define	GBATools_H

#include "header\GBA.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\IRQ.h"

#include <varargs.h>

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

u8 res_inttostr[32];
u8 irqres_inttostr[32];
u8 isAnkChar[0x100]; // boolean�^

void WaitForVsync(void); // Func.0
attriwram void fp_inttostr(int cnt,u8 len); // Func.1
void (*inttostr)(int cnt,u8 len)=fp_inttostr;
void inttostrZeroPadding(int cnt,u8 len); // Func.2
void u32tostr(u32 cnt,u8 len); // Func.3
void irqinttostr(int cnt,u8 len); // Func.4
void fp_Init_isAnkChar(void); // Func.5
void (*Init_isAnkChar)(void)=fp_Init_isAnkChar;

void WaitForVsync(void)
{
  funcadd(FuncC_GBATools,0);
  
  // HALT�������荞��(IE)���ݒ肳��Ă��邱�Ƃ������B
  VBlank_Signal=False;
  while(VBlank_Signal==False){
    asm("swi 0x020000");
  }
  
/*
  // ���ʂ�VSYNC�҂�
  while (*(volatile u16*)0x4000006 >= 160) {};
  while (*(volatile u16*)0x4000006 < 160) {};
*/
}

void fp_inttostr(int cnt,u8 len)
{
  funcadd(FuncC_GBATools,1);
  
  if (cnt<0){
    res_inttostr[0]='-';
    res_inttostr[1]='?';
    res_inttostr[2]=0;
    return;
  }
  
  int i;

  for(i=len-1;i>=0;i--){
    if(cnt==0)
    {
      res_inttostr[i]=' ';
      }else{
      res_inttostr[i]=(cnt%10)+'0';
    }
    cnt/=10;
  }

  if(res_inttostr[len-1]==' ')
  {
    res_inttostr[len-1]='0';
  }

  res_inttostr[len]=0;
}

void inttostrZeroPadding(int cnt,u8 len)
{
  funcadd(FuncC_GBATools,2);
  
  int i;
  
  for(i=len-1;i>=0;i--){
    res_inttostr[i]=(cnt%10)+'0';
    cnt/=10;
  }

  res_inttostr[len]=0;
}

void u32tostr(u32 cnt,u8 len)
{
  funcadd(FuncC_GBATools,3);
  
  int i;
  
  for(i=len-1;i>=0;i--){
    if(cnt==0)
    {
      res_inttostr[i]=' ';
      }else{
      res_inttostr[i]=(cnt%10)+'0';
    }
    cnt/=10;
  }

  if(res_inttostr[len-1]==' ')
  {
    res_inttostr[len-1]='0';
  }

  res_inttostr[len]=0;
}

void irqinttostr(int cnt,u8 len)
{
  funcadd(FuncC_GBATools,4);
  
  if (cnt<0){
    irqres_inttostr[0]='-';
    irqres_inttostr[1]='?';
    irqres_inttostr[2]=0;
    return;
  }
  
  int i;

  for(i=len-1;i>=0;i--){
    if(cnt==0)
    {
      irqres_inttostr[i]=' ';
      }else{
      irqres_inttostr[i]=(cnt%10)+'0';
    }
    cnt/=10;
  }

  if(irqres_inttostr[len-1]==' ')
  {
    irqres_inttostr[len-1]='0';
  }

  irqres_inttostr[len]=0;
}

void fp_Init_isAnkChar(void)
{
  funcadd(FuncC_GBATools,5);
  
//  __attribute__ ((always_inline, const))
  static inline u8 chk(u8 c)
  {
    if (c<=0x7f) return(True);
    if (c<=0x9f) return(False);
    if (c<=0xdf) return(True);
  
    switch(c){
      case 0xE0: return(False);
      case 0xE1: return(False);
      case 0xE2: return(False);
      case 0xE3: return(False);
      case 0xE4: return(False);
      case 0xE5: return(False);
      case 0xE6: return(False);
      case 0xE7: return(False);
      case 0xE8: return(False);
      case 0xE9: return(False);
      case 0xEA: return(False);
      case 0xEB: return(True);
      case 0xEC: return(True);
      case 0xED: return(False);
      case 0xEE: return(False);
      case 0xEF: return(True);
      case 0xF0: return(False);
      case 0xF1: return(False);
      case 0xF2: return(False);
      case 0xF3: return(False);
      case 0xF4: return(True);
      case 0xF5: return(True);
      case 0xF6: return(True);
      case 0xF7: return(True);
      case 0xF8: return(True);
      case 0xF9: return(True);
      case 0xFA: return(False);
      case 0xFB: return(False);
      case 0xFC: return(False);
      case 0xFD: return(True);
      case 0xFE: return(True);
      case 0xFF: return(True);
    }
    
    return(True);
  }

  u32 c;
  for(c=0x00;c<=0xff;c++){
    isAnkChar[c]=chk(c);
  }
}

#endif
