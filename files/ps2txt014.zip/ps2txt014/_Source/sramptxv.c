
typedef struct {
  u8 Filename[128];
  u32 LastPosition;
  u32 SavePosition[4];
  u32 SaveDate[4];
  u32 SaveTime[4];
} TSRAM_State;

typedef struct {
  u32 ID;
  u32 SRAMVersion;
  u32 MenuLastPage;
  u32 FontPackIndex;
  b32 LoadAutoState;
  u32 LineSpace;
  u32 KeyRepeatTime;
  b32 se_AllEnabled;
  b32 se_Linner2x;
  u32 se_Volume;
  b32 se_Enabled[16];
  u32 se_dummy[16];
  u32 LineTabStop;
  b32 LineShowTab;
  u32 ThemeState;
  u32 ReturnPogoShellKeys;
  u32 set_dummy[48-4];
  u32 StateCount;
  TSRAM_State State[];
} TSRAM;

TSRAM *SRAM;
TSRAM_State *SRAM_CurrentState;

const u8 *SRAM_Data=(u8*)0x0e000000;
const u32 SRAM_Size=0x10000;

u8 *SRAM_GetPtr8(u8 *ptr)
{
  return((u8*)&SRAM_Data[(u32)&ptr[0]]);
}

void SRAM_Write32(u32 *ptr,u32 v)
{
  u8 *ptr8=SRAM_GetPtr8((u8*)ptr);
  
  ptr8[0]=(u8)((v&0x000000ff)>>0);
  ptr8[1]=(u8)((v&0x0000ff00)>>8);
  ptr8[2]=(u8)((v&0x00ff0000)>>16);
  ptr8[3]=(u8)((v&0xff000000)>>24);
}

u32 SRAM_Read32(u32 *ptr)
{
  u8 *ptr8=SRAM_GetPtr8((u8*)ptr);
  u32 r;
  
  r=((u32)ptr8[0])<<0;
  r+=((u32)ptr8[1])<<8;
  r+=((u32)ptr8[2])<<16;
  r+=((u32)ptr8[3])<<24;
  
  return(r);
}

void SRAM_CreateState(u8 *Filename)
{
  u32 Count;
  Count=SRAM_Read32(&SRAM->StateCount)+1;
  SRAM_Write32(&SRAM->StateCount,Count);
  
  SRAM_CurrentState=&SRAM->State[Count-1];
  
  u8 *DstFilename;
  DstFilename=SRAM_GetPtr8(&SRAM_CurrentState->Filename[0]);
  u32 strcnt;
  
  for(strcnt=0;strcnt<128;strcnt++){
    DstFilename[strcnt]=Filename[strcnt];
  }
  
}

void SRAM_SelectState(u8 *Filename)
{
  u32 Count;
  Count=SRAM_Read32(&SRAM->StateCount);
  
  u32 i;
  for(i=0;i<Count;i++){
    SRAM_CurrentState=&SRAM->State[i];
    
    u8 *SrcFilename;
    SrcFilename=SRAM_GetPtr8(&SRAM_CurrentState->Filename[0]);
    u32 strcnt;
    
    b8 cmpf=True;
    
    for(strcnt=0;strcnt<128;strcnt++){
      if(SrcFilename[strcnt]!=Filename[strcnt]){
        cmpf=False;
        break;
      }
    }
    if(cmpf==True) return;
  }
  
  SRAM_CreateState(Filename);
}

void SRAM_Init(void)
{
  u32 cnt;
  
  SRAM=0;
  
  SRAM_Write32(&SRAM->ID,0x56585450); // ID:PTXV
  SRAM_Write32(&SRAM->SRAMVersion,2);
  SRAM_Write32(&SRAM->MenuLastPage,0);
  SRAM_Write32(&SRAM->FontPackIndex,1);
  SRAM_Write32(&SRAM->LoadAutoState,False);
  SRAM_Write32(&SRAM->LineSpace,1);
  SRAM_Write32(&SRAM->KeyRepeatTime,250);

  SRAM_Write32(&SRAM->se_AllEnabled,True);
  SRAM_Write32(&SRAM->se_Linner2x,True);
  SRAM_Write32(&SRAM->se_Volume,64);
  
  for(cnt=0;cnt<16;cnt++){
    SRAM_Write32(&SRAM->se_Enabled[cnt],True);
  }
  SRAM_Write32(&SRAM->se_Enabled[1],False); // ISE_Page
  
  for(cnt=0;cnt<16;cnt++){
    SRAM_Write32(&SRAM->se_dummy[cnt],0);
  }
  
  SRAM_Write32(&SRAM->LineTabStop,4);
  SRAM_Write32(&SRAM->LineShowTab,True);
  
  SRAM_Write32(&SRAM->ThemeState,0);
  
  SRAM_Write32(&SRAM->ReturnPogoShellKeys,0);
  
  for(cnt=0;cnt<48-4;cnt++){
    SRAM_Write32(&SRAM->set_dummy[cnt],0);
  }

  SRAM_Write32(&SRAM->StateCount,0);
}

void SRAM_Start(void)
{
  SRAM=0;
  
  if(SRAM_Read32(&SRAM->ID)!=0x56585450){
    SRAM_Init();
  }
  if(SRAM_Read32(&SRAM->SRAMVersion)!=2){
    SRAM_Init();
  }
  
  u32 v;
  
  v=SRAM_Read32(&SRAM->MenuLastPage);
  if(6<v) SRAM_Write32(&SRAM->MenuLastPage,0);
  
  v=SRAM_Read32(&SRAM->FontPackIndex);
  if(v==0) SRAM_Write32(&SRAM->FontPackIndex,1);
  if(7<v) SRAM_Write32(&SRAM->FontPackIndex,1);
  
  v=SRAM_Read32(&SRAM->LineSpace);
  if(8<v) SRAM_Write32(&SRAM->LineSpace,8);
  
  v=SRAM_Read32(&SRAM->KeyRepeatTime);
  if(v<200) SRAM_Write32(&SRAM->KeyRepeatTime,200);
  if(1000<v) SRAM_Write32(&SRAM->KeyRepeatTime,1000);
  
  v=SRAM_Read32(&SRAM->LineTabStop);
  if(v==0){
    SRAM_Write32(&SRAM->LineTabStop,4);
    SRAM_Write32(&SRAM->LineShowTab,True);
    }else{
    if(v<1) SRAM_Write32(&SRAM->LineTabStop,1);
    if(v>16) SRAM_Write32(&SRAM->LineTabStop,16);
  }
  
  v=SRAM_Read32(&SRAM->ThemeState);
  if(3<v) SRAM_Write32(&SRAM->ThemeState,0);
  
  v=SRAM_Read32(&SRAM->ReturnPogoShellKeys);
  if(2<v) SRAM_Write32(&SRAM->ReturnPogoShellKeys,1);
}

void SRAM_AllClear(void)
{
  dprint("SRAM_AllClear\n");
  
  volatile u8 *sram=(u8*)0x0e000000;
  u32 size=0xffff;
  
  u32 cnt;
  for(cnt=0;cnt<size;cnt++){
    sram[cnt]=0x00;
  }
  sram[0]=0xff;
}

void SRAM_SaveIWRAM(void)
{
  dprint("SRAM_SaveIWRAM\n");
  
  volatile u8 *iwram=(u8*)0x03000000;
  volatile u8 *sram=(u8*)0x0e008000;
  u32 size=0x8000;
  
  u32 cnt;
  for(cnt=0;cnt<size;cnt++){
    sram[cnt]=iwram[cnt];
  }
}

