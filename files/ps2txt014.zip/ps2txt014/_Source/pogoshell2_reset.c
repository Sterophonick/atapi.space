
#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

extern void pogoshell2_Visoly_doReset(void);
extern void pogoshell2_XROM_doReset(u32 jump,u32 offset);

u8 ResetType[16]="ResetTypeID:\1\0\0\0";

attriwram void ResetAutoDetect(void)
{
  pogoshell2_Visoly_doReset();
  *(volatile u16*)0x096B592E=0x0;
  pogoshell2_XROM_doReset(0,0);
  asm("swi #0x000000");
  while(1);
}

attriwram void ResetVisoly(void)
{
  pogoshell2_Visoly_doReset();
  *(volatile u16*)0x096B592E=0x0;
  asm("swi #0x000000");
  while(1);
}

attriwram void ResetXROM(void)
{
  pogoshell2_XROM_doReset(0,0);
  asm("swi #0x000000");
  while(1);
}

attriwram void fp_ReturnPogoShell2(void)
{
  REG_IME=IRQ_MASTER_OFF;
  REG_IE=0;
  REG_IF=0;
  
  REG_DM0CNT_H=0;
  REG_DM1CNT_H=0;
  REG_DM2CNT_H=0;
  REG_DM3CNT_H=0;
  REG_DISPSTAT=0;
  
  REG_INTERUPT=0;
  
  REG_BG2X=0;
  REG_BG2Y=0;
  REG_BG2PA=0x100;
  REG_BG2PD=0x100;
  
  u16 loadkeys=1;
  while(loadkeys!=0){
    loadkeys=(~*KEYS)&0x3ff;
  }
  
  u32 *ID=(u32*)&ResetType[12];
  
  switch(*ID){
    case 1:
      dprint("ExecuteReset:Visoly\n");
      ResetVisoly();
      break;
    case 2:
      dprint("ExecuteReset:XROM\n");
      ResetXROM();
      break;
    default:
      dprint("ExecuteReset:AutoDetect\n");
      ResetAutoDetect();
      break;
  }
}
void (*ReturnPogoShell2)(void)=&fp_ReturnPogoShell2;

