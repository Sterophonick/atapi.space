
typedef struct {
  u8 ID[6];
  u8 dummy[2];
  u32 BlendType;
  u32 TextAlpha;
  u32 BGAlpha;
  u8 BGPal[16*3];
  u8 BG[256/2*160];
} TBGBM;

const u32 BGBM[(6+2+(3*4)+(16*3)+(256/2*160))/4]={0x4d424742,0x00003130, 0,13,4}; // BGBM01__
const TBGBM *pBGBM=(TBGBM*)&BGBM[0];

void SetOAMBG(void)
{
  REG_DISPCNT&=~OBJ_ENABLE;
  
  SetOAMCHR(256/2,((256/8)*(160/8))/2,(u16*)&pBGBM->BG[0],16,0,0);
  
  u16 *pal=OBJpal;
  u32 palcnt;
  
  for(palcnt=0;palcnt<16;palcnt++){
    pal[16+palcnt]=RGB(pBGBM->BGPal[palcnt*3+2],pBGBM->BGPal[palcnt*3+1],pBGBM->BGPal[palcnt*3+0]);
  }
  
  u32 x,y;
  u32 tileno;
  u32 objno;
  
  for(y=0;y<(160/32);y++){
    for(x=0;x<(256/32);x++){
      tileno=(y*(256/32))+x;
      objno=tileno+4;
      tileno=256+(tileno*16);
      
      ChangeSprite(objno,tileno);
      SetSpriteSize(objno,SP_SIZE_32,SP_SQUARE,SP_COLOR_16);
      SetSpriteMode(objno,SP_MODE_TRANSPERANT);
      SetSpriteRotation(objno,False);
      SetSpritePriority(objno,1);
      SetSpritePalette(objno,1);
      MoveSprite(objno,x*32,y*32);
      
    }
  }
  
  REG_BLDMOD=BLEND_TOP_OBJ | BLEND_LOW_BG0 | BLEND_MODE_ALPHA;
  if(SRAM_Read32(&SRAM->ThemeState)==1){
    REG_COLEV=BLEND_HIGH(pBGBM->TextAlpha)+BLEND_LOW(pBGBM->BGAlpha);
    }else{
    REG_COLEV=BLEND_HIGH(16)+BLEND_LOW(0);
  }
  
  REG_DISPCNT|=OBJ_ENABLE;
}


