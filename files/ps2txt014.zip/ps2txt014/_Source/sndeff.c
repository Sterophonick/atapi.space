
#define ISE_FirstBoot (0)
#define ISE_Page (1)
#define ISE_DialogInfo (2)
#define ISE_DialogQuestion (3)
#define ISE_DialogWarrning (4)
#define ISE_MenuOpen (5)
#define ISE_MenuMove (6)
#define ISE_MenuCancel (7)
#define ISE_MenuSuccess (8)

#define ISE_Count (9)
#define ISE_Null ISE_Count

extern const u8 SE_FirstBoot;
extern const u8 SE_Page;
extern const u8 SE_DialogInfo;
extern const u8 SE_DialogQuestion;
extern const u8 SE_DialogWarrning;
extern const u8 SE_MenuOpen;
extern const u8 SE_MenuMove;
extern const u8 SE_MenuCancel;
extern const u8 SE_MenuSuccess;

void PlaySound(u32 idx)
{
  uprintf("call PlaySound(%d);\n",idx);
  dprint(resprintf);
  
  if(idx==ISE_Null) return;
  if(SRAM_Read32(&SRAM->se_AllEnabled)==False) return;
  if(SRAM_Read32(&SRAM->se_Enabled[idx])==False) return;
  
  Tsndbuf_Channel ch;
  
  ch.Data=0;
  if(SRAM_Read32(&SRAM->se_Linner2x)==False){
    ch.PCMType=sndbuf_PCMType_ADPCM4bit;
    }else{
    ch.PCMType=sndbuf_PCMType_ADPCM4bitLinner2x;
  }
  ch.Size=0;
  ch.Freq=15647;
  ch.Volume=SRAM_Read32(&SRAM->se_Volume);
  ch.Keyon=True;
  ch.SrcPos=0;
  
  switch(idx){
    case ISE_FirstBoot:
      ch.Data=(u8*)&SE_FirstBoot;
      ch.Size=2181;
      break;
    case ISE_Page:
      ch.Data=(u8*)&SE_Page;
      ch.Size=2907;
      break;
    case ISE_DialogInfo:
      ch.Data=(u8*)&SE_DialogInfo;
      ch.Size=1336;
      break;
    case ISE_DialogQuestion:
      ch.Data=(u8*)&SE_DialogQuestion;
      ch.Size=1454;
      break;
    case ISE_DialogWarrning:
      ch.Data=(u8*)&SE_DialogWarrning;
      ch.Size=2907;
      break;
    case ISE_MenuOpen:
      ch.Data=(u8*)&SE_MenuOpen;
      ch.Size=6145;
      break;
    case ISE_MenuMove:
      ch.Data=(u8*)&SE_MenuMove;
      ch.Size=890;
      break;
    case ISE_MenuCancel:
      ch.Data=(u8*)&SE_MenuCancel;
      ch.Size=4360;
      break;
    case ISE_MenuSuccess:
      ch.Data=(u8*)&SE_MenuSuccess;
      ch.Size=13079;//4360;
      break;
  }
  
  sndbuf_SetAttribute(&ch,True,True,True);
}

/*
// pcm3pcm.x only
void PlaySound(u32 idx)
{
  uprintf("call PlaySound(%d);\n",idx);
  dprint(resprintf);
  
  if(idx==ISE_Null) return;
  if(SRAM_Read32(&SRAM->se_AllEnabled)==False) return;
  if(SRAM_Read32(&SRAM->se_Enabled[idx])==False) return;
  
  Tsndbuf_Channel ch;
  
  ch.Data=0;
  if(SRAM_Read32(&SRAM->se_Linner2x)==False){
    ch.PCMType=sndbuf_PCMType_ADPCM4bit;
    }else{
    ch.PCMType=sndbuf_PCMType_ADPCM4bitLinner2x;
  }
  ch.Size=0;
  ch.Freq=15647;
  ch.Volume=SRAM_Read32(&SRAM->se_Volume);
  ch.Keyon=True;
  ch.SrcPos=0;
  
  switch(idx){
    case ISE_FirstBoot:
      ch.Data=(u8*)&SE_FirstBoot;
      ch.Size=2088;
      break;
    case ISE_Page:
      ch.Data=(u8*)&SE_Page;
      ch.Size=3456;
      break;
    case ISE_DialogInfo:
      ch.Data=(u8*)&SE_DialogInfo;
      ch.Size=1161;
      break;
    case ISE_DialogQuestion:
      ch.Data=(u8*)&SE_DialogQuestion;
      ch.Size=1852;
      break;
    case ISE_DialogWarrning:
      ch.Data=(u8*)&SE_DialogWarrning;
      ch.Size=2191;
      break;
    case ISE_MenuOpen:
      ch.Data=(u8*)&SE_MenuOpen;
      ch.Size=7266;
      break;
    case ISE_MenuMove:
      ch.Data=(u8*)&SE_MenuMove;
      ch.Size=890;
      break;
    case ISE_MenuCancel:
      ch.Data=(u8*)&SE_MenuCancel;
      ch.Size=5189;
      break;
    case ISE_MenuSuccess:
      ch.Data=(u8*)&SE_MenuSuccess;
      ch.Size=3456;
      break;
  }
  
  sndbuf_SetAttribute(&ch,True,True,True);
}
*/
