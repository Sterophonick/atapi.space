

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

typedef signed char s8;
typedef signed short s16;
typedef signed long s32;
typedef signed long long int s64;

#include "_customdiv.h"

//#include "_customdiv_divtbl.c"
#include "_customdiv_DIVSI3.h"

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

//s32 _divs32_clib(s32 s0,s32 s1); // 48byte
//s32 _divs32_user_clib(s32 s0,s32 s1); // 268byte
//s32 _divs32_user_normal(s32 s0,s32 s1); // 264byte
//s32 _divs32_user_shl2(s32 s0,s32 s1); // 428byte
//s32 _divs32_user_shl2unroll(s32 s0,s32 s1); // 1724byte
//attriwram s32 _divs32_rapper(s32 s0,s32 s1);
//s32 (*divs32)(s32 s0,s32 s1)=_divs32_rapper;

//attriwram s16 _divs16_rapper(s16 s0,s16 s1);
//s16 (*divs16)(s16 s0,s16 s1)=_divs16_rapper;

//u32 _divu32_user_shl2unroll(u32 s0,u32 s1);
s32 (*divu32)(s32 s0,s32 s1)=__divsi3_iwram;

/*
s32 _divs32_clib(s32 s0,s32 s1)
{
  return(s0/s1);
}

s32 _divs32_user_clib(s32 s0,s32 s1)
{
  unsigned al=__builtin_abs(s0);
  unsigned b2=__builtin_abs(s1);
  unsigned ah;
  unsigned tmpf;
  int i;
  
  for(i=16;i>0;i--){
    ah=(ah<<1)|(al>>31);
    tmpf=(ah>=b2) ? 1:0;
    ah-=(tmpf ? b2:0);
    al=(al<<1)|tmpf;
  }
  
  if(s0<0) al=-al;
  if(s1<0) al=-al;
  
  return(al);
}

s32 _divs32_user_normal(s32 s0,s32 s1)
{
  if((s0==0)||(s1==0)) return(0);
  
  s32 r=0;
  s32 flag=1;
  
  if(s0<0){
    flag=-flag;
    s0=-s0;
  }
  if(s1<0){
    flag=-flag;
    s1=-s1;
  }
  
  if(s0==s1){
    r=1;
    }else{
    while(s0>=s1){
      s0-=s1;
      r++;
    }
  }
  
  if(flag==1){
    return(r);
    }else{
    return(-r);
  }
}

s32 _divs32_user_shl2(s32 s0,s32 s1)
{
  if((s0==0)||(s1==0)) return(0);
  
  s32 r=0;
  s32 flag=1;
  
  if(s0<0){
    flag=-flag;
    s0=-s0;
  }
  if(s1<0){
    flag=-flag;
    s1=-s1;
  }
  
  if(s0==s1){
    r=1;
    }else{
    s32 cnt;
    s32 maxbit;
    u32 d;
    
    maxbit=0;
    for(cnt=16-1;cnt>=0;cnt--){
      if(s1>=(1<<cnt)){
        maxbit=cnt;
        break;
      }
    }
    
    maxbit=16-maxbit;
    for(cnt=maxbit-1;cnt>=0;cnt--){
      d=s1<<cnt;
      if(d<=s0){
        r+=1<<cnt;
        s0-=d;
      }
    }
  }
  
  if(flag==1){
    return(r);
    }else{
    return(-r);
  }
}

s32 _divs32_user_shl2unroll(s32 s0,s32 s1)
{
  if((s0==0)||(s1==0)) return(0);
  
  s32 r=0;
  s32 flag=1;
  
  if(s0<0){
    flag=-flag;
    s0=-s0;
  }
  if(s1<0){
    flag=-flag;
    s1=-s1;
  }
  
  if(s0==s1){
    r=1;
    }else{
    s32 maxbit;
    u32 d;
    
    if(s1>=(1<<15)){
      maxbit=15;
      }else{
      if(s1>=(1<<14)){
        maxbit=14;
        }else{
        if(s1>=(1<<13)){
          maxbit=13;
          }else{
          if(s1>=(1<<12)){
            maxbit=12;
            }else{
            if(s1>=(1<<11)){
              maxbit=11;
              }else{
              if(s1>=(1<<10)){
                maxbit=10;
                }else{
                if(s1>=(1<<9)){
                  maxbit=9;
                  }else{
                  if(s1>=(1<<8)){
                    maxbit=8;
                    }else{
                    if(s1>=(1<<7)){
                      maxbit=7;
                      }else{
                      if(s1>=(1<<6)){
                        maxbit=6;
                        }else{
                        if(s1>=(1<<5)){
                          maxbit=5;
                          }else{
                          if(s1>=(1<<4)){
                            maxbit=4;
                            }else{
                            if(s1>=(1<<3)){
                              maxbit=3;
                              }else{
                              if(s1>=(1<<2)){
                                maxbit=2;
                                }else{
                                if(s1>=(1<<1)){
                                  maxbit=1;
                                  }else{
                                  maxbit=0;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    
    maxbit=16-maxbit-1;
    if(maxbit>=15){ d=s1<<15; if(d<=s0){ r+=1<<15; s0-=d; } }
    if(maxbit>=14){ d=s1<<14; if(d<=s0){ r+=1<<14; s0-=d; } }
    if(maxbit>=13){ d=s1<<13; if(d<=s0){ r+=1<<13; s0-=d; } }
    if(maxbit>=12){ d=s1<<12; if(d<=s0){ r+=1<<12; s0-=d; } }
    if(maxbit>=11){ d=s1<<11; if(d<=s0){ r+=1<<11; s0-=d; } }
    if(maxbit>=10){ d=s1<<10; if(d<=s0){ r+=1<<10; s0-=d; } }
    if(maxbit>=9){ d=s1<<9; if(d<=s0){ r+=1<<9; s0-=d; } }
    if(maxbit>=8){ d=s1<<8; if(d<=s0){ r+=1<<8; s0-=d; } }
    if(maxbit>=7){ d=s1<<7; if(d<=s0){ r+=1<<7; s0-=d; } }
    if(maxbit>=6){ d=s1<<6; if(d<=s0){ r+=1<<6; s0-=d; } }
    if(maxbit>=5){ d=s1<<5; if(d<=s0){ r+=1<<5; s0-=d; } }
    if(maxbit>=4){ d=s1<<4; if(d<=s0){ r+=1<<4; s0-=d; } }
    if(maxbit>=3){ d=s1<<3; if(d<=s0){ r+=1<<3; s0-=d; } }
    if(maxbit>=2){ d=s1<<2; if(d<=s0){ r+=1<<2; s0-=d; } }
    if(maxbit>=1){ d=s1<<1; if(d<=s0){ r+=1<<1; s0-=d; } }
    d=s1<<0; if(d<=s0){ r+=1<<0; s0-=d; }
  }
  
  if(flag==1){
    return(r);
    }else{
    return(-r);
  }
}

u32 _divu32_user_shl2unroll(u32 s0,u32 s1)
{
  s32 r=0;
  
  if(s0==s1){
    r=1;
    }else{
    s32 maxbit;
    u32 d;
    
    if(s1>=(1<<15)){
      maxbit=15;
      }else{
      if(s1>=(1<<14)){
        maxbit=14;
        }else{
        if(s1>=(1<<13)){
          maxbit=13;
          }else{
          if(s1>=(1<<12)){
            maxbit=12;
            }else{
            if(s1>=(1<<11)){
              maxbit=11;
              }else{
              if(s1>=(1<<10)){
                maxbit=10;
                }else{
                if(s1>=(1<<9)){
                  maxbit=9;
                  }else{
                  if(s1>=(1<<8)){
                    maxbit=8;
                    }else{
                    if(s1>=(1<<7)){
                      maxbit=7;
                      }else{
                      if(s1>=(1<<6)){
                        maxbit=6;
                        }else{
                        if(s1>=(1<<5)){
                          maxbit=5;
                          }else{
                          if(s1>=(1<<4)){
                            maxbit=4;
                            }else{
                            if(s1>=(1<<3)){
                              maxbit=3;
                              }else{
                              if(s1>=(1<<2)){
                                maxbit=2;
                                }else{
                                if(s1>=(1<<1)){
                                  maxbit=1;
                                  }else{
                                  maxbit=0;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    
    maxbit=16-maxbit-1;
    if(maxbit>=15){ d=s1<<15; if(d<=s0){ r+=1<<15; s0-=d; } }
    if(maxbit>=14){ d=s1<<14; if(d<=s0){ r+=1<<14; s0-=d; } }
    if(maxbit>=13){ d=s1<<13; if(d<=s0){ r+=1<<13; s0-=d; } }
    if(maxbit>=12){ d=s1<<12; if(d<=s0){ r+=1<<12; s0-=d; } }
    if(maxbit>=11){ d=s1<<11; if(d<=s0){ r+=1<<11; s0-=d; } }
    if(maxbit>=10){ d=s1<<10; if(d<=s0){ r+=1<<10; s0-=d; } }
    if(maxbit>=9){ d=s1<<9; if(d<=s0){ r+=1<<9; s0-=d; } }
    if(maxbit>=8){ d=s1<<8; if(d<=s0){ r+=1<<8; s0-=d; } }
    if(maxbit>=7){ d=s1<<7; if(d<=s0){ r+=1<<7; s0-=d; } }
    if(maxbit>=6){ d=s1<<6; if(d<=s0){ r+=1<<6; s0-=d; } }
    if(maxbit>=5){ d=s1<<5; if(d<=s0){ r+=1<<5; s0-=d; } }
    if(maxbit>=4){ d=s1<<4; if(d<=s0){ r+=1<<4; s0-=d; } }
    if(maxbit>=3){ d=s1<<3; if(d<=s0){ r+=1<<3; s0-=d; } }
    if(maxbit>=2){ d=s1<<2; if(d<=s0){ r+=1<<2; s0-=d; } }
    if(maxbit>=1){ d=s1<<1; if(d<=s0){ r+=1<<1; s0-=d; } }
    d=s1<<0; if(d<=s0){ r+=1<<0; s0-=d; }
  }
  
  return(r);
}
*/

/*
attriwram s32 _divs32_rapper(s32 s0,s32 s1)
{
  if((s0==0)||(s1==0)) return(0);
  
  u32 u0=__builtin_abs(s0);
  u32 u1=__builtin_abs(s1);
  
  if((u0<2048)&&(u1<(16+1))){
    u0=divtbl[(u0*16)+(u1-1)];
    }else{
    u0=divu32(u0,u1);
  }
  
  if(s0<0) u0=-u0;
  if(s1<0) u0=-u0;
  
  return((s32)u0);
}
*/

/*
attriwram s16 _divs16_rapper(s16 s0,s16 s1)
{
  if((s0==0)||(s1==0)) return(0);
  
  u16 u0=__builtin_abs(s0);
  u16 u1=__builtin_abs(s1);
  
  if((u0<2048)&&(u1<(16+1))){
    u0=divtbl[(u0*16)+(u1-1)];
    }else{
    u0=divu32(u0,u1);
  }
  
  if(s0<0) u0=-u0;
  if(s1<0) u0=-u0;
  
  return((s16)u0);
}
*/

