//const int __gba_multiboot;

#define __iwram_overlay_lma __appended_start

#include "string.h"
#include "varargs.h"
#include "debug.c"

#include "header\GBA.h"
#include "header\BG.h"
#include "header\Timer.h"
#include "header\Blend.h"
#include "header\sprite.h"

#include "pcmstream.h"

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

#include "funccnt.c"

void SRAM_SaveIWRAM(void);
void SetThemeColor(void);

#include "interrupt.c"
#include "boolean.h"

volatile b8 VBlank_Enabled,VBlank_Signal;
s32 VBlank_Position;
u32 VBlank_Volume;

#include "GBATools.c"

u8 *PluginFilename;
u8 *TextFilename;
u8 *TextData;
u32 TextDataSize;

#include "textcnt.c"
#include "main_img.c"
#include "fontpack.c"
#include "OAMTools.c"

#include "pogoshell2_args.c"
#include "pogoshell2_reset.c"
#include "pogoshell2_rtc.c"

#define Color_FlameClear 0
#define Color_FlameBG 1
#define Color_FlameBright 8
#define Color_FlameMask 9

#include "sramptxv.c"
#include "sndeff.c"
#include "OAMBG.c"
#include "menu.c"

extern u8 __iwram_overlay_lma;

u32 LineHeight;
u32 LineCount;
u32 LinePos;
u32 LineSpace;
u32 LineMaxLength;
u32 LineTabStop;
b8 LineShowTab;
s32 LineDrawOffset;
u32 KeyRepeatTime;

#define RGBTableCount (7)
#define RGBTable_TextBG (0)
#define RGBTable_TextChar (1)
#define RGBTable_TabChar (2)
#define RGBTable_SystemBG (3)
#define RGBTable_SystemText (4)
#define RGBTable_SystemFrameBright (5)
#define RGBTable_SystemFrameMask (6)

const u8 RGBTableUser[]={'R','G','B','C','0','2',
0x1e,0x1e,0x1f, // TextBG
0x00,0x00,0x01, // TextChar
0x1a,0x1a,0x1a, // TabChar
0x00,0x00,0x01, // SystemBG
0x1e,0x1e,0x1f, // SystemText
0x0d,0x0d,0x0e, // SystemFrameBright
0x13,0x13,0x15, // SystemFrameMask
0xff,0xff,0xff};

const u8 RGBTableWhiteBack[]={0x00,0x00,0x00,0x00,0x00,0x00,
0x1e,0x1e,0x1f, // TextBG
0x00,0x00,0x01, // TextChar
0x1a,0x1a,0x1a, // TabChar
0x00,0x00,0x01, // SystemBG
0x1e,0x1e,0x1f, // SystemText
0x0d,0x0d,0x0e, // SystemFrameBright
0x13,0x13,0x15, // SystemFrameMask
0xff,0xff,0xff};

const u8 RGBTableBlackBack[]={0x00,0x00,0x00,0x00,0x00,0x00,
0x04,0x04,0x04, // TextBG
0x1f,0x1f,0x1f, // TextChar
0x0c,0x0c,0x0c, // TabChar
0x1e,0x1e,0x1f, // SystemBG
0x00,0x00,0x01, // SystemText
0x13,0x13,0x15, // SystemFrameBright
0x0d,0x0d,0x0e, // SystemFrameMask
0xff,0xff,0xff};

// attriwram void fp_(void); // func.
// void (*)(void)=fp_;

void BGInit(void); // func.0

attriwram void IRQ_VBlank_Dummy(void); // func.1
attriwram void IRQ_VBlank_UpScroll(void); // func.2
attriwram void IRQ_VBlank_DownScroll(void); // func.3

attriwram void fp_TextScroll(s32 Vector,b8 Smooth); // func.4
void (*TextScroll)(s32 Vector,b8 Smooth)=fp_TextScroll;

attriwram void fp_PageScroll(s32 Vector); // func.5
void (*PageScroll)(s32 Vector)=fp_PageScroll;

attriwram void fp_PageRedraw(void); // func.6
void (*PageRedraw)(void)=fp_PageRedraw;

u32 LoadLastLine(void); // func.7
void SaveLastLine(u32 LinePos); // func.8
void ChangeFontPack(u32 idx); // func.9

void Status_HidePanel(void); // func.10
void Status_ShowPanel(void); // func.11
void Status_LinePos(void); // func.12
void Status_BytePos(void); // func.13
void Status_ByteSize(void); // func.14
void Status_Clock(void); // func.15
void Status_All(void); // func.16

void _ReturnPogoShell2(void); // func.17
void OpenMainMenu(void); // func.18
int main(void); // func.19

void BGInit(void)
{
  funcadd(FuncC_main,0);
  
  // ���[�h�ݒ�
  REG_DISPCNT=MODE_1;
  
  REG_BG0CNT = ( BG_SIZEA_256_256 | BG_COLOR_16 | BG_CHARBASE(ADR_BGCHR0) | BG_MAPBASE(ADR_BGMAP0) | 1);
  REG_BG1CNT = ( BG_SIZEA_256_256 | BG_COLOR_16 | BG_CHARBASE(ADR_BGCHR1) | BG_MAPBASE(ADR_BGMAP1) | 0);
  REG_BG2CNT = 0;
  REG_BG3CNT = 0;
  
  REG_BG0HOFS=0;
  REG_BG0VOFS=0;
  REG_BG1HOFS=0;
  REG_BG1VOFS=0;
  REG_BG2HOFS=0;
  REG_BG2VOFS=0;
  REG_BG3HOFS=0;
  REG_BG3VOFS=0;
  
  u16 tile;
  u16 *MAP0=&BGMAP0[0];
  u16 *MAP1=&BGMAP1[0];
  for(tile=0;tile<(256/8)*(256/8);tile++){
    *MAP0=(0<<12)+tile;
    *MAP1=(1<<12)+tile;
    MAP0++;
    MAP1++;
  }
  
  REG_DISPCNT=MODE_1 | BG0_ENABLE | BG1_ENABLE;
}

void SetThemeColor(void)
{
  u8 *RGBTable;
  
  switch(SRAM_Read32(&SRAM->ThemeState)){
    case 0:
      RGBTable=(u8*)&RGBTableUser[0];
      break;
    case 1:
      RGBTable=(u8*)&RGBTableUser[0];
      break;
    case 2:
      RGBTable=(u8*)&RGBTableWhiteBack[0];
      break;
    case 3:
      RGBTable=(u8*)&RGBTableBlackBack[0];
      break;
  }
  
  void SetRGBTable(u32 pal,u32 idx)
  {
    idx=(idx+2)*3;
    BGPAL[pal]=RGB(RGBTable[idx+2],RGBTable[idx+1],RGBTable[idx+0]);
  }
  
  void SetRGBTableTextAlpha(u32 pal,u32 alpha)
  {
    u32 bgidx,charidx;
    u16 br,bg,bb;
    u16 cr,cg,cb;
    u16 r,g,b;
    
    bgidx=(RGBTable_TextBG+2)*3;
    charidx=(RGBTable_TextChar+2)*3;
    
    br=RGBTable[bgidx+2];
    bg=RGBTable[bgidx+1];
    bb=RGBTable[bgidx+0];
    cr=RGBTable[charidx+2];
    cg=RGBTable[charidx+1];
    cb=RGBTable[charidx+0];
    
    r=(br*(5-alpha)/5)+(cr*alpha/5);
    g=(bg*(5-alpha)/5)+(cg*alpha/5);
    b=(bb*(5-alpha)/5)+(cb*alpha/5);
    
    BGPAL[pal]=RGB(r,g,b);
  }
  
  BGPAL[0x00+0]=0;
  
  SetRGBTableTextAlpha(0x00+1,0);
  SetRGBTableTextAlpha(0x00+2,1);
  SetRGBTableTextAlpha(0x00+3,2);
  SetRGBTableTextAlpha(0x00+4,3);
  SetRGBTableTextAlpha(0x00+5,4);
  SetRGBTableTextAlpha(0x00+6,5);
  
  SetRGBTable(0x00+7,RGBTable_TabChar);
  
  BGPAL[0x10+0]=0;
  SetRGBTable(0x10+1,RGBTable_SystemBG);
  SetRGBTable(0x10+6,RGBTable_SystemText);
  
  SetRGBTable(0x10+Color_FlameBright,RGBTable_SystemFrameBright);
  SetRGBTable(0x10+Color_FlameMask,RGBTable_SystemFrameMask);
}

void IRQ_VBlank_Dummy(void)
{
  funcadd(FuncC_main,1);
  
  VBlank_Signal=True;
}

void IRQ_VBlank_UpScroll(void)
{
  funcadd(FuncC_main,2);
  
  VBlank_Signal=True;
  
  if(VBlank_Volume!=1){
    VBlank_Position-=2;
    VBlank_Volume-=2;
    }else{
    VBlank_Position-=1;
    VBlank_Volume-=1;
  }
  REG_BG0VOFS=(LineHeight*2)+LineDrawOffset+VBlank_Position;
  if(VBlank_Volume==0){
    IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_Dummy;
    VBlank_Enabled=False;
  }
}

void IRQ_VBlank_DownScroll(void)
{
  funcadd(FuncC_main,3);
  
  VBlank_Signal=True;
  
  if(VBlank_Volume!=1){
    VBlank_Position+=2;
    VBlank_Volume-=2;
    }else{
    VBlank_Position+=1;
    VBlank_Volume-=1;
  }
  REG_BG0VOFS=(LineHeight*2)+LineDrawOffset+VBlank_Position;
  if(VBlank_Volume==0){
    IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_Dummy;
    VBlank_Enabled=False;
  }
}

void fp_TextScroll(s32 Vector,b8 Smooth)
{
  funcadd(FuncC_main,4);
  
  if(Vector==-1){
    if(LinePos==0) return;
  }
  if(Vector==1){
    if(TextRealizeLine<=(LinePos+1)) return;
  }
  LinePos+=Vector;
  
  if(Smooth==False){
    VBlank_Enabled=False;
    }else{
    VBlank_Enabled=True;
    VBlank_Position=0;
    VBlank_Volume=LineHeight;
    if(Vector==-1){
      IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_UpScroll;
      }else{
      IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_DownScroll;
    }
  }
  
  u32 ofs,drawy;
  if(Vector==-1){
    ofs=Text_GetLinePosition(LinePos,LineMaxLength,LineTabStop);
    drawy=LineHeight+LineDrawOffset;
    }else{
    ofs=Text_GetLinePosition(LinePos+LineCount-1,LineMaxLength,LineTabStop);
    drawy=(LineCount-1+3)*LineHeight+LineDrawOffset;
  }
  if(ofs!=-1){
    FontData_BGCHRDrawTextTabStop(BGCHR0,0,drawy,(u8*)&TextData[ofs],LineTabStop,LineShowTab);
    }else{
    FontData_BGCHRDrawTextTabStop(BGCHR0,0,drawy,"",LineTabStop,LineShowTab);
  }
  if(LineSpace!=0){
    FontData_BGCHRFill(BGCHR0,0,drawy+LineHeight-LineSpace,240,LineSpace,1);
  }
  
  if(Smooth==False){
    }else{
    while(VBlank_Enabled==True);
    IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_Dummy;
  }
  
  if(Vector==-1){
    LineDrawOffset-=LineHeight;
    }else{
    LineDrawOffset+=LineHeight;
  }

  u32 BaseAdr=(u32)&BGCHR0[0];
  u32 size=((256-32)/8*32)*32;
  
  REG_DM3CNT_H = DMA_TRANSFER_OFF | DMA_INTR_OFF | DMA_TIMING_NOW | DMA_SIZE_16 | DMA_REPEAT_OFF;
  REG_DM3CNT_L = size/2; // 16bit
  if(LineDrawOffset<0){
    REG_DM3SAD = BaseAdr+size;
    REG_DM3DAD = BaseAdr+(((-LineDrawOffset)/8*32)*32)+size;
    REG_DM3CNT_H |= DMA_TRANSFER_ON | DMA_SAD_DEC | DMA_DAD_DEC;
    LineDrawOffset+=(-LineDrawOffset/8)*8;
    }else{
    REG_DM3SAD = BaseAdr+((LineDrawOffset/8*32)*32);
    REG_DM3DAD = BaseAdr;
    REG_DM3CNT_H |= DMA_TRANSFER_ON | DMA_SAD_INC | DMA_DAD_INC;
    LineDrawOffset-=(LineDrawOffset/8)*8;
  }
  while((REG_DM3CNT_H&DMA_TRANSFER_ON)!=0);
  REG_DM3CNT_H = DMA_TRANSFER_OFF;
  REG_BG0VOFS=(LineHeight*2)+LineDrawOffset;
}

void fp_PageScroll(s32 Vector)
{
  funcadd(FuncC_main,5);
  
  u32 cnt;
  if(Vector<0){
    for(cnt=0;cnt<-Vector;cnt++){
      TextScroll(-1,False);
    }
    }else{
    for(cnt=0;cnt<Vector;cnt++){
      TextScroll(1,False);
    }
  }
}

void fp_PageRedraw(void)
{
  funcadd(FuncC_main,6);
  
  u32 ty;
  u32 ofs;
  for(ty=0;ty<LineCount;ty++){
    ofs=Text_GetLinePosition(LinePos+ty,LineMaxLength,LineTabStop);
    if(ofs!=-1){
      FontData_BGCHRDrawTextTabStop(BGCHR0,0,(ty+2)*LineHeight+LineDrawOffset,(u8*)&TextData[ofs],LineTabStop,LineShowTab);
      }else{
      FontData_BGCHRDrawTextTabStop(BGCHR0,0,(ty+2)*LineHeight+LineDrawOffset,"",LineTabStop,LineShowTab);
    }
    if(LineSpace!=0){
      FontData_BGCHRFill(BGCHR0,0,(ty+2)*LineHeight+LineDrawOffset+LineHeight-LineSpace,240,LineSpace,1);
    }
  }
}

u32 LoadLastLine(void)
{
  funcadd(FuncC_main,7);
  
  return(Text_SeekByteToLine(SRAM_Read32(&SRAM_CurrentState->LastPosition),LineMaxLength,LineTabStop));
}

void SaveLastLine(u32 LinePos)
{
  funcadd(FuncC_main,8);
  
  SRAM_Write32(&SRAM_CurrentState->LastPosition,Text_GetLinePosition(LinePos,LineMaxLength,LineTabStop));
}

void ChangeFontPack(u32 idx)
{
  funcadd(FuncC_main,9);
  
  FontPack_Select(idx);
  LineSpace=SRAM_Read32(&SRAM->LineSpace);
  LineHeight=FontPack->FontHeight+LineSpace;
  LineCount=160/LineHeight+1;
  LineDrawOffset=0;
  LineMaxLength=240/FontPack->FontHeight*2-1;
  LineTabStop=SRAM_Read32(&SRAM->LineTabStop);
  LineShowTab=SRAM_Read32(&SRAM->LineShowTab);
  Text_InitTextPageCache();
  REG_BG0VOFS=(LineHeight*2)+LineDrawOffset;
}

u8 ClockStrCache[14];

void Status_HidePanel(void)
{
  funcadd(FuncC_main,10);
  
  FontData_BGCHRFill(BGCHR1,0,160-11,240,1,0);
  FontData_BGCHRFill(BGCHR1,0,160-10,240,10,0);
}

void Status_ShowPanel(void)
{
  funcadd(FuncC_main,11);
  
  FontData_BGCHRFill(BGCHR1,0,160-11,240,1,9);
  FontData_BGCHRFill(BGCHR1,0,160-10,240,10,1);
  
  BG1_putpixel4(0,160-10-1,0x0000);
  BG1_putpixel4(0,160-10+0,0x8900);
  BG1_putpixel4(0,160-10+1,0x1190);
  BG1_putpixel4(0,160-10+2,0x1119);
  BG1_putpixel4(0,160-10+3,0x1119);
  
  BG1_putpixel4(240-4,160-10-1,0x0000);
  BG1_putpixel4(240-4,160-10+0,0x0098);
  BG1_putpixel4(240-4,160-10+1,0x0911);
  BG1_putpixel4(240-4,160-10+2,0x9111);
  BG1_putpixel4(240-4,160-10+3,0x9111);
  
  u32 cnt;
  for(cnt=0;cnt<14;cnt++){
    ClockStrCache[cnt]=0;
  }
}

void Status_LinePos(void)
{
  funcadd(FuncC_main,12);
  
  TFontPack *BackupFontPack=FontPack;
  FontPack_Select(0);
  
  inttostr(LinePos,5);
  FontData_BGCHRDrawText(BGCHR1,1*5,160-FontPack->FontHeight,res_inttostr);
  FontData_BGCHRDrawText(BGCHR1,(1+5)*5,160-FontPack->FontHeight,"line");
  
  FontPack=BackupFontPack;
}

void Status_BytePos(void)
{
  funcadd(FuncC_main,13);
  
  TFontPack *BackupFontPack=FontPack;
  FontPack_Select(0);
  
  inttostr(Text_GetLinePosition(LinePos,LineMaxLength,LineTabStop),7);
  FontData_BGCHRDrawText(BGCHR1,11*5,160-FontPack->FontHeight,res_inttostr);
  FontData_BGCHRDrawText(BGCHR1,(11+7)*5,160-FontPack->FontHeight,"/");
  
  FontPack=BackupFontPack;
}

void Status_ByteSize(void)
{
  funcadd(FuncC_main,14);
  
  TFontPack *BackupFontPack=FontPack;
  FontPack_Select(0);
  
  inttostr(TextDataSize,7);
  FontData_BGCHRDrawText(BGCHR1,(11+8)*5,160-FontPack->FontHeight,res_inttostr);
  FontData_BGCHRDrawText(BGCHR1,(11+8+7)*5,160-FontPack->FontHeight,"byte");
  
  FontPack=BackupFontPack;
}

extern u32 pogoshell_gettime(void);

void Status_Clock(void)
{
  funcadd(FuncC_main,15);
  
  u8 str[14];
  
/*
  u32 t;
  t=pogones_gettime();
  uprintf("t=%x\n",t);
  FontData_BGCHRDrawText(BGCHR1,30,30,resprintf);
*/
  
  if(rtc_check()!=0x40){
    str[ 0]=' ';
    str[ 1]='R';
    str[ 2]='T';
    str[ 3]='C';
    str[ 4]=' ';
    str[ 5]='D';
    str[ 6]='i';
    str[ 7]='s';
    str[ 8]='a';
    str[ 9]='b';
    str[10]='l';
    str[11]='e';
    str[12]='d';
    str[13]='.';
    }else{
    TTimeFormat now;
    time2(&now);
    
    if(now.mon<10){
      str[0]=' ';
      }else{
      str[0]='0'+(now.mon/10);
    }
    str[1]='0'+(now.mon%10);
    str[2]='/';
    
    if(now.mday<10){
      str[3]=' ';
      }else{
      str[3]='0'+(now.mday/10);
    }
    str[4]='0'+(now.mday%10);
    str[5]=' ';
    
    if(now.hour<10){
      str[6]=' ';
      }else{
      str[6]='0'+(now.hour/10);
    }
    str[7]='0'+(now.hour%10);
    str[8]=':';
    
    str[9]='0'+(now.min/10);
    str[10]='0'+(now.min%10);
    str[11]=':';
    str[12]='0'+(now.sec/10);
    str[13]='0'+(now.sec%10);
  }
  
  TFontPack *BackupFontPack=FontPack;
  FontPack_Select(0);
  
  u32 bx,by;
  bx=32*5;
  by=160-FontPack->FontHeight;
  
  TFontData *FontData;
  b8 chg=False;
  u32 cnt,c1;
  for(cnt=0;cnt<14;cnt++){
    c1=str[cnt];
    if(ClockStrCache[cnt]!=c1){
      chg=True;
    }
    if(chg==True){
      ClockStrCache[cnt]=c1;
      FontData=FontData_FindFont(c1,0x00);
      FontData_Decode(FontData);
      FontData_BGCHRDrawDecodeAnk(BGCHR1,bx,by);
    }
    bx+=5;
  }
  
  FontPack=BackupFontPack;
}

void Status_All(void)
{
  funcadd(FuncC_main,16);
  
  Status_ShowPanel();
  Status_LinePos();
  Status_BytePos();
  Status_ByteSize();
  Status_Clock();
}

/*
  REG_TM0CNT = 0;
  REG_TM0D=0;
  REG_TM0CNT = TM_FREQ_PER_1024 | TM_ENABLE;
  uprintf("%d/100ms",((u32)REG_TM0D)*100000/65517);
  FontData_BGCHRDrawText(BGCHR1,0,4*16,resprintf);
  dprint(resprintf);
*/

void _ReturnPogoShell2(void)
{
  funcadd(FuncC_main,17);
  
  SaveLastLine(LinePos);
  Status_HidePanel();
  
  REG_DISPCNT&=~OBJ_ENABLE;
  REG_BLDMOD=BLEND_TOP_BG0 | BLEND_MODE_DARK;
  u32 blackout;
  for(blackout=0;blackout<15;blackout+=1){
    REG_COLEY=BLEND_DEPTH(blackout);
    WaitForVsync();
  }
  REG_COLEY=BLEND_DEPTH(16);
  u32 palcnt;
  for(palcnt=0;palcnt<256;palcnt++){
    BGPAL[palcnt]=0;
  }
  REG_DISPCNT=0;
  ReturnPogoShell2();
}

void OpenMainMenu(void)
{
  funcadd(FuncC_main,18);
  
  SaveLastLine(LinePos);
  Status_HidePanel();
  Menu_Main();
  Status_All();
  if(Menu_Main_RequestReloadLinePos==True){
    LinePos=LoadLastLine();
    PageRedraw();
  }
  if(Menu_Main_RequestReloadFont==True){
    SaveLastLine(LinePos);
    ChangeFontPack(SRAM_Read32(&SRAM->FontPackIndex));
    LinePos=LoadLastLine();
    PageRedraw();
  }
  if(Menu_Main_RequestReloadLineSpace==True){
    SaveLastLine(LinePos);
    ChangeFontPack(SRAM_Read32(&SRAM->FontPackIndex));
    LinePos=LoadLastLine();
    PageRedraw();
  }
  if(Menu_Main_RequestReloadKeyRepeatTime==True){
    KeyRepeatTime=SRAM_Read32(&SRAM->KeyRepeatTime);
  }
  if(Menu_Main_RequestReloadLineTab==True){
    SaveLastLine(LinePos);
    ChangeFontPack(SRAM_Read32(&SRAM->FontPackIndex));
    LineTabStop=SRAM_Read32(&SRAM->LineTabStop);
    LineShowTab=SRAM_Read32(&SRAM->LineShowTab);
    LinePos=LoadLastLine();
    PageRedraw();
  }
}

int main(void)
{
  funcinit();
  funcadd(FuncC_main,19);
  
//  SRAM_AllClear();
//  SRAM_SaveIWRAM(); while(1);
  
  memchkinit();
  memchk();
  
  *(u16*)0x4000204=0x0014; // set REG_WAITCNT 3/1 wait state
  
  Init_isAnkChar();
  
  sndbuf_Init();
  sndbuf_StartPCM();
  
  VBlank_Enabled=False;
  VBlank_Signal=False;
  IRQTable[IRQIndex_DMA1]=(u32)sndbuf_DMA1_Handler;
  IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_Dummy;
  IRQ_Setup(IRQ_BIT_VBLANK|IRQ_BIT_DMA1,DSTAT_USE_VBLANK);
  
  BGInit();
  BG1Fade1();
  SetOAM();
  FontInit(&__iwram_overlay_lma);
  
  GetPogoShell2Args();
  PluginFilename=ps2Arg0;
  TextFilename=ps2Arg1;
  TextData=ps2ArgDataPtr;
  TextDataSize=ps2ArgDataSize;
  
  uprintf("PluginFilename %s\n",PluginFilename); dprint(resprintf);
  uprintf("TextFilename %s\n",TextFilename); dprint(resprintf);
  uprintf("TextDataSize %d\n",TextDataSize); dprint(resprintf);
  
  dprint("rtc_enable();\n");
  rtc_enable();
  
  dprint("SRAM_Start();\n");
  SRAM_Start();
  dprint("SRAM_SelectState...\n");
  SRAM_SelectState(TextFilename);
  
  dprint("ChangeFontPack...\n");
  ChangeFontPack(SRAM_Read32(&SRAM->FontPackIndex));
  dprint("Load KeyRepeatTime...\n");
  KeyRepeatTime=SRAM_Read32(&SRAM->KeyRepeatTime);
  
  LinePos=0;
  
  REG_TM3CNT = 0;
  REG_TM3D=0;
  REG_TM3CNT = TM_FREQ_PER_64 | TM_ENABLE;
  PageRedraw();
  uprintf("PageRedraw %dclk\n",REG_TM3D); dprint(resprintf);
  REG_TM3CNT = 0;
  REG_TM3D=0;
  
  dprint("SetThemeColor();\n");
  SetThemeColor();
  dprint("SetOAMBG();\n");
  SetOAMBG();
  
  u32 NowKey;
  u32 LastKey;
  LastKey=0;
  
  b8 KeyRepeat;
  KeyRepeat=False;
  
  dprint("SRAM_Read32(&SRAM_CurrentState->LastPosition);\n");
  if(SRAM_Read32(&SRAM_CurrentState->LastPosition)==0){
    Menu_BootDialog();
    }else{
    if(SRAM_Read32(&SRAM->LoadAutoState)==True){
      LinePos=LoadLastLine();
      if(LinePos!=0) PageRedraw();
      }else{
      Menu_AutoLoad();
      if(Menu_Main_RequestReloadLinePos==True){
        LinePos=LoadLastLine();
        if(LinePos!=0) PageRedraw();
      }
    }
  }
  
  dprint("Status_All();\n");
  Status_All();
  
  while((*KEYS)!=0x3ff);
  
  // Timer0 = �������Ԍv�����f�o�b�O�p Valiable
  // Timer1 = DirectSoundA
  // Timer2 = �L�[���s�[�g�p 250msLimit
  // Timer3 = �჌�X�|���X��ʕ\���p 500msLimit
  
  b8 ChangeState=False;
  
  dprint("mainloop...\n");
  
  while(1){
    NowKey=(~*KEYS)&0x3ff;
    if(LastKey!=NowKey) KeyRepeat=False;
    LastKey=NowKey;
    
    if(NowKey==0){
  dprint("vsync\n");
      WaitForVsync();
      if(ChangeState==True){
        ChangeState=False;
        SaveLastLine(LinePos);
        Status_LinePos();
        REG_TM3CNT = 0;
        REG_TM3D=0;
        REG_TM3CNT = TM_FREQ_PER_256 | TM_ENABLE;
      }
      if(REG_TM3D>(65517/2)){
        REG_TM3CNT = 0;
        Status_BytePos();
        Status_Clock();
        u32 chkadr=memchk();
        if(chkadr!=0){
          uprintf("!! IWRAM CheckMemory broken at 0x%x",chkadr);
          FontData_BGCHRDrawText(BGCHR1,0,0,resprintf);
        }
      }
      }else{
      switch(SRAM_Read32(&SRAM->ReturnPogoShellKeys)){
        case 0: // L+R
          if(NowKey==(KEY_R|KEY_L)){
            _ReturnPogoShell2();
          }
          NowKey&=~(KEY_R|KEY_L);
          break;
        case 1: // A+B
          if(NowKey==(KEY_A|KEY_B)){
            _ReturnPogoShell2();
          }
          NowKey&=~(KEY_A|KEY_B);
          break;
        case 2: // Type2
          if((NowKey&KEY_L)!=0){
            if((NowKey&(KEY_UP|KEY_DOWN|KEY_RIGHT|KEY_LEFT))!=0){
              _ReturnPogoShell2();
            }
          }
          NowKey&=~(KEY_L);
          NowKey&=~(KEY_UP|KEY_DOWN|KEY_RIGHT|KEY_LEFT);
          break;
      }
      
      ChangeState=True;
      
      REG_TM2CNT = 0;
      REG_TM2D=0;
      REG_TM2CNT = TM_FREQ_PER_1024 | TM_ENABLE;
      
      if(SRAM_Read32(&SRAM->ReturnPogoShellKeys)==2){
        if((NowKey&KEY_R)!=0){
          if((NowKey&KEY_B)!=0){
            if(KeyRepeat==False) PlaySound(ISE_Page);
            PageScroll(-(s32)(LineCount-3));
            NowKey&=~(KEY_B);
          }
          if((NowKey&KEY_A)!=0){
            if(KeyRepeat==False) PlaySound(ISE_Page);
            PageScroll((s32)(LineCount-3));
            NowKey&=~(KEY_A);
          }
          NowKey&=~(KEY_R);
        }
      }
      
      if((NowKey==KEY_UP)||(NowKey==KEY_B)) TextScroll(-1,True);
      if((NowKey==KEY_DOWN)||(NowKey==KEY_A)) TextScroll(1,True);
      
      if(NowKey==KEY_LEFT){
        if(KeyRepeat==False) PlaySound(ISE_Page);
        PageScroll(-(s32)(LineCount-3));
      }
      if(NowKey==KEY_RIGHT){
        if(KeyRepeat==False) PlaySound(ISE_Page);
        PageScroll((s32)(LineCount-3));
      }
      
      if(NowKey==KEY_START){
        OpenMainMenu();
      }
      
      if(NowKey==KEY_SELECT){
        Status_HidePanel();
        Menu_HelpDialog();
        Status_All();
      }
      
      if(KeyRepeat==True){
//        WaitForVsync();
        }else{
        b8 LoopFlag;
        LoopFlag=True;
        while(LoopFlag==True){
          if((65117/4*KeyRepeatTime/1000)<REG_TM2D){ // 250ms wait
            KeyRepeat=True;
            LoopFlag=False;
          }
          if(NowKey!=((~*KEYS)&0x3ff)){ // ChangeKeyState
            KeyRepeat=False;
            LoopFlag=False;
          }
          if(LoopFlag==True) WaitForVsync();
        }
      }
      
    }
  }
  
  while(1);
}

