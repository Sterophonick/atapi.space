
#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

u32 TextRealizeLine; // �ۏ؂ł���s��(0xffff=�����o)
u32 TextPageCache[0x100];
u32 TextCurrentPage;
u32 TextCurrentPageCache[0x101]; // ���[���o�̂��߈�s���߂�

attriwram void fp_Text_InitTextPageCache(void); // func.0
void (*Text_InitTextPageCache)(void)=fp_Text_InitTextPageCache;
attriwram void fp_Text_CalcTextPageCache(u32 page,u32 MaxLength,u32 TabStop); // func.1
void (*Text_CalcTextPageCache)(u32 page,u32 MaxLength,u32 TabStop)=fp_Text_CalcTextPageCache;
attriwram void fp_Text_RefreshTextCurrentPageCache(u32 page,u32 MaxLength,u32 TabStop); // func.2
void (*Text_RefreshTextCurrentPageCache)(u32 page,u32 MaxLength,u32 TabStop)=fp_Text_RefreshTextCurrentPageCache;
attriwram u32 fp_Text_GetLinePosition(u32 line,u32 MaxLength,u32 TabStop); // func.3
u32 (*Text_GetLinePosition)(u32 line,u32 MaxLength,u32 TabStop)=fp_Text_GetLinePosition;
attriwram u32 fp_Text_SeekByteToLine(u32 Position,u32 MaxLength,u32 TabStop); // func.4
u32 (*Text_SeekByteToLine)(u32 Position,u32 MaxLength,u32 TabStop)=fp_Text_SeekByteToLine;

void fp_Text_InitTextPageCache(void)
{
  funcadd(FuncC_textcnt,0);
  
  TextRealizeLine=0xffff;
  
  u32 page;
  for(page=0;page<0x100;page++){
    TextPageCache[page]=-1;
  }
  
  TextCurrentPage=-1;

  u32 line;
  for(line=0;line<0x100;line++){
    TextCurrentPageCache[line]=-1;
  }
}

void fp_Text_CalcTextPageCache(u32 page,u32 MaxLength,u32 TabStop)
{
  funcadd(FuncC_textcnt,1);
  
  if(page==0){
    TextPageCache[page]=0;
    return;
  }
  if(TextPageCache[page]!=-1) return;

  if(TextPageCache[page-1]==-1){
    TextPageCache[page]=-1;
    return;
  }

  u8 *TextPtr;
  u32 TextCnt;
  u8 ch;
  u32 x;
  u32 line;
  
  TextPtr=&TextData[0];
  TextCnt=TextPageCache[page-1];
  line=0;
  x=0;
  
  while(1){
    ch=TextPtr[TextCnt];
    if(ch==0x0d){
      if(TextPtr[TextCnt+1]==0x0a){
        TextCnt+=2;
        }else{
        TextCnt+=1;
      }
      if(TextCnt>=TextDataSize){
        TextPageCache[page]=-1;
        return;
      }
      x=0;
      if(line==0xff) break;
      line++;
      }else{
      if(isAnkChar[ch]==True){
        TextCnt++;
        if(ch!=0x09){
          x++;
          }else{
          u32 mod=x; // x%TabStop
          while(mod>=TabStop){
            mod-=TabStop;
          };
          x+=TabStop-mod;
        }
        }else{
        TextCnt+=2;
        x+=2;
      }
      if(x>=MaxLength){
        if(TextCnt>=TextDataSize){
          TextPageCache[page]=-1;
          return;
        }
        x=0;
        if(line==0xff) break;
        line++;
      }
    }
  }
  
  TextPageCache[page]=TextCnt;
}

void fp_Text_RefreshTextCurrentPageCache(u32 page,u32 MaxLength,u32 TabStop)
{
  funcadd(FuncC_textcnt,2);
  
  if(TextCurrentPage==page) return;
  TextCurrentPage=page;
  
  u32 line;
  for(line=0;line<0x100;line++){
    TextCurrentPageCache[line]=-1;
  }
  
  if(page==-1) return;
  
  u32 ofs=TextPageCache[page];
  if(ofs==-1){
    Text_CalcTextPageCache(page,MaxLength,TabStop);
    ofs=TextPageCache[page];
    if(ofs==-1) return;
  }
  
  u8 *TextPtr=(u8*)&TextData[ofs];
  u32 TextCnt;
  u8 ch;
  u32 x;
  
  TextPtr=&TextData[0];
  TextCnt=ofs;
  TextCurrentPageCache[0]=TextCnt;
  line=1;
  x=0;
  
  while(1){
    ch=TextPtr[TextCnt];
    if(ch==0x0d){
      if(TextPtr[TextCnt+1]==0x0a){
        TextCnt+=2;
        }else{
        TextCnt+=1;
      }
      if(TextCnt>=TextDataSize){
        TextRealizeLine=(page*0x100)+line;
        return;
      }
      TextCurrentPageCache[line]=TextCnt;
      if(line==0x100) break;
      line++;
      x=0;
      }else{
      if(isAnkChar[ch]==True){
        TextCnt++;
        if(ch!=0x09){
          x++;
          }else{
          u32 mod=x; // x%TabStop
          while(mod>=TabStop){
            mod-=TabStop;
          };
          x+=TabStop-mod;
        }
        }else{
        TextCnt+=2;
        x+=2;
      }
      if(x>=MaxLength){
        if(TextCnt>=TextDataSize){
          TextRealizeLine=(page*0x100)+line;
          return;
        }
        TextCurrentPageCache[line]=TextCnt;
        if(line==0x100) break;
        line++;
        x=0;
      }
    }
  }
}

u32 fp_Text_GetLinePosition(u32 line,u32 MaxLength,u32 TabStop)
{
  funcadd(FuncC_textcnt,3);
  
  Text_RefreshTextCurrentPageCache(line>>8,MaxLength,TabStop);
  return(TextCurrentPageCache[line&0xff]);
}

u32 fp_Text_SeekByteToLine(u32 Position,u32 MaxLength,u32 TabStop)
{
  funcadd(FuncC_textcnt,4);
  
  if((TextDataSize-2)<=Position){
    Position=(TextDataSize-2)-1;
  }
  
  u32 line,pos;
  line=0;
  pos=0;
  while(pos<=Position){
    line++;
    pos=Text_GetLinePosition(line,MaxLength,TabStop);
  }
  if(line!=0) line--;
  return(line);
}
