
#include "_customdiv.h"

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

typedef struct {
  u8 Filename[32];
  u32 Offset;
  u32 Size;
} TFontTable_fpk;

typedef struct {
  u8 ID[4];
  u32 size;
  TFontTable_fpk fpk[8];
} TFontTable;

typedef struct {
  u16 FontHeight;
  u8 GrayScale[4];
  u32 TablePos[0x100] __attribute__((packed));
  u8 Data[0];
} TFontPack;

typedef struct {
  u16 chrno;
  u16 EncSize; // div 2 at realsize
  u8 EncMaxPacketSize;
  u8 EncData[0];
} TFontData;

TFontTable *FontTable;
TFontPack *FontPack;
u8 DecData[1024+32];

void FontInit(u8 *baseptr); // func.0
attriwram void fp_FontPack_Select(u32 num); // func.1
void (*FontPack_Select)(u32 num)=fp_FontPack_Select;
void FontPack_SetFPK(u8 *data); // func.2
attriwram void fp_FontData_Decode(TFontData *FontData); // func.3
void (*FontData_Decode)(TFontData *FontData)=fp_FontData_Decode;
attriwram TFontData *fp_FontData_SeekNext(TFontData *FontData); // func.4
TFontData *(*FontData_SeekNext)(TFontData *FontData)=fp_FontData_SeekNext;
void FontData_BG2Draw(u32 x,u32 y); // func.5
attriwram void fp_FontData_BGCHRDrawDecode(u16 *BGCHR,u32 x,u32 y); // func.6
void (*FontData_BGCHRDrawDecode)(u16 *BGCHR,u32 x,u32 y)=fp_FontData_BGCHRDrawDecode;
attriwram void fp_FontData_BGCHRDrawDecodeAnk(u16 *BGCHR,u32 x,u32 y); // func.7
void (*FontData_BGCHRDrawDecodeAnk)(u16 *BGCHR,u32 x,u32 y)=fp_FontData_BGCHRDrawDecodeAnk;
attriwram void fp_FontData_BGCHRFill(u16 *BGCHR,u32 x,u32 y,u32 w,u32 h,u16 c); // func.8
void (*FontData_BGCHRFill)(u16 *BGCHR,u32 x,u32 y,u32 w,u32 h,u16 c)=fp_FontData_BGCHRFill;
attriwram TFontData *fp_FontData_FindFont(u16 c1,u16 c2); // func.9
TFontData *(*FontData_FindFont)(u16 c1,u16 c2)=fp_FontData_FindFont;
attriwram void fp_FontData_BGCHRDrawTextLimit(u16 *BGCHR,u32 x,u32 y,u8 *str,u32 MaxLength,u32 TabStop,b8 ShowTab); // func.10
void (*FontData_BGCHRDrawTextLimit)(u16 *BGCHR,u32 x,u32 y,u8 *str,u32 MaxLength,u32 TabStop,b8 ShowTab)=fp_FontData_BGCHRDrawTextLimit;
attriwram void fp_FontData_BGCHRDrawText(u16 *BGCHR,u32 x,u32 y,u8 *str); // func.11
void (*FontData_BGCHRDrawText)(u16 *BGCHR,u32 x,u32 y,u8 *str)=fp_FontData_BGCHRDrawText;
attriwram void fp_FontData_BGCHRDrawTextTabStop(u16 *BGCHR,u32 x,u32 y,u8 *str,u32 TabStop,b8 ShowTab); // func.12
void (*FontData_BGCHRDrawTextTabStop)(u16 *BGCHR,u32 x,u32 y,u8 *str,u32 TabStop,b8 ShowTab)=fp_FontData_BGCHRDrawTextTabStop;
void FontData_OBJ2D256DrawDecode(u32 BaseOBJNo); // func.13
void FontData_OBJ1D256DrawDecode(u32 BaseOBJNo); // func.14
void FontData_BGCHRFillFlame(u16 *BGCHR,u32 x,u32 y,u32 w,u32 h,u16 colMask,u16 colBright,u16 colBG); // func.15

void FontInit(u8 *baseptr)
{
  funcadd(FuncC_fontpack,0);
  
  FontTable=(TFontTable*)&baseptr[0];
  FontPack=0;
}

void fp_FontPack_Select(u32 num)
{
  funcadd(FuncC_fontpack,1);
  
  u32 ofs;
  ofs=FontTable->fpk[num].Offset;
  if(FontTable->fpk[num].Size==0){
    ofs=FontTable->fpk[0].Offset;
  }
  FontPack=(TFontPack*)((u32)FontTable+ofs);
}

void FontPack_SetFPK(u8 *data)
{
  funcadd(FuncC_fontpack,2);
  
  FontPack=(TFontPack*)data;
}

void fp_FontData_Decode(TFontData *FontData)
{
  funcadd(FuncC_fontpack,3);
  
  u16 FontHeight=FontPack->FontHeight;
  
  u8 EncMaxPacketSize=FontData->EncMaxPacketSize;
  
  u8 *EncPtr;
  b8 EncLoadFlag;
  u8 *DecPtr,*DecTerm;
  u8 NowColor;
  u8 data;
  
  u32 i;
  
  DecData[1024+32-1]=0x00;
  
  NowColor=6;
  
  EncPtr=&FontData->EncData[0];
  EncLoadFlag=True;
  
  DecPtr=&DecData[0];
  DecTerm=&DecPtr[FontHeight*FontHeight];
  
  #define GetEncData(void) { \
    if(EncLoadFlag==True){ \
      data=*EncPtr&0x0f; \
      EncLoadFlag=False; \
      }else{ \
      data=*EncPtr>>4; \
      EncPtr++; \
      EncLoadFlag=True; \
    } \
  }
  
  while(DecPtr<DecTerm){
    GetEncData();
    if(data<EncMaxPacketSize){
      for(;data!=0;data--){
        *DecPtr=NowColor;
        DecPtr++;
      }
      if(NowColor==1){
        NowColor=6;
        }else{
        NowColor=1;
      }
      }else{
      if(data==EncMaxPacketSize){
        GetEncData();
        data++;
        for(;data!=0;data--){ // for(i=0;i<=data;i++)
          *DecPtr=DecPtr[-FontHeight];
          DecPtr++;
        }
        }else{
        u32 size;
        size=data-EncMaxPacketSize;
        for(i=((size&(~1))/2);i!=0;i--){
          GetEncData();
          *DecPtr=(data>>2&0x03)+2;
          DecPtr++;
          *DecPtr=(data&0x03)+2;
          DecPtr++;
        }
        if((size&1)!=0){
          GetEncData();
          *DecPtr=(data>>2&0x03)+2;
          DecPtr++;
        }
      }
    }
  }
  
  if(FontData->chrno==0x0900){
    DecPtr=&DecData[0];
    DecTerm=&DecPtr[FontHeight*FontHeight];
    while(DecPtr<DecTerm){
      if(*DecPtr!=1) *DecPtr=7;
      DecPtr++;
    }
  }
}

TFontData *fp_FontData_SeekNext(TFontData *FontData)
{
  funcadd(FuncC_fontpack,4);
  
  u32 ptr;
/*
  ptr=(u32)FontData;
  ptr+=2;
  ptr+=2;
  ptr++;
  ptr+=(FontData->EncSize>>1)+1;
*/
  ptr=(u32)FontData+5+(FontData->EncSize>>1)+1;
  if((ptr&0x01)!=0) ptr++;
  return((TFontData*)ptr);
}

void FontData_BG2Draw(u32 x,u32 y)
{
  funcadd(FuncC_fontpack,5);
  
  u16 FontHeight=FontPack->FontHeight;
  
  inline void put(u32 x,u32 y,u16 c)
  {
    u16* ScreenBuffer;
    ScreenBuffer=(u16*)0x6000000;
    ScreenBuffer[(y*240+x)>>1]=c;
  }
  
  u32 dx,dy;
  u16 c;
  for(dy=0;dy<FontHeight;dy++){
    for(dx=0;dx<FontHeight;dx+=2){
      c=((u16)DecData[dy*FontHeight+dx+1]<<8)+(u16)DecData[dy*FontHeight+dx+0];
      put(x+dx,y+dy,c);
    }
  }
}

void fp_FontData_BGCHRDrawDecode(u16 *BGCHR,u32 x,u32 y)
{
  funcadd(FuncC_fontpack,6);
  
  const u32 TileSize=8*8/2/2;
  
  u32 FontHeight=FontPack->FontHeight;
  u8 *DecPtr;
  
  DecPtr=&DecData[0];
  
  u32 dy;
  u32 tilebase;
  u32 ty;
  u16 *tiledata;
  u32 lastx;
  for(dy=0;dy<FontHeight;dy++){
    ty=y+dy;
    tilebase=(((ty/8)*(256/8))+(x/8))*TileSize;
    tiledata=BGCHR;
    tiledata+=tilebase+((ty&7)*2);
    lastx=FontHeight;
    switch(x&7){
      case 0:
        break;
      case 1:
        *tiledata=(*tiledata&0x000f)+((u16)DecPtr[0]<<4)+((u16)DecPtr[1]<<8)+((u16)DecPtr[2]<<12);
        tiledata++;
        *tiledata=((u16)DecPtr[3])+((u16)DecPtr[4]<<4)+((u16)DecPtr[5]<<8)+((u16)DecPtr[6]<<12);
        DecPtr+=7;
        lastx-=7;
        tiledata+=TileSize-1;
        break;
      case 2:
        *tiledata=(*tiledata&0x00ff)+((u16)DecPtr[0]<<8)+((u16)DecPtr[1]<<12);
        tiledata++;
        *tiledata=((u16)DecPtr[2])+((u16)DecPtr[3]<<4)+((u16)DecPtr[4]<<8)+((u16)DecPtr[5]<<12);
        DecPtr+=6;
        lastx-=6;
        tiledata+=TileSize-1;
        break;
      case 3:
        *tiledata=(*tiledata&0x0fff)+((u16)DecPtr[0]<<12);
        tiledata++;
//        *tiledata=((u16)DecPtr[1])+((u16)DecPtr[2]<<4)+((u16)DecPtr[3]<<8)+((u16)DecPtr[4]<<12);
        *tiledata=((u16)DecPtr[1]);
        *tiledata+=((u16)DecPtr[2]<<4);
        *tiledata+=((u16)DecPtr[3]<<8);
        *tiledata+=((u16)DecPtr[4]<<12);
        DecPtr+=5;
        lastx-=5;
        tiledata+=TileSize-1;
        break;
      case 4:
        tiledata++;
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        DecPtr+=4;
        lastx-=4;
        tiledata+=TileSize-1;
        break;
      case 5:
        tiledata++;
        *tiledata=(*tiledata&0x000f)+((u16)DecPtr[0]<<4)+((u16)DecPtr[1]<<8)+((u16)DecPtr[2]<<12);
        DecPtr+=3;
        lastx-=3;
        tiledata+=TileSize-1;
        break;
      case 6:
        tiledata++;
        *tiledata=(*tiledata&0x00ff)+((u16)DecPtr[0]<<8)+((u16)DecPtr[1]<<12);
        DecPtr+=2;
        lastx-=2;
        tiledata+=TileSize-1;
        break;
      case 7:
        tiledata++;
        *tiledata=(*tiledata&0x0fff)+((u16)DecPtr[0]<<12);
        DecPtr+=1;
        lastx-=1;
        tiledata+=TileSize-1;
        break;
    }
    
    for(;lastx>=8;lastx-=8){
      *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
      tiledata++;
      *tiledata=((u16)DecPtr[4])+((u16)DecPtr[5]<<4)+((u16)DecPtr[6]<<8)+((u16)DecPtr[7]<<12);
      DecPtr+=8;
      tiledata+=TileSize-1;
    }
    
    switch(lastx){
      case 0:
        break;
      case 1:
        *tiledata=(*tiledata&0xfff0)+((u16)DecPtr[0]);
        DecPtr+=1;
        break;
      case 2:
        *tiledata=(*tiledata&0xff00)+((u16)DecPtr[0])+((u16)DecPtr[1]<<4);
        DecPtr+=2;
        break;
      case 3:
        *tiledata=(*tiledata&0xf000)+((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8);
        DecPtr+=3;
        break;
      case 4:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        DecPtr+=4;
        break;
      case 5:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        tiledata++;
        *tiledata=(*tiledata&0xfff0)+((u16)DecPtr[4]);
        DecPtr+=5;
        break;
      case 6:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        tiledata++;
        *tiledata=(*tiledata&0xff00)+((u16)DecPtr[4])+((u16)DecPtr[5]<<4);
        DecPtr+=6;
        break;
      case 7:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        tiledata++;
        *tiledata=(*tiledata&0xf000)+((u16)DecPtr[4])+((u16)DecPtr[5]<<4)+((u16)DecPtr[6]<<8);
        DecPtr+=7;
        break;
    }
  }
}

void fp_FontData_BGCHRDrawDecodeAnk(u16 *BGCHR,u32 x,u32 y)
{
  funcadd(FuncC_fontpack,7);
  
  const u32 TileSize=8*8/2/2;
  
  u32 FontHeight=FontPack->FontHeight;
  u8 *DecPtr;
  
  u32 dy;
  u32 tilebase;
  u32 ty;
  u16 *tiledata;
  u32 lastx;
  for(dy=0;dy<FontHeight;dy++){
    ty=y+dy;
    tilebase=(((ty/8)*(256/8))+(x/8))*TileSize;
    tiledata=BGCHR;
    tiledata+=tilebase+((ty&7)*2);
    lastx=FontHeight/2;
    if(lastx<8) lastx=8;
    DecPtr=&DecData[dy*FontHeight];
    switch(x&7){
      case 0:
        break;
      case 1:
        *tiledata=(*tiledata&0x000f)+((u16)DecPtr[0]<<4)+((u16)DecPtr[1]<<8)+((u16)DecPtr[2]<<12);
        tiledata++;
        *tiledata=((u16)DecPtr[3])+((u16)DecPtr[4]<<4)+((u16)DecPtr[5]<<8)+((u16)DecPtr[6]<<12);
        DecPtr+=7;
        lastx-=7;
        tiledata+=TileSize-1;
        break;
      case 2:
        *tiledata=(*tiledata&0x00ff)+((u16)DecPtr[0]<<8)+((u16)DecPtr[1]<<12);
        tiledata++;
        *tiledata=((u16)DecPtr[2])+((u16)DecPtr[3]<<4)+((u16)DecPtr[4]<<8)+((u16)DecPtr[5]<<12);
        DecPtr+=6;
        lastx-=6;
        tiledata+=TileSize-1;
        break;
      case 3:
        *tiledata=(*tiledata&0x0fff)+((u16)DecPtr[0]<<12);
        tiledata++;
        *tiledata=((u16)DecPtr[1])+((u16)DecPtr[2]<<4)+((u16)DecPtr[3]<<8)+((u16)DecPtr[4]<<12);
        DecPtr+=5;
        lastx-=5;
        tiledata+=TileSize-1;
        break;
      case 4:
        tiledata++;
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        DecPtr+=4;
        lastx-=4;
        tiledata+=TileSize-1;
        break;
      case 5:
        tiledata++;
        *tiledata=(*tiledata&0x000f)+((u16)DecPtr[0]<<4)+((u16)DecPtr[1]<<8)+((u16)DecPtr[2]<<12);
        DecPtr+=3;
        lastx-=3;
        tiledata+=TileSize-1;
        break;
      case 6:
        tiledata++;
        *tiledata=(*tiledata&0x00ff)+((u16)DecPtr[0]<<8)+((u16)DecPtr[1]<<12);
        DecPtr+=2;
        lastx-=2;
        tiledata+=TileSize-1;
        break;
      case 7:
        tiledata++;
        *tiledata=(*tiledata&0x0fff)+((u16)DecPtr[0]<<12);
        DecPtr+=1;
        lastx-=1;
        tiledata+=TileSize-1;
        break;
    }
    
    for(;lastx>=8;lastx-=8){
      *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
      tiledata++;
      *tiledata=((u16)DecPtr[4])+((u16)DecPtr[5]<<4)+((u16)DecPtr[6]<<8)+((u16)DecPtr[7]<<12);
      DecPtr+=8;
      tiledata+=TileSize-1;
    }
    
    switch(lastx){
      case 0:
        break;
      case 1:
        *tiledata=(*tiledata&0xfff0)+((u16)DecPtr[0]);
        DecPtr+=1;
        break;
      case 2:
        *tiledata=(*tiledata&0xff00)+((u16)DecPtr[0])+((u16)DecPtr[1]<<4);
        DecPtr+=2;
        break;
      case 3:
        *tiledata=(*tiledata&0xf000)+((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8);
        DecPtr+=3;
        break;
      case 4:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        DecPtr+=4;
        break;
      case 5:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        tiledata++;
        *tiledata=(*tiledata&0xfff0)+((u16)DecPtr[4]);
        DecPtr+=5;
        break;
      case 6:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        tiledata++;
        *tiledata=(*tiledata&0xff00)+((u16)DecPtr[4])+((u16)DecPtr[5]<<4);
        DecPtr+=6;
        break;
      case 7:
        *tiledata=((u16)DecPtr[0])+((u16)DecPtr[1]<<4)+((u16)DecPtr[2]<<8)+((u16)DecPtr[3]<<12);
        tiledata++;
        *tiledata=(*tiledata&0xf000)+((u16)DecPtr[4])+((u16)DecPtr[5]<<4)+((u16)DecPtr[6]<<8);
        DecPtr+=7;
        break;
    }
  }
}

void fp_FontData_BGCHRFill(u16 *BGCHR,u32 x,u32 y,u32 w,u32 h,u16 c)
{
  funcadd(FuncC_fontpack,8);
  
  const u32 TileSize=8*8/2/2;
  
  u32 dy;
  u32 tilebase;
  u32 ty;
  u16 *tiledata;
  u32 lastx;
  
  u16 cf=(c)+(c<<4)+(c<<8)+(c<<12);
  
  for(dy=0;dy<h;dy++){
    ty=y+dy;
    tilebase=(((ty/8)*(256/8))+(x/8))*TileSize;
    tiledata=BGCHR;
    tiledata+=tilebase+((ty&7)*2);
    lastx=w;
    if(lastx<8) lastx=8;
    switch(x&7){
      case 0:
        break;
      case 1:
        *tiledata=(*tiledata&0x000f)+(cf&0xfff0);
        tiledata++;
        *tiledata=cf;
        lastx-=7;
        tiledata+=TileSize-1;
        break;
      case 2:
        *tiledata=(*tiledata&0x00ff)+(cf&0xff00);
        tiledata++;
        *tiledata=cf;
        lastx-=6;
        tiledata+=TileSize-1;
        break;
      case 3:
        *tiledata=(*tiledata&0x0fff)+(cf&0xf000);
        tiledata++;
        *tiledata=cf;
        lastx-=5;
        tiledata+=TileSize-1;
        break;
      case 4:
        tiledata++;
        *tiledata=cf;
        lastx-=4;
        tiledata+=TileSize-1;
        break;
      case 5:
        tiledata++;
        *tiledata=(*tiledata&0x000f)+(cf&0xfff0);
        lastx-=3;
        tiledata+=TileSize-1;
        break;
      case 6:
        tiledata++;
        *tiledata=(*tiledata&0x00ff)+(cf&0xff00);
        lastx-=2;
        tiledata+=TileSize-1;
        break;
      case 7:
        tiledata++;
        *tiledata=(*tiledata&0x0fff)+(cf&0xf000);
        lastx-=1;
        tiledata+=TileSize-1;
        break;
    }
    
    for(;lastx>=8;lastx-=8){
      *tiledata=cf;
      tiledata++;
      *tiledata=cf;
      tiledata+=TileSize-1;
    }
    
    switch(lastx){
      case 0:
        break;
      case 1:
        *tiledata=(*tiledata&0xfff0)+(cf&0x000f);
        break;
      case 2:
        *tiledata=(*tiledata&0xff00)+(cf&0x00ff);
        break;
      case 3:
        *tiledata=(*tiledata&0xf000)+(cf&0x0fff);
        break;
      case 4:
        *tiledata=cf;
        break;
      case 5:
        *tiledata=cf;
        tiledata++;
        *tiledata=(*tiledata&0xfff0)+(cf&0x000f);
        break;
      case 6:
        *tiledata=cf;
        tiledata++;
        *tiledata=(*tiledata&0xff00)+(cf&0x00ff);
        break;
      case 7:
        *tiledata=cf;
        tiledata++;
        *tiledata=(*tiledata&0xf000)+(cf&0x0fff);
        break;
    }
  }
}

TFontData *fp_FontData_FindFont(u16 c1,u16 c2)
{
  funcadd(FuncC_fontpack,9);
  
/*
  u8 s[3];
  s[0]=c1;
  s[1]=c2;
  s[2]=0;
  uprintf("c=%x %x s=%s\n",c1,c2,s);
  dprint(resprintf);
*/
  
  u32 cnt;
  cnt=FontPack->TablePos[c1];
  if(cnt!=0xffffffff){
    TFontData *FontData=(TFontData*)&FontPack->Data[cnt];
    u16 c1mask=c1<<8;
    u32 ptr;
    while((FontData->chrno&0xff00)==c1mask){
      if((FontData->chrno&0x00ff)==c2){
        return(FontData);
      }
//      FontData=FontData_SeekNext(FontData); // inlined
      ptr=(u32)FontData+5+(FontData->EncSize>>1)+1;
      if((ptr&0x01)!=0) ptr++;
      FontData=(TFontData*)ptr;
    }
  }
  if(c2==0x00){
    return(FontData_FindFont(0x20,0x00)); // ankspace
    }else{
    return(FontData_FindFont(0x81,0x40)); // 2bytespace
  }
}

void fp_FontData_BGCHRDrawTextLimit(u16 *BGCHR,u32 x,u32 y,u8 *str,u32 MaxLength,u32 TabStop,b8 ShowTab)
{
  funcadd(FuncC_fontpack,10);
  
  const u32 FontHeight=FontPack->FontHeight;
  
  TFontData *FontData;
  u32 i=0;
  u32 drawx=0;
  u8 c1,c2;
  u32 len;
  
  while(str[i]!=0x00){
    c1=str[i];
    if(c1==0x0d) break;
    if(isAnkChar[c1]==True){
      c2=0x00;
      i++;
      if(c1!=0x09){
        len=1;
        }else{
        u32 mod=drawx; // drawx%TabStop
        while(mod>=TabStop){
          mod-=TabStop;
        };
        len=TabStop-mod;
        if((drawx+len)>=MaxLength) len=MaxLength-drawx+1;
      }
      }else{
      c2=str[i+1];
      i+=2;
      len=2;
    }
    FontData=FontData_FindFont(c1,c2);
    FontData_Decode(FontData);
    if(c2==0x00){
      if(c1!=0x09){
        FontData_BGCHRDrawDecodeAnk(BGCHR,x+(drawx*FontHeight/2),y);
        }else{
        if(ShowTab==False){
          FontData_BGCHRFill(BGCHR,x+(drawx*FontHeight/2),y,len*FontHeight/2,FontHeight,1);
          }else{
          FontData_BGCHRDrawDecodeAnk(BGCHR,x+(drawx*FontHeight/2),y);
          if(len>=2){
            FontData_BGCHRFill(BGCHR,x+((drawx+1)*FontHeight/2),y,(len-1)*FontHeight/2,FontHeight,1);
          }
        }
      }
      }else{
      FontData_BGCHRDrawDecode(BGCHR,x+(drawx*FontHeight/2),y);
    }
    drawx+=len;
    if(drawx>=MaxLength) break;
  }
  
  if(x!=0) return;
  
  drawx=x+(drawx*FontHeight/2);
  if(drawx<240){
    FontData_BGCHRFill(BGCHR,drawx,y,240-drawx,FontHeight,1);
  }
}

void fp_FontData_BGCHRDrawText(u16 *BGCHR,u32 x,u32 y,u8 *str)
{
  funcadd(FuncC_fontpack,11);
  
  const u32 FontHeight=FontPack->FontHeight;
  const u32 MaxLength=divu32(240-x,FontHeight)*2-1;
  
  FontData_BGCHRDrawTextLimit(BGCHR,x,y,str,MaxLength,1,False);
}

void fp_FontData_BGCHRDrawTextTabStop(u16 *BGCHR,u32 x,u32 y,u8 *str,u32 TabStop,b8 ShowTab)
{
  funcadd(FuncC_fontpack,12);
  
  const u32 FontHeight=FontPack->FontHeight;
  const u32 MaxLength=divu32(240-x,FontHeight)*2-1;
  
  FontData_BGCHRDrawTextLimit(BGCHR,x,y,str,MaxLength,TabStop,ShowTab);
}

void FontData_OBJ2D256DrawDecode(u32 BaseOBJNo)
{
  funcadd(FuncC_fontpack,13);
  
  const u32 TileSize=8*8;
  
  u32 FontHeight=FontPack->FontHeight;
  u8 *DecPtr;
  
  DecPtr=&DecData[0];
  
  u32 dy;
  u32 tilebase;
  u16 *tiledata;
  u32 lastx;
  
  for(dy=0;dy<FontHeight;dy++){
    tilebase=(BaseOBJNo+((dy/8)*0x10))*(TileSize/2);
    tiledata=OAMdata;
    tiledata+=tilebase+((dy&7)*4);
    lastx=FontHeight;
    
    for(lastx=0;lastx<FontHeight;lastx+=2){
      *tiledata=((u16)DecPtr[1]<<8)+((u16)DecPtr[0]);
      tiledata++;
      DecPtr+=2;
      if((lastx%8)==6) tiledata+=-4+(TileSize/2);
    }
  }
}

void FontData_OBJ1D256DrawDecode(u32 BaseOBJNo)
{
  funcadd(FuncC_fontpack,14);
  
  const u32 TileSize=8*8;
  
  u32 FontHeight=FontPack->FontHeight;
  u8 *DecPtr;
  
  DecPtr=&DecData[0];
  
  u32 dy;
  u32 tilebase;
  u16 *tiledata;
  u32 lastx;
  
  for(dy=0;dy<FontHeight;dy++){
    tilebase=(BaseOBJNo+((dy/8)*2))*(TileSize/2);
    tiledata=OAMdata;
    tiledata+=tilebase+((dy&7)*4);
    lastx=FontHeight;
    
    for(lastx=0;lastx<FontHeight;lastx+=2){
      *tiledata=((u16)DecPtr[1]<<8)+((u16)DecPtr[0]);
      tiledata++;
      DecPtr+=2;
      if((lastx%8)==6) tiledata+=-4+(TileSize/2);
    }
  }
}

void FontData_BGCHRFillFlame(u16 *BGCHR,u32 x,u32 y,u32 w,u32 h,u16 colMask,u16 colBright,u16 colBG)
{
  funcadd(FuncC_fontpack,15);
  
  FontData_BGCHRFill(BGCHR,x-1,y-1,w+2,h+2,colMask);
  FontData_BGCHRFill(BGCHR,x,y,w,h,colBright);
  FontData_BGCHRFill(BGCHR,x+1,y+1,w-2,h-2,colBG);
}
