/* hello.c - Gameboy Advance Tutorial - Loirak Development */
#include <agb_lib.h>
#include "bg.c"

int main()
{
	Initialize();
	bgPic2Buffer((void*)bgBitmap);
	bgPal((void*)bgPalette);
	bgPic((void*)bgBitmap);
	FadeIn(2);
	Sleep(196);
	while(1)
	{
		WaitForVblank();
		CycleBGPalette();
		Sleep(15);
	}
	return 0;
}
