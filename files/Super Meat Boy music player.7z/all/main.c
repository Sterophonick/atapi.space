#include "titlescreen.h"
#include "musicselect.h"
#include "music.h"
#include "gates.h"
#include "gba_keys.h"

int selected = ch1l;
int selectmeu = 0;

sound[0].song=ch1s; sound[0].frequency=22050; sound[0].end=18000; sound[0].tic=0; //init Forest Funk
sound[1].song=ch2s; sound[1].frequency=22050; sound[1].end=18012; sound[1].tic=0; //init Betus Blues
sound[2].song=ch3s; sound[2].frequency=22050; sound[2].end=18020; sound[2].tic=0; //init Can o' Salt
sound[3].song=ch4s; sound[3].frequency=22050; sound[3].end=18054; sound[3].tic=0; //init Hot Damned
sound[4].song=ch5s; sound[4].frequency=22050; sound[4].end=18024; sound[4].tic=0; //init It Ends
sound[5].song=ch6s; sound[5].frequency=22050; sound[5].end=18005; sound[5].tic=0; //init It Ends With a Whimper
sound[6].song=ch7s; sound[6].frequency=22050; sound[6].end=; sound[6].tic=0; //init Ch. 7 gameplay
sound[7].song=escs; sound[7].frequency=22050; sound[7].end=12036; sound[7].tic=0; //init Escape!
sound[8].song=2bsss; sound[8].frequency=22050; sound[8].end=12025; sound[8].tic=0; //init C.H.A.D.'s Lullaby

void playSound(int s)
{
 REG_SOUNDCNT_H = 0x0B04;                                                       //REG_SOUNDCNT_H = 0000 1011 0000 0100, volume = 100, sound goes to the left, sound goes to the right, timer 0 is used, FIFO buffer reset
 REG_SOUNDCNT_X = 0x0080;                                                       //REG_SOUNDCNT_X = 0000 0000 1000 0000, enable the sound system, DMA 1
 REG_DM1SAD     = (unsigned long) sound[s].song;                                //REG_DM1SAD = NAME, address of DMA source is the digitized music sample
 REG_DM1DAD     = 0x040000A0;                                                   //REG_DM1DAD = REG_SGFIFOA, address of DMA destination is FIFO buffer for direct sound A
 REG_DM1CNT_H   = 0xB640;                                                       //REG_DM1CNT_H = 1011 0110 0100 0000, DMA destination is fixed, repeat transfer of 4 bytes when FIFO , buffer is empty, enable DMA 1 (number of DMA transfers is ignored), INTERRUPT
 REG_TM0D       = 65536-(16777216/sound[s].frequency);                          //REG_TM0D = 65536-(16777216/frequency);, play sample every 16777216/frequency CPU cycles
 REG_TM0CNT     = 0x00C0;                                                       //REG_TM0CNT = 0000 0000 1100 0000, enable timer 0, send Interrupt Request when timer overflows    
}

void title_bg()                                                               //copy background to video buffer using DMA
{
     while Not(keyDown(KEY_START)) {
 REG_DM3SAD = (unsigned long)title_data;
 REG_DM3DAD = (unsigned long)VideoBuffer;
 REG_DM3CNT = 0x80000000 | 120*160;
}
selectmenu = 1;
return 0;
}

void selectmusic()
{
     if (selected == ch1l)
     {
                   REG_DM3SAD = (unsigned long)1l_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                   if (keyDown(KEY_A)
                   {
                                 playSound(0);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch2l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = 2bss;
                   }
     }
     if (selected == ch2l)
     {
                   REG_DM3SAD = (unsigned long)2l_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                   if (keyDown(KEY_A)
                   {
                                 playSound(1);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch3l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch1l;
                   }
     }
     if (selected == ch3l)
     {
                   REG_DM3SAD = (unsigned long)3l_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                   if (keyDown(KEY_A)
                   {
                                 playSound(2);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch4l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch2l;
                   }
     }
     if (selected == ch4l)
     {
                   REG_DM3SAD = (unsigned long)4l_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                                      if (keyDown(KEY_A)
                   {
                                 playSound(3);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch5l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch3l;
                   }
     }
     if (selected == ch5l)
     {
                   REG_DM3SAD = (unsigned long)5l_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                                      if (keyDown(KEY_A)
                   {
                                 playSound(4);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch6l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch4l;
                   }
     }
     if (selected == ch6l)
     {
                   REG_DM3SAD = (unsigned long)6ld_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                                      if (keyDown(KEY_A)
                   {
                                 playSound(5);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch7l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch5l;
                   }
     }
     if (selected == ch7l)
     {
                   REG_DM3SAD = (unsigned long)7ld_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                                      if (keyDown(KEY_A)
                   {
                                 playSound(6);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = esc;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch6l;
                   }
     }
     if (selected == esc)
     {
                   REG_DM3SAD = (unsigned long)esc_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                                      if (keyDown(KEY_A)
                   {
                                 playSound(7);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = 2bss;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = ch7l;
                   }
     }
     if (selected == 2bss)
     {
                   REG_DM3SAD = (unsigned long)2bss_sel;
                   REG_DM3DAD = (unsigned long)VideoBuffer;
                   REG_DM3CNT = 0x80000000 | 120*160;
                                      if (keyDown(KEY_A)
                   {
                                 playSound(8);    
                   }
                   if (keyDown(KEY_DOWN)
                   {
                                      selected = ch1l;
                   }
                   if (keyDown(KEY_UP)
                   {
                                      selected = esc;
                   }
     }
}

int main(){
    selectmenu = 0;
    while Not(selectmenu = 1) {
          titlebg();
          }
    selectmusic();
}
