#include <agb_lib.h>
#include "data.h"
int select;
int wait;

int main()
{
	Initialize();
	SetMode(MODE_4|BG2_ENABLE);
	setbg2((void*)titleBitmap, (void*)titlePalette);
	FadeIn(2);
	while(!(keyDown(KEY_START)))
	{
		wait=0;
	}
	FadeOut(2);
	setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
	FadeIn(2);
	while(1)
	{
		if(keyDown(KEY_A))
		{
			FadeOut(2);
			setbg2((void*)pointselectBitmap, (void*)pointselectPalette);
			FadeIn(2);
			Sleep(128);
			select=1;
			while(select==1)
			{
				if(keyDown(KEY_A))
				{
					FadeOut(2);
					setbg2((void*)nin1Bitmap, (void*)nin1Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)nin1ansBitmap, (void*)nin1ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_B))
				{
					FadeOut(2);
					setbg2((void*)nin2Bitmap, (void*)nin2Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)nin2ansBitmap, (void*)nin2ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_L))
				{
					FadeOut(2);
					setbg2((void*)nin3Bitmap, (void*)nin3Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)nin3ansBitmap, (void*)nin3ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_R))
				{
					FadeIn(2);
					setbg2((void*)nin4Bitmap, (void*)nin4Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)nin4ansBitmap, (void*)nin4ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
			}
		}
		if(keyDown(KEY_B))
		{
			FadeOut(2);
			setbg2((void*)pointselectBitmap, (void*)pointselectPalette);
			FadeIn(2);
			Sleep(128);
			select=1;
			while(select==1)
			{
				if(keyDown(KEY_A))
				{
					FadeOut(2);
					setbg2((void*)atar1Bitmap, (void*)atar1Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)atar1ansBitmap, (void*)atar1ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_B))
				{
					FadeOut(2);
					setbg2((void*)atar2Bitmap, (void*)atar2Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)atar2ansBitmap, (void*)atar2ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_L))
				{
					FadeOut(2);
					setbg2((void*)atar3Bitmap, (void*)atar3Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)atar3ansBitmap, (void*)atar3ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_R))
				{
					FadeIn(2);
					setbg2((void*)atar4Bitmap, (void*)atar4Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)atar4ansBitmap, (void*)atar4ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
			}
		}
		if(keyDown(KEY_L))
		{
			FadeOut(2);
			setbg2((void*)pointselectBitmap, (void*)pointselectPalette);
			FadeIn(2);
			Sleep(128);
			select=1;
			while(select==1)
			{
				if(keyDown(KEY_A))
				{
					FadeOut(2);
					setbg2((void*)ind1Bitmap, (void*)ind1Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)ind1ansBitmap, (void*)ind1ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_B))
				{
					FadeOut(2);
					setbg2((void*)ind2Bitmap, (void*)ind2Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					setbg2((void*)ind2ansBitmap, (void*)ind2ansPalette);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					select=0;
				}
				if(keyDown(KEY_L))
				{
					FadeOut(2);
					setbg2((void*)ind3Bitmap, (void*)ind3Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)ind3ansBitmap, (void*)ind3ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_R))
				{
					FadeIn(2);
					setbg2((void*)ind4Bitmap, (void*)ind4Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)ind4ansBitmap, (void*)ind4ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
			}
		}
		if(keyDown(KEY_R))
		{
			FadeOut(2);
			setbg2((void*)pointselectBitmap, (void*)pointselectPalette);
			FadeIn(2);
			Sleep(128);
			select=1;
			while(select==1)
			{
				if(keyDown(KEY_A))
				{
					FadeOut(2);
					setbg2((void*)home1Bitmap, (void*)home1Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)home1ansBitmap, (void*)home1ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_B))
				{
					FadeOut(2);
					setbg2((void*)home2Bitmap, (void*)home2Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					setbg2((void*)home2ansBitmap, (void*)home2ansPalette);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					select=0;
				}
				if(keyDown(KEY_L))
				{
					FadeOut(2);
					setbg2((void*)home3Bitmap, (void*)home3Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)home3ansBitmap, (void*)home3ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
				if(keyDown(KEY_R))
				{
					FadeIn(2);
					setbg2((void*)home4Bitmap, (void*)home4Palette);
					FadeIn(2);
					Sleep(128);
					while(!(keyDown(KEY_START)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)home4ansBitmap, (void*)home4ansPalette);
					FadeIn(2);
					while(!(keyDown(KEY_SELECT)))
					{
						wait=0;
					}
					FadeOut(2);
					setbg2((void*)selectcourseBitmap, (void*)selectcoursePalette);
					FadeIn(2);
					select=0;
				}
			}
		}
	}
	return 0;
}

