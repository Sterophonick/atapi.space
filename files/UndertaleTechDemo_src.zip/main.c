/*********************************************************************************
 * Includes
 ********************************************************************************/
// Basically, first, as on top of all HAM files, the most
// important include is the mygba.h, which contains all the
// macro definitions, and the HAMlib function prototypes.
#include "mygba.h"
// Graphics include
#include "gfx/monster.raw.c"
#include "gfx/master.pal.c"
#include "ruins.raw.c"
#include "ruins.map.c"
#include "ruins.pal.c"


/*********************************************************************************
 * MULTIBOOT is interesting.
 * If you write this on the top of your main file,
 * the GBA ROM you build will automatically be capable of running both
 * from FLA carts and, in addition directly over the MBV2 cable.
 * If you do not need this, simply comment it out.
 ********************************************************************************/
MULTIBOOT

map_fragment_info_ptr BackGroundMap;

/*********************************************************************************
 * Defines
 ********************************************************************************/
#define ANIM_UP     256*4
#define ANIM_DOWN   256*8
#define ANIM_LEFT   256*0


/*********************************************************************************
 * Global Variables
 ********************************************************************************/
 int flip;
u16 g_DirectionAnim=0;  // Direction the monster faces
u8  g_AnimCnt=0;        // Counter for the animation frames (0-2)
u8  g_Monster;          // Monster sprite index
u8  g_MonsterX=110;     // x pos of the g_Monster
u8  g_MonsterY=50;      // y pos of the g_Monster
u8  g_InMotion=0;       // When Monster moves, this is 1
u32 g_Frames=0;         // Global frame counter
u8  g_NewFrame=0;
int  bg_x=0;
int  bg_y=0;


/*********************************************************************************
 * Prototypes
 ********************************************************************************/
void vblFunc      (void);
void queryKeys    (void);
void redrawMonster(void);


/*********************************************************************************
 * Program entry point
 ********************************************************************************/
int main(void)
{
    // Initialize HAMlib
    // Then we call the single most important function of ham, ham_Init .
    // This function must be called first thing when working with HAMlib,
    // because all ham_* functions will only work correctly after this has been called.
    // Behaviour of HAMlib is undefined if you comment this out.
    ham_Init();
    
    // Sets the GBAs BGMode to the value specified in bgno
    ham_SetBgMode(1);

    // Init the Text display system on the bg of your choice
    // This function must be called if you want to use HAMlibs text display system.
    // After calling this, you can use ham_DrawText and ham_SetTextCol.
    ham_InitText(0);

    // Inits the Palette for the Sprite
    ham_LoadObjPal((void *)&master_Palette,        // a pointer to the palette data that is to be loaded
                   SIZEOF_16BIT(master_Palette));  // the number of the 16 color OBJ (sprite) palette you
                                                   // want to load with the 16 color values at address src.

    ham_LoadBGPal((void *)&ruins_Palette,         // a pointer to the palette data that is to be loaded
                  SIZEOF_16BIT(ruins_Palette));   // the size of the data in u16 chunks (usually 256)

    ham_bg[1].ti = ham_InitTileSet((void*)&ruins_Tiles,              // A pointer to the source data
                                    SIZEOF_16BIT(ruins_Tiles),       // The size of the tiles to be copied into Tile RAM, in number of 16bit chunks
                                    1,                              // The Color mode of the tile set (0=16col 1=256col)
                                    1);                             // Setting this one requires a bit of understanding of the GBA hardware.
                                                                    // Basically, if you put tiles into the GBA memory, you will have to put
                                                                    // them at the start of a Character Base block in order to be able to
                                                                    // access tile #0 with a map entry of 0. If the allocated block is not
                                                                    // directly at the start of a CBB, you will have to offset your map entries.
                                                                    // This is automatically done for you when you use ham_SetMapTile.
                                                                    // However, when you load your map from ROM, you might want to align your
                                                                    // tileset to a CBB boundary. If in doubt, and you have some VRAM left, set
                                                                    // this to 1 always.
                                                                    // 0=allocate at the earliest possible spot, unsafe if you do not know / do not
                                                                    // want to offset your map entries!
                                                                    // 1=allocate only on a CBB start to ensure tile 0 is map index no 0.
                                                                    // Again, if you have no idea what this is, set it to 1.

    ham_bg[1].mi = ham_InitMapEmptySet(1,   // the size of the map (0-3). This depends on the map_rot parameter!
                                       0);  // determines if this is a map for a rotation screen. (0 = no rotation map, 1 = rotation map)
                                       
        BackGroundMap = ham_InitMapFragment((void*)&ruins_Map,           // A pointer to the source data
                                        40,                         // The total width of the map you are pointing to in tiles.
                                        30,                         // The total height of the map you are pointing to in tiles.
                                        0,                          // The horizontal offset, in tiles, on the map you want to start copying from
                                        0,                          // The vertical offset, in tiles, on the map you want to start copying from
                                        64,                         // The number of tiles (from the offset on) you want to specify horizontally
                                        64,                         // The number of tiles (from the offset on) you want to specify vertically
                                        0);                         // 0 = no rotation map, 1 = rotation map

    ham_InsertMapFragment(BackGroundMap,    // A map fragment info pointer previously created by ham_InitMapFragment
                          1,                // The BG number you want to Insert the map fragment on (0-3)
                          0,                // The X position (in tiles) in the BG map where you want the Fragment to be placed
                          0);               // The Y position (in tiles) in the BG map where you want the Fragment to be placed
                          
    ham_InitBg(1,   // The BGs number that you want to Initialize (0-3)
               1,   // 1 = show this BG, 0 = hide this BG
               2,   // Priority of this BG to other BGs (0 = highest prio, 3 = lowest)
               1);  // Enable / Disable Mosaic for this BG (0=off 1=on)

   // Returns the ham_obj entry which is now associated with the sprite created.
   // Memory for the graphics are automatically allocated and the sprite data is
   //copied. Remember that this does not mean the sprite is comitted to Hardware yet,
   // you need to run ham_CopyObjToOAM for that
   g_Monster = ham_CreateObj((void *)&monster_Bitmap[32*32],  // A pointer to the tile data for this object
                              0,                       // obj_shape
                              2,                       // obj_size
                              OBJ_MODE_NORMAL,      // obj_mode
                              1,                       // col_mode
                              0,                       // pal_no
                              0,                       // mosaic
                              0,                       // hflip
                              0,                       // vflip
                              0,                       // dbl_size
                              0,                       // prio
                              g_MonsterX,              // x position of sprite on screen
                              g_MonsterY);             // y position of sprite on screen


   // Will, once activated, trigger the specified interrupt,
   // and then call the function specified
   ham_StartIntHandler(INT_TYPE_VBL,         // The Interrupts ID you want to start.
                       (void *)&vblFunc);    // The adress of a function that should be called when the interrupt is fired

    // Loop
    while(1)
    {
        // New Frame?
        if(g_NewFrame)
        {
            if(flip==1)
            {
                ham_SetObjHFlip(g_Monster,        // The OBJ number of which you want to modify
                                        1);              // 0 = no flip 1 = flip
            }else{
                ham_SetObjHFlip(g_Monster,        // The OBJ number of which you want to modify
                                        0);              // 0 = no flip 1 = flip
            }
            // Only update animation every 5th frame,
            // and only if the Monster is "in motion"
            if(!(g_Frames%10) && g_InMotion)
            {
                // load new graphics for this sprite
                ham_UpdateObjGfx(g_Monster,(void*)&monster_Bitmap[(g_DirectionAnim+512*(g_AnimCnt%3))*2]);
                g_AnimCnt++;
                if(g_AnimCnt>1)
                {
                    g_AnimCnt=0;
                }
                g_InMotion=0;
                
            }
            ham_SetBgXY(1,      // The BG number we want to scroll
                        bg_x,    // The new X offset value
                        bg_y);   // The new Y offset value
            queryKeys    ();    // query the joypad
            redrawMonster();    // update the g_Monster position
            
            g_Frames++;         // Increase the frame counter
            g_NewFrame=0;       // Set new frame to zero again
            if(bg_x>80)
            {
                bg_x=80;
            }
            if(bg_x<0)
            {
                bg_x=0;
            }
            if(bg_y>80)
            {
                bg_y=80;
            }
            if(bg_y<0)
            {
                bg_y=0;
            }
        }
    }
}

/*********************************************************************************
 * vblFunc(void)
 *
 * This function is called whenever the GBA is about
 * to draw a new picture onto the screen.
 ********************************************************************************/
void vblFunc()
{
   // Call this (preferably during a VBL interrupt) to commit your
   // ham_obj information to the hardware. Only after you did this your
   // sprite changes will appear on screen.
   ham_CopyObjToOAM();
   
   g_NewFrame=1;
}

/*********************************************************************************
 * redrawMonster(void)
 *
 * Sets the X and Y position of the Monster
 ********************************************************************************/
void redrawMonster(void)
{
	ham_SetObjXY(g_Monster,     // The sprite number we want to move
                 g_MonsterX,    // x position of the
                 g_MonsterY);   // y position of the sprite
}

/*********************************************************************************
 * queryKeys(void)
 *
 * Get joypad input and set new positions
 ********************************************************************************/
void queryKeys(void)
{
	if(F_CTRLINPUT_UP_PRESSED)
	{
		g_DirectionAnim = ANIM_UP;
		g_MonsterY--;
		g_InMotion=1;
		flip=0;
		bg_y--;
		return;
	}

	if(F_CTRLINPUT_DOWN_PRESSED)
	{
		g_DirectionAnim = ANIM_DOWN;
		g_MonsterY++;
		g_InMotion=1;
		flip=0;
		bg_y++;
		return;
	}

	if(F_CTRLINPUT_LEFT_PRESSED)
	{
		g_DirectionAnim = ANIM_LEFT;
		g_MonsterX--;
		g_InMotion=1;
		flip=0;
		bg_x--;
		return;
	}

	if(F_CTRLINPUT_RIGHT_PRESSED)
	{
	    g_DirectionAnim = ANIM_LEFT;
		flip=1;
		g_MonsterX++;
		g_InMotion=1;
		bg_x++;
		return;
	}
	    
}
