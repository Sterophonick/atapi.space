#include <agb_lib.h>
#include "data.h"
#define us (void*)
#define vsync WaitForVblank();

int main()
{
	Initialize();
	setbg2(us waddup0Bitmap, us waddup0Palette);
	FadeIn(2);
	while(1)
	{
		vsync
		setbg2(us waddup0Bitmap, us waddup0Palette);
		Sleep(8);	
		vsync
		setbg2(us waddup1Bitmap, us waddup1Palette);
		Sleep(8);
		vsync
		setbg2(us waddup2Bitmap, us waddup2Palette);
		Sleep(8);
		vsync
		setbg2(us waddup3Bitmap, us waddup3Palette);
		Sleep(8);
		vsync
		setbg2(us waddup4Bitmap, us waddup4Palette);
		Sleep(8);
		vsync
		setbg2(us waddup5Bitmap, us waddup5Palette);
		Sleep(8);
		vsync
		setbg2(us waddup6Bitmap, us waddup6Palette);
		Sleep(8);
		vsync
		setbg2(us waddup7Bitmap, us waddup7Palette);
		Sleep(8);
		vsync
		setbg2(us waddup8Bitmap, us waddup8Palette);
		Sleep(8);
		vsync
		setbg2(us waddup9Bitmap, us waddup9Palette);
		Sleep(8);
	}
	return 0;
}