#include <agb_lib.h>
#include "colors.h"
int xpos=0;
BG bg2;

int main()
{
	REG_DISPCNT = MODE_4| BG2_ENABLE;
	setbg2((void*)colorsBitmap, (void*)colorsPalette);
	Sleep(255);
	return 0;
}