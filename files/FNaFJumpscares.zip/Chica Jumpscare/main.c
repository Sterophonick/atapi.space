#include <agb_lib.h>
#include "chicaboi.h"
#define us (void*)
#define vsync WaitForVblank();

int main()
{
	Initialize();
	setbg2(us boi0Bitmap, us boi0Palette);
	FadeIn(2);
	while(1)
	{
		vsync
		setbg2(us boi0Bitmap, us boi0Palette);
		Sleep(5);	
		vsync
		setbg2(us boi1Bitmap, us boi1Palette);
		Sleep(5);
		vsync
		setbg2(us boi2Bitmap, us boi2Palette);
		Sleep(5);
		vsync
		setbg2(us boi3Bitmap, us boi3Palette);
		Sleep(5);
		vsync
		setbg2(us boi4Bitmap, us boi4Palette);
		Sleep(5);
		vsync
		setbg2(us boi5Bitmap, us boi5Palette);
		Sleep(5);
		vsync
		setbg2(us boi6Bitmap, us boi6Palette);
		Sleep(5);
		vsync
		setbg2(us boi7Bitmap, us boi7Palette);
		Sleep(5);
		vsync
		setbg2(us boi8Bitmap, us boi8Palette);
		Sleep(5);
		vsync
		setbg2(us boi9Bitmap, us boi9Palette);
		Sleep(5);
	}
	return 0;
}