#include <agb_lib.h>
#include "data.h"
#define us (void*)
#define vsync WaitForVblank();

int main()
{
	Initialize();
	setbg2(us fredo0Bitmap, us fredo0Palette);
	FadeIn(2);
	while(1)
	{
		vsync
		setbg2(us fredo0Bitmap, us fredo0Palette);
		Sleep(12);	
		vsync
		setbg2(us fredo1Bitmap, us fredo1Palette);
		Sleep(12);
		vsync
		setbg2(us fredo2Bitmap, us fredo2Palette);
		Sleep(12);
		vsync
		setbg2(us fredo3Bitmap, us fredo3Palette);
		Sleep(12);
		vsync
		setbg2(us fredo4Bitmap, us fredo4Palette);
		Sleep(12);
		vsync
		setbg2(us fredo5Bitmap, us fredo5Palette);
		Sleep(12);
		vsync
		setbg2(us fredo6Bitmap, us fredo6Palette);
		Sleep(12);
		vsync
		setbg2(us fredo7Bitmap, us fredo7Palette);
		Sleep(12);
		vsync
		setbg2(us fredo8Bitmap, us fredo8Palette);
		Sleep(12);
		vsync
		setbg2(us fredo9Bitmap, us fredo9Palette);
		Sleep(12);
		vsync
		setbg2(us fredo10Bitmap, us fredo10Palette);
		Sleep(12);
		vsync
		setbg2(us fredo11Bitmap, us fredo11Palette);
		Sleep(12);
		vsync
		setbg2(us fredo12Bitmap, us fredo12Palette);
		Sleep(12);
		vsync
		setbg2(us fredo13Bitmap, us fredo13Palette);
		Sleep(12);
	}
	return 0;
}