#include <agb_lib.h>
#include "bonniboi.h"
#define us (void*)
#define vsync WaitForVblank();

int main()
{
	Initialize();
	setbg2(us bon0Bitmap, us bon0Palette);
	FadeIn(2);
	while(1)
	{
		vsync
		setbg2(us bon0Bitmap, us bon0Palette);
		Sleep(5);	
		vsync
		setbg2(us bon1Bitmap, us bon1Palette);
		Sleep(5);
		vsync
		setbg2(us bon2Bitmap, us bon2Palette);
		Sleep(5);
		vsync
		setbg2(us bon3Bitmap, us bon3Palette);
		Sleep(5);
		vsync
		setbg2(us bon4Bitmap, us bon4Palette);
		Sleep(5);
		vsync
		setbg2(us bon5Bitmap, us bon5Palette);
		Sleep(5);
		vsync
		setbg2(us bon6Bitmap, us bon6Palette);
		Sleep(5);
		vsync
		setbg2(us bon7Bitmap, us bon7Palette);
		Sleep(5);
		vsync
		setbg2(us bon8Bitmap, us bon8Palette);
		Sleep(5);
		vsync
		setbg2(us bon9Bitmap, us bon9Palette);
		Sleep(5);
	}
	return 0;
}