#include <agb_lib.h>
#include "data.h"
#define us (void*)
#define vsync WaitForVblank();

int main()
{
	Initialize();
	setbg2(us s0Bitmap, us s0Palette);
	FadeIn(2);
	while(1)
	{
		vsync
		setbg2(us s0Bitmap, us s0Palette);
		Sleep(5);	
		vsync
		setbg2(us s1Bitmap, us s1Palette);
		Sleep(5);
		vsync
		setbg2(us s2Bitmap, us s2Palette);
		Sleep(5);
		vsync
		setbg2(us s3Bitmap, us s3Palette);
		Sleep(5);
		vsync
		setbg2(us s4Bitmap, us s4Palette);
		Sleep(5);
		vsync
		setbg2(us s5Bitmap, us s5Palette);
		Sleep(5);
		vsync
		setbg2(us s6Bitmap, us s6Palette);
		Sleep(5);
		vsync
		setbg2(us s7Bitmap, us s7Palette);
		Sleep(5);
		vsync
		setbg2(us s8Bitmap, us s8Palette);
		Sleep(5);
		vsync
		setbg2(us s9Bitmap, us s9Palette);
		Sleep(5);
	}
	return 0;
}