#include <agb_lib.h>
#include "concept.c"

int main()
{
	Initialize();
	SetMode(MODE_3|BG2_ENABLE);
	bgPic2Buffer((u16*)conceptBitmap);
	bgPal((u16*)conceptPalette);
	bgPic((u16*)conceptBitmap);
	FadeIn(2);
	Sleep(512);
	while(1);
	return 0;
}