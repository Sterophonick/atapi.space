
#define EnableFuncLog False

#define FuncC_Count (5)
#define FuncF_Count (128)

#define FuncC_main (0)
#define FuncC_main_img (1)
#define FuncC_fontpack (2)
#define FuncC_GBATools (3)
#define FuncC_textcnt (4)

u8 *CountBuffer=(u8*)0x0e008000;

void funcinit(void);
attriwram void fp_funcadd(u32 c,u32 f);

#if EnableFuncLog==True
void funcinit(void)
{
  u32 c,f;
  u32 off;
  
  for(c=0;c<FuncC_Count;c++){
    for(f=0;f<FuncF_Count;f++){
      off=(c*FuncF_Count+f)*2;
      CountBuffer[off+0]=0x00;
      CountBuffer[off+1]=0x00;
    }
  }
}
#else
#define funcinit() {}
#endif

#if EnableFuncLog==True
void fp_funcadd(u32 c,u32 f)
{
  if(FuncF_Count<=f) f=FuncF_Count-1;
  
  u32 off=(c*FuncF_Count+f)*2;
  
  if(CountBuffer[off+0]!=0xff){
    CountBuffer[off+0]++;
    }else{
    if(CountBuffer[off+1]!=0xff){
      CountBuffer[off+0]=0x00;
      CountBuffer[off+1]++;
      }else{
      CountBuffer[off+0]=0xff;
      CountBuffer[off+1]=0xff;
    }
  }
}
void (*funcadd)(u32 c,u32 f)=fp_funcadd;
#else
#define funcadd(c,f) {}
#endif

