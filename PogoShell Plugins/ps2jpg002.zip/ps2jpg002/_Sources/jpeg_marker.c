
b8 AnalizeJpegMarker(void)
{
  b8 StartSOSFlag;
  u8 Marker0,Marker1;
  
  StartSOSFlag=False;
  
  YUVMode=YUVMode_Unknown;
  DelayRestartInterval=0;
  
  while(StartSOSFlag==False){
    Marker0=rfs8bit();
    Marker1=rfs8bit();
    if(Marker0!=0xff){
      uprintf("Detect NoMark.0x%x 0x%x\n",Marker0,Marker1);
      msgSetStr(resprintf);
      return(False);
      while(1);
      }else{
      switch(Marker1){
        case 0xd8:
          dprint("Start of image segment\n");
          break;
        case 0xe0:
          dprint("APP0 Application marker\n");
          Marker_APP0();
          break;
        case 0xdb:
          dprint("DQT Define quantization table segment\n");
          Marker_DQT();
          break;
        case 0xc0:
          dprint("SOF0 Start of Frame / Baseline DCT, Huffman\n");
          Marker_SOF0();
          break;
        case 0xc4:
          dprint("DHT Define Huffman Table\n");
          Marker_DHT();
          break;
        case 0xdd:
          dprint("DRI Define Restart Interval\n");
          Marker_DRI();
          break;
        case 0xda:
          dprint("SOS Start of scan segment\n");
          Marker_SOS();
          StartSOSFlag=True;
          break;
        default:
          if((0xe1<=Marker1) && (Marker1<=0xef)){
            dprint("APPx Extend Application marker\n");
            Marker_APPx();
            }else{
            if(((0xc0<=Marker1) && (Marker1<=0xc3)) || ((0xc5<=Marker1) && (Marker1<=0xc7)) || ((0xc9<=Marker1) && (Marker1<=0xcb)) || ((0xcd<=Marker1) && (Marker1<=0xcf))){
              uprintf("Error:SOF NotSupport Start of Frame Type(%x)\n",Marker1);
              dprint(resprintf);
              uprintf("Detect NotSupport SOF(0x%x)\n",Marker1);
              msgSetStr(resprintf);
              return(False);
            }
            if((0xf0<=Marker1) && (Marker1<=0xfd)){
              uprintf("Detect JpegReserve Type(%x)\n",Marker1);
              msgSetStr(resprintf);
              return(False);
            }
            Marker_Unknown();
          }
          break;
      }
    }
  }
  
  BitStreamStartPosition=rfsGetPosition();
  
  return(True);
}

u32 Marker__GetSize(void)
{
  return(rfs16bit()-2);
}

u32 Marker__GetNextPosition(void)
{
  u32 size=Marker__GetSize();
  
  return(rfsGetPosition()+size);
}

void Marker_Unknown(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  rfsSetPosition(nextpos);
}

void Marker_APP0(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  rfsSetPosition(nextpos);
}

void Marker_APPx(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  rfsSetPosition(nextpos);
}

void Marker_DQT(void)
{
  u32 size=Marker__GetSize();
  u32 nextpos;
  
  TQuantizeTable *_QuantizeTable;
  u32 Count,cnt,qcnt;
  u8 tag;
  
  nextpos=rfsGetPosition()+size;
  
  Count=size/65;
  
  for(cnt=0;cnt<Count;cnt++){
    tag=rfs8bit();
    _QuantizeTable=&QuantizeTable[tag&0x0f];
    _QuantizeTable->Precision=tag >> 4;
    for(qcnt=0;qcnt<64;qcnt++){
      _QuantizeTable->data[qcnt]=(s8)(rfs8bit());
    }
  }
  
/*
  dprint("debug:");
  for(cnt=0;cnt<Count;cnt++){
    uprintf("QuantizeTable[%d]\n",cnt); dprint(resprintf);
    _QuantizeTable=&QuantizeTable[cnt];
    uprintf("Precision=%d\n",_QuantizeTable->Precision); dprint(resprintf);
    dprint("data=");
    for(qcnt=0;qcnt<64;qcnt++){
      uprintf("%d,",_QuantizeTable->data[zigzag[qcnt]]); dprint(resprintf);
    }
    dprint("\n");
  }
  dprint("\n");
*/
  
  rfsSetPosition(nextpos);
}

void Marker_SOF0(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  TFlameInfo *_FlameInfo;
  TSampleInfo *_SampleInfo;
  
  u32 cnt;
  u8 tmp;
  
  _FlameInfo=&FlameInfo;
  
  _FlameInfo->DepthPerSample=rfs8bit();
  _FlameInfo->Height=rfs16bit();
  _FlameInfo->Width=rfs16bit();
  SampleCount=rfs8bit();
  
  _FlameInfo->SampleMaxHFact=0;
  _FlameInfo->SampleMaxVFact=0;
  
  SampleInfo[0].HFact=0;
  SampleInfo[0].VFact=0;
  SampleInfo[1].HFact=0;
  SampleInfo[1].VFact=0;
  SampleInfo[2].HFact=0;
  SampleInfo[2].VFact=0;
  
  for(cnt=0;cnt<SampleCount;cnt++){
    u32 ID=rfs8bit()-1;
    if(cnt!=ID){
      msgSetStr("SOF0:ID Error.");
      while(1);
    }
    
    _SampleInfo=&SampleInfo[ID];
    
    tmp=rfs8bit();
    _SampleInfo->HFact=tmp >> 4;
    _SampleInfo->VFact=tmp & 0x0f;
    _SampleInfo->QuantizeTableIndex=rfs8bit();
    if(_FlameInfo->SampleMaxHFact<_SampleInfo->HFact) _FlameInfo->SampleMaxHFact=_SampleInfo->HFact;
    if(_FlameInfo->SampleMaxVFact<_SampleInfo->VFact) _FlameInfo->SampleMaxVFact=_SampleInfo->VFact;
    
    uprintf("debug:SampleInfo[%d]\n",cnt); dprint(resprintf);
    uprintf("HFact=%d VFact=%d\n",_SampleInfo->HFact,_SampleInfo->VFact); dprint(resprintf);
    uprintf("QuantizeTableIndex=%d\n",_SampleInfo->QuantizeTableIndex); dprint(resprintf);
  }
  
  if(((SampleInfo[0].HFact==1)&&(SampleInfo[0].VFact==1))&&
     ((SampleInfo[1].HFact==1)&&(SampleInfo[1].VFact==1))&&
     ((SampleInfo[2].HFact==1)&&(SampleInfo[2].VFact==1))){
    msgSetStr("YUVModeSwitch to YUV111");
    YUVMode=YUVMode_111;
  }
  
  if(((SampleInfo[0].HFact==2)&&(SampleInfo[0].VFact==2))&&
     ((SampleInfo[1].HFact==1)&&(SampleInfo[1].VFact==1))&&
     ((SampleInfo[2].HFact==1)&&(SampleInfo[2].VFact==1))){
    msgSetStr("YUVModeSwitch to YUV411");
    YUVMode=YUVMode_411;
  }
  
  if(((SampleInfo[0].HFact==1)&&(SampleInfo[0].VFact==1))&&
     ((SampleInfo[1].HFact==0)&&(SampleInfo[1].VFact==0))&&
     ((SampleInfo[2].HFact==0)&&(SampleInfo[2].VFact==0))){
    msgSetStr("YUVModeSwitch to YUV100");
    YUVMode=YUVMode_100;
  }
  
  _FlameInfo->MCUWidthSize=_FlameInfo->SampleMaxHFact*8;
  _FlameInfo->MCUHeightSize=_FlameInfo->SampleMaxVFact*8;
  
  _FlameInfo->MCUWidthCount=(_FlameInfo->Width+_FlameInfo->MCUWidthSize-1) / _FlameInfo->MCUWidthSize;
  _FlameInfo->MCUHeightCount=(_FlameInfo->Height+_FlameInfo->MCUHeightSize-1) / _FlameInfo->MCUHeightSize;
  _FlameInfo->MCUCount=_FlameInfo->MCUWidthCount*_FlameInfo->MCUHeightCount;
  
  rfsSetPosition(nextpos);
}

void Marker_DHT(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  THuffmanTree *_HuffmanTree;
  
  u8 tmp;
  u32 cls,id;
  u32 len[16];
  u32 lcnt,bcnt;
  u32 hufcode,hufbit;
  
  void CreateHuffmanTree(u32 *hufbit,u32 code,u32 bits)
  {
    if(1<bits) CreateHuffmanTree(hufbit,code >> 1,bits-1);
    *hufbit=(*hufbit<<1)+(code&0x01);
  }
  
  while(rfsGetPosition()<nextpos){
    tmp=rfs8bit();
    cls=tmp >> 4;
    id=tmp & 0x0f;
    for(lcnt=0;lcnt<16;lcnt++){
      len[lcnt]=rfs8bit();
    }
    
    _HuffmanTree=&HuffmanTree[cls][id];
    
    _HuffmanTree->size=0;
    hufcode=0;
    for(lcnt=0;lcnt<16;lcnt++){
      for(bcnt=0;bcnt<len[lcnt];bcnt++){
        _HuffmanTree->code[_HuffmanTree->size]=rfs8bit();
        _HuffmanTree->bitcount[_HuffmanTree->size]=lcnt+1;
        hufbit=0;
        CreateHuffmanTree(&hufbit,hufcode,_HuffmanTree->bitcount[_HuffmanTree->size]);
        _HuffmanTree->bitimage[_HuffmanTree->size]=hufbit;
        hufcode++;
        _HuffmanTree->size++;
      }
      hufcode=hufcode << 1;
    }
    
/*
    uprintf("debug:HuffmanTree[%d,%d]\n",cls,id); dprint(resprintf);
    for (lcnt=0;lcnt<_HuffmanTree->size;lcnt++){
      uprintf("data[%d]=%x %x %x\n",lcnt,_HuffmanTree->code[lcnt],_HuffmanTree->bitcount[lcnt],_HuffmanTree->bitimage[lcnt]); dprint(resprintf);
    }
    uprintf("\n");
*/
  }
  
  rfsSetPosition(nextpos);
}

void Marker_DRI(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  DelayRestartInterval=rfs16bit();
  
  rfsSetPosition(nextpos);
}

void Marker_SOS(void)
{
  u32 nextpos=Marker__GetNextPosition();
  
  u32 cnt;
  
  ScanCount=rfs8bit();
  
  for(cnt=0;cnt<ScanCount;cnt++){
    u32 ID=rfs8bit()-1;
    if(cnt!=ID){
      msgSetStr("SOS:ID Error.");
      while(1);
    }
    
    TScanInfo *_ScanInfo=&ScanInfo[ID];
    b8 tmp;
    
    tmp=rfs8bit();
    _ScanInfo->HuffmanTableDC=tmp >> 4;
    _ScanInfo->HuffmanTableAC=tmp & 0x0f;
    _ScanInfo->HuffmanTreeDC=&HuffmanTree[0][_ScanInfo->HuffmanTableDC];
    _ScanInfo->HuffmanTreeAC=&HuffmanTree[1][_ScanInfo->HuffmanTableAC];
    _ScanInfo->SampleInfo=&SampleInfo[cnt];
    _ScanInfo->QuantizeTable=&QuantizeTable[_ScanInfo->SampleInfo->QuantizeTableIndex];
    _ScanInfo->DCDiff=0;
    
    uprintf("debug:ScanInfo[%d]\n",cnt); dprint(resprintf);
    uprintf("HuffmanTableDC=%d at 0x%x\n",_ScanInfo->HuffmanTableDC,(u32)_ScanInfo->HuffmanTreeDC); dprint(resprintf);
    uprintf("HuffmanTableAC=%d at 0x%x\n",_ScanInfo->HuffmanTableAC,(u32)_ScanInfo->HuffmanTreeAC); dprint(resprintf);
    uprintf("\n");
  }
  
  rfsSetPosition(nextpos);
}
