
u8 *rfsBaseBuf;
u8 *rfsBuf;

u8 *rfsCurBuf;
u8 _rfsCurBuf[1024+256];
u32 rfsCurBufGap;

u32 rfsCurPos;

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

// private

u8 *rbsBaseBuf;
u8 *rbsBuf;
u32 rbsCurrentBuf;
u32 rbsCurrentBufLast;
u32 rbsCurrentBit;
attriwram void fp_rbsLoadWord(void);
void (*rbsLoadWord)(void)=fp_rbsLoadWord;
attrinline void rbsInitBit(void);
attrinline void rbsLoadBit(u32 reqbit);

// public
b8 rbsEOIFlag,rbsRSTFlag,rbsRST_Skip1MCUFlag,rbsErrorFlag;
void rbsInit(u8 *ptr);
void rbsClose(void);
attriwram b8 fp_rbsCheckSegment(void);
b8 (*rbsCheckSegment)(void)=fp_rbsCheckSegment;
attrinline u32 rbsDecodeHuffman(THuffmanTree *HuffmanTree);
attrinline s32 rbsGetVL(u32 bits);
attrinline void rbsSkipVL(u32 bits);
attriwram void fp_rbsGetCurPos(u32 *_posbit);
void (*rbsGetCurPos)(u32 *_posbit)=fp_rbsGetCurPos;
attriwram void fp_rbsSetCurPos(u32 posbit);
void (*rbsSetCurPos)(u32 posbit)=fp_rbsSetCurPos;
attriwram void fp_rbsRefreshCurBuf(void);
void (*rbsRefreshCurBuf)(void)=fp_rbsRefreshCurBuf;

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

void rfsInit(u8 *ptr)
{
  rfsBaseBuf=ptr;
  
  rfsBuf=rfsBaseBuf;
  
  rfsCurPos=0;
  
  rfsCurBufGap=((u32)&rfsBuf[0])&3;
  
  REG_DM2SAD = (u32)&rfsBuf[-rfsCurBufGap];
  REG_DM2DAD = (u32)&_rfsCurBuf[0];
  REG_DM2CNT_L=(1024)/4;
  REG_DM2CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_OFF);
//  while((REG_DM2CNT_H&BIT15)!=0);
  rfsCurBuf=&_rfsCurBuf[rfsCurBufGap];
}

void rfsClose(void)
{
  rfsCurBuf=0;
  rfsBuf=0;
}

void rfsStartFlame(void)
{
  u32 edsize=(u32)&rfsCurBuf[0]-(u32)&_rfsCurBuf[0];
  
  if(edsize<1024-256){
    return;
  }
  
  rfsBuf+=edsize-rfsCurBufGap;
  
  rfsCurBufGap=((u32)&rfsBuf[0])&3;
  
  REG_DM2SAD = (u32)&rfsBuf[-rfsCurBufGap];
  REG_DM2CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_OFF);
//  while((REG_DM2CNT_H&BIT15)!=0);
  rfsCurBuf=&_rfsCurBuf[rfsCurBufGap];
}

u8 *rfsReadBuf(u32 size)
{
  u8 *ret;
  
  ret=rfsCurBuf;
  rfsCurBuf+=size;
  rfsCurPos+=size;
  
  return(ret);
}

u8 rfs8bit(void)
{
  u8 d;
  
  d=rfsCurBuf[0];
  rfsCurBuf++;
  rfsCurPos++;
  
  return(d);
}

u16 rfs16bit(void)
{
  u16 d;
  
  d=(u16)rfsCurBuf[0]<<8;
  d+=(u16)rfsCurBuf[1];
  rfsCurBuf+=2;
  rfsCurPos+=2;
  
  return(d);
}

attrinline u32 rfsGetPosition(void)
{
  return(rfsCurPos);
}

attrinline void rfsSetPosition(u32 _pos)
{
  rfsBuf=rfsBaseBuf+_pos;
  
  rfsCurPos=_pos;
  
  rfsCurBufGap=((u32)&rfsBuf[0])&3;
  
  REG_DM2SAD = (u32)&rfsBuf[-rfsCurBufGap];
  REG_DM2DAD = (u32)&_rfsCurBuf[0];
  REG_DM2CNT_L=(1024)/4;
  REG_DM2CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_OFF);
//  while((REG_DM2CNT_H&BIT15)!=0);
  rfsCurBuf=&_rfsCurBuf[rfsCurBufGap];
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

void rbsInit(u8 *ptr)
{
  rbsBaseBuf=ptr;
  rbsBuf=ptr;
  
  rbsEOIFlag=False;
  rbsRSTFlag=False;
  rbsRST_Skip1MCUFlag=False;
  rbsErrorFlag=False;
  
  rbsCurrentBuf=0;
  rbsCurrentBufLast=0;
  rbsCurrentBit=0;
}

void rbsClose(void)
{
}

b8 fp_rbsCheckSegment(void)
{
  u8 *tmpbuf;
  u8 mark;
  
  tmpbuf=rbsBuf;
  tmpbuf-=rbsCurrentBufLast / 8;
  
  mark=*tmpbuf;
  tmpbuf++;
  
  if(mark!=0xff) return(False);
  
  rbsEOIFlag=False;
  rbsRSTFlag=False;
  rbsRST_Skip1MCUFlag=False;
  rbsErrorFlag=False;
  
  mark=*tmpbuf;
  tmpbuf++;
  
  if(mark==0x00){
    mark=*tmpbuf;
    tmpbuf++;
    if(mark!=0xff) return(False);
    rbsRST_Skip1MCUFlag=True;
    mark=*tmpbuf;
    tmpbuf++;
  }
  
  rbsCurrentBuf=0;
  rbsCurrentBufLast=0;
  rbsCurrentBit=0;
  
  if(mark==0xd9){
    rbsEOIFlag=True;
    }else{
    if((0xd0<=mark)&&(mark<=0xd7)){
      rbsRSTFlag=True;
      }else{
      rbsErrorFlag=True;
    }
  }
  
  rbsBuf=tmpbuf;
  
  return(True);
}

void fp_rbsLoadWord(void)
{
  u32 dw;
  
  attriwram u8 read(void)
  {
    u8 res;
    
    res=*rbsBuf;
    rbsBuf++;
    if(res==0xff){
      res=*rbsBuf;
      if(res==0x00){
        rbsBuf++;
        res=0xff;
        }else{
        res=0x00;
      }
    }
    return(res);
  }
  
  dw=read();
  dw=(dw<<8)+read();
  
  rbsCurrentBuf+=dw << (16-rbsCurrentBufLast);
  rbsCurrentBufLast+=16;
}

void rbsInitBit(void)
{
  rbsCurrentBit=0;
}

void rbsLoadBit(u32 reqbit)
{
  if(rbsCurrentBufLast<16) rbsLoadWord();
  
  rbsCurrentBit=(rbsCurrentBit << reqbit)+(rbsCurrentBuf >> (32-reqbit));
  rbsCurrentBuf=rbsCurrentBuf << reqbit;
  rbsCurrentBufLast-=reqbit;
}

u32 rbsDecodeHuffman(THuffmanTree *HuffmanTree)
{
  u32 reqbit;
  u32 cnt;
  u32 LastBit;
  
  rbsInitBit();
  LastBit=0;
  
  for(cnt=0;cnt<HuffmanTree->size;cnt++){
    reqbit=HuffmanTree->bitcount[cnt];
    if(LastBit<reqbit){
      rbsLoadBit(reqbit-LastBit);
      LastBit=reqbit;
    }
    if(rbsCurrentBit==HuffmanTree->bitimage[cnt]){
      return(HuffmanTree->code[cnt]);
    }
  }
  
  msgSetStr("BitStream HuffmanDecodeError.\n");
  uprintf("pos at 0x%x (0x%x)\n",(u32)rbsBuf,(u32)rbsBuf-(u32)rbsBaseBuf);
  msgSetStr(resprintf);
  while(1);
  return(0);
}

s32 rbsGetVL(u32 bits)
{
  u32 sign;
  s32 res;
  
  rbsInitBit();
  rbsLoadBit(bits);
  
  res=rbsCurrentBit;
  sign=1 << (bits-1);
  if((u32)res<sign) res-=(s32)((sign << 1)-1);
  
  return(res);
}

void rbsSkipVL(u32 bits)
{
  rbsInitBit();
  rbsLoadBit(bits);
/*

  if(rbsCurrentBufLast<16) rbsLoadWord();
  
  rbsCurrentBit=(rbsCurrentBit << reqbit)+(rbsCurrentBuf >> (32-reqbit));
  rbsCurrentBuf=rbsCurrentBuf << reqbit;
  rbsCurrentBufLast-=reqbit;
*/
}

void fp_rbsGetCurPos(u32 *_posbit)
{
  u32 pos,bit;
  u8 *chkbyte;
  
  pos=(u32)rbsBuf-(u32)rbsBaseBuf;
  bit=rbsCurrentBufLast;
  
  while(bit>=8){
    pos--;
    bit-=8;
    
    chkbyte=rbsBaseBuf;
    chkbyte+=pos;
    chkbyte--;
    if(*chkbyte==0xff) pos--;
  }
  
  if(bit!=0){
    pos--;
    
    chkbyte=rbsBaseBuf;
    chkbyte+=pos;
    chkbyte--;
    if(*chkbyte==0xff) pos--;
  }
  
  *_posbit=pos+(bit<<24);
}

void fp_rbsSetCurPos(u32 posbit)
{
}

void fp_rbsRefreshCurBuf(void)
{
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

