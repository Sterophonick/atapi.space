
#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

#define ADR_BGCHR0  0/16 // 32kb 1024char(256x256pixel)
#define ADR_BGMAP0 60/ 2 //  2kb 256x256map
#define ADR_BGCHR1 32/16 // 28kb 896char(256x224pixel)
#define ADR_BGMAP1 62/ 2 //  2kb 256x256map
#define ADR_BGCHR2  0/16
#define ADR_BGMAP2  0/ 2
#define ADR_BGCHR3  0/16
#define ADR_BGMAP3  0/ 2

static u16 *OBJPAL = (u16*)0x5000200;
static u16 *OBJCHR = (u16*)0x6014000;

// BG�A�h���X
u16 *BGPAL = MEM_BG_PAL;
u16 *BGCHR0 = MEM_BG_CHAR(ADR_BGCHR0);
u16 *BGMAP0 = MEM_BG_MAP(ADR_BGMAP0);
u16 *BGCHR1 = MEM_BG_CHAR(ADR_BGCHR1);
u16 *BGMAP1 = MEM_BG_MAP(ADR_BGMAP1);
u16 *BGCHR2 = MEM_BG_CHAR(ADR_BGCHR2);
u16 *BGMAP2 = MEM_BG_MAP(ADR_BGMAP2);
u16 *BGCHR3 = MEM_BG_CHAR(ADR_BGCHR3);
u16 *BGMAP3 = MEM_BG_MAP(ADR_BGMAP3);

static void SetBGCHR(u32 chrbase,u32 chrcnt,u32 palbase,u16* img,u16* pal);
static void SetOBJCHR(u32 chrbase,u32 chrcnt,u32 palbase,u16* img,u16* pal);
void InitializeSprites(void); // func.0
attriwram void fp_MoveSprite(u8 no, int x, int y); // func.1
void (*MoveSprite)(u8 no, int x, int y)=fp_MoveSprite;
attriwram void fp_SetSpriteSize(u8 no,u16 size,u16 form,u16 color); // func.2
void (*SetSpriteSize)(u8 no,u16 size,u16 form,u16 color)=fp_SetSpriteSize;
attriwram void fp_SetSpritePalette(u8 no, u8 pal); // func.3
void (*SetSpritePalette)(u8 no, u8 pal)=fp_SetSpritePalette;
attriwram void fp_SetSpriteMode(u8 no,u16 mode); // func.4
void (*SetSpriteMode)(u8 no,u16 mode)=fp_SetSpriteMode;
attriwram void fp_SetSpriteRotation(u8 no,b8 enable); // func.5
void (*SetSpriteRotation)(u8 no,b8 enable)=fp_SetSpriteRotation;
attriwram void fp_ChangeSprite(u8 no, u16 ch); // func.6
void (*ChangeSprite)(u8 no, u16 ch)=fp_ChangeSprite;
attriwram void fp_SetSpritePriority(u8 no, u8 p); // func.7
void (*SetSpritePriority)(u8 no, u8 p)=fp_SetSpritePriority;

static void SetBGCHR(u32 chrbase,u32 chrcnt,u32 palbase,u16* img,u16* pal)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)&pal[0];
  REG_DM3DAD = (u32)&BGPAL[palbase*16];
  REG_DM3CNT_L=16*2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);

  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)&img[0];
  REG_DM3DAD = (u32)&BGCHR0[chrbase*64/2/2];
  REG_DM3CNT_L=chrcnt*64/2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
}

static void SetOBJCHR(u32 chrbase,u32 chrcnt,u32 palbase,u16* img,u16* pal)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)&pal[0];
  REG_DM3DAD = (u32)&OBJPAL[palbase*16];
  REG_DM3CNT_L=16*2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_OFF);

  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)&img[0];
  REG_DM3DAD = (u32)&OBJCHR[chrbase*64/2/2];
  REG_DM3CNT_L=chrcnt*64/2/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_OFF);
}

// ���ׂẴX�v���C�g��\�������Ȃ�
void InitializeSprites(void)
{
  funcadd(FuncC_main_img,0);
  
  OAMEntry* sprites = (OAMEntry*)OAMmem; // OAM
  
  int loop;
  for(loop = 0; loop < 128; loop++)
  {
    sprites[loop].attribute0 = 160;  //y to > 159
    sprites[loop].attribute1 = 240;  //x to > 239
  }
}

// �X�v���C�g�̈ʒu��ύX
void fp_MoveSprite(u8 no, int x, int y)
{
  funcadd(FuncC_main_img,1);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM

  if(x<0) x=512+x;
  if(y<0) y=256+y;

  sp->attribute1 = (sp->attribute1 & 0xFE00) | x;
  sp->attribute0 = (sp->attribute0 & 0xFF00) | y;
}

/* -----------------------------------------  /
  SetSpriteSize
  �X�v���C�g�̌`���ݒ�
  sp�E�E�E�ύX����X�v���C�g���w��
  size�E�ESP_SIZE_8,SP_SIZE_16,SP_SIZE_32,SP_SIZE_64�̂����ꂩ
  form�E�ESP_SQUARE,SP_TALL,SP_WIDE
  color�E�ESP_COLOR_16,SP_COLOR_256
/ ------------------------------------------ */
void fp_SetSpriteSize(u8 no,u16 size,u16 form,u16 color)
{
  funcadd(FuncC_main_img,2);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute0 &= 0x1FFF;
  sp->attribute0 |= color | form | (160);
  
  sp->attribute1 &= 0x3FFF;
  sp->attribute1 |= size | (240);
}

void fp_SetSpritePalette(u8 no, u8 pal)
{
  funcadd(FuncC_main_img,3);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute2&=~(BIT15|BIT14|BIT13|BIT12);
  sp->attribute2|=pal<<12;
}

void fp_SetSpriteMode(u8 no,u16 mode)
{
  funcadd(FuncC_main_img,4);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  // SP_MODE_NORMAL SP_MODE_TRANSPERANT SP_MODE_WINDOWED
  sp->attribute0 &= ~(BIT11|BIT10);
  sp->attribute0 |= mode;
}

void fp_SetSpriteRotation(u8 no,b8 enable)
{
  funcadd(FuncC_main_img,5);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute0 &= ~(BIT9|BIT8);
  if(enable==True) sp->attribute0 |= SP_SIZE_DOUBLE|SP_ROTATION_FLAG;
}

void fp_ChangeSprite(u8 no, u16 ch)
{
  funcadd(FuncC_main_img,6);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute2 = sp->attribute2 & 0xFC00;
  sp->attribute2 = sp->attribute2 | ch;
}

void fp_SetSpritePriority(u8 no, u8 p)
{
  funcadd(FuncC_main_img,7);
  
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute2&=~(BIT11|BIT10);
  sp->attribute2|=p<<10;
}

void SetSpriteRotateParamIdx(u8 no,u32 ParamIdx)
{
  OAMEntry* sp = (OAMEntry*)OAMmem+no; // OAM
  
  sp->attribute1 &= 0xC1FF;
  sp->attribute1 |= (ParamIdx << 9);
}
