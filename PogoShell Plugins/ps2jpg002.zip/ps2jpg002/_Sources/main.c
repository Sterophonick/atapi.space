
#include "header\GBA.h"
#include "header\BG.h"
#include "header\Timer.h"
#include "header\DMA.h"
#include "header\IRQ.h"
#include "header\sprite.h"
#include "header\blend.h"
#include "header\sound.h"

#define __iwram_overlay_lma __appended_start

#define attriwram __attribute__ ((section (".data.iwram")))
//#define attriwram 

#define attriwram111 __attribute__ ((section (".iwram0")))
#define attriwram411 __attribute__ ((section (".iwram1")))
#define attriwram100 __attribute__ ((section (".iwram2")))
#define attriwram111Half __attribute__ ((section (".iwram3")))
#define attriwram411Half __attribute__ ((section (".iwram4")))
#define attriwram100Half __attribute__ ((section (".iwram5")))

#define attrinline __attribute__ ((always_inline, const)) static inline 
//#define attrinline 

#include "string.h"
#include "varargs.h"
#include "debug.c"

#include "header\GBA.h"
#include "header\BG.h"
#include "header\Timer.h"
#include "header\Blend.h"
#include "header\sprite.h"

#define VRAM0 ((u16*)(0x6000000))

#include "funccnt.c"

#include "interrupt.c"
#include "boolean.h"
#include "memtool.c"
#include "idct.c"

#include "_YUVTools.c"

volatile b8 VBlank_Enabled,VBlank_Signal;

#include "GBATools.c"

u8 *PluginFilename;
u8 *TextFilename;
u8 *TextData;
u32 TextDataSize;

#include "main_img.c"

#include "pogoshell2_args.c"
#include "pogoshell2_reset.c"
#include "pogoshell2_rtc.c"

//#include "sramgmvp.c"

void SetSprites(void);
void SB_SetSize(void);
attriwram void fp_SB_SetPos(u32 PosX,u32 PosY);
void (*SB_SetPos)(u32 PosX,u32 PosY)=fp_SB_SetPos;
attriwram void IRQ_Timer1_SBHide(void);
void msgClear(void);
attriwram void fp_msgCRLF(void);
void (*msgCRLF)(void)=fp_msgCRLF;
attriwram void fp_msgSetStr(const u8 *str);
void (*msgSetStr)(const u8 *str)=fp_msgSetStr;
attriwram void fp_msgShow(void);
void (*msgShow)(void)=fp_msgShow;
attriwram void IRQ_Timer2_ReqClearMsg(void);

b8 DispHalfFlag;
u32 BaseX,BaseY;

#include "jpeg.h"
#include "jpeg_fs.c"
#include "jpeg_marker.c"
#include "jpeg_cache.c"
#include "jpeg_decodeimage.c"

void SetSprites(void);
void SetScrollBarSize(u32 XSize,u32 YSize);
void IRQ_VBlank_Dummy(void);
attriwram void fp_mainloop(void);
void (*mainloop)(void)=fp_mainloop;
void SetDispHalfPer(s32 v);
void ShowFlameInfo(void);

void LoadIWRAMMappedCode(u32 YUVMode,b8 DispHalfFlag);

extern u16 SB_palette[];
extern u16 SB_data[];
extern u16 SmallFont_palette[];
extern u16 SmallFont_data[];

#define obj_SBBase (0)
#define obj_SBPal (0)
#define obj_SmallFontBase (22)
#define obj_SmallFontPal (1)
#define obj_SmallFontUseObj (20)

b8 SBReqClear;
b8 msgReqClear;

u32 obj_SmallFontCurObj;
u32 SB_SizeX,SB_SizeY;
u32 SB_PosX,SB_PosY;

void Scroll_Left(void);
void Scroll_Right(void);
void Scroll_Up(void);
void Scroll_Down(void);
void Scroll_LeftUp(void);
void Scroll_LeftDown(void);
void Scroll_RightUp(void);
void Scroll_RightDown(void);

void fp_ProcessKeys(u16 loadkeys);
void (*ProcessKeys)(u16 loadkeys)=fp_ProcessKeys;
void IRQ_Timer0_KeyRepeat(void);

u16 KeyRepeat_LastKeys;
volatile b8 KeyRepeat_WaitFlag;

// ------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------

void IRQ_VBlank_Dummy(void)
{
  funcadd(FuncC_main,1);
  
  VBlank_Signal=True;
}

void SetSprites(void)
{
  InitializeSprites();
  
  SetOBJCHR(obj_SBBase,22,obj_SBPal,SB_data,SB_palette);
  SetOBJCHR(obj_SmallFontBase,95*2,obj_SmallFontPal,SmallFont_data,SmallFont_palette);
  
  u32 cnt;
  RotData *rot;
  
  for(cnt=0;cnt<32;cnt++){
    rot=(RotData*)OAMmem+cnt;
    rot->pa=0x100*1;
    rot->pb=0x100*0;
    rot->pc=0x100*0;
    rot->pd=0x100*1;
  }
  
  void set(u32 Base)
  {
    u32 BaseObj=512+obj_SBBase+(Base*11);
    u32 BaseMap=Base*10;
    u32 BaseRot=Base*4;
    
    u32 cnt,obj;
    u32 last;
    RotData *rot;
    
    for(cnt=0;cnt<10;cnt++){
      obj=BaseMap+cnt;
      SetSpriteMode(obj,SP_MODE_TRANSPERANT);
      SetSpriteRotation(obj,False);
      SetSpriteRotateParamIdx(obj,0);
      SetSpritePalette(obj,obj_SBPal);
      MoveSprite(obj,cnt*16+(Base*32),cnt*16);
    }
    for(cnt=0;cnt<8;cnt++){
      obj=BaseMap+cnt;
      if(Base==0){
        SetSpriteSize(obj,SP_SIZE_16,SP_TALL,SP_COLOR_16);
        }else{
        SetSpriteSize(obj,SP_SIZE_16,SP_WIDE,SP_COLOR_16);
      }
    }
    
    // ScrollBar BG
    cnt=0;
    if(Base==0){
      last=160-8;
      }else{
      last=240-8;
    }
    
    while(last>64){
      obj=BaseMap+cnt;
      ChangeSprite(obj,BaseObj+0);
      SetSpriteRotation(obj,True);
      SetSpriteRotateParamIdx(obj,BaseRot+0);
      SetSpritePriority(obj,2);
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-0)*64));
        }else{
        MoveSprite(obj,((cnt-0)*64),160-(8*1.5));
      }
      last-=64;
      cnt++;
    }
    
    rot=(RotData*)OAMmem+BaseRot+0;
    if(Base==0){
      rot->pd=0x100*32/64;
      }else{
      rot->pa=0x100*32/64;
    }
    
    // ScrollBar BG mod
    if(last!=0){
      obj=BaseMap+cnt;
      ChangeSprite(obj,BaseObj+0);
      SetSpriteRotation(obj,True);
      SetSpriteRotateParamIdx(obj,BaseRot+1);
      SetSpritePriority(obj,2);
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-0)*64)-32+(last/2));
        }else{
        MoveSprite(obj,((cnt-0)*64)-32+(last/2),160-(8*1.5));
      }
      
      rot=((RotData*)OAMmem)+BaseRot+1;
      if(Base==0){
        rot->pd=0x100*32/last;
        }else{
        rot->pa=0x100*32/last;
      }
    }
    
    // ScrollBar Grip
    cnt=4;
    if(Base==0){
      last=160-8;
      }else{
      last=240-8;
    }
    
    while(last>64){
      obj=BaseMap+cnt;
      ChangeSprite(obj,BaseObj+4);
      SetSpriteRotation(obj,True);
      SetSpriteRotateParamIdx(obj,BaseRot+2);
      SetSpritePriority(obj,1);
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-4)*64));
        }else{
        MoveSprite(obj,((cnt-4)*64),160-(8*1.5));
      }
      last-=64;
      cnt++;
    }
    
    rot=(RotData*)OAMmem+BaseRot+2;
    if(Base==0){
      rot->pd=0x100*32/64;
      }else{
      rot->pa=0x100*32/64;
    }
    
    // ScrollBar Grip mod
    if(last!=0){
      obj=BaseMap+cnt;
      ChangeSprite(obj,BaseObj+4);
      SetSpriteRotation(obj,True);
      SetSpriteRotateParamIdx(obj,BaseRot+3);
      SetSpritePriority(obj,1);
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-4)*64)-32+(last/2));
        }else{
        MoveSprite(obj,((cnt-4)*64)-32+(last/2),160-(8*1.5));
      }
      
      rot=((RotData*)OAMmem)+BaseRot+3;
      if(Base==0){
        rot->pd=0x100*32/last;
        }else{
        rot->pa=0x100*32/last;
      }
    }
    
    // ScrollBar BG Top
    obj=BaseMap+8;
    ChangeSprite(obj,BaseObj+8);
    SetSpriteSize(obj,SP_SIZE_8,SP_SQUARE,SP_COLOR_16);
    SetSpritePriority(obj,0);
    if(Base==0){
      MoveSprite(obj,240-8,2);
      }else{
      MoveSprite(obj,2,160-8);
    }
    
    // ScrollBar BG Bottom
    obj=BaseMap+9;
    ChangeSprite(obj,BaseObj+9);
    SetSpriteSize(obj,SP_SIZE_8,SP_SQUARE,SP_COLOR_16);
    SetSpritePriority(obj,0);
    if(Base==0){
      MoveSprite(obj,240-8,6);
      }else{
      MoveSprite(obj,6,160-8);
    }
  }
  
  set(0);
  set(1);
  
  u32 obj;
  
  // SizeGrip (Dummy)
  obj=3;
  ChangeSprite(obj,512+obj_SBBase+21);
  SetSpriteSize(obj,SP_SIZE_8,SP_SQUARE,SP_COLOR_16);
  SetSpritePriority(obj,0);
  SetSpriteMode(obj,SP_MODE_TRANSPERANT);
  SetSpriteRotation(obj,False);
  SetSpriteRotateParamIdx(obj,0);
  SetSpritePalette(obj,obj_SBPal);
  MoveSprite(obj,240-8,160-8);
  
  // CreateCacheProgress
  obj=127;
  ChangeSprite(obj,512+obj_SBBase+10);
  SetSpriteSize(obj,SP_SIZE_8,SP_SQUARE,SP_COLOR_16);
  SetSpritePriority(obj,0);
  SetSpriteMode(obj,SP_MODE_TRANSPERANT);
  SetSpriteRotation(obj,False);
  SetSpriteRotateParamIdx(obj,0);
  SetSpritePalette(obj,obj_SBPal);
  MoveSprite(obj,240,160);
  
  REG_BLDMOD=BLEND_LOW_BG2 | BLEND_MODE_ALPHA;
  REG_COLEV=BLEND_HIGH(4)+BLEND_LOW(16);
}

void SB_SetSize(void)
{
  void set(u32 Base,u32 size)
  {
    u32 BaseMap=Base*10;
    u32 BaseRot=Base*4;
    
    u32 cnt,obj;
    u32 last;
    RotData *rot;
    
    // ScrollBar Grip
    cnt=4;
    last=size;
    
    while(last>64){
      obj=BaseMap+cnt;
      SetSpriteRotation(obj,True);
      SetSpriteRotateParamIdx(obj,BaseRot+2);
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-4)*64));
        }else{
        MoveSprite(obj,((cnt-4)*64),160-(8*1.5));
      }
      last-=64;
      cnt++;
    }
    
    // ScrollBar Grip mod
    if(last!=0){
      obj=BaseMap+cnt;
      SetSpriteRotation(obj,True);
      SetSpriteRotateParamIdx(obj,BaseRot+3);
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-4)*64)-32+(last/2));
        }else{
        MoveSprite(obj,((cnt-4)*64)-32+(last/2),160-(8*1.5));
      }
      
      rot=((RotData*)OAMmem)+BaseRot+3;
      if(Base==0){
        rot->pd=0x100*32/last;
        }else{
        rot->pa=0x100*32/last;
      }
      cnt++;
    }
    
    for(;cnt<8;cnt++){
      obj=BaseMap+cnt;
      SetSpriteRotation(obj,False);
      if(Base==0){
        MoveSprite(obj,240+16,0);
        }else{
        MoveSprite(obj,0,160+16);
      }
    }
  }
  
  SB_SizeX=(240-8)*DispInfo.DrawWidth/FlameInfo.Width;
  SB_SizeY=(160-8)*DispInfo.DrawHeight/FlameInfo.Height;
  
  if(SB_SizeX>(240-8)) SB_SizeX=240-8;
  if(SB_SizeY>(160-8)) SB_SizeY=160-8;
  
  if(SB_SizeY>4){
    set(0,SB_SizeY-3);
    }else{
    set(0,0);
  }
  
  if(SB_SizeX>4){
    set(1,SB_SizeX-3);
    }else{
    set(1,0);
  }
  
}

void fp_SB_SetPos(u32 PosX,u32 PosY)
{
  attriwram void set(u32 Base,u32 size,u32 pos)
  {
    u32 BaseMap=Base*10;
    
    u32 cnt,obj;
    u32 last;
    
    // ScrollBar Grip
    cnt=4;
    last=size;
    
    while(last>64){
      obj=BaseMap+cnt;
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-4)*64)+pos);
        }else{
        MoveSprite(obj,((cnt-4)*64)+pos,160-(8*1.5));
      }
      last-=64;
      cnt++;
    }
    
    // ScrollBar Grip mod
    if(last!=0){
      obj=BaseMap+cnt;
      if(Base==0){
        MoveSprite(obj,240-(8*1.5),((cnt-4)*64)-32+(last/2)+pos);
        }else{
        MoveSprite(obj,((cnt-4)*64)-32+(last/2)+pos,160-(8*1.5));
      }
    }
  }
  
  SB_PosX=PosX;
  SB_PosY=PosY;
  
  u32 x,y;
  
  x=(SB_PosX*DispInfo.DrawMCUWidthSize)*(240-8)/DispInfo.Width;
  y=(SB_PosY*DispInfo.DrawMCUHeightSize)*(160-8)/DispInfo.Height;
  
  MoveSprite(8,240-8,y);
  if(SB_SizeY>2){
    MoveSprite(9,240-8,y+SB_SizeY-2);
    if(SB_SizeY>4){
      set(0,SB_SizeY-3,y+2);
    }
  }
  
  MoveSprite(18,x,160-8);
  if(SB_SizeX>2){
    MoveSprite(19,x+SB_SizeX-2,160-8);
    if(SB_SizeX>4){
      set(1,SB_SizeX-3,x+2);
    }
  }
  
  REG_DISPCNT|=OBJ_ENABLE;
  
  REG_TM1CNT=0;
  REG_TM1D=-32767;
  REG_TM1CNT= TM_FREQ_PER_1024 | TM_ENABLE | TM_USEIRQ;
  SBReqClear=False;
}

void IRQ_Timer1_SBHide(void)
{
  SBReqClear=True;
  REG_TM1CNT=0;
}

void msgClear(void)
{
  u32 objnum;
  
  for(objnum=obj_SmallFontUseObj;objnum<127;objnum++){
    SetSpriteSize(objnum,SP_SIZE_8,SP_TALL,SP_COLOR_16);
    SetSpriteMode(objnum,SP_MODE_NORMAL);
    SetSpriteRotation(objnum,False);
    SetSpritePriority(objnum,3);
    SetSpritePalette(objnum,obj_SmallFontPal);
    MoveSprite(objnum,0,0);
    ChangeSprite(objnum,512+obj_SmallFontBase+(0)*2);
  }
  
  obj_SmallFontCurObj=obj_SmallFontUseObj;
}

void fp_msgCRLF(void)
{
  u32 objnum;
  u32 y;
  
  for(objnum=obj_SmallFontUseObj;objnum<127;objnum++){
    OAMEntry* sp = (OAMEntry*)OAMmem+objnum; // OAM
    
    y=(sp->attribute0 & 0x00FF);
    if(y<16){
      MoveSprite(objnum,0,0);
      ChangeSprite(objnum,512+obj_SmallFontBase+(0)*2);
      }else{
      y-=16;
      sp->attribute0 = (sp->attribute0 & 0xFF00) | y;
    }
  }
}

void fp_msgSetStr(const u8 *str)
{
//  dprint(str);
  msgCRLF();
  
  attrinline void msgSetChar(u32 x,u32 y,u8 ch)
  {
    u32 objnum=obj_SmallFontCurObj;
    
    if((obj_SmallFontCurObj+1)<127){
      obj_SmallFontCurObj++;
      }else{
      obj_SmallFontCurObj=obj_SmallFontUseObj;
    }
    
    MoveSprite(objnum,x*8+4,y*16+4);
    ChangeSprite(objnum,512+obj_SmallFontBase+(ch-' ')*2);
  }
  
  u32 cnt;
  
  cnt=0;
  while(str[cnt]!=0){
    if(str[cnt]>' '){
      msgSetChar(cnt,8,str[cnt]);
    }
    cnt++;
  }
  
  msgShow();
}

void fp_msgShow(void)
{
  REG_BG2CNT=3;
  REG_DISPCNT|=OBJ_ENABLE;
  
  REG_TM2CNT=0;
  REG_TM2D=0;
  REG_TM2CNT= TM_FREQ_PER_1024 | TM_ENABLE | TM_USEIRQ;
  msgReqClear=False;
}

void IRQ_Timer2_ReqClearMsg(void)
{
  REG_TM2CNT=0;
  msgReqClear=True;
}

void LoadIWRAMMappedCode(u32 YUVMode,b8 DispHalfFlag)
{
  extern u32 __load_start_iwram0;
  extern u32 __load_start_iwram1;
  extern u32 __load_start_iwram2;
  extern u32 __load_start_iwram3;
  extern u32 __load_start_iwram4;
  extern u32 __load_start_iwram5;
//  extern u32 __load_start_iwram6;
//  extern u32 __load_start_iwram7;
//  extern u32 __load_start_iwram8;
//  extern u32 __load_start_iwram9;
  extern u32 __iwram_overlay_start;
  extern u32 __iwram_overlay_end;
  
  u32 IWRAMNum;
  u32 StartAdrs=0;
  
  if(DispHalfFlag==False){
    IWRAMNum=YUVMode;
    }else{
    IWRAMNum=YUVMode+4;
  }
  
  switch(IWRAMNum){
//    case YUVMode_Unknown:
    case YUVMode_111:
      StartAdrs=(u32)&__load_start_iwram0;
      IntBlockDraw=fp_IntBlockDraw111;
      break;
    case YUVMode_411:
      StartAdrs=(u32)&__load_start_iwram1;
      IntBlockDraw=fp_IntBlockDraw411;
      break;
    case YUVMode_100:
      StartAdrs=(u32)&__load_start_iwram2;
      IntBlockDraw=fp_IntBlockDraw100;
      break;
    case YUVMode_111+4:
      StartAdrs=(u32)&__load_start_iwram3;
      IntBlockDraw=fp_IntBlockDraw111Half;
      break;
    case YUVMode_411+4:
      StartAdrs=(u32)&__load_start_iwram4;
      IntBlockDraw=fp_IntBlockDraw411Half;
      break;
    case YUVMode_100+4:
      StartAdrs=(u32)&__load_start_iwram5;
      IntBlockDraw=fp_IntBlockDraw100Half;
      break;
    default:
      msgSetStr("Illigal YUVMode");
      while(1);
  }
  
  memcpy(&__iwram_overlay_start,(u32*)StartAdrs,(u32)&__iwram_overlay_end-(u32)&__iwram_overlay_start);
}

void SetDispHalfPer(s32 v)
{
  if(v!=0){
    s32 mode;
    
    switch(DispInfo.Per){
      case 50: mode=0; break;
      case 100: mode=1; break;
      case 125: mode=2; break;
      case 150: mode=3; break;
      case 175: mode=4; break;
      case 200: mode=5; break;
      default: mode=-1;
    }
    
    mode+=v;
    if((mode<0)||(5<mode)) return;
    
    switch(mode){
      case 0: DispInfo.Per=50; break;
      case 1: DispInfo.Per=100; break;
      case 2: DispInfo.Per=125; break;
      case 3: DispInfo.Per=150; break;
      case 4: DispInfo.Per=175; break;
      case 5: DispInfo.Per=200; break;
      default: while(1);
    }
    
    uprintf("zoom=%d%\n",DispInfo.Per);
    msgSetStr(resprintf);
  }
  
  DispInfo.Width=FlameInfo.Width*DispInfo.Per/100;
  DispInfo.Height=FlameInfo.Height*DispInfo.Per/100;
  DispInfo.DrawWidth=240*100/DispInfo.Per;
  DispInfo.DrawHeight=160*100/DispInfo.Per;
  DispInfo.DrawMCUWidthSize=FlameInfo.MCUWidthSize*DispInfo.Per/100;
  DispInfo.DrawMCUHeightSize=FlameInfo.MCUHeightSize*DispInfo.Per/100;
  
  u32 tmpper;
  
  tmpper=DispInfo.Per;
  if(tmpper<100){
    DispHalfFlag=True;
    DispInfo.DrawMCUWidthCount=240/DispInfo.DrawMCUWidthSize;
    DispInfo.DrawMCUHeightCount=160/DispInfo.DrawMCUHeightSize;
    
    REG_BG2PA=0x100*100/100;
    REG_BG2PB=0*100/100;
    REG_BG2PC=0*100/100;
    REG_BG2PD=0x100*100/100;
    }else{
    DispHalfFlag=False;
    DispInfo.DrawMCUWidthCount=DispInfo.DrawWidth/FlameInfo.MCUWidthSize;
    DispInfo.DrawMCUHeightCount=DispInfo.DrawHeight/FlameInfo.MCUHeightSize;
    if(tmpper!=100){
      DispInfo.DrawMCUWidthCount++;
      DispInfo.DrawMCUHeightCount++;
    }
    
    REG_BG2PA=0x100*100/tmpper;
    REG_BG2PB=0*100/tmpper;
    REG_BG2PC=0*100/tmpper;
    REG_BG2PD=0x100*100/tmpper;
    
    tmpper=100;
  }
  
  DispInfo.MCUWidthSize=FlameInfo.MCUWidthSize*tmpper/100;
  DispInfo.MCUHeightSize=FlameInfo.MCUHeightSize*tmpper/100;
  DispInfo.MCUWidthCount=FlameInfo.MCUWidthCount;
  DispInfo.MCUHeightCount=FlameInfo.MCUHeightCount;
  
  LoadIWRAMMappedCode(YUVMode,DispHalfFlag);
  
  SB_SetSize();
  SB_SetPos(BaseX,BaseY);
  
  MemSet32DMA3(0,&VRAM0[0],160*240*2);
  DrawImageFull(BaseX,BaseY);
}

void ShowFlameInfo(void)
{
  uprintf("MCUCount (%d*%d)=%d\n",FlameInfo.MCUWidthCount,FlameInfo.MCUHeightCount,FlameInfo.MCUCount);
  msgSetStr(resprintf);
  uprintf("PicSize (%d*%d)=%d\n",FlameInfo.Width,FlameInfo.Height,FlameInfo.Width*FlameInfo.Height);
  msgSetStr(resprintf);
  
  uprintf("MaxFact H=%d F=%d\n",FlameInfo.SampleMaxHFact,FlameInfo.SampleMaxVFact);
  msgSetStr(resprintf);
  uprintf("DRI %d\n",DelayRestartInterval);
  msgSetStr(resprintf);
  
  uprintf("BitStreamStartPosition=%d\n",BitStreamStartPosition);
  dprint(resprintf);
}

int main(void)
{
  SetSprites();
  msgClear();
  
//  MemSet32DMA3(0,(u8*)0x02000000,256*1024); // PogoShell ArgLinkForce
  
  REG_DISPCNT=MODE_3 | DISP_BG2 | DISP_SELECTBUFFER(0) | OBJ_ENABLE | OBJ_MAP_1D;
  REG_BG2CNT=3;
  
  REG_BG2PA=0x100;
  REG_BG2PB=0;
  REG_BG2PC=0;
  REG_BG2PD=0x100;
  
  REG_BG2X=0*0x100;
  REG_BG2Y=0*0x100;
  
  GetPogoShell2Args();
  
  IRQTable[IRQIndex_Timer0]=(u32)IRQ_Timer0_KeyRepeat;
  IRQTable[IRQIndex_Timer1]=(u32)IRQ_Timer1_SBHide;
  IRQTable[IRQIndex_Timer2]=(u32)IRQ_Timer2_ReqClearMsg;
  IRQTable[IRQIndex_VBlank]=(u32)IRQ_VBlank_Dummy;
  IRQ_Setup(IRQ_BIT_VBLANK|IRQ_BIT_TIMER0|IRQ_BIT_TIMER1|IRQ_BIT_TIMER2,DSTAT_USE_VBLANK);
  
  rfsInit(ps2ArgDataPtr);
  rfsStartFlame();
  
  uprintf("ExtendData at 0x%x\n",(u32)ps2ArgDataPtr);
  msgSetStr(resprintf);
  
//  InitDCTTable();
  InitYUVTable();
  Initialize_Fast_IDCT();
  
  if(AnalizeJpegMarker()==False){
    msgSetStr("JpegHeader AnalizeError.");
    while(1);
  }
  
  if(FlameInfo.MCUCount>=16384){
    uprintf("MCUover %d<16384\n",FlameInfo.MCUCount);
    msgSetStr(resprintf);
    FlameInfo.MCUHeightCount=16384/FlameInfo.MCUWidthCount;
    FlameInfo.MCUCount=FlameInfo.MCUHeightCount*FlameInfo.MCUWidthCount;
  }
  FlameInfo.Width=FlameInfo.MCUWidthCount*FlameInfo.MCUWidthSize;
  FlameInfo.Height=FlameInfo.MCUHeightCount*FlameInfo.MCUHeightSize;
  
  ShowFlameInfo();
  
  rbsInit(ps2ArgDataPtr+BitStreamStartPosition);
  
  DispInfo.Per=100;
  
  TMCUCache *_MCUCache=&MCUCache[0];
  _MCUCache->PosBit=0;
  _MCUCache->DCDiff[0]=0;
  _MCUCache->DCDiff[1]=0;
  _MCUCache->DCDiff[2]=0;
  CreatedMCUCacheIndex=0;
  LastMCUProcIndex=-1;
  DecodeSkipImageOne(&CreatedMCUCacheIndex);
  
  BaseX=0;
  BaseY=0;
  
  REG_TM3CNT=0;
  REG_TM3D=0;
  REG_TM3CNT=TM_ENABLE | TM_FREQ_PER_1024;
  SetDispHalfPer(0);
  uprintf("DecodeImageOne(SetDiplay) %dms %dx1024clk\n",((u32)REG_TM3D*1024/256)/(16670000/1000/256),REG_TM3D);
  dprint(resprintf);
  
  REG_DISPCNT=MODE_3 | DISP_BG2 | DISP_SELECTBUFFER(0) | OBJ_ENABLE | OBJ_MAP_1D;
  
  mainloop();
  
  while(1);
}

void fp_ProcessKeys(u16 loadkeys)
{
  if(loadkeys==0) return;
  
  if(loadkeys & KEY_A){
    SetDispHalfPer(-1);
  }
  if(loadkeys & KEY_B){
    SetDispHalfPer(1);
  }
  if((loadkeys & KEY_LEFT)&&(loadkeys & KEY_UP)){
    Scroll_LeftUp();
    loadkeys&=~(KEY_LEFT | KEY_UP);
    SB_SetPos(BaseX,BaseY);
  }
  if((loadkeys & KEY_LEFT)&&(loadkeys & KEY_DOWN)){
    Scroll_LeftDown();
    loadkeys&=~(KEY_LEFT | KEY_DOWN);
    SB_SetPos(BaseX,BaseY);
  }
  if((loadkeys & KEY_RIGHT)&&(loadkeys & KEY_UP)){
    Scroll_RightUp();
    loadkeys&=~(KEY_RIGHT | KEY_UP);
    SB_SetPos(BaseX,BaseY);
  }
  if((loadkeys & KEY_RIGHT)&&(loadkeys & KEY_DOWN)){
    Scroll_RightDown();
    loadkeys&=~(KEY_RIGHT | KEY_DOWN);
    SB_SetPos(BaseX,BaseY);
  }
  if(loadkeys & KEY_LEFT){
    Scroll_Left();
    SB_SetPos(BaseX,BaseY);
  }
  if(loadkeys & KEY_RIGHT){
    Scroll_Right();
    SB_SetPos(BaseX,BaseY);
  }
  if(loadkeys & KEY_UP){
    Scroll_Up();
    SB_SetPos(BaseX,BaseY);
  }
  if(loadkeys & KEY_DOWN){
    Scroll_Down();
    SB_SetPos(BaseX,BaseY);
  }
  if(loadkeys & KEY_SELECT){
    msgShow();
  }
  if(loadkeys & KEY_START){
    SetDispHalfPer(0);
  }
  if((loadkeys&KEY_L)&&(loadkeys&KEY_R)){
    ReturnPogoShell2();
    while(1);
  }
}

void IRQ_Timer0_KeyRepeat(void)
{
  KeyRepeat_WaitFlag=False;
  REG_TM0CNT=0;
}

void fp_mainloop(void)
{
  u16 loadkeys;
  
  KeyRepeat_LastKeys=0;
  KeyRepeat_WaitFlag=False;
  
  BaseX=0;
  BaseY=0;
  
  while(1){
    if(SBReqClear==True){
      SBReqClear=False;
      REG_DISPCNT&=~(OBJ_ENABLE);
      REG_BG2CNT=2;
      REG_TM1CNT=0;
      REG_TM2CNT=0;
    }
    if(msgReqClear==True){
      msgReqClear=False;
      REG_BG2CNT=2;
      REG_TM1CNT=0;
      REG_TM2CNT=0;
    }
    
    if(VBlank_Signal==False){
      if(CreatedMCUCacheIndex+1>=FlameInfo.MCUCount){
        WaitForVsync();
        }else{
//        iuprintf("VsyncIdle.Cache %d\n",CreatedMCUCacheIndex); dprint(resprintf);
        while(VBlank_Signal==False){
          if(CreatedMCUCacheIndex+1<FlameInfo.MCUCount){
            DecodeSkipImageOne(&CreatedMCUCacheIndex);
          }
        }
      }
    }
    VBlank_Signal=False;
    
    loadkeys=(~*KEYS)&0x3ff;
    
    if(loadkeys!=KeyRepeat_LastKeys){
      KeyRepeat_WaitFlag=False;
    }
    
    if(KeyRepeat_WaitFlag==False) ProcessKeys(loadkeys);
    
    if(loadkeys!=KeyRepeat_LastKeys){
      KeyRepeat_LastKeys=loadkeys;
      KeyRepeat_WaitFlag=True;
      REG_TM0CNT=0;
      REG_TM0D=-(200*65117/1000);
      REG_TM0CNT=TM_ENABLE | TM_FREQ_PER_256 | TM_USEIRQ;
    }
    
    if(CreatedMCUCacheIndex+1<FlameInfo.MCUCount){
      MoveSprite(127,240-16,((160-8)*(CreatedMCUCacheIndex+1)/FlameInfo.MCUCount)-4);
      }else{
      MoveSprite(127,240,160);
    }
  }
}

void Scroll_Left(void)
{
  u32 ofsx;
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  
  ofsx=0;
  if((BaseX+ofsx)==0) return;
  
  BaseX--;
  
  MemCopy32DownDMA3(&VRAM0[0],&VRAM0[MCUWidthSize],((160*240)-MCUWidthSize)*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(-1,0);
}

void Scroll_Right(void)
{
  u32 ofsx;
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  
  ofsx=DispInfo.DrawMCUWidthCount-1;
  if((BaseX+1+ofsx)>=DispInfo.MCUWidthCount) return;
  
  BaseX++;
  
  MemCopy32DMA3(&VRAM0[MCUWidthSize],&VRAM0[0],((160*240)-MCUWidthSize)*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(1,0);
}

void Scroll_Up(void)
{
  u32 ofsy;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  
  ofsy=0;
  if((BaseY+ofsy)==0) return;
  
  BaseY--;
  
  MemCopy32DownDMA3(&VRAM0[0],&VRAM0[MCUHeightSize*240],((160*240)-(MCUHeightSize*240))*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(0,-1);
}

void Scroll_Down(void)
{
  u32 ofsy;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  
  ofsy=DispInfo.DrawMCUHeightCount-1;
  if((BaseY+1+ofsy)>=DispInfo.MCUHeightCount) return;
  
  BaseY++;
  
  MemCopy32DMA3(&VRAM0[MCUHeightSize*240],&VRAM0[0],((160*240)-(MCUHeightSize*240))*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(0,1);
}

void Scroll_LeftUp(void)
{
  u32 ofsx,ofsy;
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  
  ofsx=0;
  if((BaseX+ofsx)==0){
    Scroll_Up();
    return;
  }
  
  ofsy=0;
  if((BaseY+ofsy)==0){
    Scroll_Left();
    return;
  }
  
  BaseX--;
  BaseY--;
  
  MemCopy32DownDMA3(&VRAM0[0],&VRAM0[MCUWidthSize+(MCUHeightSize*240)],((160*240)-MCUWidthSize-(MCUHeightSize*240))*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(-1,-1);
}

void Scroll_LeftDown(void)
{
  u32 ofsx,ofsy;
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  
  ofsx=0;
  if((BaseX+ofsx)==0){
    Scroll_Down();
    return;
  }
  
  ofsy=DispInfo.DrawMCUHeightCount-1;
  if((BaseY+1+ofsy)>=DispInfo.MCUHeightCount){
    Scroll_Left();
    return;
  }
  
  BaseX--;
  BaseY++;
  
  MemCopy32DMA3(&VRAM0[(MCUHeightSize*240)-MCUWidthSize],&VRAM0[0],((160*240)-(MCUHeightSize*240)+MCUWidthSize)*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(-1,1);
}

void Scroll_RightUp(void)
{
  u32 ofsx,ofsy;
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  
  ofsx=DispInfo.DrawMCUWidthCount-1;
  if((BaseX+1+ofsx)>=DispInfo.MCUWidthCount){
    Scroll_Up();
    return;
  }
  
  ofsy=0;
  if((BaseY+ofsy)==0){
    Scroll_Right();
    return;
  }
  
  BaseX++;
  BaseY--;
  
  MemCopy32DownDMA3(&VRAM0[0],&VRAM0[-MCUWidthSize+(MCUHeightSize*240)],((160*240)+MCUWidthSize-(MCUHeightSize*240))*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(1,-1);
}

void Scroll_RightDown(void)
{
  u32 ofsx,ofsy;
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  
  ofsx=DispInfo.DrawMCUWidthCount-1;
  if((BaseX+1+ofsx)>=DispInfo.MCUWidthCount){
    Scroll_Down();
    return;
  }
  
  ofsy=DispInfo.DrawMCUHeightCount-1;
  if((BaseY+1+ofsy)>=DispInfo.MCUHeightCount){
    Scroll_Right();
    return;
  }
  
  BaseX++;
  BaseY++;
  
  MemCopy32DMA3(&VRAM0[(MCUHeightSize*240)+MCUWidthSize],&VRAM0[0],((160*240)-(MCUHeightSize*240)-MCUWidthSize)*2);
//  while((REG_DM3CNT_H&BIT15)!=0);
  
  DrawImageOneLine(1,1);
}

