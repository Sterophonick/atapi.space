
#include "time.h"

#define RTC_DATA ((volatile u16 *)0x080000C4)
#define RTC_RW ((volatile u16 *)0x080000C6)
#define RTC_ENABLE ((volatile u16 *)0x080000C8)

void rtc_cmd(int v)
{
	int l;
	u16 b;

	v = v<<1;

	for(l=7; l>=0; l--)
	{
		b = (v>>l) & 0x2;
		*RTC_DATA = b | 4;
		*RTC_DATA = b | 4;
		*RTC_DATA = b | 4;
		*RTC_DATA = b | 5;
	}
}

void rtc_data(int v)
{
	int l;
	u16 b;

	v = v<<1;

	for(l=0; l<8; l++)
	{
		b = (v>>l) & 0x2;
		*RTC_DATA = b | 4;
		*RTC_DATA = b | 4;
		*RTC_DATA = b | 4;
		*RTC_DATA = b | 5;
	}
}

int rtc_read(void)
{
	int j,l;
	u16 b;
	int v = 0;


	for(l=0; l<8; l++)
	{
		for(j=0;j<5; j++)
			*RTC_DATA = 4;
		*RTC_DATA = 5;
		b = *RTC_DATA;
		v = v | ((b & 2)<<l);
	}

	v = v>>1;

	return v;
}

static int check_val = 0;

void rtc_disable(void)
{
	*RTC_ENABLE = 0;

	check_val = 0;
}

void rtc_enable(void)
{
	*RTC_ENABLE = 1;

	*RTC_DATA = 1;
	*RTC_DATA = 5;
	*RTC_RW = 7;

	rtc_cmd(0x63);

	*RTC_RW = 5;

	check_val =  rtc_read();
}

/* PogoNes��

void rtc_enable(void)
{
	_u16 *timeregs=(u16*)0x080000c8;
	*timeregs=1;
	if(*timeregs==1) check_val=0x40;
}
*/

// Normally returns 0x40
int rtc_check(void)
{
	return (check_val & 0x40);
}

int rtc_get(u8 *data)
{
	int i;

/*	*RTC_DATA = 1;
	*RTC_DATA = 5;
	*RTC_RW = 7;

	rtc_cmd(0x60);

	*RTC_DATA = 1;
	*RTC_DATA = 5;
	*RTC_RW = 7;

	rtc_cmd(0x62);
	rtc_data(0x40);
*/
	*RTC_DATA = 1;
	*RTC_RW = 7;

	*RTC_DATA = 1;
	*RTC_DATA = 5;

	rtc_cmd(0x65);

	*RTC_RW = 5;

	for(i=0; i<4; i++)
		data[i] = (u8)rtc_read();
	
	*RTC_RW = 5;

	for(i=4; i<7; i++)
		data[i] = (u8)rtc_read();

	return 0;
}

#define UNBCD(x) (((x) & 0xF) + (((x) >> 4) * 10))

typedef struct {
  u32 hour,min,sec;
  u32 year,mon,mday;
} TTimeFormat;

void time2(TTimeFormat *tm)
{
	u8 data[7];

	rtc_get(data);

	tm->sec = UNBCD(data[6]);
	tm->min = UNBCD(data[5]);

	tm->hour = UNBCD(data[4] & 0x3F);
	if(tm->hour>=12) tm->hour-=12;
//	if(data[4] & 0x80) tm->hour += 12;

	tm->mday = UNBCD(data[2] & 0x3F);
	tm->mon = UNBCD(data[1]);
	tm->year = UNBCD(data[0]) + 2000;
}

static struct tm tmp_tm;

#define SECpMIN 60
#define SECpHOUR 3600
#define SECpDAY (3600*24)
#define SECpMON (3600*24*31)
#define SECpYEAR (3600*24*31*12)

struct tm *_localtime(time_t t)
{
	tmp_tm.tm_year = t / SECpYEAR;
	t -= (tmp_tm.tm_year * SECpYEAR);

	tmp_tm.tm_year += 2000;

	tmp_tm.tm_mon = t / SECpMON;
	t -= (tmp_tm.tm_mon * SECpMON);

	tmp_tm.tm_mday = t / SECpDAY;
	t -= (tmp_tm.tm_mday * SECpDAY);

	tmp_tm.tm_hour = t / SECpHOUR;
	t -= (tmp_tm.tm_hour * SECpHOUR);

	tmp_tm.tm_min = t / SECpMIN;
	t -= (tmp_tm.tm_min * SECpMIN);

	tmp_tm.tm_sec = t;


	return &tmp_tm;
}


time_t time(time_t *t)
{
	//char tmp[64];

	u32 total;
	int secs,mins,hour,days,mons,year;
	u8 data[7];

	rtc_get(data);

	//sprintf(tmp, "%x %x %x %x %x %x\n", data[0], data[1], data[2], data[4], data[5], data[6]);
	//dprint(tmp);

	secs = UNBCD(data[6]);
	mins = UNBCD(data[5]);
	hour = UNBCD(data[4]);

	days = UNBCD(data[2]);
	mons = UNBCD(data[1]);
	year = UNBCD(data[0]);

	total = secs + mins*SECpMIN + hour*SECpHOUR + days*SECpDAY + mons*SECpMON + year*SECpYEAR;
	if(t) *t = total;

	//sprintf(tmp, "%d %d %d - %02d:%02d:%02d (%08x)\n", year + 2000, mons, days, hour, mins, secs, total);
	//dprint(tmp);

	return total;

}
