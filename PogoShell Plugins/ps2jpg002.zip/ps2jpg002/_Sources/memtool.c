#include "header\dma.h"

static void MemCopy32DMA3(void *src,void *dst,u32 len)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)src;
  REG_DM3DAD = (u32)dst;
  REG_DM3CNT_L=len/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_INC | DMA_DAD_INC | DMA_INTR_ON);
}

static void MemCopy32DownDMA3(void *src,void *dst,u32 len)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)src+len-4;
  REG_DM3DAD = (u32)dst+len-4;
  REG_DM3CNT_L=len/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_DEC | DMA_DAD_DEC | DMA_INTR_ON);
}

static void MemSet32DMA3(u32 v,void *dst,u32 len)
{
  while((REG_DM3CNT_H&BIT15)!=0);
  REG_DM3SAD = (u32)&v;
  REG_DM3DAD = (u32)dst;
  REG_DM3CNT_L=len/4;
  REG_DM3CNT_H=(DMA_SIZE_32 | DMA_TRANSFER_ON | DMA_TIMING_NOW | 
                DMA_REPEAT_OFF | DMA_SAD_FIX | DMA_DAD_INC | DMA_INTR_ON);
}

