
void fp_LoadSkipIntBlock(u32 ScanCnt)
{
  TScanInfo *_ScanInfo=&ScanInfo[ScanCnt];
  
  u32 dctcnt;
  u32 bitlen;
  
  bitlen=rbsDecodeHuffman(_ScanInfo->HuffmanTreeDC);
  if(bitlen!=0){
    _ScanInfo->DCDiff+=rbsGetVL(bitlen);
  }
  
  THuffmanTree *_HuffmanTreeAC=_ScanInfo->HuffmanTreeAC;
  
  dctcnt=1;
  while(dctcnt<64){
    bitlen=rbsDecodeHuffman(_HuffmanTreeAC);
    if(bitlen==0x00){
      dctcnt=64;
      }else{
      dctcnt+=bitlen >> 4; // zerorun
//      if(dctcnt<64){
      {
        bitlen=bitlen & 0x0f;
        if(bitlen!=0) rbsSkipVL(bitlen);
      }
      dctcnt++;
    }
  }
}

/*
u16 fp_GetMCU_DCDiffRGB(void)
{
  attriwram u32 GetDCDiff(u32 ScanCnt)
  {
    TScanInfo *_ScanInfo=&ScanInfo[ScanCnt];
    s32 tmp;
    
    tmp=(((_ScanInfo->DCDiff*_ScanInfo->QuantizeTable->data[0]) >> 3) >> 3)+0x10;
    if((u32)tmp>0x1f) tmp=(tmp<0) ? 0x00 : 0x1f;
    
    return((u32)tmp);
  }
  
  return(YUV2RGBTable[(GetDCDiff(2) << 10)+(GetDCDiff(1) << 5)+(GetDCDiff(0) << 0)]);
}
*/

void fp_CheckSegment(u32 *MCUCnt)
{
  if(CheckSegment_EndFlag==True) return;
  
  if(rbsCheckSegment()==True){
    if(rbsEOIFlag==True){
      iuprintf("MCU(%d):EOI End of image segment\n",*MCUCnt);
      dprint(resprintf);
      CheckSegment_EndFlag=True;
      return;
    }
    if(rbsRSTFlag==True){
      u32 basecnt=*MCUCnt;
      if(rbsRST_Skip1MCUFlag==True){
        dprint("MCUCnt++\n");
        *MCUCnt=*MCUCnt+1;
      }
      u32 ScanCnt;
      for(ScanCnt=0;ScanCnt<ScanCount;ScanCnt++){
        ScanInfo[ScanCnt].DCDiff=0;
      }
      *MCUCnt=((*MCUCnt-1) / FlameInfo.MCUWidthCount)*FlameInfo.MCUWidthCount+FlameInfo.MCUWidthCount;
      iuprintf("MCU(%d):RSTx - Restart Interval x\n",*MCUCnt); dprint(resprintf);
      
      if(CreatedMCUCacheIndex<*MCUCnt){
        u32 cnt;
        for(cnt=basecnt;cnt<*MCUCnt;cnt++){
          TMCUCache *_MCUCache1=&MCUCache[cnt-1];
          TMCUCache *_MCUCache2=&MCUCache[cnt];
          _MCUCache2->PosBit=_MCUCache1->PosBit;
          _MCUCache2->DCDiff[0]=_MCUCache1->DCDiff[0];
          _MCUCache2->DCDiff[1]=_MCUCache1->DCDiff[1];
          _MCUCache2->DCDiff[2]=_MCUCache1->DCDiff[2];
        }
      }
    }
    if(rbsErrorFlag==True){
      iuprintf("MCU(%d):DetectErrorMarker\n",*MCUCnt);
      msgSetStr(resprintf);
//      while(1);
    }
  }
}

void fp_DecodeSkipImageOne(u32 *MCUCnt)
{
  TMCUCache *_MCUCache;
  
  if(LastMCUProcIndex==*MCUCnt){
    rbsRefreshCurBuf();
    }else{
    _MCUCache=&MCUCache[*MCUCnt];
    rbsSetCurPos(_MCUCache->PosBit);
    ScanInfo[0].DCDiff=_MCUCache->DCDiff[0];
    ScanInfo[1].DCDiff=_MCUCache->DCDiff[1];
    ScanInfo[2].DCDiff=_MCUCache->DCDiff[2];
  }
  
  switch(YUVMode){
    case YUVMode_111:
      LoadSkipIntBlock(0);
      LoadSkipIntBlock(1);
      LoadSkipIntBlock(2);
      break;
    case YUVMode_411:
      LoadSkipIntBlock(0);
      LoadSkipIntBlock(0);
      LoadSkipIntBlock(0);
      LoadSkipIntBlock(0);
      LoadSkipIntBlock(1);
      LoadSkipIntBlock(2);
      break;
    case YUVMode_100:
      LoadSkipIntBlock(0);
      break;
  }
  
//  VRAM0[PrevX+PrevY]=GetMCU_DCDiffRGB();
  
  *MCUCnt=*MCUCnt+1;
  
  CheckSegment(MCUCnt);
  _MCUCache=&MCUCache[*MCUCnt];
  rbsGetCurPos(&_MCUCache->PosBit);
  _MCUCache->DCDiff[0]=ScanInfo[0].DCDiff;
  _MCUCache->DCDiff[1]=ScanInfo[1].DCDiff;
  _MCUCache->DCDiff[2]=ScanInfo[2].DCDiff;
  
  LastMCUProcIndex=*MCUCnt;
}
