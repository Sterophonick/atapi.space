
typedef struct {
  u8 code[256];
  u8 bitcount[256];
  u16 bitimage[256];
  u32 size;
} THuffmanTree;

typedef struct {
  u8 data[64];
  u8 Precision;
} TQuantizeTable;

typedef struct {
  u16 DepthPerSample;
  u16 Height,Width;
  u32 SampleMaxHFact,SampleMaxVFact;
  u32 MCUWidthSize,MCUHeightSize;
  u32 MCUWidthCount,MCUHeightCount;
  u32 MCUCount;
} TFlameInfo;

typedef struct {
  u32 Per;
  u32 Height,Width;
  u32 DrawHeight,DrawWidth;
  u32 DrawMCUHeightSize,DrawMCUWidthSize;
  u32 DrawMCUHeightCount,DrawMCUWidthCount;
  u32 MCUWidthSize,MCUHeightSize;
  u32 MCUWidthCount,MCUHeightCount;
} TDispInfo;

typedef struct {
  u8 HFact,VFact;
  u8 QuantizeTableIndex;
} TSampleInfo;

typedef struct {
  u32 HuffmanTableDC,HuffmanTableAC;
  THuffmanTree *HuffmanTreeDC;
  THuffmanTree *HuffmanTreeAC;
  TSampleInfo *SampleInfo;
  TQuantizeTable *QuantizeTable;
  s32 DCDiff;
} TScanInfo;

typedef struct {
  u32 PosBit;
  s16 DCDiff[3];
} TMCUCache;

typedef s16 TIntBlock;

static u32 zigzag[64]={
  0,  1,  8, 16,  9,  2,  3, 10,
 17, 24, 32, 25, 18, 11,  4,  5,
 12, 19, 26, 33, 40, 48, 41, 34,
 27, 20, 13,  6,  7, 14, 21, 28,
 35, 42, 49, 56, 57, 50, 43, 36,
 29, 22, 15, 23, 30, 37, 44, 51,
 58, 59, 52, 45, 38, 31, 39, 46,
 53, 60, 61, 54, 47, 55, 62, 63};

#define YUVMode_Unknown (0)
#define YUVMode_111 (1)
#define YUVMode_411 (2)
#define YUVMode_100 (3)

u32 BitStreamStartPosition;
u32 YUVMode;
TFlameInfo FlameInfo;
TQuantizeTable QuantizeTable[4];
THuffmanTree HuffmanTree[2][2];
u32 ScanCount;
TScanInfo ScanInfo[3];
u32 SampleCount;
TSampleInfo SampleInfo[3];
u32 DelayRestartInterval;
b8 CheckSegment_EndFlag=False;
u32 LastMCUProcIndex;
u32 CreatedMCUCacheIndex;
TDispInfo DispInfo;

TIntBlock Y0Block[64],Y1Block[64],Y2Block[64],Y3Block[64],CbBlock[64],CrBlock[64];

TMCUCache *MCUCache=(TMCUCache*)0x02010000;

// jpeg_cache.c

attriwram void fp_LoadSkipIntBlock(u32 ScanCnt);
void (*LoadSkipIntBlock)(u32 ScanCnt)=fp_LoadSkipIntBlock;
attriwram void fp_DecodeSkipImageOne(u32 *MCUCnt);
void (*DecodeSkipImageOne)(u32 *MCUCnt)=fp_DecodeSkipImageOne;
attriwram void fp_CheckSegment(u32 *MCUCnt);
void (*CheckSegment)(u32 *MCUCnt)=fp_CheckSegment;

// jpeg_decodeimage.c

attriwram void fp_LoadIntBlock(u32 ScanCnt,TIntBlock *IntBlock);
void (*LoadIntBlock)(u32 ScanCnt,TIntBlock *IntBlock)=fp_LoadIntBlock;
attriwram111 void fp_IntBlockDraw111(u16 *DrawPtr);
attriwram111Half void fp_IntBlockDraw111Half(u16 *DrawPtr);
attriwram411 void fp_IntBlockDraw411(u16 *DrawPtr);
attriwram411Half void fp_IntBlockDraw411Half(u16 *DrawPtr);
attriwram100 void fp_IntBlockDraw100(u16 *DrawPtr);
attriwram100Half void fp_IntBlockDraw100Half(u16 *DrawPtr);
void (*IntBlockDraw)(u16 *DrawPtr);
attriwram void fp_DecodeImageOne(u32 MCUCount,u16 *DrawPtr);
void (*DecodeImageOne)(u32 MCUCount,u16 *DrawPtr)=fp_DecodeImageOne;
attriwram void fp_DrawImageFull(u32 BaseX,u32 BaseY);
void (*DrawImageFull)(u32 BaseX,u32 BaseY)=fp_DrawImageFull;
attriwram void fp_DrawImageOneLine(s32 tagx,s32 tagy);
void (*DrawImageOneLine)(s32 tagx,s32 tagy)=fp_DrawImageOneLine;

// jpeg_fs.c

void rfsInit(u8 *ptr);
void rfsClose(void);
attrinline u8 *rfsReadBuf(u32 size);
attrinline u8 rfs8bit(void);
attrinline u16 rfs16bit(void);

attrinline u32 rfsGetPosition(void);
attrinline void rfsSetPosition(u32 _pos);

// jpeg_marker.c

b8 AnalizeJpegMarker(void);

u32 Marker__GetSize(void);
u32 Marker__GetNextPosition(void);
void Marker_Unknown(void);
void Marker_APP0(void);
void Marker_APPx(void);
void Marker_DQT(void);
void Marker_SOF0(void);
void Marker_DHT(void);
void Marker_DRI(void);
void Marker_SOS(void);

