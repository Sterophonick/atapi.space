
void fp_LoadIntBlock(u32 ScanCnt,TIntBlock *IntBlock)
{
  TScanInfo *_ScanInfo=&ScanInfo[ScanCnt];
  THuffmanTree *_HuffmanTreeAC=_ScanInfo->HuffmanTreeAC;
  u8 *QuantizeData=&_ScanInfo->QuantizeTable->data[0];
  
  u32 dctcnt;
  u32 bitlen;
  
  bitlen=rbsDecodeHuffman(_ScanInfo->HuffmanTreeDC);
  if(bitlen!=0){
    _ScanInfo->DCDiff+=rbsGetVL(bitlen);
  }
  IntBlock[0]=_ScanInfo->DCDiff*QuantizeData[0];
  
  for(dctcnt=1;dctcnt<64;dctcnt++){
    IntBlock[dctcnt]=0;
  }
  
  dctcnt=1;
  while(dctcnt<64){
    bitlen=rbsDecodeHuffman(_HuffmanTreeAC);
    if(bitlen==0x00){
      dctcnt=64;
      }else{
      dctcnt+=bitlen >> 4; // zerorun
//      if(dctcnt<64){
      {
        bitlen=bitlen & 0x0f;
        if(bitlen!=0){
          IntBlock[zigzag[dctcnt]]=rbsGetVL(bitlen)*QuantizeData[dctcnt];
        }
      }
      dctcnt++;
    }
  }
  
  Fast_IDCT(&IntBlock[0]);
}

#define DecodeImageOne_CalcYUV(blk,cmp) \
  cmp=(blk >> 3)+0x10; \
  if((u32)cmp>0x1f) cmp=(cmp<0) ? 0x00 : 0x1f; \


void fp_IntBlockDraw111(u16 *DrawPtr)
{
  u16 *VRAMPtr=DrawPtr;
  
  TIntBlock *YBlk=&Y0Block[0];
  TIntBlock *CbBlk=&CbBlock[0];
  TIntBlock *CrBlk=&CrBlock[0];
  
  LoadIntBlock(0,&Y0Block[0]);
  LoadIntBlock(1,&CbBlock[0]);
  LoadIntBlock(2,&CrBlock[0]);
  
  u32 x,y;
  s32 _Y,_Cb,_Cr;
  u32 ofs=0;
  
  for(y=0;y<8;y++){
    for(x=0;x<8;x++){
      DecodeImageOne_CalcYUV(YBlk[ofs],_Y);
      DecodeImageOne_CalcYUV(CbBlk[ofs],_Cb);
      DecodeImageOne_CalcYUV(CrBlk[ofs],_Cr);
      ofs++;
      *VRAMPtr=YUV2RGBTable[((u32)_Cr << 10)+((u32)_Cb << 5)+((u32)_Y << 0)];
      VRAMPtr++;
    }
    VRAMPtr+=-8+(240*1);
  }
  
}

void fp_IntBlockDraw111Half(u16 *DrawPtr)
{
  u16 *VRAMPtr=DrawPtr;
  
  TIntBlock *YBlk=&Y0Block[0];
  TIntBlock *CbBlk=&CbBlock[0];
  TIntBlock *CrBlk=&CrBlock[0];
  
  LoadIntBlock(0,&Y0Block[0]);
  LoadIntBlock(1,&CbBlock[0]);
  LoadIntBlock(2,&CrBlock[0]);
  
  u32 x,y;
  s32 _Y,_Cb,_Cr;
  u32 ofs=0;
  
  for(y=0;y<4;y++){
    for(x=0;x<4;x++){
      DecodeImageOne_CalcYUV(YBlk[ofs],_Y);
      DecodeImageOne_CalcYUV(CbBlk[ofs],_Cb);
      DecodeImageOne_CalcYUV(CrBlk[ofs],_Cr);
      ofs+=2;
      *VRAMPtr=YUV2RGBTable[((u32)_Cr << 10)+((u32)_Cb << 5)+((u32)_Y << 0)];
      VRAMPtr+=1;
    }
    ofs+=8;
    VRAMPtr+=-4+(240*1);
  }
  
}

void fp_IntBlockDraw411(u16 *DrawPtr)
{
  u32 ofsy,ofsc;
  u16 *VRAMPtr;
  
  TIntBlock *YBlk;
  TIntBlock *CbBlk;
  TIntBlock *CrBlk;
  
  LoadIntBlock(0,&Y0Block[0]);
  LoadIntBlock(0,&Y1Block[0]);
  LoadIntBlock(0,&Y2Block[0]);
  LoadIntBlock(0,&Y3Block[0]);
  LoadIntBlock(1,&CbBlock[0]);
  LoadIntBlock(2,&CrBlock[0]);
  
  attrinline void trans411(void)
  {
    u16 *YUVCTable;
    u32 x,y;
    s32 _Y,_Cb,_Cr;
    
    for(y=0;y<4;y++){
      for(x=0;x<4;x++){
        DecodeImageOne_CalcYUV(CbBlk[ofsc],_Cb);
        DecodeImageOne_CalcYUV(CrBlk[ofsc],_Cr);
        ofsc++;
        YUVCTable=&YUV2RGBTable[((u32)_Cr << 10)+((u32)_Cb << 5)+((u32)0 << 0)];
        
        DecodeImageOne_CalcYUV(YBlk[ofsy],_Y);
        ofsy++;
        *VRAMPtr=YUVCTable[(u32)_Y];
        VRAMPtr++;
        
        DecodeImageOne_CalcYUV(YBlk[ofsy],_Y);
        ofsy+=-1+8;
        *VRAMPtr=YUVCTable[(u32)_Y];
        VRAMPtr+=-1+240;
        
        DecodeImageOne_CalcYUV(YBlk[ofsy],_Y);
        ofsy++;
        *VRAMPtr=YUVCTable[(u32)_Y];
        VRAMPtr++;
        
        DecodeImageOne_CalcYUV(YBlk[ofsy],_Y);
        ofsy+=1-8;
        *VRAMPtr=YUVCTable[(u32)_Y];
        VRAMPtr+=1-240;
      }
      ofsc+=-4+(8*1);
      ofsy+=-8+(8*2);
      VRAMPtr+=-8+(240*2);
    }
  }
  
  CbBlk=&CbBlock[0];
  CrBlk=&CrBlock[0];
  
  YBlk=&Y0Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=0+(0*240);
  ofsy=0;
  ofsc=0+(0*8);
  
  trans411();
  
  YBlk=&Y1Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=8+(0*240);
  ofsy=0;
  ofsc=4+(0*8);
  
  trans411();
  
  YBlk=&Y2Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=0+(8*240);
  ofsy=0;
  ofsc=0+(4*8);
  
  trans411();
  
  YBlk=&Y3Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=8+(8*240);
  ofsy=0;
  ofsc=4+(4*8);
  
  trans411();
  
}

void fp_IntBlockDraw411Half(u16 *DrawPtr)
{
  u32 ofsy,ofsc;
  u16 *VRAMPtr;
  
  TIntBlock *YBlk;
  TIntBlock *CbBlk;
  TIntBlock *CrBlk;
  
  LoadIntBlock(0,&Y0Block[0]);
  LoadIntBlock(0,&Y1Block[0]);
  LoadIntBlock(0,&Y2Block[0]);
  LoadIntBlock(0,&Y3Block[0]);
  LoadIntBlock(1,&CbBlock[0]);
  LoadIntBlock(2,&CrBlock[0]);
  
  attrinline void trans411(void)
  {
    u32 x,y;
    s32 _Y,_Cb,_Cr;
    
    for(y=0;y<4;y++){
      for(x=0;x<4;x++){
        DecodeImageOne_CalcYUV(CbBlk[ofsc],_Cb);
        DecodeImageOne_CalcYUV(CrBlk[ofsc],_Cr);
        ofsc++;
        DecodeImageOne_CalcYUV(YBlk[ofsy],_Y);
        ofsy+=2;
        *VRAMPtr=YUV2RGBTable[((u32)_Cr << 10)+((u32)_Cb << 5)+((u32)_Y << 0)];
        VRAMPtr++;
      }
      ofsc+=-4+(8*1);
      ofsy+=-8+(8*2);
      VRAMPtr+=-4+(240*1);
    }
  }
  
  CbBlk=&CbBlock[0];
  CrBlk=&CrBlock[0];
  
  YBlk=&Y0Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=0+(0*240);
  ofsy=0;
  ofsc=0+(0*8);
  
  trans411();
  
  YBlk=&Y1Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=4+(0*240);
  ofsy=0;
  ofsc=4+(0*8);
  
  trans411();
  
  YBlk=&Y2Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=0+(4*240);
  ofsy=0;
  ofsc=0+(4*8);
  
  trans411();
  
  YBlk=&Y3Block[0];
  VRAMPtr=DrawPtr;
  VRAMPtr+=4+(4*240);
  ofsy=0;
  ofsc=4+(4*8);
  
  trans411();
  
}

void fp_IntBlockDraw100(u16 *DrawPtr)
{
  u16 *VRAMPtr=DrawPtr;
  
  TIntBlock *YBlk=&Y0Block[0];
  
  LoadIntBlock(0,&Y0Block[0]);
  
  u32 x,y;
  s32 _Y;
  u32 ofs=0;
  
  u16 *YUVCTable;
  
  YUVCTable=&YUV2RGBTable[((u32)0x10 << 10)+((u32)0x10 << 5)+((u32)0 << 0)];
  
  for(y=0;y<8;y++){
    for(x=0;x<8;x++){
      DecodeImageOne_CalcYUV(YBlk[ofs],_Y);
      ofs++;
      *VRAMPtr=YUVCTable[(u32)_Y];
      VRAMPtr++;
    }
    VRAMPtr+=-8+(240*1);
  }
  
}

void fp_IntBlockDraw100Half(u16 *DrawPtr)
{
  u16 *VRAMPtr=DrawPtr;
  
  TIntBlock *YBlk=&Y0Block[0];
  
  LoadIntBlock(0,&Y0Block[0]);
  
  u32 x,y;
  s32 _Y;
  u32 ofs=0;
  
  u16 *YUVCTable;
  
  YUVCTable=&YUV2RGBTable[((u32)0x10 << 10)+((u32)0x10 << 5)+((u32)0 << 0)];
  
  for(y=0;y<4;y++){
    for(x=0;x<4;x++){
      DecodeImageOne_CalcYUV(YBlk[ofs],_Y);
      ofs+=2;
      *VRAMPtr=YUVCTable[(u32)_Y];
      VRAMPtr++;
    }
    ofs+=8;
    VRAMPtr+=-4+(240*1);
  }
  
}

void fp_DecodeImageOne(u32 MCUCount,u16 *DrawPtr)
{
  if(DelayRestartInterval==0){
    while(CreatedMCUCacheIndex<MCUCount){
      DecodeSkipImageOne(&CreatedMCUCacheIndex);
    }
    }else{
    u32 Limit;
    Limit=(MCUCount/DelayRestartInterval)+1;
    Limit=(Limit*DelayRestartInterval)+10;
    if(Limit>(FlameInfo.MCUCount-1)) Limit=FlameInfo.MCUCount-1;
    while(CreatedMCUCacheIndex<Limit){
      DecodeSkipImageOne(&CreatedMCUCacheIndex);
    }
  }
  
  
/*
  if(LastMCUProcIndex==MCUCount){
    rbsRefreshCurBuf();
    }else{
*/
  {
    TMCUCache *_MCUCache=&MCUCache[MCUCount];
    rbsSetCurPos(_MCUCache->PosBit);
    ScanInfo[0].DCDiff=_MCUCache->DCDiff[0];
    ScanInfo[1].DCDiff=_MCUCache->DCDiff[1];
    ScanInfo[2].DCDiff=_MCUCache->DCDiff[2];
  }
  
  IntBlockDraw(DrawPtr);
  
  MCUCount++;
  CheckSegment(&MCUCount);
  if(CreatedMCUCacheIndex<MCUCount){
    TMCUCache *_MCUCache=&MCUCache[MCUCount];
    rbsGetCurPos(&_MCUCache->PosBit);
    _MCUCache->DCDiff[0]=ScanInfo[0].DCDiff;
    _MCUCache->DCDiff[1]=ScanInfo[1].DCDiff;
    _MCUCache->DCDiff[2]=ScanInfo[2].DCDiff;
    CreatedMCUCacheIndex=MCUCount;
  }
  
  LastMCUProcIndex=MCUCount;
}

void fp_DrawImageFull(u32 BaseX,u32 BaseY)
{
  u32 xcnt,ycnt;
  u32 x,y;
  u32 DrawY;
  u16 *DrawPtr;
  u32 MCUCnt;
  
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  u32 MCUWidthCount=DispInfo.MCUWidthCount;
  u32 MCUHeightCount=DispInfo.MCUHeightCount;
  
  xcnt=BaseX+DispInfo.DrawMCUWidthCount;
  if(xcnt>MCUWidthCount) xcnt=MCUWidthCount;
  
  ycnt=BaseY+DispInfo.DrawMCUHeightCount;
  if(ycnt>MCUHeightCount) ycnt=MCUHeightCount;
  
  DrawY=0;
  MCUCnt=BaseY*MCUWidthCount;
  for(y=BaseY;y<ycnt;y++){
    DrawPtr=&VRAM0[DrawY*240];
    for(x=BaseX;x<xcnt;x++){
      DecodeImageOne(MCUCnt+x,DrawPtr);
      DrawPtr+=MCUWidthSize;
    }
    DrawY+=MCUHeightSize;
    MCUCnt+=MCUWidthCount;
  }
}

void fp_DrawImageOneLine(s32 tagx,s32 tagy)
{
  u32 xcnt,ycnt;
  u32 ofsx,ofsy;
  u32 x,y;
  u32 MCUCnt;
  u16 *DrawPtr;
  
  u32 MCUWidthSize=DispInfo.MCUWidthSize;
  u32 MCUHeightSize=DispInfo.MCUHeightSize;
  u32 MCUWidthCount=DispInfo.MCUWidthCount;
  u32 MCUHeightCount=DispInfo.MCUHeightCount;
  
  if(tagx!=0){
    if(tagx<0){
      ofsx=0;
      }else{
      ofsx=DispInfo.DrawMCUWidthCount-1;
    }
    if((BaseX+ofsx)>=MCUWidthCount) return;
    
    ycnt=BaseY+DispInfo.DrawMCUHeightCount;
    if(ycnt>MCUHeightCount) ycnt=MCUHeightCount;
    
    DrawPtr=&VRAM0[ofsx*MCUWidthSize];
    MCUCnt=(BaseX+ofsx)+(BaseY*MCUWidthCount);
    for(y=BaseY;y<ycnt;y++){
      DecodeImageOne(MCUCnt,DrawPtr);
      DrawPtr+=MCUHeightSize*240;
      MCUCnt+=MCUWidthCount;
    }
  }
  
  if(tagy!=0){
    if(tagy<0){
      ofsy=0;
      }else{
      ofsy=DispInfo.DrawMCUHeightCount-1;
    }
    if((BaseY+ofsy)>=MCUHeightCount) return;
    
    xcnt=BaseX+DispInfo.DrawMCUWidthCount;
    if(xcnt>MCUWidthCount) xcnt=MCUWidthCount;
    
    DrawPtr=&VRAM0[ofsy*MCUHeightSize*240];
    MCUCnt=BaseX+((BaseY+ofsy)*MCUWidthCount);
    for(x=BaseX;x<xcnt;x++){
      DecodeImageOne(MCUCnt,DrawPtr);
      DrawPtr+=MCUWidthSize;
      MCUCnt++;
    }
  }
}
