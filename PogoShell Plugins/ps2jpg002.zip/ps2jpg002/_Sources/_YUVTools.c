
#define CellSize (6)
#define GBX ((228 / 2 / CellSize)*CellSize)
#define GBY ((156 / 2 / CellSize)*CellSize)
#define CellCount ((GBX / CellSize)*(GBY / CellSize))

typedef struct {
  u8 Y,Cr,Cb;
} TYUV;

typedef struct {
  u8 Y0,Y1,Y2,Y3,Cr,Cb;
} TYUV4;

typedef struct {
  s32 Y,Cr,Cb;
} TiYUV;

typedef struct {
  s32 Y0,Y1,Y2,Y3,Cr,Cb;
} TiYUV4;

// -------------------------------------------------------------
// �O���e�[�u��

//extern const u16 _YUVTools_YUV2RGBTable; // Cr5Cb5Y5 -> b5g5r5
extern const u16 _YUVTools_YUV2RGBTable_lz7; // Cr5Cb5Y5 -> b5g5r5

// -------------------------------------------------------------
// �L��ϐ� (EWRAM)

static u16 *YUV2RGBTable=(u16*)(0x02000000); // sizeof(0x8000*16bit)

// -------------------------------------------------------------
// �錾

void InitYUVTable(void);
u16 YUV2RGB(TYUV YUV);

void InitCellToVRAMTable(void);

// -------------------------------------------------------------
// ����

extern void LZ77UnCompWram(void *Srcp, void *Destp);

void InitYUVTable(void)
{
//  MemCopy32DMA3((void*)&_YUVTools_YUV2RGBTable,(void*)&YUV2RGBTable[0],0x8000*2);
  LZ77UnCompWram((void*)&_YUVTools_YUV2RGBTable_lz7,(void*)&YUV2RGBTable[0]);
}

u16 YUV2RGB(TYUV YUV)
{
  u32 idx;
  
  idx=((u32)YUV.Cr << 10)+((u32)YUV.Cb << 5)+((u32)YUV.Y << 0);
  return(YUV2RGBTable[idx]);
}

